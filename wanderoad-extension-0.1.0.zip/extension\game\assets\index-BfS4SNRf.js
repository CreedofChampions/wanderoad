import{C as We,V as lt,M as on,a as Et,b as Fo,R as Ut,B as tl,c as Ht,d as el,F as ia,N as ii,L as be,H as Pi,U as Oi,e as $e,f as et,S as Ke,g as aa,h as Ho,W as jn,i as Se,j as te,k as Vn,O as qe,D as ke,l as ra,A as Do,m as U0,Z as H0,n as W0,o as $0,p as K0,q as sl,r as nl,s as ol,I as ve,t as hs,u as ca,v as q0,Q as la,G as Qe,T as il,w as Ni,x as j0,y as al,z as Hn,E as V0,J as je,K as an,P as rl,X as cl,Y as ll,_ as hl,$ as ul,a0 as dl,a1 as fl,a2 as pl,a3 as ml,a4 as Y0,a5 as Bi,a6 as gl,a7 as vl,a8 as ai,a9 as wl,aa as X0,ab as Ln,ac as bl,ad as xl,ae as yl,af as _l,ag as Tl,ah as Al,ai as Z0,aj as Ml,ak as Sl,al as kl,am as El,an as Rl,ao as zl,ap as J0,aq as Cl,ar as Fa,as as Da,at as Ia,au as Pa,av as Oa,aw as Ll,ax as So,ay as Fl,az as Dl}from"./three-DzKbA3ve.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const o of document.querySelectorAll('link[rel="modulepreload"]'))n(o);new MutationObserver(o=>{for(const i of o)if(i.type==="childList")for(const a of i.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&n(a)}).observe(document,{childList:!0,subtree:!0});function e(o){const i={};return o.integrity&&(i.integrity=o.integrity),o.referrerPolicy&&(i.referrerPolicy=o.referrerPolicy),o.crossOrigin==="use-credentials"?i.credentials="include":o.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function n(o){if(o.ep)return;o.ep=!0;const i=e(o);fetch(o.href,i)}})();const Gi={skyZenith:"#4E80B4",skyUpper:"#7BA9CE",skyMid:"#A8CAE0",skyHorizon:"#E4DAC2",skyHorizonSun:"#FBE2AE",sunGlow:"#FFF1CE",sunDisc:"#FFFAEA",skyAnti:"#C8D4D6",haze:"#A9BCC7",mist:"#D6DDD4",cloudTop:"#FFF8EC",cloudBody:"#F6E7D2",cloudTerm:"#E8CFB4",cloudUnder:"#B7ACC3",cloudCore:"#9791B0",cloudRim:"#FFEFBE",cirrus:"#F3E6D6",gTip:"#C6D46B",gUpper:"#93B84E",gMid:"#6C9A47",gLow:"#436E4F",gBase:"#2B564F",gTrans:"#E9EE7C",gSheen:"#EDF0C8",gDry:"#D9C079",gPatchA:"#87AC4B",gPatchB:"#6C9A56",gPatchC:"#9DBC5E",gPatchD:"#5F8A5A",tLit:"#93B159",tMid:"#6A924F",tShade:"#456A54",tHollow:"#33564F",ridgeNear:"#8FA9A2",ridgeMid:"#9CB0B4",ridgeFar:"#AEBCC9",ridgeFurthest:"#BFC8D4",pathLit:"#C9AD80",pathShade:"#7A664D",rockLit:"#B4A794",rockShade:"#5F5C58",bounce:"#AA9C64",wShallow:"#A5CBBE",wMid:"#5F9CA0",wDeep:"#2F5F6C",wDeepShade:"#274E5C",wSpark:"#FFFCEC",wFoam:"#EEF5EF",wetStone:"#6E7E75",sA:"#CBB99E",sB:"#BDA98C",sC:"#D6C6AA",sD:"#B2A490",sShade:"#6C6355",sDeep:"#585A62",mortar:"#AB9C85",moss:"#6F8C4E",lichen:"#B3BE96",cLit:"#84A94C",cMid:"#5A8148",cShade:"#2F5546",cDeep:"#254A44",cTrans:"#BED063",cVarA:"#98AC43",cVarB:"#6E9440",cVarC:"#A9B65C",trunkLit:"#8E7659",trunkShade:"#4C3F34",roofA:"#B96A4C",roofB:"#A05C46",roofSlate:"#6E7583",thatch:"#BC9E66",wallA:"#EFE4D0",wallB:"#E4D5BA",timber:"#7C5D46",windowGlow:"#FFD98C",tarmacLit:"#8E8B86",tarmacShade:"#4A4C52",tarmacWet:"#5E6670",lineWhite:"#F2EADA",lineYellow:"#E7C87A",gravelLit:"#C3AE8B",gravelShade:"#78684F",kerb:"#CFC5B2",postWood:"#8A7357",postPaint:"#EFE4D0",paintA:"#C8503F",paintB:"#E0B14E",paintC:"#3F6E8C",paintD:"#EFE7D6",paintE:"#4E7F79",paintF:"#2E3440",chrome:"#D7DCE0",glass:"#7FA2B8",tyre:"#2A2A2E",tail:"#E4573F",head:"#FFF3D0",sun:"#FFD79C",ambSky:"#9EC6E6",ambGround:"#AA9C64",shadowTint:"#5C6E9E"},As={};for(const s in Gi)As[s]=new We(Gi[s]).convertSRGBToLinear();const Il=s=>`vec3(${s.r.toFixed(5)},${s.g.toFixed(5)},${s.b.toFixed(5)})`,G={};for(const s in As)G[s]=Il(As[s]);const ge={};for(const s in As)ge[s]=[As[s].r,As[s].g,As[s].b];function Pl(){return`
const vec3 K_SUN        = ${G.sun};
const vec3 K_AMB_SKY    = ${G.ambSky};
const vec3 K_AMB_GND    = ${G.ambGround};
const vec3 K_SHADOW     = ${G.shadowTint};
const vec3 K_HAZE       = ${G.haze};
const vec3 K_MIST       = ${G.mist};
const vec3 K_SKY_ZEN    = ${G.skyZenith};
const vec3 K_SKY_UP     = ${G.skyUpper};
const vec3 K_SKY_MID    = ${G.skyMid};
const vec3 K_SKY_HOR    = ${G.skyHorizon};
const vec3 K_SKY_HORSUN = ${G.skyHorizonSun};
const vec3 K_SKY_ANTI   = ${G.skyAnti};
const vec3 K_SUN_GLOW   = ${G.sunGlow};
const vec3 K_SUN_DISC   = ${G.sunDisc};
const vec3 K_C_TOP      = ${G.cloudTop};
const vec3 K_C_BODY     = ${G.cloudBody};
const vec3 K_C_TERM     = ${G.cloudTerm};
const vec3 K_C_UNDER    = ${G.cloudUnder};
const vec3 K_C_CORE     = ${G.cloudCore};
const vec3 K_C_RIM      = ${G.cloudRim};
const vec3 K_T_LIT      = ${G.tLit};
const vec3 K_T_MID      = ${G.tMid};
const vec3 K_T_SHADE    = ${G.tShade};
const vec3 K_T_HOLLOW   = ${G.tHollow};
const vec3 K_ROCK_LIT   = ${G.rockLit};
const vec3 K_ROCK_SHADE = ${G.rockShade};
const vec3 K_PATH_LIT   = ${G.pathLit};
const vec3 K_PATH_SHADE = ${G.pathShade};
const vec3 K_TAR_LIT    = ${G.tarmacLit};
const vec3 K_TAR_SHADE  = ${G.tarmacShade};
const vec3 K_LINE_W     = ${G.lineWhite};
const vec3 K_LINE_Y     = ${G.lineYellow};
const vec3 K_GRAVEL_LIT = ${G.gravelLit};
const vec3 K_GRAVEL_SHD = ${G.gravelShade};
const vec3 K_W_SHALLOW  = ${G.wShallow};
const vec3 K_W_MID      = ${G.wMid};
const vec3 K_W_DEEP     = ${G.wDeep};
const vec3 K_BOUNCE     = ${G.bounce};
const float SUN_I = 1.38;
`}const us=[{ground:[1,1,1],rock:[1,1,1],foliage:[1,1,1],haze:Gi.haze,hazeMul:1,dryness:0,snow:0,wet:.12},{ground:[1.24,1.1,.72],rock:[1.12,1.05,.92],foliage:[1.14,1.02,.66],haze:"#D6C79E",hazeMul:1.35,dryness:.85,snow:0,wet:.02},{ground:[.82,.9,.98],rock:[.9,.95,1.06],foliage:[.72,.86,.86],haze:"#9FB6CE",hazeMul:.72,dryness:.1,snow:1,wet:.2},{ground:[1.42,1.06,.78],rock:[1.3,1.02,.86],foliage:[1.05,.9,.62],haze:"#E6C7AC",hazeMul:1.6,dryness:1,snow:0,wet:0},{ground:[.88,.96,.9],rock:[.86,.9,.9],foliage:[.84,.96,.86],haze:"#CBD6D2",hazeMul:1.9,dryness:0,snow:0,wet:1}];function ha(){const s=us.length,t=new Float32Array(s*3),e=new Float32Array(s*3),n=new Float32Array(s*3),o=new Float32Array(s*3),i=new Float32Array(s*4);return us.forEach((a,c)=>{t.set(a.ground,c*3),e.set(a.rock,c*3),n.set(a.foliage,c*3);const r=new We(a.haze).convertSRGBToLinear();o.set([r.r,r.g,r.b],c*3),i.set([a.hazeMul,a.dryness,a.snow,a.wet],c*4)}),{ground:t,rock:e,foliage:n,haze:o,scal:i,count:s}}const Ol=`precision highp float;
precision highp int;
uniform mat4 modelMatrix;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform mat4 viewMatrix;
uniform mat3 normalMatrix;
uniform vec3 cameraPosition;
in vec3 position;
`,Nl=`
vec3  SAFE3(vec3 c){ return clamp(mix(vec3(0.0), c, equal(c, c)), vec3(0.0), vec3(64.0)); }
float SAFE1(float x){ return (x == x) ? clamp(x, 0.0, 64.0) : 0.0; }
`,Q0=`precision highp float;
precision highp int;
${Nl}`,Dt=`
float hash11(float p){ p=fract(p*0.1031); p*=p+33.33; p*=p+p; return fract(p); }
float hash12(vec2 p){ vec3 p3=fract(vec3(p.xyx)*0.1031); p3+=dot(p3,p3.yzx+33.33);
  return fract((p3.x+p3.y)*p3.z); }
vec2 hash22(vec2 p){ vec3 p3=fract(vec3(p.xyx)*vec3(0.1031,0.1030,0.0973));
  p3+=dot(p3,p3.yzx+33.33); return fract((p3.xx+p3.yz)*p3.zy); }
vec3 hash32(vec2 p){ vec3 p3=fract(vec3(p.xyx)*vec3(0.1031,0.1030,0.0973));
  p3+=dot(p3,p3.yxz+33.33); return fract((p3.xxy+p3.yzz)*p3.zyx); }
float hash13(vec3 p){ p=fract(p*0.1031); p+=dot(p,p.zyx+31.32); return fract((p.x+p.y)*p.z); }
vec3 hash33(vec3 p){ p=fract(p*vec3(0.1031,0.1030,0.0973)); p+=dot(p,p.yxz+33.33);
  return fract((p.xxy+p.yxx)*p.zyx); }
`,It=`
float vn2(vec2 p){ vec2 i=floor(p), f=fract(p); vec2 u=f*f*f*(f*(f*6.0-15.0)+10.0);
  return mix(mix(hash12(i),hash12(i+vec2(1,0)),u.x),
             mix(hash12(i+vec2(0,1)),hash12(i+vec2(1,1)),u.x),u.y); }
float vn3(vec3 p){ vec3 i=floor(p), f=fract(p); vec3 u=f*f*f*(f*(f*6.0-15.0)+10.0);
  float a=hash13(i+vec3(0,0,0)), b=hash13(i+vec3(1,0,0));
  float c=hash13(i+vec3(0,1,0)), d=hash13(i+vec3(1,1,0));
  float e=hash13(i+vec3(0,0,1)), g=hash13(i+vec3(1,0,1));
  float h=hash13(i+vec3(0,1,1)), k=hash13(i+vec3(1,1,1));
  return mix(mix(mix(a,b,u.x),mix(c,d,u.x),u.y), mix(mix(e,g,u.x),mix(h,k,u.x),u.y), u.z); }
vec2 grad2(vec2 i){ float a=hash12(i)*6.2831853; return vec2(cos(a),sin(a)); }
float pn2(vec2 p){ vec2 i=floor(p), f=fract(p); vec2 u=f*f*f*(f*(f*6.0-15.0)+10.0);
  float a=dot(grad2(i),f), b=dot(grad2(i+vec2(1,0)),f-vec2(1,0));
  float c=dot(grad2(i+vec2(0,1)),f-vec2(0,1)), d=dot(grad2(i+vec2(1,1)),f-vec2(1,1));
  return mix(mix(a,b,u.x),mix(c,d,u.x),u.y)*1.42; }
vec3 grad3(vec3 i){ return normalize(hash33(i)*2.0-1.0); }
float pn3(vec3 p){ vec3 i=floor(p), f=fract(p); vec3 u=f*f*f*(f*(f*6.0-15.0)+10.0);
  float n000=dot(grad3(i+vec3(0,0,0)),f-vec3(0,0,0));
  float n100=dot(grad3(i+vec3(1,0,0)),f-vec3(1,0,0));
  float n010=dot(grad3(i+vec3(0,1,0)),f-vec3(0,1,0));
  float n110=dot(grad3(i+vec3(1,1,0)),f-vec3(1,1,0));
  float n001=dot(grad3(i+vec3(0,0,1)),f-vec3(0,0,1));
  float n101=dot(grad3(i+vec3(1,0,1)),f-vec3(1,0,1));
  float n011=dot(grad3(i+vec3(0,1,1)),f-vec3(0,1,1));
  float n111=dot(grad3(i+vec3(1,1,1)),f-vec3(1,1,1));
  return mix(mix(mix(n000,n100,u.x),mix(n010,n110,u.x),u.y),
             mix(mix(n001,n101,u.x),mix(n011,n111,u.x),u.y),u.z)*1.35; }
float fbm2(vec2 p, int oct){ float a=0.5,s=0.0,n=0.0;
  for(int i=0;i<8;i++){ if(i>=oct)break; s+=a*pn2(p); n+=a; p*=2.02; p+=vec2(3.1,1.7); a*=0.5; }
  return s/n; }
float fbm3(vec3 p, int oct){ float a=0.5,s=0.0,n=0.0;
  for(int i=0;i<6;i++){ if(i>=oct)break; s+=a*pn3(p); n+=a; p*=2.03; p+=vec3(2.7,1.3,4.1); a*=0.5; }
  return s/n; }
`,ua=`
uniform float uTime;
uniform vec3  uSunDir;        // world -> sun, normalised
uniform vec3  uCamPos;
uniform vec2  uWindOrigin;    // centre of the wind render target, world xz
uniform vec2  uCloudDrift;
uniform sampler2D uWindTex;
// The pen's uHeight / uSplat / uMeadow samplers are gone: they were bakes of one fixed
// valley into fixed-size textures, which is exactly the assumption an infinite world
// cannot make. Height, splat and tussock hue now arrive as per-vertex attributes from the
// chunk mesher instead, so they stream with the terrain and cost no texture units.
uniform sampler2D uShadowMap;
uniform sampler2D uCloudSh;   // baked cloud-shadow coverage
uniform vec2  uCloudShOrigin;
uniform vec2  uShadowC;      // centre of the sun shadow map, world xz
uniform vec4  uCull;         // xy = view direction on the ground, z = cos(half angle)
uniform vec2  uWindLag;      // mean wind direction x the response-lag distance
uniform mat4  uLightMat;
uniform float uShadowTexel;
uniform float uCloudAmount;
uniform float uFogMul;
uniform float uFogNear;      // metres before aerial perspective starts
uniform float uFogFar;       // metres to full haze
// There is deliberately no uChunkOrigin. Chunk vertices are local to their node and the
// node's world position rides in three's own modelMatrix, so one material with one uniform
// set draws every chunk in the world. Global precision is handled by rebasing the whole
// scene graph (see render/origin.js), not by a per-draw offset uniform.
`,Wo=`
vec3 skyDome(vec3 d, out float sunMask){
  float y  = d.y;
  float yy = max(y, -0.18);
  // four-stop vertical wash
  vec3 col = mix(K_SKY_HOR, K_SKY_MID, smoothstep(-0.02, 0.13, yy));
  col = mix(col, K_SKY_UP,  smoothstep(0.10, 0.36, yy));
  col = mix(col, K_SKY_ZEN, smoothstep(0.32, 0.86, yy));

  // azimuthal asymmetry: warm toward the sun, cool away from it
  vec2 dh = normalize(d.xz + vec2(1e-5));
  vec2 sh = normalize(uSunDir.xz + vec2(1e-5));
  float az = dot(dh, sh) * 0.5 + 0.5;
  float horiz = pow(1.0 - clamp(yy, 0.0, 1.0), 3.4);
  col = mix(col, K_SKY_ANTI,    horiz * (1.0-az) * 0.62);
  col = mix(col, K_SKY_HORSUN,  horiz * pow(az, 2.1) * 0.92);

  // Mie forward-scatter halo
  float ang = dot(d, uSunDir);
  float halo = pow(max(ang, 0.0), 7.0);
  float wide = pow(max(ang, 0.0), 1.9);
  col = mix(col, K_SUN_GLOW, clamp(halo*0.72 + wide*0.16, 0.0, 0.9));

  // sun disc (painted 3x oversize, never blown out)
  sunMask = smoothstep(0.99977, 0.99992, ang);
  col = mix(col, K_SUN_DISC*1.9, sunMask);

  // thin cirrus streaks, sheared by the upper wind
  float cd = smoothstep(0.035, 0.30, yy);
  if(cd > 0.001){
    vec2 sp = d.xz / max(y, 0.05) * 0.0016;
    sp += uCloudDrift * 0.00022;
    vec2 w = vec2(fbm2(sp*2.1+vec2(7.3,2.1),3), fbm2(sp*2.1+vec2(1.9,9.4),3));
    float ci = fbm2(vec2(sp.x*0.55, sp.y*3.4) + w*0.6, 4);
    ci = smoothstep(0.10, 0.44, ci) * cd * (0.30 + 0.5*pow(max(ang,0.0),1.4));
    col = mix(col, ${G.cirrus}*(0.92+0.55*pow(max(ang,0.0),3.0)), ci*0.55*uCloudAmount);
  }
  return col;
}
vec3 skyDome(vec3 d){ float s; return skyDome(d, s); }

// The same wash without the sun disc and without the warped cirrus fbm.  A
// reflection in moving water resolves none of that detail — it just costs ten
// octaves of noise per pixel of river and comes back as sparkle.
vec3 skyDomeLite(vec3 d){
  float yy = max(d.y, -0.18);
  vec3 col = mix(K_SKY_HOR, K_SKY_MID, smoothstep(-0.02, 0.13, yy));
  col = mix(col, K_SKY_UP,  smoothstep(0.10, 0.36, yy));
  col = mix(col, K_SKY_ZEN, smoothstep(0.32, 0.86, yy));
  vec2 dh = normalize(d.xz + vec2(1e-5));
  vec2 sh = normalize(uSunDir.xz + vec2(1e-5));
  float az = dot(dh, sh)*0.5 + 0.5;
  float horiz = pow(1.0 - clamp(yy, 0.0, 1.0), 3.4);
  col = mix(col, K_SKY_ANTI,   horiz*(1.0-az)*0.62);
  col = mix(col, K_SKY_HORSUN, horiz*pow(az, 2.1)*0.92);
  float ang = max(dot(d, uSunDir), 0.0);
  col = mix(col, K_SUN_GLOW, clamp(pow(ang,7.0)*0.72 + pow(ang,1.9)*0.16, 0.0, 0.9));
  return col;
}
`;function fs({cshSpan:s=4600,cloudDeck:t=980}={}){return`
// The analytic coverage field.  Thirteen octaves of warped fbm — beautiful,
// and far too expensive to evaluate once per fragment of a full screen.  It is
// therefore evaluated ONCE PER FRAME into a 512² map (see CLOUDSH_FS) that is
// centred on where the cloud deck projects along the sun vector; every surface
// in the valley then reads its cloud shadow with a single texture fetch.  The
// field's finest feature is ~95 m across and the map is 9 m/texel, so the baked
// version is indistinguishable from the live one.
float cloudField(vec2 q){
  vec2 p = (q - uCloudDrift) * 0.00071;
  vec2 w = vec2(fbm2(p*1.55+vec2(11.3,4.7),3), fbm2(p*1.55+vec2(37.1,19.2),3));
  float f = fbm2(p + w*0.62, 4);
  float g = fbm2(p*3.7 + w*1.1, 3);
  f = f*0.78 + g*0.22;
  return clamp(smoothstep(-0.035, 0.30, f) * uCloudAmount, 0.0, 1.0);
}
const float CSH_SPAN = ${s.toFixed(1)};
vec2 cloudShadowUV(vec3 wp){
  float t = (${t.toFixed(1)} - wp.y) / max(uSunDir.y, 0.06);
  vec2 q = wp.xz + uSunDir.xz * t;
  return (q - uCloudShOrigin) / CSH_SPAN + 0.5;
}
float cloudShadow(vec3 wp){
  vec2 uv = cloudShadowUV(wp);
  float c = texture(uCloudSh, clamp(uv, vec2(0.0015), vec2(0.9985))).r;
  return 1.0 - 0.64 * c;
}
`}const Cs=`
// four taps, no painterly wobble — for surfaces too small to show the edge
float sunShadowFast(vec3 wp, float ndl){
  vec4 lp = uLightMat * vec4(wp, 1.0);
  vec3 pc = lp.xyz / lp.w * 0.5 + 0.5;
  if(pc.z > 0.9995) return 1.0;
  vec2 e = abs(pc.xy - 0.5);
  float fade = 1.0 - smoothstep(0.40, 0.497, max(e.x, e.y));
  if(fade <= 0.001) return 1.0;
  float bias = mix(0.0026, 0.0006, clamp(ndl,0.0,1.0));
  float s = 0.0;
  s += step(pc.z-bias, texture(uShadowMap, pc.xy + vec2( 1.0, 1.0)*uShadowTexel).r);
  s += step(pc.z-bias, texture(uShadowMap, pc.xy + vec2(-1.0, 1.0)*uShadowTexel).r);
  s += step(pc.z-bias, texture(uShadowMap, pc.xy + vec2( 1.0,-1.0)*uShadowTexel).r);
  s += step(pc.z-bias, texture(uShadowMap, pc.xy + vec2(-1.0,-1.0)*uShadowTexel).r);
  return mix(1.0, s*0.25, fade);
}
float sunShadow(vec3 wp, float ndl){
  vec4 lp = uLightMat * vec4(wp, 1.0);
  vec3 pc = lp.xyz / lp.w;
  pc = pc * 0.5 + 0.5;
  if(pc.z > 0.9995) return 1.0;
  vec2 e = abs(pc.xy - 0.5);
  float fade = 1.0 - smoothstep(0.40, 0.497, max(e.x, e.y));
  if(fade <= 0.001) return 1.0;
  float bias = mix(0.0022, 0.00045, clamp(ndl,0.0,1.0));
  // Painterly wobble: the shadow edge is DRAWN, not filtered — the noise offset
  // is what gives the edge its brush character, and it is specified in metres
  // so it stays the same shape whatever the map's span or resolution.  Because
  // the wobble dominates the silhouette, five taps in a cross read the same as
  // the old nine in a box, on every lit fragment in the valley.
  float j0 = vn2(wp.xz*2.7) - 0.5;
  float j1 = vn2(wp.zx*8.3 + 9.7) - 0.5;
  vec2 jo = vec2(j0*2.0 + j1*0.9, j1*1.6 - j0*0.7) * 0.00070833;
  float r = uShadowTexel*1.7;
  float s = step(pc.z - bias, texture(uShadowMap, pc.xy + jo).r);
  s += step(pc.z - bias, texture(uShadowMap, pc.xy + jo + vec2( r, r)).r);
  s += step(pc.z - bias, texture(uShadowMap, pc.xy + jo + vec2(-r, r)).r);
  s += step(pc.z - bias, texture(uShadowMap, pc.xy + jo + vec2( r,-r)).r);
  s += step(pc.z - bias, texture(uShadowMap, pc.xy + jo + vec2(-r,-r)).r);
  return mix(1.0, s*0.2, fade);
}
`,ps=`
// three-colour hue-path ramp; transitions are soft but visibly banded
vec3 ramp3(float t, vec3 shade, vec3 mid, vec3 lit, float soft, float jit){
  float a = smoothstep(0.17 - soft + jit, 0.17 + soft + jit, t);
  float b = smoothstep(0.58 - soft + jit, 0.58 + soft + jit, t);
  return mix(mix(shade, mid, a), lit, b);
}
struct Surf {
  vec3 N; vec3 V; vec3 P;     // normal, surface->eye, world pos
  vec3 shade; vec3 mid; vec3 lit;
  float soft;                 // band softness
  float jit;                  // painterly wobble of the band edges
  float shadow;               // 0 shadowed .. 1 lit
  float trans;                // translucency thickness 0..1
  vec3  transCol;
  float rim; float ao; float ambient;
};
vec3 paint(Surf s){
  float ndl  = dot(s.N, uSunDir);
  // Half-lambert. A 13.5° sun grazes flat ground at ndl≈0.23; plain Lambert
  // would drop the whole valley floor into the shade band and golden hour
  // would read as dusk.
  float wrap = clamp(ndl*0.62 + 0.46, 0.0, 1.0);
  float jit  = s.jit;
  float t    = wrap * mix(0.34, 1.0, s.shadow);
  vec3  col  = ramp3(t, s.shade, s.mid, s.lit, s.soft, jit);

  float litAmt = smoothstep(0.34, 0.86, t);
  col *= mix(vec3(0.94), K_SUN * 1.32, litAmt * 0.62);

  // shadows change hue, they do not go black
  col = mix(col*0.80 + K_SHADOW*0.040, col, s.shadow*0.82 + 0.18);

  // Hemispheric ambient TINTS rather than washes: normalised to unit luminance
  // so it can rotate hue (cool from the sky, warm from the ground bounce)
  // without ever bleaching the palette.
  vec3 hemi = mix(K_AMB_GND, K_AMB_SKY, s.N.y*0.5 + 0.5);
  vec3 hueOnly = hemi / max(dot(hemi, vec3(0.2126,0.7152,0.0722)), 1e-3);
  col *= mix(vec3(1.0), hueOnly, 0.22 * s.ambient * (1.0 - litAmt*0.55));
  col += hemi * 0.052 * s.ambient * s.ao * (1.0 - litAmt*0.85);

  // backlight rim — the connective tissue of the whole image
  float back = smoothstep(0.05, 0.85, dot(s.V, -uSunDir));
  float fres = pow(1.0 - clamp(dot(s.N, s.V), 0.0, 1.0), 4.2);
  col += K_SUN * (fres * back * s.rim * 1.15 * s.shadow);

  // subsurface transmission (grass, leaves, smoke)
  if(s.trans > 0.001){
    // light coming THROUGH the blade, not bouncing off it: only the part of
    // the surface that is nearly edge-on to the sun actually transmits
    float tr = pow(clamp(dot(s.V, -uSunDir), 0.0, 1.0), 3.2);
    float thin = pow(clamp(1.0 - abs(dot(s.N, uSunDir)), 0.0, 1.0), 2.2);
    col += s.transCol * tr * thin * s.trans * s.shadow * 0.52;
  }
  col *= s.ao;
  return col;
}

// ── aerial perspective ──────────────────────────────────────────────────────
float gFogAmt = 0.0;   // written by aerial(), read back as the alpha channel so
                       // the post chain knows how far away each pixel is
// uFogNear / uFogFar replace the pen's baked CFG.fogNear=70 / CFG.fogFar=1700. That valley
// was 2 km across and 1700 m of visibility was generous; a car doing 90 m/s down a steppe
// arterial needs to see the next ridge, so the game drives these from the camera's far
// plane and softens them per biome (dunes haze up, highlands clear).
vec3 aerial(vec3 col, float dist, vec3 V, float worldY){
  dist = (dist == dist) ? min(dist, 1.0e6) : 1.0e6;   // a NaN depth must not
  float d  = max(dist - uFogNear, 0.0);   // poison the colour
  float hf = mix(1.0, exp(-max(worldY - 6.0, 0.0)/260.0), 0.72);
  float f  = 1.0 - exp(-pow(d / uFogFar, 1.28) * 3.1 * hf * uFogMul);
  float mie = pow(clamp(dot(-V, uSunDir), 0.0, 1.0), 3.4);
  vec3 fc = mix(K_HAZE, K_SKY_HORSUN, mie*0.88);
  fc = mix(fc, K_SKY_ANTI, clamp(dot(-V,uSunDir),-1.0,0.0)*-0.32);
  // mist pooling in the valley floor
  float pool = smoothstep(46.0, 8.0, worldY) * smoothstep(120.0, 420.0, dist);
  fc = mix(fc, K_MIST, pool*0.45);
  f  = clamp(f + pool*0.16, 0.0, 1.0);
  gFogAmt = f;
  return mix(col, fc, f);
}
`,da=`
precision mediump float;
out vec4 o;
void main(){ o = vec4(1.0); }`;function ce(...s){return Q0+ua+Pl()+s.join("")}function Kt(...s){return Ol+ua+s.join("")}const Bl=13.5,Gl=118;function Ul(s=Bl,t=Gl){const e=s*Math.PI/180,n=t*Math.PI/180;return new lt(Math.sin(n)*Math.cos(e),Math.sin(e),Math.cos(n)*Math.cos(e)).normalize()}const pt={uTime:{value:0},uSunDir:{value:Ul()},uCamPos:{value:new lt},uWindOrigin:{value:new Et},uCloudDrift:{value:new Et},uWindTex:{value:null},uShadowMap:{value:null},uCloudSh:{value:null},uCloudShOrigin:{value:new Et},uShadowC:{value:new Et},uCull:{value:new Fo(0,0,-1,0)},uWindLag:{value:new Et},uLightMat:{value:new on},uShadowTexel:{value:1/2048},uCloudAmount:{value:.62},uFogMul:{value:1},uFogNear:{value:140},uFogFar:{value:4200}};function Zt(s={}){const t={};for(const e in pt)t[e]=pt[e];for(const e in s)t[e]=s[e];return t}const Hl=`
out vec3 vDir;
void main(){
  vDir = position;
  // Translation only: the sky must rotate with the camera but never move relative to it,
  // and the w-trick pins it to the far plane so it can never poke through terrain.
  mat4 v = viewMatrix;
  v[3].xyz = vec3(0.0);
  vec4 p = projectionMatrix * v * vec4(position, 1.0);
  gl_Position = p.xyww;
}
`,Wl=`
in vec3 vDir;
out vec4 fragColor;
void main(){
  vec3 d = normalize(vDir);
  float sunMask;
  vec3 col = skyDome(d, sunMask);
  // Alpha carries "how far away" for the post chain; the sky is as far as it gets.
  fragColor = vec4(SAFE3(col), 1.0);
}
`;function $l(){const s=new Ut({glslVersion:"300 es",uniforms:Zt(),vertexShader:Kt(Hl),fragmentShader:ce(Dt,It,Wo,Wl),side:tl,depthWrite:!1,depthTest:!1}),t=new Ht(new el(2,2,2),s);return t.frustumCulled=!1,t.renderOrder=-1e3,t.name="sky",t}const Os=ha();function Kl(){const s=(e,n,o)=>{const i=[];for(let a=0;a<n;a++){const c=[];for(let r=0;r<o;r++)c.push(e[a*o+r].toFixed(4));i.push(`vec${o}(${c.join(",")})`)}return i.join(`,
  `)},t=Os.count;return`
const int NBIOME = ${t};
const vec3 B_GROUND[${t}] = vec3[${t}](
  ${s(Os.ground,t,3)}
);
const vec3 B_ROCK[${t}] = vec3[${t}](
  ${s(Os.rock,t,3)}
);
const vec3 B_FOLIAGE[${t}] = vec3[${t}](
  ${s(Os.foliage,t,3)}
);
const vec3 B_HAZE[${t}] = vec3[${t}](
  ${s(Os.haze,t,3)}
);
// x hazeMul, y dryness, z snow, w wet
const vec4 B_SCAL[${t}] = vec4[${t}](
  ${s(Os.scal,t,4)}
);
`}const ql=`
in vec3 normal;
in vec4 aBiome;   // weights 0..3, the fifth is 1 - sum
in vec2 aRoad;    // x = carve mask, y = carriageway

out vec3 vWorld;
out vec3 vNormal;
out vec4 vBiome;
out vec2 vRoad;
out float vDist;

void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld  = wp.xyz;
  vNormal = normalize(mat3(modelMatrix) * normal);
  vBiome  = aBiome;
  vRoad   = aRoad;
  vDist   = length(wp.xyz - uCamPos);
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`,jl=`
in vec3 vWorld;
in vec3 vNormal;
in vec4 vBiome;
in vec2 vRoad;
in float vDist;
out vec4 fragColor;

// The five weights, renormalised. The mesher stores four and lets the fifth fall out of
// the sum, which saves a byte per vertex and guarantees they add to one after
// interpolation — a genuine partition, so no fragment is ever "no biome".
void weights(out float w[NBIOME]){
  float a = vBiome.x, b = vBiome.y, c = vBiome.z, d = vBiome.w;
  float e = max(1.0 - (a+b+c+d), 0.0);
  float s = max(a+b+c+d+e, 1e-4);
  w[0]=a/s; w[1]=b/s; w[2]=c/s; w[3]=d/s; w[4]=e/s;
}

void main(){
  float w[NBIOME];
  weights(w);

  vec3 tintG = vec3(0.0), tintR = vec3(0.0), haze = vec3(0.0);
  vec4 scal = vec4(0.0);
  for(int i=0;i<NBIOME;i++){
    tintG += B_GROUND[i]  * w[i];
    tintR += B_ROCK[i]    * w[i];
    haze  += B_HAZE[i]    * w[i];
    scal  += B_SCAL[i]    * w[i];
  }

  vec3 N = normalize(vNormal);
  vec3 V = normalize(uCamPos - vWorld);
  float slope = 1.0 - clamp(N.y, 0.0, 1.0);

  // ── ground colour ─────────────────────────────────────────────────────────
  // Two large-scale noise fields break the flatness: one picks between the four ground
  // stops, the other is a fine grain that survives to the horizon and stops distant
  // hillsides reading as vinyl.
  float blot = fbm2(vWorld.xz * 0.0042, 4) * 0.5 + 0.5;
  float grain = pn2(vWorld.xz * 0.16) * 0.5 + 0.5;

  vec3 lit   = mix(K_T_LIT,   K_T_MID,    blot * 0.55);
  vec3 mid   = mix(K_T_MID,   K_T_SHADE,  blot * 0.40);
  vec3 shade = mix(K_T_SHADE, K_T_HOLLOW, blot * 0.62);

  // Dryness bleaches the greens towards straw. It is a hue rotation, not a desaturation:
  // dead grass is yellow, not grey.
  vec3 dry = vec3(0.86, 0.76, 0.42);
  lit   = mix(lit,   lit   * dry * 1.45, scal.y);
  mid   = mix(mid,   mid   * dry * 1.32, scal.y);
  shade = mix(shade, shade * dry * 1.18, scal.y);

  lit *= tintG; mid *= tintG; shade *= tintG;

  // ── rock on the steep parts ───────────────────────────────────────────────
  float rockAmt = smoothstep(0.36, 0.66, slope) * (0.55 + 0.45*grain);
  vec3 rLit = K_ROCK_LIT * tintR, rShd = K_ROCK_SHADE * tintR;
  lit   = mix(lit,   rLit,          rockAmt);
  mid   = mix(mid,   mix(rLit,rShd,0.5), rockAmt);
  shade = mix(shade, rShd,          rockAmt);

  // ── snow above the line, only on ground the snow could sit on ─────────────
  float snowLine = smoothstep(120.0, 240.0, vWorld.y) * scal.z;
  float snowHold = smoothstep(0.55, 0.16, slope);
  float snow = clamp(snowLine * snowHold * (0.6 + 0.5*grain), 0.0, 1.0);
  lit   = mix(lit,   vec3(0.95,0.96,0.99), snow);
  mid   = mix(mid,   vec3(0.80,0.85,0.94), snow);
  shade = mix(shade, vec3(0.58,0.66,0.82), snow);

  // ── the road ──────────────────────────────────────────────────────────────
  float onRoad = vRoad.y;
  if(onRoad > 0.003){
    // Surface kind comes from the biome mix: tarmac in the green world, gravel in the
    // steppe, sand in the dunes. Blended, so a road entering a desert visibly silts up.
    float sandy   = w[3];
    float gravely = w[1];
    vec3 tLit = K_TAR_LIT,  tShd = K_TAR_SHADE;
    tLit = mix(tLit, K_GRAVEL_LIT, gravely*0.85);
    tShd = mix(tShd, K_GRAVEL_SHD, gravely*0.85);
    tLit = mix(tLit, K_T_LIT*1.35*dry, sandy*0.9);
    tShd = mix(tShd, K_T_MID*1.05*dry, sandy*0.9);

    // Wear: two long streaks where the wheels run, and a rough grain everywhere.
    float wear = pn2(vWorld.xz * vec2(0.9, 0.11)) * 0.5 + 0.5;
    float chip = vn2(vWorld.xz * 3.1);
    vec3 rl = mix(tLit, tLit*1.10, wear) * mix(0.94, 1.06, chip);
    vec3 rs = mix(tShd, tShd*0.92, wear);

    lit   = mix(lit,   rl,               onRoad);
    mid   = mix(mid,   mix(rl,rs,0.55),  onRoad);
    shade = mix(shade, rs,               onRoad);
  }

  // ── shading ───────────────────────────────────────────────────────────────
  float ndl = dot(N, uSunDir);
  float sh  = sunShadow(vWorld, ndl) * cloudShadow(vWorld);

  Surf s;
  s.N = N; s.V = V; s.P = vWorld;
  s.shade = shade; s.mid = mid; s.lit = lit;
  s.soft  = mix(0.16, 0.34, clamp(vDist/900.0, 0.0, 1.0));
  s.jit   = (vn2(vWorld.xz * 0.55) - 0.5) * 0.09;
  s.shadow = sh;
  s.trans = 0.0; s.transCol = vec3(0.0);
  s.rim   = mix(0.30, 0.10, onRoad);
  s.ao    = 1.0;
  s.ambient = 1.0;

  vec3 col = paint(s);

  // Standing water in the wetland: a dark wet sheen under the fog, not a mirror. The real
  // water surface is a separate mesh; this is the mud it sits on.
  col = mix(col, col*0.62 + K_W_DEEP*0.10, scal.w * smoothstep(6.0, 0.5, vWorld.y) * 0.7);

  // Biome haze colour feeds the shared aerial term.
  col = aerial(col, vDist, V, vWorld.y);
  col = mix(col, mix(col, haze, 0.55), clamp(scal.x - 1.0, 0.0, 1.2) * gFogAmt * 0.6);

  fragColor = vec4(SAFE3(col), gFogAmt);
}
`;function Vl(){const s=fs({cshSpan:9200,cloudDeck:980});return new Ut({glslVersion:"300 es",uniforms:Zt(),vertexShader:Kt(ql),fragmentShader:ce(Dt,It,Kl(),Wo,s,Cs,ps,jl),side:ia})}const Yl=5,Xl=1.02,Zl=.75,Na=.62,Jl=1.4,Ba=.85,Ql=.38,th=.36,eh=.44,Ga=.1,sh=.14,nh=.06,oh=`
in vec2 uv;
out vec2 vUv;
void main(){
  // One oversized triangle, not two triangles: no diagonal seam for the FXAA pass to find
  // and one less vertex-shader invocation per full-screen pass.
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`,ih=`
uniform sampler2D uSrc; uniform float uThresh; uniform float uSoft;
in vec2 vUv; out vec4 outColor;
void main(){
  // the NaN firewall lives here too: one bad texel entering the bloom pyramid gets
  // smeared over a whole neighbourhood by the downsample chain
  vec3 c = SAFE3(texture(uSrc, vUv).rgb);
  float l = dot(c, vec3(0.2126,0.7152,0.0722));
  float k = smoothstep(uThresh, uThresh+uSoft, l);
  outColor = vec4(c*k, 1.0);
}`,Ua=`
uniform sampler2D uSrc; uniform vec2 uTexel;
in vec2 vUv; out vec4 outColor;
void main(){
  vec2 t=uTexel;
  vec3 a=texture(uSrc,vUv+t*vec2(-2,-2)).rgb, b=texture(uSrc,vUv+t*vec2(0,-2)).rgb, c=texture(uSrc,vUv+t*vec2(2,-2)).rgb;
  vec3 d=texture(uSrc,vUv+t*vec2(-2, 0)).rgb, e=texture(uSrc,vUv).rgb,               f=texture(uSrc,vUv+t*vec2(2, 0)).rgb;
  vec3 g=texture(uSrc,vUv+t*vec2(-2, 2)).rgb, h=texture(uSrc,vUv+t*vec2(0, 2)).rgb, i=texture(uSrc,vUv+t*vec2(2, 2)).rgb;
  vec3 j=texture(uSrc,vUv+t*vec2(-1,-1)).rgb, k=texture(uSrc,vUv+t*vec2(1,-1)).rgb;
  vec3 l=texture(uSrc,vUv+t*vec2(-1, 1)).rgb, m=texture(uSrc,vUv+t*vec2(1, 1)).rgb;
  vec3 o = e*0.125 + (a+c+g+i)*0.03125 + (b+d+f+h)*0.0625 + (j+k+l+m)*0.125;
  outColor = vec4(o,1.0);
}`,ah=`
uniform sampler2D uSrc; uniform sampler2D uPrev; uniform vec2 uTexel; uniform float uRadius;
in vec2 vUv; out vec4 outColor;
void main(){
  vec2 t=uTexel*uRadius;
  vec3 s = texture(uSrc,vUv+t*vec2(-1,-1)).rgb*1.0 + texture(uSrc,vUv+t*vec2(0,-1)).rgb*2.0
         + texture(uSrc,vUv+t*vec2( 1,-1)).rgb*1.0 + texture(uSrc,vUv+t*vec2(-1,0)).rgb*2.0
         + texture(uSrc,vUv).rgb*4.0                + texture(uSrc,vUv+t*vec2( 1,0)).rgb*2.0
         + texture(uSrc,vUv+t*vec2(-1, 1)).rgb*1.0 + texture(uSrc,vUv+t*vec2(0, 1)).rgb*2.0
         + texture(uSrc,vUv+t*vec2( 1, 1)).rgb*1.0;
  outColor = vec4(texture(uPrev,vUv).rgb + s/16.0, 1.0);
}`,rh=`
uniform sampler2D uSrc; uniform vec2 uTexel; uniform vec2 uDir;
in vec2 vUv; out vec4 outColor;
void main(){
  vec2 d = uTexel*uDir;
  vec3 c = texture(uSrc,vUv).rgb*0.227;
  c += (texture(uSrc,vUv+d*1.3846).rgb + texture(uSrc,vUv-d*1.3846).rgb)*0.316;
  c += (texture(uSrc,vUv+d*3.2308).rgb + texture(uSrc,vUv-d*3.2308).rgb)*0.070;
  outColor = vec4(c,1.0);
}`,ch=`
uniform sampler2D uScene, uBloom, uSoft;
uniform vec2  uRes;
uniform float uExposure, uBloomAmt, uPaint, uCA, uVignette, uGrain;
uniform float uRadial, uVigSpeed, uCALimit;
in vec2 vUv; out vec4 outColor;

/*  Luma FXAA.  A million-blade meadow is the worst possible case for spatial
    aliasing, which is why the scene used to be brute-force supersampled at
    1.3x.  Resolving the edges here instead buys back 1.45x of the entire
    fragment budget — every shaded pixel in the frame — for five extra taps in
    one full-screen pass.  Blades are already floored to ~1 px wide by the grass
    shader, so there is nothing thinner than a pixel for it to smear.         */
// The buffer is linear HDR, where a sunlit blade can sit at 1.5 and a shaded
// one at 0.03.  Thresholding raw linear luma makes FXAA fire almost nowhere in
// the light and everywhere in the dark; folding it through the same Reinhard
// shape the eye will see puts every threshold back in the range the algorithm
// was designed for, which is the difference between it working on grass and not.
float fxLuma(vec3 c){ c = c/(c + vec3(1.0)); return dot(c, vec3(0.2126,0.7152,0.0722)); }
vec3 fxaa(sampler2D tex, vec2 uv, vec2 rcp, vec3 mC){
  float lNW = fxLuma(texture(tex, uv + vec2(-1.0,-1.0)*rcp).rgb);
  float lNE = fxLuma(texture(tex, uv + vec2( 1.0,-1.0)*rcp).rgb);
  float lSW = fxLuma(texture(tex, uv + vec2(-1.0, 1.0)*rcp).rgb);
  float lSE = fxLuma(texture(tex, uv + vec2( 1.0, 1.0)*rcp).rgb);
  float lM  = fxLuma(mC);
  float lMin = min(lM, min(min(lNW,lNE), min(lSW,lSE)));
  float lMax = max(lM, max(max(lNW,lNE), max(lSW,lSE)));
  if(lMax - lMin < max(0.016, lMax*0.055)) return mC;   // flat: leave it alone
  vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), ((lNW + lSW) - (lNE + lSE)));
  float red = max((lNW+lNE+lSW+lSE)*0.0156, 0.0039);
  float rcpDir = 1.0 / (min(abs(dir.x), abs(dir.y)) + red);
  dir = clamp(dir*rcpDir, vec2(-6.0), vec2(6.0)) * rcp;
  vec3 a = 0.5*(texture(tex, uv + dir*(1.0/3.0 - 0.5)).rgb
              + texture(tex, uv + dir*(2.0/3.0 - 0.5)).rgb);
  vec3 b = a*0.5 + 0.25*(texture(tex, uv - dir*0.5).rgb + texture(tex, uv + dir*0.5).rgb);
  float lB = fxLuma(b);
  return (lB < lMin || lB > lMax) ? a : b;
}

vec3 tonemap(vec3 x){
  x = max(x, vec3(0.0));
  vec3 a = x*(x*0.36 + 0.42);
  vec3 b = x*(x*0.34 + 0.66) + 0.11;
  return clamp(a/b, 0.0, 1.0);
}
float luma(vec3 c){ return dot(c, vec3(0.2126,0.7152,0.0722)); }
vec3 toSRGB(vec3 c){
  return mix(c*12.92, 1.055*pow(max(c,vec3(1e-5)), vec3(1.0/2.4))-0.055, step(0.0031308, c));
}

// Speed streak. Six taps between the pixel and the vanishing point, spanning 3.5% of the
// radius vector — ~38 px at the corner of a 1080p frame, ~0 in the middle of it.
const int   RB_TAPS = 6;
const float RB_SPAN = 0.035;

void main(){
  vec2 uv = vUv;
  vec2 d  = uv - 0.5;
  float r2 = dot(d,d);

  // ── edge resolve, then a whisper of chromatic aberration at the rim ────
  // the centre texel was being fetched four separate times — by FXAA, twice by
  // the aberration and once for the fog weight.  One fetch, passed around.
  vec4 src = texture(uScene, uv);
  vec2 rcp = 1.0/uRes;
  vec3 c = SAFE3(fxaa(uScene, uv, rcp, src.rgb));
  // uCALimit is 0.06*limit^2 from the CPU. It rides an r2*r2 falloff, not the pen's r2, so
  // the grip fringe is confined to the outer corners: at the limit it reaches 0.015 (~14 px
  // of split at 1080p, at the very corner) and is already under 2 px by mid-frame. On the
  // pen's own r2 falloff a term that size would tear a rainbow across the whole image.
  float ca = uCA * (0.0016 + r2*0.0060) + uCALimit*r2*r2;
  c.r += texture(uScene, uv + d*ca).r - src.r;
  c.b += texture(uScene, uv - d*ca).b - src.b;
  c = SAFE3(c);
  float fogW = src.a;

  // ── speed streak ───────────────────────────────────────────────────────
  // uRadial is the blend weight of the streaked copy, not the tap span: the frame never
  // loses its edges, it gains a ghost of them trailing outward. The vanishing point is
  // held sharp — smearing it too reads as a tunnel, not as velocity.
  if(uRadial > 0.0){
    vec2 st = d * (RB_SPAN / float(RB_TAPS));
    vec3 acc = vec3(0.0);
    for(int i=1;i<=RB_TAPS;i++) acc += texture(uScene, uv - st*float(i)).rgb;
    c = mix(c, SAFE3(acc/float(RB_TAPS)), uRadial * smoothstep(0.02, 0.20, r2));
  }

  // ── watercolour softening with distance (wet-in-wet, not bokeh) ────────
  // fogW is gFogAmt, written into the alpha channel by aerial() in every world shader.
  vec3 soft = texture(uSoft, uv).rgb;
  float wet = clamp(fogW*0.85, 0.0, 1.0);
  c = mix(c, soft, wet * 0.42 * uPaint);

  // ── chroma bleed: paint runs, pixels do not ────────────────────────────
  // this used to be a flat 20% everywhere, which quietly smeared the colour of
  // near detail too; it belongs to distance, like the softening it accompanies
  {
    float lc = luma(c);
    vec3 chroma = soft - vec3(luma(soft));
    c = mix(c, vec3(lc) + chroma, (0.09 + 0.17*wet)*uPaint);
  }

  // ── bloom ──────────────────────────────────────────────────────────────
  vec3 bl = texture(uBloom, uv).rgb;
  c += bl * uBloomAmt * mix(vec3(1.0), K_SUN, 0.55);

  // ── the print ──────────────────────────────────────────────────────────
  // last chance: the soft/bloom chains are sampled here and a single bad texel
  // anywhere upstream would otherwise survive the tonemap as a solid block
  c = SAFE3(c) * uExposure;
  c = tonemap(c);

  // shadows to violet, highlights to cream — the single biggest lever
  float l = luma(c);
  vec3 shadowPush = mix(vec3(0.90,0.95,1.16), vec3(1.0), smoothstep(0.0, 0.34, l));
  vec3 highPush   = mix(vec3(1.0), vec3(1.055,1.012,0.925), smoothstep(0.44, 0.98, l));
  c *= mix(vec3(1.0), shadowPush, 0.85*uPaint) * mix(vec3(1.0), highPush, 0.9*uPaint);
  // lift: nothing in a Ghibli frame is ever pure black
  vec3 lift = vec3(0.017, 0.021, 0.036)*uPaint;
  c = c*(1.0 - lift) + lift;
  // gentle S and a nudge of saturation in the midtones
  c = mix(c, c*c*(3.0-2.0*c), 0.16*uPaint);
  l = luma(c);
  float satBoost = 1.0 + 0.16*uPaint*smoothstep(0.10,0.42,l)*(1.0-smoothstep(0.62,0.96,l));
  c = mix(vec3(l), c, satBoost);

  // ── paper tooth ────────────────────────────────────────────────────────
  // two gradient-noise evaluations, not four: this is a +/-3% multiplier on the
  // final colour, and it runs on every pixel of the frame
  vec2 gp = uv*uRes/2.4;
  float grain = pn2(gp*0.5)*0.62 + pn2(gp*0.13 + 11.0)*0.38;
  float fibre = pn2(vec2(uv.x*uRes.x*0.06, uv.y*uRes.y*0.9));
  c *= 1.0 + grain*0.030*uGrain + fibre*0.010*uGrain;

  // ── vignette, warm-dark ────────────────────────────────────────────────
  float vig = pow(clamp(1.0 - r2*1.15, 0.0, 1.0), 1.55);
  c *= mix(vec3(1.0), mix(vec3(0.62,0.60,0.66), vec3(1.0), vig), uVignette);
  // ...and the speed vignette on top of it: tighter (r2*2.1 vs 1.15) and cooler, so it
  // closes in from the corners as the car winds up instead of just re-darkening the frame.
  float vigS = pow(clamp(1.0 - r2*2.10, 0.0, 1.0), 1.10);
  c *= mix(vec3(1.0), mix(vec3(0.55,0.55,0.60), vec3(1.0), vigS), uVigSpeed);

  c = toSRGB(clamp(c, 0.0, 1.0));

  // ── ordered dither: the sky must never band ────────────────────────────
  float dth = fract(dot(gl_FragCoord.xy, vec2(0.7548776662, 0.5698402909)));
  c += (dth - 0.5)/255.0;
  outColor = vec4(c, 1.0);
}`;function Ns(s,t,e=[]){return new Ut({glslVersion:"300 es",uniforms:Zt(t),vertexShader:Kt(oh),fragmentShader:ce(...e,s),depthTest:!1,depthWrite:!1})}class lh{constructor(t,{width:e,height:n,pixelRatio:o=1,renderScale:i=1,bloomLevels:a=Yl}={}){this.renderer=t,this.pixelRatio=o,this.renderScale=i,this.bloomLevels=Math.max(1,a|0),this.speed=0,this.limit=0,this.exposure=1,this.bloom=1,this.paint=1,this._quality=1,t.toneMapping=ii,t.outputColorSpace=be;const c=t.getContext(),r=!!(c.getExtension("EXT_color_buffer_half_float")||c.getExtension("EXT_color_buffer_float"));this._type=r?Pi:Oi,r||console.error("[post] no renderable half-float target; HDR bloom disabled (threshold 1.02 is unreachable on an 8-bit buffer)"),this._quadGeo=new $e,this._quadGeo.setAttribute("position",new et(new Float32Array([-1,-1,0,3,-1,0,-1,3,0]),3)),this._quadGeo.setAttribute("uv",new et(new Float32Array([0,0,2,0,0,2]),2)),this._quadGeo.boundingSphere=new Ke(new lt,10),this._quadCam=new aa,this._quadScene=new Ho,this._quadMesh=new Ht(this._quadGeo,null),this._quadMesh.frustumCulled=!1,this._quadScene.add(this._quadMesh),this._bright=Ns(ih,{uSrc:{value:null},uThresh:{value:Xl},uSoft:{value:Zl}}),this._downMats=[],this._upMats=[];for(let l=1;l<this.bloomLevels;l++)this._downMats.push(Ns(Ua,{uSrc:{value:null},uTexel:{value:new Et(1,1)}})),this._upMats.push(Ns(ah,{uSrc:{value:null},uPrev:{value:null},uTexel:{value:new Et(1,1)},uRadius:{value:Jl}}));this._softDown=Ns(Ua,{uSrc:{value:null},uTexel:{value:new Et(1,1)}}),this._blurMats=[0,1].map(l=>Ns(rh,{uSrc:{value:null},uTexel:{value:new Et(1,1)},uDir:{value:new Et(l?0:1,l?1:0)}})),this._composite=Ns(ch,{uScene:{value:null},uBloom:{value:null},uSoft:{value:null},uRes:{value:new Et(1,1)},uExposure:{value:1},uBloomAmt:{value:Na},uPaint:{value:1},uCA:{value:1},uVignette:{value:Ba},uGrain:{value:1},uRadial:{value:0},uVigSpeed:{value:Ga},uCALimit:{value:0}},[Dt,It]),this._sceneRT=null,this._bloomRTs=[],this._upRTs=[],this._softRTs=[],this.setSize(e,n)}get quality(){return this._quality}set quality(t){const e=Math.min(1,Math.max(.5,t));e!==this._quality&&(this._quality=e,this._buildBloom())}get target(){return this._sceneRT}get bufferWidth(){return this._w}get bufferHeight(){return this._h}setSize(t,e){const n=this.pixelRatio*this.renderScale,o=Math.max(16,Math.floor(t*n)),i=Math.max(16,Math.floor(e*n));this._sceneRT&&o===this._w&&i===this._h||(this._w=o,this._h=i,this._sceneRT&&this._sceneRT.dispose(),this._sceneRT=new jn(o,i,{type:this._type,format:Vn,minFilter:te,magFilter:te,wrapS:Se,wrapT:Se,depthBuffer:!0,stencilBuffer:!1,samples:0}),this._composite.uniforms.uRes.value.set(o,i),this._softRTs.forEach(a=>a.dispose()),this._softRTs=[0,1].map(()=>this._mkRT(Math.max(2,o>>3),Math.max(2,i>>3))),this._blurMats.forEach(a=>a.uniforms.uTexel.value.set(1/this._softRTs[0].width,1/this._softRTs[0].height)),this._buildBloom())}_mkRT(t,e){return new jn(t,e,{type:this._type,format:Vn,minFilter:te,magFilter:te,wrapS:Se,wrapT:Se,depthBuffer:!1,stencilBuffer:!1})}_buildBloom(){this._bloomRTs.forEach(n=>n.dispose()),this._upRTs.forEach(n=>n.dispose()),this._bloomRTs=[],this._upRTs=[];let t=Math.max(2,Math.floor(this._w*this._quality)>>1),e=Math.max(2,Math.floor(this._h*this._quality)>>1);for(let n=0;n<this.bloomLevels;n++)this._bloomRTs.push(this._mkRT(t,e)),this._upRTs.push(this._mkRT(t,e)),t=Math.max(2,t>>1),e=Math.max(2,e>>1)}_blit(t,e){this._quadMesh.material=t,this.renderer.setRenderTarget(e||null),this.renderer.render(this._quadScene,this._quadCam)}render(t,e){const n=this.renderer;n.toneMapping!==ii&&(n.toneMapping=ii),n.outputColorSpace!==be&&(n.outputColorSpace=be),n.setRenderTarget(this._sceneRT),n.render(t,e),this._bright.uniforms.uSrc.value=this._sceneRT.texture,this._blit(this._bright,this._bloomRTs[0]);const o=this._bloomRTs.length;for(let r=1;r<o;r++){const l=this._downMats[r-1];l.uniforms.uSrc.value=this._bloomRTs[r-1].texture,l.uniforms.uTexel.value.set(1/this._bloomRTs[r-1].width,1/this._bloomRTs[r-1].height),this._blit(l,this._bloomRTs[r])}for(let r=0;r<o-1;r++){const l=o-2-r,h=this._upMats[r];h.uniforms.uSrc.value=r===0?this._bloomRTs[o-1].texture:this._upRTs[l+1].texture,h.uniforms.uPrev.value=this._bloomRTs[l].texture,h.uniforms.uTexel.value.set(1/this._upRTs[l].width,1/this._upRTs[l].height),this._blit(h,this._upRTs[l])}this._softDown.uniforms.uSrc.value=this._sceneRT.texture,this._softDown.uniforms.uTexel.value.set(1/this._softRTs[0].width,1/this._softRTs[0].height),this._blit(this._softDown,this._softRTs[0]),this._blurMats[0].uniforms.uSrc.value=this._softRTs[0].texture,this._blit(this._blurMats[0],this._softRTs[1]),this._blurMats[1].uniforms.uSrc.value=this._softRTs[1].texture,this._blit(this._blurMats[1],this._softRTs[0]);const i=Math.min(1,Math.max(0,this.speed)),a=Math.min(1,Math.max(0,this.limit)),c=this._composite.uniforms;c.uScene.value=this._sceneRT.texture,c.uBloom.value=(o>1?this._upRTs[0]:this._bloomRTs[0]).texture,c.uSoft.value=this._softRTs[0].texture,c.uExposure.value=this.exposure,c.uBloomAmt.value=Na*this.bloom,c.uPaint.value=this.paint,c.uCA.value=this.paint,c.uVignette.value=Ba,c.uGrain.value=this.paint,c.uRadial.value=Ql*i*i*hh(th,eh,i),c.uVigSpeed.value=Ga+sh*i,c.uCALimit.value=nh*a*a,this._blit(this._composite,null)}dispose(){this._sceneRT&&this._sceneRT.dispose(),this._bloomRTs.forEach(t=>t.dispose()),this._upRTs.forEach(t=>t.dispose()),this._softRTs.forEach(t=>t.dispose()),this._sceneRT=null,this._bloomRTs=[],this._upRTs=[],this._softRTs=[],[this._bright,this._softDown,this._composite,...this._downMats,...this._upMats,...this._blurMats].forEach(t=>t.dispose()),this._quadGeo.dispose(),this._quadScene.remove(this._quadMesh),this._quadMesh.material=null}}function hh(s,t,e){const n=Math.min(1,Math.max(0,(e-s)/(t-s)));return n*n*(3-2*n)}const K=Math.PI*2,_s=Math.PI/180,X=(s,t,e)=>s<t?t:s>e?e:s,N=s=>s<0?0:s>1?1:s,O=(s,t,e)=>s+(t-s)*e,mt=(s,t,e)=>{const n=N((e-s)/(t-s));return n*n*(3-2*n)},ri=(s,t,e)=>{const n=N((e-s)/(t-s));return n*n*n*(n*(n*6-15)+10)};function ks(s,t){let e=(t-s)%K;return e>Math.PI&&(e-=K),e<=-Math.PI&&(e+=K),e}function kt(s,t,e,n){return O(s,t,1-Math.exp(-e*n))}function uh(s,t,e,n){return s+ks(s,t)*(1-Math.exp(-e*n))}function Rt(s,t,e=0){let n=Math.imul(s|0,2376512323)^Math.imul(t|0,3625334849)^Math.imul(e|0,3407524639);return n=Math.imul(n^n>>>15,739982445),n=Math.imul(n^n>>>12,695872825),(n^n>>>15)>>>0}function Es(s,t,e,n=0){let o=Math.imul(s|0,2376512323)^Math.imul(t|0,3625334849)^Math.imul(e|0,3407524639)^Math.imul(n|0,374761393);return o=Math.imul(o^o>>>13,1540483477),(o^o>>>15)>>>0}function Ee(s){let t=s>>>0;return()=>{t=t+1831565813|0;let e=Math.imul(t^t>>>15,1|t);return e=e+Math.imul(e^e>>>7,61|e)^e,((e^e>>>14)>>>0)/4294967296}}function dh(s,t){return Math.sqrt(s*s+t*t)}function Ui(s,t,e,n,o,i){const a=o-e,c=i-n,r=a*a+c*c;let l=r>0?((s-e)*a+(t-n)*c)/r:0;l=N(l);const h=e+a*l,u=n+c*l;return{d:dh(s-h,t-u),t:l,x:h,z:u}}function oo(s,t,e,n,o){const i=o*o,a=i*o;return(2*a-3*i+1)*s+(a-2*i+o)*t+(-2*a+3*i)*e+(a-i)*n}const fh=9200,ph=980,mh=4,gh=.1,vh=`
in vec4 wdat;      // x depth in metres, yz bed-downhill direction, w flow speed
out vec3 vW;
out vec4 vD;
out float vDist;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vW = wp.xyz;
  vD = wdat;
  vDist = length(wp.xyz - uCamPos);
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`,wh=s=>`
in vec3 vW;
in vec4 vD;
in float vDist;
out vec4 fragColor;

// The pen read its gusts out of a 256² wind render target that every system in the valley
// shared. Wanderoad has no wind pass yet (uWindTex is unbound), and sampling an unbound
// sampler is a black texture, not a calm day — so the cat's-paw field is analytic here.
// Two octaves at ~130 m per cell, advected slowly across the world: gust cells that are big
// enough to darken a whole bay and slow enough that you watch one arrive.
float gustAt(vec2 p){
  vec2 q = p * 0.0078 - vec2(uTime * 0.052, uTime * 0.019);
  float g = fbm2(q, 3) * 0.5 + 0.5;
  // Ceiling of 1.25 rather than the pen's 1.6: an fbm hits its ceiling far more often than
  // the pen's simulated wind field did, and at 1.6 the surface is permanently at full chop.
  return clamp(smoothstep(0.44, 0.90, g) * 1.25, 0.0, 1.25);
}

// ── band limiting ───────────────────────────────────────────────────────────
// The pen never had to solve this: its water was a 12-to-30 m ribbon that left the screen
// after a few hundred metres. A flooded wetland is a sheet running to the horizon, seen
// almost edge-on, so a pixel two kilometres out covers tens of metres of surface — and every
// noise band finer than that pixel turns into moire chevrons instead of ripples.
//
// fw is the pixel footprint per flow-space axis, straight off the hardware derivatives, and
// f is a band's frequency along each of those axes. Their dot product is how many cycles of
// that band fit inside one pixel; past about a half the band carries no information, so it
// is faded out rather than point-sampled. Same idea as a mip chain, done analytically
// because these bands are functions rather than textures.
//
// It has to be the dot product and not max(fw)*max(f). Both the footprint and the ripple
// bands are strongly anisotropic, and at grazing incidence they are anisotropic in the SAME
// direction: the pixel is long down the view, the ripples are long down the flow. Collapsing
// either to a single number is the isotropic-mip mistake, and it blurs the whole surface to
// a flat sheet the moment the camera drops towards eye level — which, in a driving game, is
// where the camera lives.
float bandLimit(vec2 fw, vec2 f){ return 1.0 - smoothstep(0.28, 0.72, dot(fw, abs(f))); }

// Anisotropic chop: four bands, all far longer down the ripple axis than across it, which is
// the single thing that makes water look like it is going somewhere. The pen's frequencies
// and weights, each gated at its own Nyquist limit, and each advected by the local current as
// a domain offset in metres rather than as a term buried inside the frequency scaling.
float ripple(vec2 q, vec2 drift, float t, float gust, vec2 fw){
  vec2 d1 = q - drift*1.122;   // 0.055/0.049 — the pen's own downstream rate, in metres
  vec2 d2 = q - drift*0.950;   // 0.115/0.121
  vec2 d3 = q - drift*0.810;   // 0.255/0.315
  // The capillary chop is wind-driven, not current-driven, so it keeps the pen's fixed
  // advection instead of following the bed.
  vec2 d4 = q - vec2(t*2.087, -t*0.667);
  float n1 = pn2(vec2(d1.x*0.049, d1.y*0.40))        * bandLimit(fw, vec2(0.049, 0.40));
  float n2 = pn2(vec2(d2.x*0.121, d2.y*0.92) + 7.0)  * bandLimit(fw, vec2(0.121, 0.92));
  float n3 = pn2(vec2(d3.x*0.315, d3.y*2.30) + 19.0) * bandLimit(fw, vec2(0.315, 2.30));
  float n4 = pn2(vec2(d4.x*1.15, d4.y*1.05) + 31.0)  * bandLimit(fw, vec2(1.15, 1.05)) * gust;
  return n1*0.52 + n2*0.30 + n3*0.17 + n4*0.30;
}

// ── the ripple frame ────────────────────────────────────────────────────────
// A rigid, world-anchored rotation of world space, gently domain-warped, seeded per world.
//
// It CANNOT be the pen's per-fragment flow frame (q = dot(P.xz, flow)). Out here a world
// position is thousands of metres long, so a two-degree wobble in an interpolated flow
// direction moves the noise domain by a hundred metres — and the downhill field of any lake
// converges on a line down its middle, where that direction sweeps through 180 degrees inside
// a single quad. The result is a fan of zebra stripes radiating from every deep channel, at a
// frequency no amount of band limiting can reach, because in the domain the stripes really
// are there.
//
// So the frame is global and linear in position: continuous everywhere, no chunk seams, and
// stable no matter how far from the origin the player has driven. The local current still
// does the work you can see — it enters as the advection velocity below, where it multiplies
// TIME instead of position and therefore cannot blow up.
const vec2 RIP_AXIS = vec2(${s.x.toFixed(6)}, ${s.z.toFixed(6)});
vec2 rippleFrame(vec2 p){
  // A ~270 m domain warp so the streaks meander instead of ruling the whole world in parallel
  // lines. Amplitude times frequency stays well under one, so the map keeps a bounded
  // derivative and the frame stays as well-behaved as the plain rotation underneath it.
  vec2 w = vec2(pn2(p*0.0037 + 11.3), pn2(p*0.0037 + 41.7)) * 46.0;
  vec2 s = p + w;
  return vec2(dot(s, RIP_AXIS), dot(s, vec2(-RIP_AXIS.y, RIP_AXIS.x)));
}

void main(){
  // Dry bed. The terrain already occludes the plane wherever the ground rises through it, so
  // this only matters at LOD cracks and along the shoreline, where a metre of tolerance stops
  // the plane's own 2 m-sampled waterline from cutting inside the mesh's 1 m-sampled one.
  if(!(vD.x > -0.5)) discard;

  vec3 P = vW;
  vec3 V = normalize(uCamPos - P);
  float depth = max(vD.x, 0.0);
  float sp = vD.w;

  vec2 q = rippleFrame(P.xz);
  vec2 fw = max(fwidth(q), vec2(1e-4));

  // The local current, expressed in the ripple frame. Interpolation is safe here: where two
  // vertices flow at each other the vector simply shortens towards zero, which is slack water
  // and reads as slack water, instead of spinning through every heading inside one quad.
  vec2 fl = vD.yz;
  fl *= min(1.0, inversesqrt(max(dot(fl, fl), 1e-8)));
  vec2 adv = vec2(dot(fl, RIP_AXIS), dot(fl, vec2(-RIP_AXIS.y, RIP_AXIS.x)));
  vec2 drift = adv * (uTime * sp);

  // Gust cells are ~32 m across at their finest, so they too stop carrying information once
  // the pixel is wider than that — and their surface darkening is the most visible aliasing
  // of the lot, because it is a contrast term rather than a colour one.
  float gust = gustAt(P.xz) * bandLimit(fw, vec2(0.031));

  // The finite differences that build the normal are sampled at the pixel footprint of their
  // OWN axis rather than at the pen's fixed 0.42 m, so each degrades into a box filter of
  // exactly the right width instead of into noise — and a grazing pixel does not drag the
  // across-axis difference out with it.
  vec2 e = max(fw, vec2(0.42));
  float h0 = ripple(q, drift, uTime, gust, fw);
  float hx = ripple(q + vec2(e.x, 0.0), drift, uTime, gust, fw);
  float hy = ripple(q + vec2(0.0, e.y), drift, uTime, gust, fw);
  float amp = mix(0.055, 0.20, clamp(sp*0.22, 0.0, 1.0)) * (0.55 + 0.9*gust);
  // Shallow water is choppier: the bed shortens the wave.
  amp *= mix(1.35, 1.0, smoothstep(0.3, 2.6, depth));
  vec2 dh = (vec2(hx, hy) - h0)/e * amp * 14.0;
  // Back out of the ripple frame into world xz. The warp is ignored in this rotation: it is a
  // few degrees of shear, and the normal only has to look right, not integrate.
  vec2 axC = vec2(-RIP_AXIS.y, RIP_AXIS.x);
  vec3 N = normalize(vec3(-(dh.x*RIP_AXIS.x + dh.y*axC.x), 1.0, -(dh.x*RIP_AXIS.y + dh.y*axC.y)));
  // Flatten with distance so a lake two kilometres away is a plate of colour and not a
  // boiling field of highlights. Barely stronger than the pen's 0.75 over 120-520 m: with
  // the bands gated above, this is now a look control rather than an anti-aliasing measure.
  N = normalize(mix(N, vec3(0.0,1.0,0.0), smoothstep(110.0, 560.0, vDist)*0.82));

  float ndl = dot(N, uSunDir);
  float sh = sunShadow(P, ndl) * cloudShadow(P);

  // ── depth-graded body colour, in bands ─────────────────────────────────────
  // Painted water is not a smooth gradient; it is a few flat plates of colour whose
  // boundaries you can point at. The pen keyed those plates off distance-across-the-channel;
  // here they key off real depth, so a shelving bay draws its own contour lines.
  float bedDepth = smoothstep(0.12, 4.4, depth);
  float plateJ = pn2(vec2(q.x*0.045, q.y*0.42) + 3.0)*0.070*bandLimit(fw, vec2(0.045, 0.42));
  float b1 = smoothstep(0.16 + plateJ, 0.30 + plateJ, bedDepth);
  float b2 = smoothstep(0.50 + plateJ, 0.68 + plateJ, bedDepth);
  vec3 body = mix(K_W_SHALLOW, K_W_MID, b1);
  body = mix(body, K_W_DEEP, b2);
  // the gravel bed showing through the shallows (cool wet stone, not sand)
  float bedN = pn2(P.xz*0.55)*0.5 + 0.5;
  vec3 wetBed = mix(${G.wetStone}, K_W_SHALLOW, 0.45) * mix(0.80, 1.06, mix(0.5, bedN, bandLimit(fw, vec2(0.55))));
  body = mix(wetBed, body, smoothstep(0.02, 0.22, bedDepth));
  // caustic light rocking over the shallow bed
  vec2 dc = q - drift*0.471;   // 0.8/1.7
  float caus = pn2(vec2(dc.x*1.7, dc.y*2.9 + uTime*0.5));
  caus = pow(clamp(caus*0.5 + 0.5, 0.0, 1.0), 3.0);
  body += ${G.wSpark}*caus*0.20*(1.0 - smoothstep(0.05, 0.40, bedDepth))*sh*bandLimit(fw, vec2(1.7, 2.9));

  // ── reflection ─────────────────────────────────────────────────────────────
  // Sky only. The pen also had a planar mirror pass for its one valley; a streaming world
  // would need one render target per water body per frame, and stylised water keeps its own
  // colour at grazing angles anyway — which is why the Fresnel term is clamped so low.
  vec3 R = reflect(-V, N);
  vec3 refl = skyDomeLite(normalize(vec3(R.x, max(R.y, 0.012), R.z)));
  float fres = 0.035 + 0.70*pow(1.0 - clamp(dot(N,V), 0.0, 1.0), 4.0);
  fres = clamp(fres, 0.0, 0.46);

  vec3 col = mix(body, refl, fres*0.86);
  col = mix(col*0.74 + K_SHADOW*0.10, col, sh*0.82 + 0.18);

  // ── flow ribbons ───────────────────────────────────────────────────────────
  // Long creases travelling downstream: they show which way the water is going with no motion
  // at all, which is what carries the read on a distant reach only twelve pixels wide.
  {
    vec2 e1 = q - drift*1.333;   // 0.10/0.075
    vec2 e2 = q - drift*1.097;   // 0.17/0.155
    float r1 = pn2(vec2(e1.x*0.075, e1.y*0.55) + 5.0);
    float r2 = pn2(vec2(e2.x*0.155, e2.y*1.05) + 41.0);
    float rib = smoothstep(0.28, 0.62, abs(r1)*0.75 + abs(r2)*0.45);
    float bright = smoothstep(0.0, 0.5, r1 + r2);
    col = mix(col, mix(${G.wDeepShade}, ${G.wSpark}, bright),
              rib*0.16*(0.4 + 0.6*sh)*bandLimit(fw, vec2(0.155, 1.05)));
  }

  // ── quantised sun glitter ──────────────────────────────────────────────────
  // Hard-stepped into discrete winking glints rather than left as a specular lobe: a
  // specular lobe on stylised water reads as plastic.
  float f = dot(normalize(R), uSunDir);
  float broad = pow(max(f, 0.0), 22.0);
  vec2 dg = q - drift*0.579 - vec2(0.0, uTime*0.097);   // 1.1/1.9 and 0.35/3.6
  float glintN = pn2(dg*vec2(1.9, 3.6))*0.5 + 0.5;
  float twinkle = step(0.42, glintN) * (0.55 + 0.75*pn2((q - vec2(uTime*0.286))*7.0));
  // A winking glint is a sub-pixel event by construction, so once a pixel is wider than the
  // glint field it hands its energy to the broad lobe rather than strobing.
  float glint = smoothstep(0.9975, 0.99925, f) * twinkle * bandLimit(fw, vec2(1.9, 3.6));
  float glitterPath = smoothstep(0.55, 1.0, dot(normalize(vec2(V.x,V.z)), -normalize(uSunDir.xz)));
  col += ${G.wSpark} * (glint*2.6 + broad*0.42) * sh * (0.35 + 0.75*glitterPath);

  // ── shore foam ─────────────────────────────────────────────────────────────
  // Keyed off the measured depth, so the foam band is a genuine contour of the bed and
  // widens by itself wherever the shore shelves gently.
  float edge = 1.0 - smoothstep(0.0, 1.25, depth);
  vec2 ds = q - drift*0.824;   // 0.7/0.85
  float scallop = mix(0.5, pn2(vec2(ds.x*0.85, ds.y*2.2))*0.5 + 0.5, bandLimit(fw, vec2(0.85, 2.2)));
  float foam = clamp(smoothstep(0.42, 0.96, edge*(0.50 + 0.95*scallop)), 0.0, 1.0);
  col = mix(col, ${G.wFoam}*mix(0.80, 1.10, scallop), foam*0.55);

  // cat's paws darken the surface where a gust touches down
  col *= mix(1.0, 0.86, smoothstep(0.75, 1.6, gust));

  col += K_SUN * pow(clamp(dot(V,-uSunDir), 0.0, 1.0), 5.0) * 0.16 * sh;
  col = aerial(col, vDist, V, P.y);
  fragColor = vec4(SAFE3(col), gFogAmt);
}
`;function bh(s){const t=Rt(11433,4574,s)/4294967296*K,e={x:Math.cos(t),z:Math.sin(t)},n=fs({cshSpan:fh,cloudDeck:ph});return new Ut({glslVersion:"300 es",uniforms:Zt(),vertexShader:Kt(vh),fragmentShader:ce(Dt,It,Wo,n,Cs,ps,wh(e)),transparent:!1,side:ke})}const Ha=new Map;function xh(s){let t=Ha.get(s);if(t)return t;t=new Uint16Array((s-1)*(s-1)*6);let e=0;for(let n=0;n<s-1;n++)for(let o=0;o<s-1;o++){const i=n*s+o,a=i+1,c=i+s,r=c+1;t[e++]=i,t[e++]=c,t[e++]=a,t[e++]=a,t[e++]=c,t[e++]=r}return Ha.set(s,t),t}const Wa=s=>`${s.level}:${s.cx},${s.cz}`;class yh{constructor({seed:t,scene:e}){this.seed=t>>>0,this.scene=e,this.material=bh(this.seed),this.group=new qe,this.group.name="water",this.group.matrixAutoUpdate=!1,e.add(this.group),this.planes=new Map,this.stats={live:0,visible:0},this._cullT=0,this._cam=new lt}add(t){if(!t||!t.water||t.level>mh)return;const e=Wa(t);if(this.planes.has(e))return;const n=this._buildPlane(t);if(!n)return;const o=new Ht(n,this.material);o.position.set(t.ox,t.water.level,t.oz),o.matrixAutoUpdate=!1,o.updateMatrix(),o.frustumCulled=!0,o.renderOrder=1,o.userData.level=t.level,this.group.add(o),this.planes.set(e,o),this.stats.live=this.planes.size}remove(t){if(!t)return;const e=Wa(t),n=this.planes.get(e);n&&(this.group.remove(n),n.geometry.dispose(),this.planes.delete(e),this.stats.live=this.planes.size)}update(t,e){if(e&&this._cam.set(e.x,e.y,e.z),this._cullT-=t,this._cullT>0)return;this._cullT=gh;const n=pt.uFogFar.value*1.25;let o=0;for(const i of this.planes.values()){const a=i.geometry.boundingSphere,c=i.position.x+a.center.x-this._cam.x,r=i.position.z+a.center.z-this._cam.z,l=n+a.radius,h=c*c+r*r<l*l;i.visible=h,h&&o++}this.stats.visible=o}dispose(){for(const t of this.planes.values())this.group.remove(t),t.geometry.dispose();this.planes.clear(),this.scene.remove(this.group),this.material.dispose(),this.stats.live=0,this.stats.visible=0}_buildPlane(t){const e=t.grid|0;if(e<3)return null;const n=this._bedReader(t,e);if(!n)return null;const o=e+1>>1,i=(e-1)/(o-1),a=t.water.level,c=t.size/(o-1),r=i*2,l=Rt(t.cx,t.cz,this.seed^31358)/4294967296*K,h=Math.cos(l),u=Math.sin(l),d=new Float32Array(o*o*3),f=new Float32Array(o*o*4);for(let g=0;g<o;g++){const m=g*i;for(let v=0;v<o;v++){const x=v*i,b=g*o+v;d[b*3]=v*c,d[b*3+1]=0,d[b*3+2]=g*c;const y=x-r<0?0:x-r,A=x+r>e-1?e-1:x+r,_=m-r<0?0:m-r,S=m+r>e-1?e-1:m+r,T=(n(A,m)-n(y,m))/((A-y)*t.step)||0,M=(n(x,S)-n(x,_))/((S-_)*t.step)||0;let k=-T,R=-M;const P=Math.sqrt(k*k+R*R);P>.001?(k/=P,R/=P):(k=h,R=u);const z=a-n(x,m);f[b*4]=z,f[b*4+1]=k,f[b*4+2]=R;const L=1-.72*N((z-1.2)/7);f[b*4+3]=(.35+2*N(P*8))*L}}const p=new $e;return p.setAttribute("position",new et(d,3)),p.setAttribute("wdat",new et(f,4)),p.setIndex(new et(xh(o),1)),p.boundingSphere=new Ke(new lt(t.size*.5,0,t.size*.5),t.size*.7072),p}_bedReader(t,e){const n=t.heights;if(n&&n.length>=e*e)return(a,c)=>n[c*e+a];const o=t.mesh&&t.mesh.geometry&&t.mesh.geometry.getAttribute("position");if(!o||o.count<e*e)return null;const i=o.array;return(a,c)=>i[(c*e+a)*3+1]}}const Fn=9,Dn=3050,Qs=Fn*Dn,_h=9200,$a=980,Th=10500,Hi=12800,Ka=1500,Ah=.35,qa=2.3,Mh=`
in vec2 vUv;
out vec4 fragColor;
void main(){
  vec2 tile = floor(vUv*2.0);
  float seed = (tile.x + tile.y*2.0)*37.13 + 5.0;
  vec2 c = fract(vUv*2.0)*2.0 - 1.0;
  float r = length(c);
  float ang = atan(c.y, c.x);
  vec2 ring = vec2(cos(ang), sin(ang));
  float lob = fbm2(ring*2.35 + seed*13.7, 3) + fbm2(ring*5.1 + seed*29.1, 2)*0.45;
  float R = 0.80 + lob*0.20;
  float a = smoothstep(R, R-0.34, r);
  float den = fbm2(c*2.6 + seed*31.3, 3)*0.5 + 0.5;
  float edge = smoothstep(R-0.36, R-0.02, r);
  float aSoft = smoothstep(R, R-0.42, r);
  fragColor = vec4(a, den, edge, aSoft);
}
`,Sh=`
in vec2 vUv;
out vec4 fragColor;
void main(){
  vec2 q = uCloudShOrigin + (vUv - 0.5)*CSH_SPAN;
  float c = smoothstep(0.06, 0.60, cloudField(q));
  fragColor = vec4(c, c, c, 1.0);
}
`,ja=`
in vec2 uv;
out vec2 vUv;
void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
`,kh=`
in vec2 corner;
in vec3 pdata;   // radius, per-puff seed, height fraction within its formation
in vec2 fcen;    // the formation's lattice centre, xz
out vec2 vC;
out float vSeed;
out float vHF;
out vec3 vW;
out float vOp;
out vec3 vRight;
out vec3 vUp;
out vec3 vFwd;

const float DECK_PERIOD = ${Qs.toFixed(1)};

void main(){
  // Wrap by whole lattice periods into the window around the camera. The offset is computed
  // from the FORMATION centre, not the puff, so a formation always wraps as one cloud
  // instead of tearing in half.
  vec2 fhome = fcen + uCloudDrift;
  vec2 wrapOff = floor((uCamPos.xz - fhome)/DECK_PERIOD + 0.5) * DECK_PERIOD;
  vec2 fw = fhome + wrapOff;
  vec3 wc = position + vec3(uCloudDrift.x + wrapOff.x, 0.0, uCloudDrift.y + wrapOff.y);

  // The same field that draws the shadow decides whether this puff exists. cloudField()
  // subtracts uCloudDrift again, so a cloud's existence is pinned to its wrapped home in the
  // world while the puff itself rides the wind — a cloud that moves rather than one that
  // blinks.
  float op = smoothstep(0.16, 0.52, cloudField(fw));
  // Fade well inside DECK_PERIOD*0.5 so the wrap always happens to an invisible puff.
  op *= 1.0 - smoothstep(${Th.toFixed(1)}, ${Hi.toFixed(1)}, length(uCamPos - wc));
  vOp = op;
  if(op < 0.012){ gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }

  vRight = normalize(vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]));
  vUp    = normalize(vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]));
  vFwd   = normalize(vec3(viewMatrix[0][2], viewMatrix[1][2], viewMatrix[2][2]));

  float rad = pdata.x * mix(0.80, 1.06, op);
  float ra = pdata.y*2.399963;                    // golden-angle spin per puff
  float cr = cos(ra), sr = sin(ra);
  vec2 rc = vec2(corner.x*cr - corner.y*sr, corner.x*sr + corner.y*cr);
  vec3 wp = wc + vRight*(rc.x*rad) + vUp*(rc.y*rad*0.86);
  vC = rc; vSeed = pdata.y; vHF = pdata.z; vW = wp;
  gl_Position = projectionMatrix * viewMatrix * vec4(wp, 1.0);
}
`,Eh=`
uniform sampler2D uPuff;
in vec2 vC;
in float vSeed;
in float vHF;
in vec3 vW;
in float vOp;
in vec3 vRight;
in vec3 vUp;
in vec3 vFwd;
out vec4 fragColor;
void main(){
  float r = length(vC);
  if(!(r <= 1.02)) discard;
  vec2 tile = vec2(mod(floor(vSeed*4.0), 2.0), mod(floor(vSeed*2.0), 2.0));
  vec4 prof = texture(uPuff, (clamp(vC,-1.0,1.0)*0.5 + 0.5)*0.5 + tile*0.5);
  // An analytic radial falloff multiplies the baked profile: it softens the silhouette, and
  // it makes a hard-edged opaque quad structurally impossible even if the atlas is missing.
  float a = prof.r * smoothstep(1.02, 0.60, r);
  if(!(a > 0.004)) discard;
  float den = prof.g;
  a *= mix(0.62, 1.0, den);
  a *= vOp;

  // Fake volumetric normal off the billboard disc, biased upward: cumulus tops face the sky,
  // bellies face the ground.
  float zz = sqrt(max(0.0, 1.0 - min(r,1.0)*min(r,1.0)));
  vec3 N = normalize(vRight*vC.x + vUp*vC.y + vFwd*zz*0.85 + vec3(0.0, 0.62, 0.0));
  vec3 V = normalize(uCamPos - vW);

  float ndl = dot(N, uSunDir);
  float t = clamp(ndl*0.5 + 0.5, 0.0, 1.0);
  // Height fraction as its own term rather than a nudge to the lambert: it is what separates
  // a stack of towers into readable storeys instead of one grey mass, because a cumulus is
  // lit as much by the sky dome above it as by the sun on its shoulder.
  t = mix(t, clamp(t + vHF*0.36 - 0.10, 0.0, 1.0), 0.78);
  t *= mix(0.68, 1.10, den);
  float term = smoothstep(0.30, 0.54, t);       // the terminator, as a line

  vec3 col = ramp3(t, K_C_UNDER, K_C_TERM, K_C_TOP, 0.085, (den-0.5)*0.06);
  // the belly goes violet fast, and it does not pass through grey to get there
  col = mix(mix(K_C_CORE, K_C_UNDER, 0.30), col, smoothstep(0.0, 0.28, t));
  col = mix(col, K_C_BODY, 0.13);
  col *= mix(vec3(1.0), K_SUN*1.28, term*0.44);

  // silver lining: the rim of a backlit cumulus blazes
  float back = clamp(dot(V, -uSunDir), 0.0, 1.0);
  float edge = prof.b;
  float sunEdge = clamp(dot(normalize(vRight*vC.x + vUp*vC.y), uSunDir)*0.5+0.5, 0.0, 1.0);
  float rimLine = smoothstep(0.30, 0.84, edge);
  float silver = rimLine * pow(sunEdge, 1.9) * (0.34 + 1.7*pow(back, 1.3));
  col = mix(col, K_C_RIM*1.45, clamp(silver, 0.0, 0.94));
  // ...and a thin cool line down the shaded side, which is the thing that actually reads as
  // "drawn" rather than "rendered"
  col = mix(col, mix(K_C_CORE, K_SHADOW, 0.42), rimLine*(1.0-sunEdge)*(1.0-term)*0.36);
  col += K_SUN * pow(back, 6.0) * 0.62 * (1.0-edge*0.4);

  // Clouds are far enough that full aerial perspective would erase them; the pen carries
  // them at 55% of their true distance so they haze without dissolving.
  col = aerial(col, length(uCamPos - vW)*0.55, V, vW.y);
  fragColor = vec4(SAFE3(col), clamp(a, 0.0, 1.0));
}
`,tc=new Ho,Rh=new aa,zh=(()=>{const s=new $e;s.setAttribute("position",new et(new Float32Array([-1,-1,0,3,-1,0,-1,3,0]),3)),s.setAttribute("uv",new et(new Float32Array([0,0,2,0,0,2]),2)),s.boundingSphere=new Ke(new lt,10);const t=new Ht(s,null);return t.frustumCulled=!1,tc.add(t),t})();function Va(s,t,e){zh.material=t,s.setRenderTarget(e),s.render(tc,Rh),s.setRenderTarget(null)}function Ch(s){const t=Ee(Rt(23568,53445,s>>>0)),e=[];for(let h=0;h<Fn;h++)for(let u=0;u<Fn;u++){const d=(u-(Fn-1)/2)*Dn+(t()-.5)*Dn*.75,f=(h-(Fn-1)/2)*Dn+(t()-.5)*Dn*.75,p=620+t()*820,g=.72+t()*.85,m=2+(t()*3|0),v=(300+t()*230)*g;let x=0;const b=[],y=7+(t()*7|0);for(let A=0;A<y;A++){const _=t()*K,S=Math.sqrt(t())*v,T=Math.cos(_)*S,M=Math.sin(_)*S*.72,k=t()*.1*v;b.push({x:T,y:k,z:M,rad:(.44+t()*.32)*v,seed:t()*100}),k>x&&(x=k)}for(let A=0;A<m;A++){const _=t()*K,S=Math.sqrt(t())*v*.55,T=Math.cos(_)*S,M=Math.sin(_)*S*.7,k=(.85+t()*1.15)*v,R=4+(t()*4|0);for(let P=0;P<R;P++){const z=P/(R-1),L=z*k,U=(.52-.22*z*z+t()*.13)*v*(1-.25*z),W=(t()-.5)*v*.3*(.4+z),I=(t()-.5)*v*.3*(.4+z);if(b.push({x:T+W,y:L,z:M+I,rad:U,seed:t()*100}),L>x&&(x=L),P>0&&t()<.7){const H=t()*K,V=U*(.55+t()*.5);b.push({x:T+W+Math.cos(H)*V,y:L+(t()-.3)*U*.5,z:M+I+Math.sin(H)*V,rad:U*(.42+t()*.3),seed:t()*100})}}}for(const A of b)e.push({cx:d+A.x,cy:p+A.y,cz:f+A.z,rad:A.rad,seed:A.seed,hf:x>1?X(A.y/x,0,1):.5,fx:d,fz:f})}const n=e.length,o=new Float32Array(n*4*3),i=new Float32Array(n*4*2),a=new Float32Array(n*4*3),c=new Float32Array(n*4*2);for(let h=0;h<n;h++){const u=e[h];for(let d=0;d<4;d++){const f=h*4+d;o[f*3]=u.cx,o[f*3+1]=u.cy,o[f*3+2]=u.cz,i[f*2]=d===1||d===3?1:-1,i[f*2+1]=d>=2?1:-1,a[f*3]=u.rad,a[f*3+1]=u.seed,a[f*3+2]=u.hf,c[f*2]=u.fx,c[f*2+1]=u.fz}}const r=new $e;r.setAttribute("position",new et(o,3)),r.setAttribute("corner",new et(i,2)),r.setAttribute("pdata",new et(a,3)),r.setAttribute("fcen",new et(c,2));const l=new Uint32Array(n*6);return r.setIndex(new et(l,1)),r.boundingSphere=new Ke(new lt(0,900,0),Qs),{geom:r,puffs:e,index:l,count:n}}class Lh{constructor({renderer:t,scene:e,seed:n}){this.renderer=t,this.scene=e,this.seed=n>>>0;const o=fs({cshSpan:_h,cloudDeck:$a});this.puffRT=new jn(1024,1024,{format:Vn,type:Oi,minFilter:ra,magFilter:te,generateMipmaps:!0,depthBuffer:!1});const i=new Ut({glslVersion:"300 es",uniforms:Zt(),vertexShader:Kt(ja),fragmentShader:ce(Dt,It,Mh),depthTest:!1,depthWrite:!1});Va(t,i,this.puffRT),i.dispose(),this.shadowRT=new jn(512,512,{format:Vn,type:Oi,minFilter:te,magFilter:te,wrapS:Se,wrapT:Se,generateMipmaps:!1,depthBuffer:!1}),this.shadowMat=new Ut({glslVersion:"300 es",uniforms:Zt({uCloudSh:{value:null}}),vertexShader:Kt(ja),fragmentShader:ce(Dt,It,o,Sh),depthTest:!1,depthWrite:!1}),pt.uCloudSh.value=this.shadowRT.texture,this.deck=Ch(this.seed),this.material=new Ut({glslVersion:"300 es",uniforms:Zt({uPuff:{value:this.puffRT.texture}}),vertexShader:Kt(Dt,It,o,kh),fragmentShader:ce(ps,Eh),side:ke,transparent:!0,depthTest:!0,depthWrite:!1,blending:K0,blendSrc:$0,blendDst:W0,blendEquation:Do,blendSrcAlpha:H0,blendDstAlpha:U0,blendEquationAlpha:Do}),this.mesh=new Ht(this.deck.geom,this.material),this.mesh.name="clouds",this.mesh.frustumCulled=!1,this.mesh.matrixAutoUpdate=!1,this.mesh.renderOrder=40,e.add(this.mesh);const a=Rt(7482,49421,this.seed)/4294967296*K;this._driftX=Math.cos(a)*qa,this._driftZ=Math.sin(a)*qa,this._sortT=0,this._dist=new Float32Array(this.deck.count),this._order=new Int32Array(this.deck.count);for(let c=0;c<this.deck.count;c++)this._order[c]=c;this.stats={puffs:this.deck.count,drawn:0},this.update(0,{x:0,y:0,z:0})}update(t,e){const n=e?e.x:0,o=e?e.y:0,i=e?e.z:0,a=pt.uTime.value;pt.uCloudDrift.value.set(this._driftX*a,this._driftZ*a),this._sortT-=t,this._sortT<=0&&(this._sortT=Ah,this._sort(n,o,i));const c=pt.uSunDir.value,r=($a-o)/Math.max(c.y,.06);pt.uCloudShOrigin.value.set(n+c.x*r,i+c.z*r),Va(this.renderer,this.shadowMat,this.shadowRT)}_sort(t,e,n){const o=this.deck.puffs,i=this.deck.index,a=o.length,c=this._dist,r=this._order,l=pt.uCloudDrift.value.x,h=pt.uCloudDrift.value.y;for(let g=0;g<a;g++){const m=o[g],v=Math.round((t-(m.fx+l))/Qs)*Qs,x=Math.round((n-(m.fz+h))/Qs)*Qs,b=m.cx+l+v-t,y=m.cy-e,A=m.cz+h+x-n;c[g]=b*b+y*y+A*A}for(let g=1;g<a;g++){const m=r[g],v=c[m];let x=g-1;for(;x>=0&&c[r[x]]<v;)r[x+1]=r[x],x--;r[x+1]=m}const u=Hi*Hi;let d=0;for(let g=0;g<a;g++)c[r[g]]<=u&&d++;let f=d>Ka?d-Ka:0,p=0;for(let g=0;g<a;g++){const m=r[g];if(c[m]>u)continue;if(f>0){f--;continue}const v=m*4;i[p++]=v,i[p++]=v+1,i[p++]=v+2,i[p++]=v,i[p++]=v+2,i[p++]=v+3}this.deck.geom.index.needsUpdate=!0,this.deck.geom.setDrawRange(0,p),this.stats.drawn=p/6}dispose(){this.scene.remove(this.mesh),this.deck.geom.dispose(),this.material.dispose(),this.shadowMat.dispose(),pt.uCloudSh.value===this.shadowRT.texture&&(pt.uCloudSh.value=null),this.shadowRT.dispose(),this.puffRT.dispose(),this.stats.drawn=0}}const Yn=64,In=new Float32Array(Yn),Pn=new Float32Array(Yn);for(let s=0;s<Yn;s++){const t=s/Yn*6.283185307179586;In[s]=Math.cos(t),Pn[s]=Math.sin(t)}const io=Yn-1;function we(s,t,e=0){const n=Math.floor(s),o=Math.floor(t),i=s-n,a=t-o,c=i*i*i*(i*(i*6-15)+10),r=a*a*a*(a*(a*6-15)+10),l=Rt(n,o,e)>>>20&io,h=Rt(n+1,o,e)>>>20&io,u=Rt(n,o+1,e)>>>20&io,d=Rt(n+1,o+1,e)>>>20&io,f=In[l]*i+Pn[l]*a,p=In[h]*(i-1)+Pn[h]*a,g=In[u]*i+Pn[u]*(a-1),m=In[d]*(i-1)+Pn[d]*(a-1);return O(O(f,p,c),O(g,m,c),r)*1.42}function $t(s,t,e=5,n=0,o=2.03,i=.5){let a=.5,c=1,r=0,l=0;for(let h=0;h<e;h++)r+=a*we(s*c,t*c,n+h*1013),l+=a,a*=i,c*=o;return r/l}function Io(s,t,e=5,n=0,o=2.07,i=.5){let a=.5,c=1,r=0,l=0,h=1;for(let u=0;u<e;u++){let d=1-Math.abs(we(s*c,t*c,n+u*7919));d*=d,d*=h,h=d*1.6,h>1?h=1:h<0&&(h=0),r+=a*d,l+=a,a*=i,c*=o}return r/l*2-1}function Fh(s,t,e=4,n=0,o=2,i=.5){let a=.5,c=1,r=0,l=0;for(let h=0;h<e;h++)r+=a*Math.abs(we(s*c,t*c,n+h*3733)),l+=a,a*=i,c*=o;return r/l*2-1}function ec(s,t,e,n,o=1){const i=$t(s+5.2,t+1.3,3,n+101),a=$t(s+9.7,t+4.1,3,n+227);return $t(s+o*i,t+o*a,e,n)}const rs={MEADOW:0,STEPPE:1,HIGHLAND:2,DUNES:3,WETLAND:4},_t=5,Wi=["Meadow","Steppe","Highlands","Dunes","Wetland"],ao=1/7200,Ya=1/15500,Xa=1/9800,Za=1/2600;function Dh(s,t,e){const n=ec(s*ao,t*ao,5,e^6699,.8),o=Io(s*ao*1.7,t*ao*1.7,4,e^23613);let i=N(.5+n*.62+Math.max(0,o)*.34-.06);const a=$t(s*Ya+41.3,t*Ya-17.9,3,e^30635);let c=N(.5+a*.85-mt(.52,.95,i)*.62);const r=$t(s*Xa-88.1,t*Xa+12.7,4,e^13297),l=mt(.44,.16,i);let h=N(.5+r*.9+l*.3-mt(.55,.9,i)*.25);const u=we(s*Za,t*Za,e^40503)*.045;return i=N(i+u),c=N(c+u*1.4),h=N(h-u*1.1),{e:i,t:c,m:h}}const Ja=s=>N(.5+(s-.5)*1.92);function sc(s,t,e){const n=Dh(s,t,e),o=Ja(n.e),i=Ja(n.t),a=N(.5+(n.t-n.m)*1.45);return{ue:o,ut:i,ua:a,e:n.e,t:n.t,m:n.m}}const Ih=[[.5,.45,.52,1.9,2.3,1.3,1],[.48,.72,.64,1.6,2.6,1.6,1.32],[.88,.45,.26,3,1.1,2,1.35],[.42,.95,.8,1.5,3.1,1.7,1.55],[.13,.12,.52,2.6,2.6,1,1.5]],nc=new Float32Array(_t),oc=new Float32Array([1,1,1,1,1]);function Ph(s){for(let t=0;t<_t;t++)oc[t]=s&&s[t]>0?s[t]:1}function fa(s,t,e,n=nc){const o=sc(s,t,e);return $i(o,n)}function $i(s,t=nc){let e=0,n=0,o=-1;for(let a=0;a<_t;a++){const c=Ih[a],r=(s.ue-c[0])*c[3],l=(s.ua-c[1])*c[4],h=(s.ut-c[2])*c[5],u=c[6]*oc[a]*Math.exp(-(r*r+l*l+h*h));t[a]=u,e+=u,u>o&&(o=u,n=a)}const i=1/(e||1);for(let a=0;a<_t;a++)t[a]*=i;return{w:t,dominant:n,e:s.e,t:s.t,m:s.m,ue:s.ue,ua:s.ua,ut:s.ut}}const Be=[{amp:108,base:6,rough:.18,wave:1e3,gain:.3,lac:2.3,drive:1,water:1.2},{amp:62,base:3,rough:.1,wave:1550,gain:.28,lac:2.3,drive:1,water:0},{amp:205,base:14,rough:.86,wave:2150,gain:.26,lac:2.3,drive:1,water:.6},{amp:62,base:2,rough:.02,wave:900,gain:.3,lac:2.2,drive:1,water:0},{amp:26,base:-2,rough:.05,wave:1100,gain:.28,lac:2.2,drive:1,water:2.5}];function Oh(s,t,e,n,o,i,a){const c=$t(s+5.2,t+1.3,2,n+101,2.03,.5),r=$t(s+9.7,t+4.1,2,n+227,2.03,.5);return $t(s+o*c,t+o*r,e,n,i,a)}function ro(s,t){return s*O(t,1,mt(-.4,.4,s))}function Nh(s,t,e,n){const o=Be[n],i=1/o.wave;switch(n){case rs.MEADOW:{const a=Oh(s*i,t*i,5,e^2577,.55,o.lac,o.gain),c=Io(s*i*.55,t*i*.55,3,e^2578,2.1,.3);return o.base+ro(a*.86+c*.14,.44)*o.amp}case rs.STEPPE:{const a=$t(s*i,t*i,4,e^2849,o.lac,o.gain),c=we(s*i*.34,t*i*.34,e^2850);return o.base+ro(a*.62+c*.38,.5)*o.amp}case rs.HIGHLAND:{const a=Io(s*i,t*i,5,e^3121,o.lac,o.gain),c=$t(s*i*2.4,t*i*2.4,4,e^3122,2.2,.3),r=N(a*.5+.5),l=Math.pow(r,1.34)*1.3-.17;return o.base+(l*.91+c*.09)*o.amp}case rs.DUNES:{const a=Fh(s*i,t*i,4,e^3393,o.lac,o.gain),c=Math.sin((s*.0037+t*.0014)*6.283+$t(s*i*.5,t*i*.5,3,e^3394)*4.2);return o.base+ro(a*.8+c*.2,.55)*o.amp}case rs.WETLAND:{const a=$t(s*i,t*i,4,e^3665,o.lac,o.gain),c=mt(.15,-.35,a);return o.base+ro(a,.6)*o.amp-c*4.5}default:return 0}}function Ls(s,t){let e=0,n=0;for(let i=0;i<_t;i++){const a=s[i];a<.02||(e+=Be[i].water*a,n+=a)}if(n<=0)return null;const o=e/n;return t<o?o:null}const $o=[{trees:26,rocks:5,bushes:16,reeds:0,posts:.6,grass:1,kinds:["broadleaf","broadleaf","poplar"]},{trees:4,rocks:8,bushes:9,reeds:0,posts:.9,grass:.72,kinds:["acacia","scrub"]},{trees:18,rocks:26,bushes:6,reeds:0,posts:.4,grass:.34,kinds:["pine","pine","deadpine"]},{trees:.5,rocks:10,bushes:2,reeds:0,posts:.25,grass:.06,kinds:["palm","scrub"]},{trees:11,rocks:2,bushes:12,reeds:34,posts:1.2,grass:.8,kinds:["willow","willow","broadleaf"]}],ci=[{surface:"tarmac",grip:1,rough:.06,width:8,lines:1},{surface:"gravel",grip:.78,rough:.3,width:9,lines:.15},{surface:"tarmac",grip:.92,rough:.14,width:6.8,lines:.8},{surface:"sand",grip:.62,rough:.42,width:10.5,lines:0},{surface:"tarmac",grip:.86,rough:.1,width:7.2,lines:.6}];function ic(s,t,e){let n=0;for(let o=0;o<_t;o++)n+=s[o]*t[o][e];return n}const ts=[{cell:1800,jitter:.34,connect:.86,width:8.6,verge:5,curve:.44,step:38,bend:220,radius:122,swing:.1,grade:222},{cell:620,jitter:.42,connect:.5,width:6.2,verge:3,curve:.62,step:19,bend:140,radius:103,swing:.11,grade:76}],Bh=3,Gh=130,Po=1/4294967296;function cs(s,t,e,n,o){const i=ts[e],a=Rt(s,t,n^(e===0?20858:11165)),c=((a&65535)*Po*65536-.5)*2*i.jitter,r=((a>>>16&65535)*Po*65536-.5)*2*i.jitter;return o[0]=(s+.5+c)*i.cell,o[1]=(t+.5+r)*i.cell,o}function On(s,t,e,n,o){const i=ts[n];return Rt(s*2+e,t,o^(n===0?40001:20343))*Po<i.connect}const Ye=[0,0],ue=[0,0];function Qa(s,t,e,n,o){cs(s,t,e,n,Ye);let i=0,a=0,c,r,l;On(s,t,0,e,n)&&(cs(s+1,t,e,n,ue),c=ue[0]-Ye[0],r=ue[1]-Ye[1],l=Math.hypot(c,r)||1,i+=c/l,a+=r/l),On(s-1,t,0,e,n)&&(cs(s-1,t,e,n,ue),c=Ye[0]-ue[0],r=Ye[1]-ue[1],l=Math.hypot(c,r)||1,i+=c/l,a+=r/l),On(s,t,1,e,n)&&(cs(s,t+1,e,n,ue),c=ue[0]-Ye[0],r=ue[1]-Ye[1],l=Math.hypot(c,r)||1,i+=c/l,a+=r/l),On(s,t-1,1,e,n)&&(cs(s,t-1,e,n,ue),c=Ye[0]-ue[0],r=Ye[1]-ue[1],l=Math.hypot(c,r)||1,i+=c/l,a+=r/l);const h=Math.hypot(i,a);if(h<1e-5){const u=Rt(s,t,n^15063)*Po*K;o[0]=Math.cos(u),o[1]=Math.sin(u)}else o[0]=i/h,o[1]=a/h;return o}const vn=[0,0],wn=[0,0],li=[0,0],bn=[0,0],Uh=[1,.72,.5,.34,.22],tr=70;function Hh(s,t){for(let e=0;e<48;e++){let n=!1;for(let o=1;o<t;o++){const i=s[o*2-2],a=s[o*2-1],c=s[o*2],r=s[o*2+1],l=s[o*2+2],h=s[o*2+3],u=c-i,d=r-a,f=l-c,p=h-r,g=Math.atan2(Math.abs(u*p-d*f),u*f+d*p),m=(Math.hypot(u,d)+Math.hypot(f,p))*.5;if(g*tr<=m)continue;const v=X(.5*(1-m/(g*tr)),.1,.5);s[o*2]=c+((i+l)*.5-c)*v,s[o*2+1]=r+((a+h)*.5-r)*v,n=!0}if(!n)break}}function Wh(s,t,e,n,o,i,a,c,r,l){const h=r*r,u=h*r,d=2*u-3*h+1,f=u-2*h+r,p=-2*u+3*h,g=u-h;return l[0]=d*s+f*e+p*o+g*a,l[1]=d*t+f*n+p*i+g*c,l}function $h(s,t,e,n,o,i,a,c,r,l){const h=r*r,u=6*h-6*r,d=3*h-4*r+1,f=-6*h+6*r,p=3*h-2*r;return l[0]=u*s+d*e+f*o+p*a,l[1]=u*t+d*n+f*i+p*c,l}function Kh(s,t,e,n,o,i,a,c,r){const l=e-s,h=n-t,u=o*r,d=i*r,f=a*r,p=c*r;let g=0;for(let m=0;m<=16;m++){const v=m/16,x=6*v-6*v*v,b=3*v*v-4*v+1,y=3*v*v-2*v,A=x*l+b*u+y*f,_=x*h+b*d+y*p,S=(6-12*v)*l+(6*v-4)*u+(6*v-2)*f,T=(6-12*v)*h+(6*v-4)*d+(6*v-2)*p,M=Math.hypot(A,_);if(M<1e-6)return 1/0;const k=Math.abs(A*T-_*S)/(M*M*M);k>g&&(g=k)}return g}const co=new Float32Array(128),Ts=new Float32Array(128);function qh(s,t,e,n,o,i,a,c){const r=ts[n],l=Rt(s*2+e,t,c^(n===0?1530731135:513636291)),h=Rt(t*2+e,s,c^746053899),u=Math.max(1,Math.round(o/(2*r.bend)));for(let A=0;A<=i;A++){const _=A/i;let S=Math.sin(K*u*_+(h&1023)/1023*K);for(let T=1;T<Bh;T++){const M=.42*((l>>>T*10&1023)/1023),k=(h>>>T*10&1023)/1023*K;S+=M*Math.sin(K*(u+T)*_+k)}co[A]=Math.tanh(2.4*S)}const d=1/i;let f=0,p=0;Ts[0]=0;for(let A=1;A<=i;A++){const _=f+(co[A-1]+co[A])*.5*d;p+=(f+_)*.5*d,f=_,Ts[A]=p}const g=f,m=Ts[i]-g*.5;let v=0,x=0;for(let A=0;A<=i;A++){const _=A/i,S=_*_,T=S*_,M=Ts[A]-g*S*.5-(-2*T+3*S)*m;Ts[A]=M,Math.abs(M)>x&&(x=Math.abs(M));const k=Math.abs(co[A]-g-(6-12*_)*m);k>v&&(v=k)}const b=1/r.radius*(.8+.2*((l&1023)/1023));let y=v>1e-9?b*o*o/v:0;x*y>a&&(y=a/Math.max(x,1e-9));for(let A=0;A<=i;A++)Ts[A]*=y}function jh(s,t,e,n,o){const i=ts[n],a=e===0?s+1:s,c=e===0?t:t+1,r=cs(s,t,n,o,[0,0]),l=cs(a,c,n,o,[0,0]),h=Math.hypot(l[0]-r[0],l[1]-r[1])||1;Qa(s,t,n,o,vn),Qa(a,c,n,o,wn);const u=h*Math.min(i.curve*2,1.25);let d=u,f=1/0;for(let T=0;T<5;T++){const M=u*Uh[T],k=Kh(r[0],r[1],l[0],l[1],vn[0],vn[1],wn[0],wn[1],M);if(k<f&&(f=k,d=M),k*Gh<=1)break}const p=vn[0]*d,g=vn[1]*d,m=wn[0]*d,v=wn[1]*d,x=X(Math.round(h/i.step),8,96),b=Math.min(i.swing*h,f>1e-9?.45/f:1/0);qh(s,t,e,n,h,x,b,o);const y=new Float32Array((x+1)*2);for(let T=0;T<=x;T++){const M=T/x;Wh(r[0],r[1],p,g,l[0],l[1],m,v,M,li),$h(r[0],r[1],p,g,l[0],l[1],m,v,M,bn);const k=Math.hypot(bn[0],bn[1])||1,R=-bn[1]/k,P=bn[0]/k,z=Ts[T];y[T*2]=li[0]+R*z,y[T*2+1]=li[1]+P*z}Hh(y,x);const _=1+((Rt(s*3+e,t*7,o^30657)&255)/255-.5)*.22,S={tier:n,pts:y,span:h/x,width:i.width*_,verge:i.verge,key:`${n}:${s},${t},${e}`,minX:0,maxX:0,minZ:0,maxZ:0,segs:x,blk:null};return Xh(S),S}const Vh=4096,lo=new Map;function Yh(s,t,e,n,o){const i=`${o}:${n}:${s},${t},${e}`;let a=lo.get(i);return a===void 0&&(a=jh(s,t,e,n,o),lo.size>=Vh&&lo.clear(),lo.set(i,a)),a}function ac(s){const t=s.pts.length/2;return{tier:s.tier,pts:s.pts,y:new Float32Array(t),water:new Float32Array(t),land:null,span:s.span,width:s.width,verge:s.verge,key:s.key,minX:s.minX,maxX:s.maxX,minZ:s.minZ,maxZ:s.maxZ,segs:s.segs,blk:s.blk}}const Ms=8;function Xh(s){let t=1/0,e=-1/0,n=1/0,o=-1/0;for(let r=0;r<s.pts.length;r+=2){const l=s.pts[r],h=s.pts[r+1];l<t&&(t=l),l>e&&(e=l),h<n&&(n=h),h>o&&(o=h)}s.minX=t,s.maxX=e,s.minZ=n,s.maxZ=o;const i=s.pts.length/2-1;s.segs=i;const a=Math.ceil(i/Ms),c=new Float32Array(a*4);for(let r=0;r<a;r++){const l=r*Ms,h=Math.min(i,l+Ms);let u=1/0,d=1/0,f=-1/0,p=-1/0;for(let g=l;g<=h;g++){const m=s.pts[g*2],v=s.pts[g*2+1];m<u&&(u=m),m>f&&(f=m),v<d&&(d=v),v>p&&(p=v)}c[r*4]=u,c[r*4+1]=d,c[r*4+2]=f,c[r*4+3]=p}s.blk=c}function er(s,t,e,n){let o=s[t]-e;o<0&&(o=e-s[t+2],o<0&&(o=0));let i=s[t+1]-n;return i<0&&(i=n-s[t+3],i<0&&(i=0)),o*o+i*i}function Ko(s,t,e,n,o,i=40){const a=[];for(let c=0;c<ts.length;c++){const r=ts[c],l=r.cell*(1+2*r.jitter),h=8/27*Math.min(r.curve*2,1.25)*l+r.swing*l,u=r.cell*(1+r.jitter)+h+i,d=Math.floor((s-u)/r.cell),f=Math.floor((e+u)/r.cell),p=Math.floor((t-u)/r.cell),g=Math.floor((n+u)/r.cell);for(let m=p;m<=g;m++)for(let v=d;v<=f;v++)for(let x=0;x<2;x++){if(!On(v,m,x,c,o))continue;const b=Yh(v,m,x,c,o),y=b.width*.5+b.verge+i;b.maxX<s-y||b.minX>e+y||b.maxZ<t-y||b.minZ>n+y||a.push(ac(b))}}return a}const re=18;function Zh(s,t,e,n,o){const i=1-2*o;for(let a=0;a<n;a++){for(let c=0;c<e;c++){const r=s[c>0?c-1:0],l=s[c],h=s[c<e-1?c+1:e-1];t[c]=r*o+l*i+h*o}s.set(t)}}function ko(s,t,e){return X(Math.round(s*s/(2*e*t*t)),1,160)}const ho=new Map,xn=[0,0],Jh=(()=>{const s=[[0,0,1]];for(let t=0;t<8;t++){const e=t/8*K;s.push([Math.cos(e)*.55,Math.sin(e)*.55,.5]),s.push([Math.cos(e+K/16),Math.sin(e+K/16),.22])}return s})();function sr(s,t,e,n,o,i){const a=`${i}:${e}:${s},${t}`,c=ho.get(a);if(c!==void 0)return c;cs(s,t,e,n,xn);const r=ts[e].grade*.5;let l=0,h=0;for(const[f,p,g]of Jh)l+=g*o(xn[0]+f*r,xn[1]+p*r),h+=g;const u=o(xn[0],xn[1]),d=X(l/h,u-re,u+re);return ho.size>=rc&&ho.clear(),ho.set(a,d),d}function Qh(s,t,e,n){const[o,i,a]=s.key.slice(s.key.indexOf(":")+1).split(",").map(Number),c=sr(o,i,s.tier,e,t,n),r=sr(a===0?o+1:o,a===0?i:i+1,s.tier,e,t,n),l=s.y.length,h=c-s.y[0],u=r-s.y[l-1];if(h===0&&u===0)return;const d=X(ts[s.tier].grade*2.6/Math.max(s.span,.001),2,(l-1)*.5);for(let f=0;f<l;f++){const p=1-mt(0,d,f),g=1-mt(0,d,l-1-f);s.y[f]+=h*p+u*g}}function tu(s,t,e=null,n=null,o=null){const i=s.y.length,a=new Float32Array(i);for(let u=0;u<i;u++)a[u]=t(s.pts[u*2],s.pts[u*2+1]);s.y.set(a),s.land=a;const c=s.water;for(let u=0;u<i;u++){const d=e?e(s.pts[u*2],s.pts[u*2+1]):null;c[u]=d===null?-1/0:d+1.1}const r=new Float32Array(i),l=ts[s.tier];Zh(s.y,r,i,ko(l.grade,s.span,.25),.25),o!==null&&Qh(s,t,n,o);for(let u=0;u<i;u++){const d=s.y[u]-a[u];d>re?s.y[u]=a[u]+re:d<-re&&(s.y[u]=a[u]-re),s.y[u]<c[u]&&(s.y[u]=c[u])}const h=ko(l.grade*.4,s.span,.2);for(let u=0;u<h;u++){for(let d=1;d<i-1;d++)r[d]=s.y[d-1]*.2+s.y[d]*.6+s.y[d+1]*.2;r[0]=s.y[0],r[i-1]=s.y[i-1],s.y.set(r)}if(e){for(let d=0;d<i;d++)s.y[d]<c[d]&&(s.y[d]=c[d]);const u=ko(l.grade*.4,s.span,.25);for(let d=0;d<u;d++){for(let f=1;f<i-1;f++){const p=s.y[f-1]*.25+s.y[f]*.5+s.y[f+1]*.25;r[f]=p>c[f]?p:c[f]}r[0]=s.y[0],r[i-1]=s.y[i-1],s.y.set(r)}}return s}const eu=24,nr=80,rc=4096,or=new Map,Ki=new Map,hi=new Map;function Wn(s,t,e){return s.size>=rc&&s.clear(),s.set(t,e),e}function su(s,t,e,n=null){const o=dc(s,cc(t,e,n),t,e,n);return s.y.set(o.y),s.water.set(o.water),s}function cc(s,t,e){return`${s}|${e?"w":"d"}|${Math.round(t(0,0)*64)}|${Math.round(t(1237.5,-911.25)*64)}`}const nu=(s,t)=>s.key<t.key?-1:s.key>t.key?1:0;function $n(s,t,e,n,o){const i=`${t}:${s.key}`,a=or.get(i);return a||(tu(s,n,o,e,t),Wn(or,i,{y:Float32Array.from(s.y),water:Float32Array.from(s.water),land:Float32Array.from(s.land)}))}function lc(s,t){s.y.set(t.y),s.water.set(t.water),s.land=t.land}function hc(s,t){const e=ac(s);return e.y.set(t.y),e.water.set(t.water),e.land=t.land,e}function uc(s,t){const e=Ko(s.minX,s.minZ,s.maxX,s.maxZ,t,eu),n=[];for(const o of e)o.key!==s.key&&n.push(o);return n.sort(nu),n}function ou(s,t,e,n,o){if(s.tier===0)return $n(s,t,e,n,o).y;const i=`${t}:${s.key}`,a=Ki.get(i);if(a)return a;const c=$n(s,t,e,n,o),r=hc(s,c),l=uc(s,e).filter(h=>h.tier===0);for(const h of l)lc(h,$n(h,t,e,n,o));return qi(r,l,l.length),Wn(Ki,i,r.y)}function dc(s,t,e,n,o){const i=`${t}:${s.key}`,a=hi.get(i);if(a)return a;const c=$n(s,t,e,n,o);if(s.tier===0)return Wn(hi,i,{y:c.y,water:c.water});const r=[],l=[];for(const p of uc(s,e))p.tier===0?r.push(p):p.key<s.key&&l.push(p);const h=hc(s,c);for(const p of r)lc(p,$n(p,t,e,n,o));qi(h,r,r.length),Wn(Ki,i,Float32Array.from(h.y));for(const p of l)p.y.set(ou(p,t,e,n,o));qi(h,l,l.length);const u=h.y,d=c.water,f=c.land;for(let p=0;p<u.length;p++){const g=u[p]-f[p];g>re?u[p]=f[p]+re:g<-re&&(u[p]=f[p]-re),u[p]<d[p]&&(u[p]=d[p])}return Wn(hi,i,{y:u,water:d})}class qo{constructor(t,e,n,o,i,a,c=60,r=null){this.edges=Ko(t,e,n,o,i,Math.max(c,nr)),this.seed=i,this._land=a;const l=cc(i,a,r);for(const h of this.edges){const u=dc(h,l,i,a,r);h.y.set(u.y),h.water.set(u.water)}}static forEdge(t,e,n,o=null){return new qo(t.minX,t.minZ,t.maxX,t.maxZ,e,n,nr,o)}query(t,e){let n=1/0,o=0,i=0,a=0,c=1,r=0,l=0,h=0,u=null;for(const d of this.edges){const f=d.width*.5+d.verge+30;if(t<d.minX-f||t>d.maxX+f||e<d.minZ-f||e>d.maxZ+f)continue;const p=d.pts,g=d.blk;for(let m=0;m<g.length;m+=4){if(er(g,m,t,e)>=n*n)continue;const v=(m>>2)*Ms,x=Math.min(d.segs,v+Ms);for(let b=v;b<x;b++){const y=p[b*2],A=p[b*2+1],_=p[b*2+2],S=p[b*2+3],T=Ui(t,e,y,A,_,S);if(T.d<n){n=T.d,o=O(d.y[b],d.y[b+1],T.t),i=d.width,a=d.tier;const M=_-y,k=S-A,R=Math.hypot(M,k)||1;c=M/R,r=k/R,l=T.x,h=T.z,u=d}}}}return{d:n,y:o,width:i,tier:a,tx:c,tz:r,qx:l,qz:h,edge:u}}carve(t,e,n={mask:0,y:0,edge:0,d:1/0,tier:0,tx:1,tz:0,width:0,land:NaN}){let o=0,i=0,a=0,c=0,r=0,l=1/0,h=0,u=1,d=0,f=NaN;for(const p of this.edges){const g=p.width*.5,m=g+p.verge*2.6+60;if(t<p.minX-m||t>p.maxX+m||e<p.minZ-m||e>p.maxZ+m)continue;const v=p.pts,x=p.blk;let b=1/0,y=0,A=1,_=0,S=m*m;for(let k=0;k<x.length;k+=4){if(er(x,k,t,e)>=S)continue;const R=(k>>2)*Ms,P=Math.min(p.segs,R+Ms);for(let z=R;z<P;z++){const L=v[z*2],U=v[z*2+1],W=v[z*2+2],I=v[z*2+3],H=Ui(t,e,L,U,W,I);if(H.d<b){b=H.d,S=b*b,y=O(p.y[z],p.y[z+1],H.t);const V=W-L,D=I-U,$=Math.hypot(V,D)||1;A=V/$,_=D/$}}}if(b>m)continue;b<l&&(l=b,h=p.tier,u=A,d=_);let T=1;if(b>g){f!==f&&(f=this._land(t,e));const k=Math.abs(y-f),R=g+3+Math.min(k,re+4)*1.6;if(T=1-mt(g,R,b),T<=5e-4)continue}o+=T,i+=T*y,a+=T*p.width,c=Math.max(c,T);const M=1-mt(g-.4,g+.35,b);M>r&&(r=M)}return n.d=l,n.tier=h,n.tx=u,n.tz=d,n.width=o>1e-6?a/o:0,n.mask=c,n.edge=r,n.y=o>1e-6?i/o:0,n.land=f,n}}function fc(s){if(s.edge<=.001)return 0;const t=s.width*.5,e=N(t>0?s.d/t:0);return s.edge*e*e*.18}function qi(s,t,e){if(!e)return;const n=[];let o=0;for(let u=0;u<e;u++){const d=t[u],f=d.width*.5+14;s.maxX<d.minX-f||s.minX>d.maxX+f||s.maxZ<d.minZ-f||s.minZ>d.maxZ+f||(n[o++]=d)}if(!o)return;const i=s.y.length,a=new Float32Array(i),c=new Float32Array(i);for(let u=0;u<i;u++){const d=s.pts[u*2],f=s.pts[u*2+1];let p=1/0,g=0;for(let m=0;m<o;m++){const v=n[m],x=v.width*.5+14;if(d<v.minX-x||d>v.maxX+x||f<v.minZ-x||f>v.maxZ+x)continue;const b=v.pts.length/2-1;for(let y=0;y<b;y++){const A=Ui(d,f,v.pts[y*2],v.pts[y*2+1],v.pts[y*2+2],v.pts[y*2+3]);A.d<p&&(p=A.d,g=O(v.y[y],v.y[y+1],A.t))}}if(p<18){const m=1-mt(4,18,p),v=s.land?s.land[u]:s.y[u],x=X(g,v-re,v+re);a[u]=x-s.y[u],c[u]=m}}const r=new Float32Array(i);for(let u=0;u<i;u++)r[u]=a[u]*c[u];const l=new Float32Array(i),h=ko(85,s.span,.3);for(let u=0;u<h;u++){for(let d=0;d<i;d++){const f=r[d>0?d-1:0],p=r[d],g=r[d<i-1?d+1:i-1];l[d]=c[d]>.75?p:f*.3+p*.4+g*.3}r.set(l)}for(let u=0;u<i;u++)s.y[u]+=r[u]}const rn=3600,iu=5.2,au=6.8,ir=90,ru=330,pc={scale:1};function cu(s){pc.scale=Number.isFinite(s)&&s>=0?s:1}const lu=1/4294967296;function mc(s,t,e,n){const o=Rt(s,t,e^1735987),i=Rt(s,t,e^7848283),a=.18+.64*((o&65535)/65536),c=.18+.64*((o>>>16&65535)/65536),r=i*lu,l=ir+(ru-ir)*Math.pow(r,1.45),h=O(iu,au,(i>>>9&1023)/1023),u=pc.scale;return n.x=(s+a)*rn,n.z=(t+c)*rn,n.h=l*u,n.r=l*h*(u<=1?.62+.38*u:Math.pow(u,.94)),n}const hu={x:0,z:0,h:0,r:0};function uu(s,t,e,n={h:0,cover:0,top:0}){const o=Math.floor(s/rn),i=Math.floor(t/rn);let a=0,c=0,r=0;for(let l=-1;l<=1;l++)for(let h=-1;h<=1;h++){const u=mc(o+h,i+l,e,hu),d=s-u.x,f=t-u.z,p=d*d+f*f,g=u.r*u.r;if(p>=g)continue;const m=1-p/g,v=m*m;a+=u.h*v,v>c&&(c=v),u.h>r&&(r=u.h)}return n.h=a,n.cover=c,n.top=r,n}const du={h:0,cover:0,top:0},ar=1/940,fu=.055;function pu(s,t,e){const n=uu(s,t,e,du);if(n.h<=.01)return 0;const o=Io(s*ar,t*ar,3,e^20967,2.1,.32);return n.h+o*n.top*fu*mt(0,.22,n.cover)}function rr(s,t,e){const n=Math.floor(s/rn),o=Math.floor(t/rn);let i=null;for(let a=-1;a<=1;a++)for(let c=-1;c<=1;c++){const r=mc(n+c,o+a,e,{x:0,z:0,h:0,r:0}),l=Math.hypot(s-r.x,t-r.z);(!i||l<i.d)&&(i={x:r.x,z:r.z,h:r.h,r:r.r,d:l,maxGrade:1.5396*r.h/r.r})}return i}const mu=new Float32Array(_t),cr=.015,gu=.055,vu=1.6;function wu(s,t,e){return 1-mt(s,t,e)}function bu(s,t,e=1){if(s.mask<=.001)return t;const n=s.y,o=Math.abs(t-n),i=s.width*.5,a=i+3+o*vu,c=wu(i,a,s.d)*N(e);return O(t,n,c)-fc(s)}function Kn(s,t,e,n){let o=0,i=0;for(let a=0;a<_t;a++){const c=n[a];if(c<cr)continue;const r=c*mt(cr,gu,c);r<=0||(o+=r*Nh(s,t,e,a),i+=r)}return i>0&&(o/=i),o+=pu(s,t,e),o+$t(s*.03,t*.03,3,e^7949,2,.3)*.55}function Xn(s,t,e){const{w:n}=fa(s,t,e,mu);return Kn(s,t,e,n)}const pa=s=>(t,e)=>Xn(t,e,s),jo=s=>(t,e)=>{const{w:n}=fa(t,e,s,xu);return Ls(n,Kn(t,e,s,n))},xu=new Float32Array(_t),Fe=48;class yu{constructor(t,e,n,o,i,a=128){this.seed=t,this.x0=Math.floor((e-a)/Fe)*Fe,this.z0=Math.floor((n-a)/Fe)*Fe,this.nx=Math.ceil((o+a-this.x0)/Fe)+2,this.nz=Math.ceil((i+a-this.z0)/Fe)+2;const c=this.nx*this.nz;this.ue=new Float32Array(c),this.ua=new Float32Array(c),this.ut=new Float32Array(c);for(let r=0;r<this.nz;r++)for(let l=0;l<this.nx;l++){const h=sc(this.x0+l*Fe,this.z0+r*Fe,t),u=r*this.nx+l;this.ue[u]=h.ue,this.ua[u]=h.ua,this.ut[u]=h.ut}this._out={ue:0,ua:0,ut:0,e:0,t:0,m:0}}sample(t,e){const n=(t-this.x0)/Fe,o=(e-this.z0)/Fe;let i=Math.floor(n),a=Math.floor(o);i<0?i=0:i>this.nx-2&&(i=this.nx-2),a<0?a=0:a>this.nz-2&&(a=this.nz-2);const c=N(n-i),r=N(o-a),l=a*this.nx+i,h=l+1,u=l+this.nx,d=u+1,f=g=>O(O(g[l],g[h],c),O(g[u],g[d],c),r),p=this._out;return p.ue=f(this.ue),p.ua=f(this.ua),p.ut=f(this.ut),p}}class Re{constructor(t,e,n,o,i,a=80){this.seed=t,this.climate=new yu(t,e,n,o,i,a+64),this.roads=new qo(e,n,o,i,t,pa(t),a,jo(t)),this._carve={mask:0,y:0,edge:0,d:1/0,tier:0,tx:1,tz:0,width:0},this._wl=new Float32Array(_t)}weights(t,e,n=this._wl){return $i(this.climate.sample(t,e),n)}land(t,e){const{w:n}=this.weights(t,e);return Kn(t,e,this.seed,n)}height(t,e){const n=this.roads.carve(t,e,this._carve),{w:o}=this.weights(t,e);if(n.mask<=.001)return Kn(t,e,this.seed,o);let i=0;for(let a=0;a<_t;a++)i+=o[a]*Be[a].drive;return n.d<=n.width*.5&&i>=.99999?n.y-fc(n):bu(n,Kn(t,e,this.seed,o),i)}normal(t,e,n=.6,o=[0,1,0]){const i=this.height(t-n,e),a=this.height(t+n,e),c=this.height(t,e-n),r=this.height(t,e+n),l=i-a,h=c-r,u=2*n,d=Math.hypot(l,u,h)||1;return o[0]=l/d,o[1]=u/d,o[2]=h/d,o}surface(t,e,n=null){const o=n||(this._surf||={y:0,nx:0,ny:1,nz:0,w:new Float32Array(_t),dominant:0,onRoad:0,roadDist:1/0,roadTier:0,roadTx:1,roadTz:0,grip:1,rough:0,surfaceKind:"grass"}),i=$i(this.climate.sample(t,e),o.w);o.dominant=i.dominant,o.y=this.height(t,e);const a=this.normal(t,e);o.nx=a[0],o.ny=a[1],o.nz=a[2];const c=this.roads.carve(t,e,this._carve);o.onRoad=c.edge,o.roadDist=c.d,o.roadTier=c.tier,o.roadTx=c.tx,o.roadTz=c.tz;let r=0,l=0;for(let d=0;d<_t;d++)r+=o.w[d]*ci[d].grip,l+=o.w[d]*ci[d].rough;const h=O(.52,.72,o.w[0]+o.w[4]),u=O(.85,.45,o.w[0]);return o.grip=O(h,r,o.onRoad),o.rough=O(u,l,o.onRoad),o.surfaceKind=o.onRoad>.5?ci[i.dominant].surface:"ground",o}quickHeight(t,e){return this.height(t,e)}}const ma=.5;function ga(s,t,e,n=s.height(t,e)){const{w:o}=s.weights(t,e),i=Ls(o,-1/0);return i===null?1/0:n-i}function _u(s,t,e,n=s.height(t,e)){return ga(s,t,e,n)>=ma}function Tu(s,t,e){const n=new Re(e,s-60,t-60,s+60,t+60,20);return _u(n,s,t)}function Au(s,t=0,e=0){let a=3e3,c=new Re(s,t-a,e-a,t+a,e+a,120),r=null;const l=(u,d)=>{const f=c.height(u,d),p=ga(c,u,d,f);return(!r||p>r.margin)&&(r={x:u,z:d,y:f,margin:p}),p>=ma?{x:u,z:d,y:f}:null},h=l(t,e);if(h)return{...h,heading:0,score:0};for(let u=1;u<=64;u++){const d=u*150;d>a-200&&(a=d+3e3,c=new Re(s,t-a,e-a,t+a,e+a,120));for(let f=0;f<16;f++){const p=f/16*Math.PI*2,g=l(t+Math.cos(p)*d,e+Math.sin(p)*d);if(g)return{...g,heading:0,score:0}}}return{x:r.x,z:r.z,y:r.y,heading:0,score:0}}function lr(s,t=0,e=0){const o=new Re(s,t-3e3,e-3e3,t+3e3,e+3e3,120);let i=null;for(const a of o.roads.edges){if(a.tier!==0)continue;const c=a.pts.length/2;for(let r=1;r<c-1;r++){const l=a.pts[r*2],h=a.pts[r*2+1],u=Math.abs(a.y[r+1]-a.y[r-1])/(2*a.span),d=Math.hypot(l-t,h-e),f=mt(.045,.13,u)*900+d*.012;if(i&&f>=i.score)continue;const p=o.height(l,h);if(ga(o,l,h,p)<ma)continue;const g=a.pts[r*2+2]-a.pts[r*2-2],m=a.pts[r*2+3]-a.pts[r*2-1];i={x:l,z:h,y:p,heading:Math.atan2(g,m),score:f}}}return i||Au(s,t,e)}const Nn=64,Mu=8,Su=30,ku=s=>s<=2?65:33,Eu=65,ds=s=>Nn*(1<<s);function Ru(s){const{cx:t,cz:e,level:n,seed:o}=s,i=ds(n),a=ku(n),c=t*i,r=e*i,l=i/(a-1),h=new Re(o,c,r,c+i,r+i,Math.max(80,l*3)),u=a*a,d=(a-1)*4,f=u+d,p=new Float32Array(f*3),g=new Float32Array(f*3),m=new Uint8Array(f*4),v=new Uint8Array(f*2),x=new Float32Array(u);let b=1/0,y=-1/0,A=1/0,_=-1/0,S=!1;const T=new Float32Array(_t),M={mask:0,y:0,edge:0,d:1/0,tier:0,tx:1,tz:0,width:0};for(let D=0;D<a;D++){const $=r+D*l;for(let q=0;q<a;q++){const Q=c+q*l,ot=D*a+q,ht=h.height(Q,$);x[ot]=ht,ht<b&&(b=ht),ht>y&&(y=ht),p[ot*3]=q*l,p[ot*3+1]=ht,p[ot*3+2]=D*l,h.weights(Q,$,T),m[ot*4]=T[0]*255|0,m[ot*4+1]=T[1]*255|0,m[ot*4+2]=T[2]*255|0,m[ot*4+3]=T[3]*255|0,h.roads.carve(Q,$,M),v[ot*2]=N(M.mask)*255|0,v[ot*2+1]=N(M.edge)*255|0;const rt=Ls(T,ht);rt!==null&&(S=!0,rt<A&&(A=rt),rt>_&&(_=rt))}}for(let D=0;D<a;D++)for(let $=0;$<a;$++){const q=D*a+$,Q=x[D*a+Math.max(0,$-1)],ot=x[D*a+Math.min(a-1,$+1)],ht=x[Math.max(0,D-1)*a+$],rt=x[Math.min(a-1,D+1)*a+$],Tt=$===0||$===a-1?l:l*2,Pt=D===0||D===a-1?l:l*2;let Wt=(Q-ot)/Tt,Ot=(ht-rt)/Pt;const le=Math.hypot(Wt,1,Ot);g[q*3]=Wt/le,g[q*3+1]=1/le,g[q*3+2]=Ot/le}const R=(a-1)*(a-1)*6+d*6,P=f>65535?Uint32Array:Uint16Array,z=new P(R);let L=0;for(let D=0;D<a-1;D++)for(let $=0;$<a-1;$++){const q=D*a+$,Q=q+1,ot=q+a,ht=ot+1;(($^D)&1)===0?(z[L++]=q,z[L++]=ot,z[L++]=Q,z[L++]=Q,z[L++]=ot,z[L++]=ht):(z[L++]=q,z[L++]=ot,z[L++]=ht,z[L++]=q,z[L++]=ht,z[L++]=Q)}let U=u;const W=D=>{const $=D*3;return p[U*3]=p[$],p[U*3+1]=p[$+1]-Su,p[U*3+2]=p[$+2],g[U*3]=g[$],g[U*3+1]=g[$+1],g[U*3+2]=g[$+2],m[U*4]=m[D*4],m[U*4+1]=m[D*4+1],m[U*4+2]=m[D*4+2],m[U*4+3]=m[D*4+3],v[U*2]=v[D*2],v[U*2+1]=v[D*2+1],U++},I=[];for(let D=0;D<a-1;D++)I.push(D);for(let D=0;D<a-1;D++)I.push(D*a+(a-1));for(let D=a-1;D>0;D--)I.push((a-1)*a+D);for(let D=a-1;D>0;D--)I.push(D*a);const H=I.map(W);for(let D=0;D<I.length;D++){const $=I[D],q=I[(D+1)%I.length],Q=H[D],ot=H[(D+1)%I.length];z[L++]=$,z[L++]=Q,z[L++]=q,z[L++]=q,z[L++]=Q,z[L++]=ot}let V=null;return S&&(V={level:(A+_)*.5,minY:b,maxY:y}),{cx:t,cz:e,level:n,size:i,ox:c,oz:r,step:l,grid:a,minY:b,maxY:y,vertCount:f,position:p,normal:g,biome:m,road:v,index:z,heights:n===0?x:null,water:V}}const Zn=2,ji=0,gc=["trees","rocks","bushes","reeds","posts","flowers"],zu={trees:1414677829,rocks:1380926283,bushes:1112888136,reeds:1380271428,posts:1347375956,flowers:1179406167},hr=1/1250,ur=1/265,Vo=3.4,Cu=-.09,dr=.08,Lu=.24;function Fu(s,t,e){const n=e^983333|0,o=ec(s*hr,t*hr,4,n,.75),i=$t(s*ur,t*ur,3,n^20958|0);return o+i*.2}function Oo(s,t,e){const n=Fu(s,t,e),o=mt(Cu,dr,n),i=mt(dr,Lu,n);return o*(1+(Vo-1)*i)}const No=.5,Du=No+(1-No)*Vo,fr=1/175,pr=1/46,vc=6,Iu=-.02,Pu=.62;function Ou(s,t,e){const n=e^6426637|0,o=$t(s*fr,t*fr,3,n),i=$t(s*pr,t*pr,2,n^12049|0),a=mt(Iu,Pu,o+i*.28);return a<=0?0:a*a*vc*(1-Bn(s,t,e)*.7)}function Bn(s,t,e){return N((Oo(s,t,e)-1)/(Vo-1))}const mr=1/320,gr=1/240;function Nu(s,t,e){const n=we(s*mr,t*mr,e^45312|0);return mt(-.34,.3,n)*.88}const Ss=5;function Bu(s,t,e){const n=we(s*gr,t*gr,e^96387557|0)*.5+.5,o=N(n)*Ss|0;return o>=Ss?Ss-1:o}const vr={trees:Oo,bushes:(s,t,e)=>No+(1-No)*Oo(s,t,e),flowers:Ou,rocks:null,reeds:null,posts:null},va={trees:Vo,bushes:Du,flowers:vc,rocks:1,reeds:1,posts:1},Gu={trees:32,bushes:32,flowers:8};function wr(s,t,e,n,o,i){const a=Math.floor(n/t),c=Math.floor(o/t),r=Math.floor((n+i)/t)-a+2,l=Math.floor((o+i)/t)-c+2,h=new Float32Array(r*l);for(let u=0;u<l;u++)for(let d=0;d<r;d++)h[u*r+d]=s((a+d)*t,(c+u)*t,e);return{v:h,i0:a,j0:c,nx:r,nz:l,step:t}}function br(s,t,e){const n=t/s.step-s.i0,o=e/s.step-s.j0;let i=n|0,a=o|0;i>s.nx-2&&(i=s.nx-2),a>s.nz-2&&(a=s.nz-2);const c=n-i,r=o-a,l=a*s.nx+i,h=s.v[l]+(s.v[l+1]-s.v[l])*c,u=s.v[l+s.nx]+(s.v[l+s.nx+1]-s.v[l+s.nx])*c;return h+(u-h)*r}const Uu={flowers:12},ui={y:0,ny:1};function Hu(s,t,e){const n=t/s.step-s.i0,o=e/s.step-s.j0;let i=n|0,a=o|0;i>s.nx-2&&(i=s.nx-2),a>s.nz-2&&(a=s.nz-2);const c=n-i,r=o-a,l=a*s.nx+i,h=s.v[l],u=s.v[l+1],d=s.v[l+s.nx],f=s.v[l+s.nx+1];ui.y=(h+(u-h)*c)*(1-r)+(d+(f-d)*c)*r;const p=((u-h)*(1-r)+(f-d)*r)/s.step,g=((d-h)*(1-c)+(f-u)*c)/s.step;return ui.ny=1/Math.hypot(p,1,g),ui}const Wu=300,Yo=$o.map(s=>Object.assign({},s,{flowers:Wu*s.grass})),$u=.7,Ku=34,qu=6,Eo={},wc={},bc={};for(const s of gc){let t=0;for(let e=0;e<_t;e++)t=Math.max(t,Yo[e][s]);t*=va[s],Eo[s]=s==="posts"?Ku:Math.sqrt(1e4*$u/t),wc[s]=Eo[s]*Eo[s],bc[s]=s==="posts"?qu:1}const ju={trees:Math.cos(34*_s),rocks:Math.cos(58*_s),bushes:Math.cos(42*_s),reeds:Math.cos(12*_s),posts:Math.cos(24*_s),flowers:Math.cos(30*_s)},yn=.15,xc=26,Vu=1.6,uo=2,Yu={trees:(s,t,e)=>s<=yn&&t>=e*.5+2.5,bushes:(s,t,e)=>s<=yn&&t>=e*.5+1.4,rocks:(s,t,e)=>s<=yn&&t>=e*.5+1.2,reeds:s=>s<=yn,posts:(s,t)=>s<=.05&&t<=xc,flowers:s=>s<=yn},Xu={trees:(s,t)=>t===null||s>=t+.9,bushes:(s,t)=>t===null||s>=t+.5,rocks:(s,t)=>t===null||s>=t-.6,posts:(s,t)=>t===null||s>=t+.3,reeds:(s,t)=>t!==null&&t-s<=Vu&&t-s>=-.35,flowers:(s,t)=>t===null||s>=t+.25};function Zu(s,t){let e=0;for(let n=0;n<_t;n++)if(e+=s[n],t<e)return n;return _t-1}function Bs(s,t,e,n,o,i,a,c,r){const l=Eo[s],h=wc[s],u=bc[s],d=zu[s],f=ju[s],p=Yu[s],g=Xu[s],m=vr[s]===null?null:wr(vr[s],Gu[s],e,n,o,i),v=Uu[s]||0;let x=null;const b=Math.floor(n/l),y=Math.floor((n+i-1e-6)/l),A=Math.floor(o/l),_=Math.floor((o+i-1e-6)/l);for(let S=A;S<=_;S++)for(let T=b;T<=y;T++){if(m!==null&&br(m,(T+.5)*l,(S+.5)*l)<=0)continue;const M=Ee(Es(T,S,d,e)),k=(T+M())*l,R=(S+M())*l;if(k<n||k>=n+i||R<o||R>=o+i)continue;const P=m===null?1:br(m,k,R);if(P<=0)continue;const z=t.weights(k,R);a.set(z.w);const L=z.dominant,U=ic(a,Yo,s)*P;if(M()>=U*h*u/1e4)continue;const W=t.roads.carve(k,R);if(!p(W.edge,W.d,W.width))continue;let I=null,H;v!==0?(x===null&&(x=wr(($,q)=>t.height($,q),v,e,n,o,i)),I=Hu(x,k,R),H=I.y):H=t.height(k,R);const V=Ls(a,-1/0);if(!g(H,V))continue;let D;if(I!==null)D=I.ny;else{const $=(H-t.height(k+uo,R))/uo,q=(H-t.height(k,R+uo))/uo;D=1/Math.hypot($,1,q)}D<f||(c.x=k,c.z=R,c.y=H,c.ny=D,c.dominant=L,c.wy=V,c.onRoad=W.edge,c.roadD=W.d,c.roadW=W.width,c.roadTx=W.tx,c.roadTz=W.tz,r(c,M))}}function yc({cx:s,cz:t,level:e,seed:n}){const o={trees:[],rocks:[],bushes:[],reeds:[],posts:[],flowers:[]};if(!(e>=0)||e>Zn)return o;const i=ds(e),a=s*i,c=t*i,r=new Re(n,a,c,a+i,c+i,Math.max(xc+16,i*.25)),l=new Float32Array(_t),h={x:0,z:0,y:0,ny:1,wy:null,dominant:0,onRoad:0,roadD:1/0,roadW:0,roadTx:1,roadTz:0};return Bs("trees",r,n,a,c,i,l,h,(u,d)=>{const f=$o[Zu(l,d())].kinds;o.trees.push({x:u.x,y:u.y,z:u.z,yaw:d()*K,scale:.72+d()*.66,kind:f[d()*f.length|0],hue:d(),biome:u.dominant})}),Bs("bushes",r,n,a,c,i,l,h,(u,d)=>{o.bushes.push({x:u.x,y:u.y,z:u.z,yaw:d()*K,scale:.62+d()*.7,kind:"scrub",hue:d(),biome:u.dominant})}),Bs("rocks",r,n,a,c,i,l,h,(u,d)=>{const f=d();o.rocks.push({x:u.x,y:u.y,z:u.z,yaw:d()*K,scale:.34+Math.pow(d(),2.4)*3.1,kind:f<.58?"boulder":f<.86?"slab":"shard",tilt:(d()-.5)*(f<.58?.5:f<.86?.9:.3),hue:d(),biome:u.dominant})}),Bs("reeds",r,n,a,c,i,l,h,(u,d)=>{o.reeds.push({x:u.x,y:u.y,z:u.z,yaw:d()*K,scale:.6+d()*.7,kind:"reed",hue:d(),depth:u.wy-u.y,biome:u.dominant})}),Bs("posts",r,n,a,c,i,l,h,(u,d)=>{const f=u.roadD<u.roadW*.5+3.5;o.posts.push({x:u.x,y:u.y,z:u.z,yaw:f?Math.atan2(u.roadTx,u.roadTz)+Math.PI*.5:d()*K,scale:f?.85+d()*.3:.7+d()*.5,kind:f?d()<.12?"milestone":"marker":"fence",lean:(d()-.5)*.16,hue:d(),biome:u.dominant})}),e<=ji&&Bs("flowers",r,n,a,c,i,l,h,(u,d)=>{const f=d()<Nu(u.x,u.z,n),p=Bu(u.x,u.z,n),g=f?p>=Ss-1?"spire":"daisy":"tuft";o.flowers.push({x:u.x,y:u.y,z:u.z,yaw:d()*K,scale:.74+d()*.52,kind:g,species:p,hue:d(),biome:u.dominant})}),o}function Ju(s){if(!(s>=0)||s>Zn)return 0;const t=ds(s)*ds(s);let e=0;for(const n of gc){if(n==="flowers")continue;let o=0;for(let i=0;i<_t;i++)o=Math.max(o,Yo[i][n]);e+=o*va[n]}return Math.ceil(e*t/1e4)}function Qu(){const s=ds(ji)*ds(ji);let t=0;for(let e=0;e<_t;e++)t=Math.max(t,Yo[e].flowers);return Math.ceil(t*va.flowers*s/1e4)}const w={MATTE:0,METAL:1,EMIT:2,GLASS:3,LAMP_A:4,LAMP_B:5,LAMP_C:6,BODY:7},B=s=>ge[s],Ue=(s,t)=>[s[0]*t,s[1]*t,s[2]*t],ut=(s,t,e)=>[O(s[0],t[0],e),O(s[1],t[1],e),O(s[2],t[2],e)];function Xt(){return{pos:[],nrm:[],col:[],mat:[],idx:[],n:0}}function Mt(s,t,e,n,o,i,a,c,r){return s.pos.push(t,e,n),s.nrm.push(o,i,a),s.col.push(c[0],c[1],c[2]),s.mat.push(r||0),s.n++}function Rs(s,t,e,n,o){s.idx.push(t,e,n,t,n,o)}function Jn(s,t,e,n){s.idx.push(t,e,n)}function tn(s,t,e,n){return[s*e-t*n,s*n+t*e]}function E(s,t,e,n,o,i,a,c,r,l){const h=Math.cos(c),u=Math.sin(c),d=(g,m,v)=>{const[x,b]=tn(g*o,v*a,h,u);return[t+x,e+m*i,n+b]},f=(g,m)=>{const[v,x]=tn(g,m,h,u);return[v,0,x]},p=[{q:[[1,-1,-1],[1,-1,1],[1,1,1],[1,1,-1]],n:f(1,0)},{q:[[-1,-1,1],[-1,-1,-1],[-1,1,-1],[-1,1,1]],n:f(-1,0)},{q:[[-1,1,-1],[1,1,-1],[1,1,1],[-1,1,1]],n:[0,1,0]},{q:[[-1,-1,1],[1,-1,1],[1,-1,-1],[-1,-1,-1]],n:[0,-1,0]},{q:[[-1,-1,1],[-1,1,1],[1,1,1],[1,-1,1]],n:f(0,1)},{q:[[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,-1]],n:f(0,-1)}];for(const g of p){const m=g.q.map(v=>{const x=d(v[0],v[1],v[2]);return Mt(s,x[0],x[1],x[2],g.n[0],g.n[1],g.n[2],r,l)});Rs(s,m[0],m[1],m[2],m[3])}}function C(s,t,e,n,o,i,a,c,r,l){let h=[e[0]-t[0],e[1]-t[1],e[2]-t[2]];const u=Math.hypot(h[0],h[1],h[2])||1;h=[h[0]/u,h[1]/u,h[2]/u];let d=[0,1,0];Math.abs(h[1])>.94&&(d=[1,0,0]);let f=[h[1]*d[2]-h[2]*d[1],h[2]*d[0]-h[0]*d[2],h[0]*d[1]-h[1]*d[0]];const p=Math.hypot(f[0],f[1],f[2])||1;f=[f[0]/p,f[1]/p,f[2]/p];const g=[h[1]*f[2]-h[2]*f[1],h[2]*f[0]-h[0]*f[2],h[0]*f[1]-h[1]*f[0]],m=[],v=[];for(let x=0;x<i;x++){const b=x/i*K,y=Math.cos(b),A=Math.sin(b),_=f[0]*y+g[0]*A,S=f[1]*y+g[1]*A,T=f[2]*y+g[2]*A;m.push(Mt(s,t[0]+_*n,t[1]+S*n,t[2]+T*n,_,S,T,a,c)),v.push(Mt(s,e[0]+_*o,e[1]+S*o,e[2]+T*o,_,S,T,a,c))}for(let x=0;x<i;x++){const b=(x+1)%i;Rs(s,m[x],v[x],v[b],m[b])}if(l){const x=Mt(s,e[0],e[1],e[2],h[0],h[1],h[2],a,c);for(let b=0;b<i;b++){const y=(b+1)%i,A=Mt(s,s.pos[v[b]*3],s.pos[v[b]*3+1],s.pos[v[b]*3+2],h[0],h[1],h[2],a,c),_=Mt(s,s.pos[v[y]*3],s.pos[v[y]*3+1],s.pos[v[y]*3+2],h[0],h[1],h[2],a,c);Jn(s,x,A,_)}}if(r){const x=Mt(s,t[0],t[1],t[2],-h[0],-h[1],-h[2],a,c);for(let b=0;b<i;b++){const y=(b+1)%i,A=Mt(s,s.pos[m[b]*3],s.pos[m[b]*3+1],s.pos[m[b]*3+2],-h[0],-h[1],-h[2],a,c),_=Mt(s,s.pos[m[y]*3],s.pos[m[y]*3+1],s.pos[m[y]*3+2],-h[0],-h[1],-h[2],a,c);Jn(s,x,_,A)}}}function Xo(s,t,e,n,o,i,a,c,r,l){const h=Math.cos(c),u=Math.sin(c),d=(k,R,P)=>{const[z,L]=tn(k,P,h,u);return[t+z,e+R,n+L]},f=d(-o,0,-i),p=d(o,0,-i),g=d(o,0,i),m=d(-o,0,i),v=d(-o,a,0),x=d(o,a,0),b=k=>{const R=[0,i,k*a],P=Math.hypot(R[1],R[2])||1,[z,L]=tn(0,R[2]/P,h,u);return[z,R[1]/P,L]},y=b(-1),A=b(1);let _=[f,p,x,v].map(k=>Mt(s,k[0],k[1],k[2],y[0],y[1],y[2],r,l));Rs(s,_[0],_[1],_[2],_[3]),_=[m,v,x,g].map(k=>Mt(s,k[0],k[1],k[2],A[0],A[1],A[2],r,l)),Rs(s,_[0],_[1],_[2],_[3]);const S=(()=>{const[k,R]=tn(-1,0,h,u);return[k,0,R]})(),T=(()=>{const[k,R]=tn(1,0,h,u);return[k,0,R]})();let M=[f,v,m].map(k=>Mt(s,k[0],k[1],k[2],S[0],S[1],S[2],r,l));Jn(s,M[0],M[1],M[2]),M=[p,g,x].map(k=>Mt(s,k[0],k[1],k[2],T[0],T[1],T[2],r,l)),Jn(s,M[0],M[1],M[2])}function td(s,t,e){const n=t[0]-s[0],o=t[1]-s[1],i=t[2]-s[2],a=e[0]-s[0],c=e[1]-s[1],r=e[2]-s[2],l=o*r-i*c,h=i*a-n*r,u=n*c-o*a,d=Math.hypot(l,h,u);return d>1e-9?[l/d,h/d,u/d]:[0,1,0]}function Me(s,t,e,n,o,i,a,c){let r=e,l=o,h=td(t,e,o);c&&h[0]*c[0]+h[1]*c[1]+h[2]*c[2]<0&&(r=o,l=e,h=[-h[0],-h[1],-h[2]]);const u=Mt(s,t[0],t[1],t[2],h[0],h[1],h[2],i,a),d=Mt(s,r[0],r[1],r[2],h[0],h[1],h[2],i,a),f=Mt(s,n[0],n[1],n[2],h[0],h[1],h[2],i,a),p=Mt(s,l[0],l[1],l[2],h[0],h[1],h[2],i,a);Rs(s,u,d,f,p)}function cn(s){const t=new $e;return t.setAttribute("position",new et(new Float32Array(s.pos),3)),t.setAttribute("nrm",new et(new Float32Array(s.nrm),3)),t.setAttribute("vcol",new et(new Float32Array(s.col),3)),t.setAttribute("vmat",new et(new Float32Array(s.mat),1)),t.setIndex(s.idx),t.computeBoundingSphere(),t}const _c=`
in vec3 nrm; in vec3 vcol; in float vmat;
out vec3 vW; out vec3 vN; out vec3 vC; out vec3 vL; out float vM; out float vDist;
void main(){
  vec4 wp = modelMatrix*vec4(position,1.0);
  vW = wp.xyz; vN = normalize(mat3(modelMatrix)*nrm); vC = vcol; vM = vmat;
  vL = position;
  vec4 mv = viewMatrix*wp; vDist = -mv.z;
  gl_Position = projectionMatrix*mv;
}`;function ed(s){const t=s?"uGhostAlpha":"gFogAmt";return`
uniform vec3 uLamp;   // x,y,z = the three switchable emissive channels, 0..1
${s?"uniform float uGhostAlpha;":""}
in vec3 vW; in vec3 vN; in vec3 vC; in vec3 vL; in float vM; in float vDist;
out vec4 outColor;
void main(){
  vec3 N=normalize(vN), V=normalize(uCamPos-vW);
  vec3 base = vC;
  // Grain in OBJECT space, not the pen's world space. The pen's painted objects were
  // bolted to the valley floor, so the two were the same thing; a car doing 90 m/s
  // through a world-space noise field crawls with paint-coloured static.
  float g  = pn2(vL.xz*4.3 + vL.y*3.7)*0.5+0.5;
  float g2 = pn2(vL.xz*17.0 - vL.y*9.0)*0.5+0.5;
  base *= 0.90 + 0.20*g + 0.06*g2;

  // lit / mid / shade travel along a hue path, never a brightness ramp
  vec3 lit = base*1.12;
  vec3 mid = mix(base*0.76, K_AMB_SKY*0.22, 0.16);
  vec3 shd = mix(base*0.40, K_SHADOW*0.60, 0.44);
  float rim = 0.30, ao = 1.0;

  // Upper bound as well as lower: slot 7 sits above the lamps and would otherwise be
  // decoded as lamp channel C and come out as a brake disc.
  if(vM > 3.5 && vM < 6.5){                 // switchable lamp, channels A/B/C
    float ch = vM < 4.5 ? uLamp.x : (vM < 5.5 ? uLamp.y : uLamp.z);
    vec3 dead = mix(base*0.50, K_SKY_MID*0.30, 0.35);
    vec3 hot  = base*2.6 + K_SUN*0.22;
    vec3 c = mix(dead, hot, ch);
    // An unlit lens is an object and hazes with everything else; a lamp that is ON is a
    // light source and must stay legible through the haze, so the fog is faded out with
    // the channel rather than applied flat.
    c = mix(aerial(c, vDist, V, vW.y), c, ch);
    outColor = vec4(SAFE3(c), ${t});
    return;
  }
  if(vM > 1.5 && vM < 2.5){                 // lit window
    float flick = 0.94 + 0.06*sin(uTime*2.1 + vW.x*3.1 + vW.z*1.7);
    outColor = vec4(SAFE3(base*2.4*flick + K_SUN*0.25), ${s?"uGhostAlpha":"0.0"});
    return;
  }
  if(vM > 0.5 && vM < 1.5){                 // painted metal: crisper bands
    lit = base*1.25; mid = base*0.62;
    shd = mix(base*0.30, K_SHADOW*0.7, 0.5);
    rim = 0.62;
  }
  if(vM > 2.5 && vM < 3.5){                 // glass / dark opening
    lit = mix(base, K_SKY_MID, 0.55); mid = base*0.7; shd = base*0.42; rim = 0.75;
  }
  if(vM > 6.5){                             // coach paint — the body of a car
    /* Two measured losses are being paid back here, both of them downstream of this
     * shader and neither of them fixable downstream without regrading the whole frame
     * (numbers from tools/diag-carpaint.mjs, which walks a body fragment through this
     * shader, the tonemap and the grade and prints what the browser suite would read):
     *
     *   1. The filmic tonemap in render/post.js has a slope of ~3.8 near black and ~0.8
     *      up at 0.8, so it lifts a paint's two dark channels far harder than it
     *      compresses its bright one. A body colour that is 0.88 saturated in linear
     *      comes out of the composite at 0.42. Pushing the base away from its own
     *      luminance BEFORE the ramp is the only place that is recoverable, because
     *      everything after this point is shared with the sky and the grass.
     *   2. MATTE mixes 16% flat sky ambient into its mid band and 44% flat shadow tint
     *      into its shade band. On plaster and thatch that reads as air. Across a whole
     *      body shell it reads as the paint going grey — and on the dark chips the
     *      shadow tint simply wins, which is why an ink car and a verdigris car used to
     *      arrive at the same blue.
     *
     * Deliberately NOT metal's ramp: rim 0.62 puts a hot sun edge on every panel, which
     * is what bleached the shell when the body was drawn as METAL. 0.34 is a sheen. */
    float bl = dot(base, vec3(0.2126,0.7152,0.0722));
    vec3 deep = max(base + (base - vec3(bl))*0.30, vec3(0.0));
    lit = deep*1.18;
    mid = deep*0.74;
    shd = mix(deep*0.34, K_SHADOW*0.44, 0.22);
    rim = 0.34;
  }

  float ndl = dot(N,uSunDir);
  float sh = sunShadow(vW,ndl)*cloudShadow(vW);
  Surf s; s.N=N; s.V=V; s.P=vW; s.shade=shd; s.mid=mid; s.lit=lit;
  s.soft = mix(0.075, 0.19, clamp(vDist*0.004,0.0,1.0));
  s.jit = (vn2(vL.xz*3.9 + vL.y*1.7) - 0.5)*0.055;
  s.shadow=sh; s.trans=0.0; s.transCol=vec3(0.0);
  s.rim=${s?"rim*2.1":"rim"}; s.ao=ao; s.ambient=1.0;
  vec3 col=paint(s);
  ${s?`
  // A ghost is a rumour of a car: keep the silhouette and the sun-side rim, let the
  // middle of every panel drift towards the sky it is standing in front of.
  float fres = pow(1.0 - clamp(dot(N,V),0.0,1.0), 2.6);
  col = mix(col*0.72 + K_SKY_MID*0.16, col + K_SUN*0.35, fres);
  `:""}
  col = aerial(col,vDist,V,vW.y);
  outColor = vec4(SAFE3(col), ${t});
}`}const sd=fs({cshSpan:9200,cloudDeck:980});function Zo({side:s=ke,ghost:t=!1,opacity:e=.85,uniforms:n={}}={}){const o={uLamp:{value:new lt(0,0,0)}};t&&(o.uGhostAlpha={value:e});const i=new Ut({glslVersion:"300 es",uniforms:Zt(Object.assign(o,n)),vertexShader:Kt(_c),fragmentShader:ce(Dt,It,sd,Cs,ps,ed(t)),side:s});return t&&(i.transparent=!0,i.depthWrite=!0,i.blending=K0,i.blendSrc=$0,i.blendDst=W0,i.blendEquation=Do,i.blendSrcAlpha=H0,i.blendDstAlpha=U0,i.blendEquationAlpha=Do),i}function nd(){return new Ut({glslVersion:"300 es",uniforms:Zt(),vertexShader:Kt(_c),fragmentShader:da,side:ke,colorWrite:!1})}const Tc=900,xr=2.6,qt=32,_n=1200,od=24,Vi={uMeanWind:{value:new Et(3,1)}};function Ac(){return Vi}const Yi=`
uniform vec2 uMeanWind;   // supplied by windUniforms(), not by the shared U block
const float WIND_SPAN = ${Tc.toFixed(1)};
// Beyond the render target we still want visible gust bands rolling over the far hills,
// so the fallback is an analytic version of the same travelling wave.
float windBandAnalytic(vec2 p){
  vec2 q = p - uMeanWind * (uTime * 1.22);
  float a = fbm2(q * 0.0052, 3);
  float b = pn2(q * 0.0168 + 13.0);
  float c = pn2(q * 0.055  + 41.0);
  return clamp(a*1.30 + b*0.55 + c*0.22, -1.2, 1.4);
}
vec4 windSample(vec2 p){
  vec2 uv = (p - uWindOrigin) / WIND_SPAN + 0.5;
  vec2 c = clamp(uv, vec2(0.003), vec2(0.997));
  vec4 w = texture(uWindTex, c);
  float edge = 1.0 - smoothstep(0.40, 0.498, max(abs(uv.x-0.5), abs(uv.y-0.5)));
  // Inside the render target the simulated field IS the answer. The analytic fallback
  // costs ~20 hash evaluations and is pure waste there — and since a blade's vertices all
  // sample the same point, this branch is perfectly coherent across a warp. It is the
  // single largest saving in the grass vertex shader.
  if(edge >= 0.999) return w;
  float band = windBandAnalytic(p);
  float gust = clamp(0.80 + band*0.95, 0.05, 2.3);
  vec4 fb = vec4(uMeanWind*gust, gust, clamp(band, 0.0, 1.0)*0.85);
  return mix(fb, w, edge);
}
// logarithmic boundary layer, normalised to the 10 m reference height
float windProfile(float z){
  return log((max(z,0.015) + 0.06) / 0.06) * 0.19523;
}
`,id=`precision highp float;
in vec3 position;
in vec2 uv;
out vec2 vUv;
void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`,ad=`${Q0}${ua}
uniform vec2  uMeanWind;
uniform vec4  uCellA[6];      // xy: head station + cross offset, z: length, w: width
uniform vec4  uCellB[6];      // x: amplitude, y: veer, z: age, w: -
uniform vec2  uFwd;
uniform vec2  uSide;
uniform float uGustiness;
uniform float uTurbI;
uniform sampler2D uWindTerr;  // coarse ground height, metres
uniform vec3  uWindTerrO;     // xy: proxy centre in world xz, z: 1 / proxy span
${Dt}${It}
in vec2 vUv;
out vec4 outColor;

float terrH(vec2 p){
  vec2 uv = (p - uWindTerrO.xy) * uWindTerrO.z + 0.5;
  return texture(uWindTerr, clamp(uv, vec2(0.008), vec2(0.992))).r;
}
vec3 terrN(vec2 p, float e){
  float l = terrH(p - vec2(e,0.0)), r = terrH(p + vec2(e,0.0));
  float d = terrH(p - vec2(0.0,e)), u = terrH(p + vec2(0.0,e));
  return normalize(vec3(l-r, 2.0*e, d-u));
}

/* divergence-free turbulence with an inertial-subrange amplitude spectrum: eddy velocity
   at wavenumber k scales as k^(-1/3), and each octave decorrelates on its own turnover
   time tau ~ k^(-2/3). */
vec2 turbulence(vec2 p, float t, out float mag){
  vec2 v = vec2(0.0);
  float k = 0.0118, amp = 1.0, e = 0.021;
  mag = 0.0;
  for(int i=0;i<4;i++){
    vec2 q = (p - uMeanWind*t) * k;
    float tt = t * (0.055 * pow(2.0, float(i)*0.667));
    float n0 = pn3(vec3(q,                tt));
    float nx = pn3(vec3(q + vec2(e,0.0),  tt));
    float ny = pn3(vec3(q + vec2(0.0,e),  tt));
    vec2 curl = vec2(ny - n0, -(nx - n0)) / e;
    v   += amp * curl;
    mag += amp * length(curl);
    k *= 2.0; amp *= 0.7937;               // 2^(-1/3)
  }
  return v;
}

void main(){
  vec2 p = uWindOrigin + (vUv - 0.5) * ${Tc.toFixed(1)};
  float t = uTime;

  vec2 flow = uMeanWind;
  float meanSpd = max(length(uMeanWind), 0.05);

  // ── coherent gust cells ──────────────────────────────────────────────────
  // 'crossS' rather than 'cross': shadowing the built-in compiles, but the grass shader
  // shares these chunks and does call cross().
  float along = dot(p, uFwd), crossS = dot(p, uSide);
  float gust = 0.0, veer = 0.0, front = 0.0;
  for(int i=0;i<6;i++){
    float u = (along - uCellA[i].x) / uCellA[i].z;
    if(u > 0.18 || u < -6.5) continue;
    float head = smoothstep(0.15, 0.0, u);
    float body = exp(u*2.05);
    float cw   = exp(-pow(abs(crossS - uCellA[i].y)/(uCellA[i].w*0.5), 2.3));
    float g = uCellB[i].x * head * body * cw;
    gust  += g;
    veer  += g * uCellB[i].y;
    front += uCellB[i].x * exp(-abs(u)*9.0) * cw;   // the sharp leading edge
  }
  gust *= uGustiness; front *= uGustiness;

  // ── inertial-subrange turbulence, advected with the flow ─────────────────
  float tmag;
  vec2 turb = turbulence(p, t, tmag) * meanSpd * uTurbI;
  flow += turb;

  // ── terrain coupling ─────────────────────────────────────────────────────
  // The probe offsets are the pen's (58 m for the crest, 48 m upwind for the shelter).
  // They are wider than one proxy texel, which is why a 37.5 m proxy is enough.
  float h  = terrH(p);
  float hs = 0.25*(terrH(p+vec2(58.0,0.0)) + terrH(p-vec2(58.0,0.0))
                 + terrH(p+vec2(0.0,58.0)) + terrH(p-vec2(0.0,58.0)));
  float crest = (h - hs) / 24.0;
  float speedup = 1.0 + 0.92*clamp(crest, 0.0, 1.1);
  float hUp = terrH(p - uFwd*48.0);
  float shelter = exp(-max(hUp - h, 0.0)/23.0);
  speedup *= mix(0.42, 1.0, shelter);

  vec3 n = terrN(p, 40.0);
  vec2 grad = -n.xz;
  float slope = length(grad);
  vec2 contour = normalize(vec2(-grad.y, grad.x) + vec2(1e-6));
  if(dot(contour, uFwd) < 0.0) contour = -contour;
  vec2 fdir = normalize(flow + vec2(1e-6));
  fdir = normalize(mix(fdir, contour, clamp(slope*2.1, 0.0, 0.58)));

  float spd = length(flow) * speedup * (1.0 + gust*1.35);
  // the gust front veers the direction as it passes over
  float a = veer * 0.85;
  vec2 dir = vec2(fdir.x*cos(a) - fdir.y*sin(a), fdir.x*sin(a) + fdir.y*cos(a));

  vec2 vel = dir * spd;
  float gustNorm = spd / max(meanSpd, 0.4);
  float excite = clamp(front*1.35 + tmag*0.22, 0.0, 3.0);

  outColor = vec4(vel, gustNorm, excite);
}`;class rd{constructor(t,e={}){this.renderer=t;const n=X(e.quality??1,.4,2),o=Math.max(128,Math.round((e.res??320)*Math.sqrt(n))&-2);this.everyNthFrame=Math.max(1,e.everyNthFrame??3),this._frame=0,this.rt=new jn(o,o,{type:Pi,format:Vn,minFilter:te,magFilter:te,wrapS:Se,wrapT:Se,depthBuffer:!1,stencilBuffer:!1}),pt.uWindTex.value=this.rt.texture;const i=Ee((e.seed??4242)>>>0);this._r=i,this.time=0,this.baseSpeed=4.2,this.baseDir=292*_s,this.meanSpeed=this.baseSpeed,this.meanDir=this.baseDir,this.tgtSpeed=this.baseSpeed,this.tgtDir=this.baseDir,this.gustiness=1,this.vec=new Et,this.fwd=[0,1],this.side=[-1,0],this.cloudDrift=new Et,this.cloudWind=new Et;const a=Math.sin(this.meanDir+Math.PI),c=Math.cos(this.meanDir+Math.PI);this.fwd=[a,c],this.side=[-c,a],this.vec.set(a*this.meanSpeed,c*this.meanSpeed),this.cells=[];for(let u=0;u<6;u++)this.cells.push({s:-1400+u*430+i()*260,c:(i()-.5)*900,len:26+i()*34,wid:70+i()*130,amp:.85+i()*1.35,veer:(i()-.5)*.42,life:0});this._pxData=new Uint16Array(qt*qt),this._pxNext=new Float32Array(qt*qt),this._pxCursor=qt*qt,this._pxNextOX=0,this._pxNextOZ=0,this.proxy=new sl(this._pxData,qt,qt,nl,Pi),this.proxy.minFilter=te,this.proxy.magFilter=te,this.proxy.wrapS=Se,this.proxy.wrapT=Se,this.proxy.needsUpdate=!0,this._seed=(e.seed??4242)>>>0,this.worldSeed=(e.worldSeed??20260726)>>>0;const r=new $e;r.setAttribute("position",new et(new Float32Array([-1,-1,0,3,-1,0,-1,3,0]),3)),r.setAttribute("uv",new et(new Float32Array([0,0,2,0,0,2]),2)),r.boundingSphere=new Ke(new lt,10),this._quadGeo=r,this._quadScene=new Ho,this._quadCam=new aa;const l=[],h=[];for(let u=0;u<6;u++)l.push(new Fo),h.push(new Fo);this._uni={uTime:pt.uTime,uWindOrigin:pt.uWindOrigin,uMeanWind:Vi.uMeanWind,uCellA:{value:l},uCellB:{value:h},uFwd:{value:new Et(a,c)},uSide:{value:new Et(-c,a)},uGustiness:{value:1},uTurbI:{value:.26},uWindTerr:{value:this.proxy},uWindTerrO:{value:new lt(0,0,1/_n)}},this.material=new Ut({glslVersion:"300 es",vertexShader:id,fragmentShader:ad,uniforms:this._uni,depthTest:!1,depthWrite:!1}),this._quad=new Ht(r,this.material),this._quad.frustumCulled=!1,this._quadScene.add(this._quad)}setSeed(t){return this.worldSeed=t>>>0,this._pxCursor=qt*qt,this}update(t,e){const n=this._r;this.time+=t;const o=1-Math.exp(-t/25),i=1-Math.exp(-t/40);this.tgtSpeed=X(this.tgtSpeed+(n()-.5)*t*2.4,this.baseSpeed*.62,this.baseSpeed*1.45),this.tgtDir=X(this.tgtDir+(n()-.5)*t*.16,this.baseDir-.34,this.baseDir+.34),this.meanSpeed+=(this.tgtSpeed-this.meanSpeed)*o,this.meanDir+=(this.tgtDir-this.meanDir)*i;const a=Math.sin(this.meanDir+Math.PI),c=Math.cos(this.meanDir+Math.PI);this.vec.set(a*this.meanSpeed,c*this.meanSpeed),this.fwd[0]=a,this.fwd[1]=c,this.side[0]=-c,this.side[1]=a;const r=this.meanSpeed*1.25*t;for(const u of this.cells)u.s+=r,u.life+=t,u.s-(e.x*a+e.z*c)>620&&(u.s-=1560+n()*280,u.c=(n()-.5)*940,u.len=26+n()*34,u.wid=70+n()*130,u.amp=.8+n()*1.4,u.veer=(n()-.5)*.44,u.life=0);const l=this.meanDir+Math.PI+.19;this.cloudWind.set(Math.sin(l)*this.meanSpeed*2.35,Math.cos(l)*this.meanSpeed*2.35),this.cloudDrift.x+=this.cloudWind.x*t,this.cloudDrift.y+=this.cloudWind.y*t,Vi.uMeanWind.value.copy(this.vec);const h=Math.hypot(this.vec.x,this.vec.y)||1;pt.uWindLag.value.set(this.vec.x/h*xr,this.vec.y/h*xr),this._stepProxy(e),this._frame%this.everyNthFrame===0&&this._pass(e),this._frame++}_stepProxy(t){const e=qt*qt;this._pxCursor>=e&&(this._pxNextOX=t.x,this._pxNextOZ=t.z,this._pxCursor=0);const n=_n/(qt-1),o=this._pxNextOX-_n*.5,i=this._pxNextOZ-_n*.5,a=Math.min(e,this._pxCursor+od);for(let c=this._pxCursor;c<a;c++){const r=c%qt,l=c/qt|0;this._pxNext[c]=Xn(o+r*n,i+l*n,this.worldSeed)}if(this._pxCursor=a,a>=e){for(let c=0;c<e;c++)this._pxData[c]=ol.toHalfFloat(this._pxNext[c]);this.proxy.needsUpdate=!0,this._uni.uWindTerrO.value.set(this._pxNextOX,this._pxNextOZ,1/_n)}}_pass(t){const e=this._uni;pt.uWindOrigin.value.set(t.x,t.z),e.uFwd.value.set(this.fwd[0],this.fwd[1]),e.uSide.value.set(this.side[0],this.side[1]),e.uGustiness.value=this.gustiness;for(let i=0;i<6;i++){const a=this.cells[i];e.uCellA.value[i].set(a.s,a.c,a.len,a.wid),e.uCellB.value[i].set(a.amp,a.veer,a.life,0)}const n=this.renderer,o=n.getRenderTarget();n.setRenderTarget(this.rt),n.render(this._quadScene,this._quadCam),n.setRenderTarget(o)}sample(t,e,n){const o=this.fwd[0],i=this.fwd[1],a=this.side[0],c=this.side[1];let r=this.vec.x,l=this.vec.y;const h=t*o+e*i,u=t*a+e*c;let d=0,f=0;for(const z of this.cells){const L=(h-z.s)/z.len;if(L>.16||L<-6)continue;const U=mt(.14,0,L),W=Math.exp(L*2.05),I=Math.exp(-Math.pow(Math.abs(u-z.c)/(z.wid*.5),2.3)),H=z.amp*U*W*I*this.gustiness;d+=H,f+=H*z.veer}const p=this.time,g=(t-this.vec.x*p)*.0125,m=(e-this.vec.y*p)*.0125,v=we(g,m,this._seed),x=we(g+3.7,m-1.9,this._seed),b=g*2.6,y=m*2.6,A=we(b+11,y+5,this._seed),_=we(b-7,y+13,this._seed);r+=(v*1+A*.79)*this.meanSpeed*.19,l+=(x*1+_*.79)*this.meanSpeed*.19;const S=1+d*.85,T=Math.cos(f),M=Math.sin(f),k=(r*T-l*M)*S,R=(r*M+l*T)*S,P=n===void 0?1:Math.log((Math.max(n,.015)+.06)/.06)*.19523;return{x:k*P,z:R*P,gust:d,speed:Math.hypot(k,R)*P}}dispose(){this.rt.dispose(),this.proxy.dispose(),this.material.dispose(),this._quadGeo.dispose(),pt.uWindTex.value===this.rt.texture&&(pt.uWindTex.value=null)}}const cd=9200,yr=190,ld=128,ln={FOLIAGE:0,PETAL:1,EYE:2},hd=[B("wallA"),ut(B("windowGlow"),B("wallA"),.6),ut(B("roofA"),B("wallA"),.62),ut(B("cloudUnder"),B("wallA"),.42),ut(ut(B("cloudUnder"),B("skyUpper"),.34),B("wallA"),.45)],_r=ut(B("gMid"),B("gLow"),.35),Tr=B("gPatchB"),ud=ut(B("gPatchA"),B("mist"),.2),dd=Ue(B("gDry"),1.06),wa={daisy:{h:.55,flex:1},spire:{h:.9,flex:1.35},tuft:{h:.26,flex:.5}},Ar=Object.keys(wa);function Mr(s,t,e,n,o,i,a,c,r){const l=Math.cos(a),h=Math.sin(a),u=Math.cos(c),d=Math.sin(c),f=(A,_,S)=>{const T=_*l-S*h,M=_*h+S*l,k=A*u-T*d,R=A*d+T*u;return[t+k,e+R,n+M]},p=f(0,1,0),g=p[0]-t,m=p[1]-e,v=p[2]-n,x=f(0,0,0),b=Mt(s,x[0],x[1],x[2],g,m,v,dd,ln.EYE),y=[];for(let A=0;A<i*2;A++){const _=A/(i*2)*K,S=A%2===0?o:o*.62,T=f(Math.cos(_)*S,-o*.18,Math.sin(_)*S);y.push(Mt(s,T[0],T[1],T[2],g,m,v,r,ln.PETAL))}for(let A=0;A<y.length;A++)Jn(s,b,y[A],y[(A+1)%y.length])}function di(s,t,e,n,o,i,a){const c=Math.cos(t),r=Math.sin(t),l=-r*.5,h=c*.5,u=[];for(let f=0;f<=2;f++){const p=f/2,g=o*(1-p)*(.4+1.4*p),m=e+i*(p*1.5-p*p*1.1);u.push([[c*n*p+l*g,m,r*n*p+h*g],[c*n*p-l*g,m,r*n*p-h*g]])}const d=u.map(f=>{const p=[-r*.25,.94,c*.25];return[Mt(s,f[0][0],f[0][1],f[0][2],p[0],p[1],p[2],a,ln.FOLIAGE),Mt(s,f[1][0],f[1][1],f[1][2],p[0],p[1],p[2],a,ln.FOLIAGE)]});for(let f=0;f<d.length-1;f++)Rs(s,d[f][0],d[f][1],d[f+1][1],d[f+1][0])}const Sr=[1,1,1];function fd(s,t){const e=Xt(),n=Ee(t>>>0),o=wa[s];if(s==="daisy"){for(let a=0;a<4;a++){const c=a/4*K+n()*1.1,r=.035+n()*.07,l=o.h*(.62+n()*.38),h=.05+n()*.1,u=Math.cos(c)*(r+h),d=Math.sin(c)*(r+h);C(e,[Math.cos(c)*r*.3,0,Math.sin(c)*r*.3],[u,l,d],.007,.005,3,_r,ln.FOLIAGE),Mr(e,u,l+.012,d,.042+n()*.016,5,(n()-.5)*.7,(n()-.5)*.7,Sr)}for(let a=0;a<3;a++)di(e,a/3*K+n(),.01,.13+n()*.05,.045,.05,Tr)}else if(s==="spire"){const i=o.h;C(e,[0,0,0],[.03,i,.02],.011,.006,3,_r,ln.FOLIAGE);const a=8;for(let c=0;c<a;c++){const r=c/(a-1),l=c*2.399,h=.036*(1-r*.55),u=i*(.42+.55*r);Mr(e,Math.cos(l)*h*.7+.03*r,u,Math.sin(l)*h*.7+.02*r,h,3,1.15,l*.3,Sr)}for(let c=0;c<3;c++)di(e,c/3*K+n(),.01,.15+n()*.05,.04,.07,Tr)}else for(let a=0;a<6;a++)di(e,a/6*K+n()*.5,.005,.17+n()*.08,.07,.13+n()*.07,ud);return e}function pd(s){const t=cn(s),e=new ca;return e.setAttribute("position",t.getAttribute("position")),e.setAttribute("nrm",t.getAttribute("nrm")),e.setAttribute("vcol",t.getAttribute("vcol")),e.setAttribute("vmat",t.getAttribute("vmat")),e.setIndex(t.getIndex()),e}const kr=s=>`vec3(${s[0].toFixed(4)},${s[1].toFixed(4)},${s[2].toFixed(4)})`;function md(){const s=ha(),t=[];for(let e=0;e<s.count;e++)t.push(kr([s.foliage[e*3],s.foliage[e*3+1],s.foliage[e*3+2]]));return`
const int NSPEC = ${Ss};
const vec3 SPECIES[${Ss}] = vec3[${Ss}](${hd.map(kr).join(",")});
const int NFOL = ${s.count};
const vec3 B_FOLIAGE[${s.count}] = vec3[${s.count}](${t.join(",")});
`}const gd=`
uniform float uStemH;    // nominal height of this silhouette, metres
uniform float uFlex;     // how loosely it moves: a tuft barely does, a spire whips
uniform vec2  uRing;     // x = where the size fade starts, y = the cull radius
in vec3 nrm; in vec3 vcol; in float vmat;
in vec4 iPos;            // xyz = root on the ground, w = scale
in vec4 iVar;            // yaw, species, phase, biome
out vec3 vW; out vec3 vN; out vec3 vC; out vec3 vL; out float vM; out float vDist;
void degenerate(){ gl_Position = vec4(2.0, 2.0, 2.0, 1.0); }

void main(){
  // Three rejections before anything is transformed. Distance first because it is one dot
  // product, then the same ground-plane view cone render/grass.js culls blades against —
  // more than half of every ring is behind the camera and this is what stops us paying for
  // it. Instances within about six metres are exempt: at that range the plant's own width
  // subtends more than the cone's pad.
  vec2 toB = iPos.xz - uCamPos.xz;
  float d2 = dot(toB, toB);
  float invD = inversesqrt(max(d2, 1e-4));
  float dist = d2 * invD;
  if(dist > uRing.y){ degenerate(); return; }
  if(d2 > 40.0 && dot(toB, uCull.xy)*invD < uCull.z){ degenerate(); return; }
  float fade = 1.0 - smoothstep(uRing.x, uRing.y, dist);
  if(fade < 0.02){ degenerate(); return; }

  // Shrink out rather than pop out. The floor of 0.4 matters: a plant that reaches zero
  // size is invisible for the last few metres of the ring anyway, and starting the shrink
  // from 1.0 makes the whole far field visibly breathe as the car moves.
  float sc = iPos.w * (0.4 + 0.6*fade);
  float rot = iVar.x;
  float ca = cos(rot), sa = sin(rot);
  vec3 lp = position * sc;
  vec3 p  = vec3(lp.x*ca - lp.z*sa, lp.y, lp.x*sa + lp.z*ca);
  vec3 n  = vec3(nrm.x*ca - nrm.z*sa, nrm.y, nrm.x*sa + nrm.z*ca);

  // The same wind field the grass and the trees read, so a gust crosses all three at once.
  // A stem is a cantilever: lean goes as the square of the height, which is what makes the
  // head swing while the rosette at the foot stays put.
  vec4 W = windSample(iPos.xz - uWindLag);
  float H = max(uStemH * sc, 0.02);
  vec2 wv = W.rg * windProfile(H * 0.7);
  float ph = iVar.z;
  float f0 = 1.05 + 0.85*fract(ph*0.31831);
  float osc = sin(uTime*6.2831853*f0 + ph);
  float bend = (length(wv)*0.085 + (W.a*0.42 + max(W.b-1.0, 0.0)*0.55)*0.16*osc) * uFlex;
  bend = clamp(bend, -0.5, 0.6);
  vec2 bd = normalize(wv + vec2(1e-5));
  float yn = clamp(p.y / H, 0.0, 1.3);
  p.xz += bd * (bend * yn*yn * H * 0.55);
  p.y  -= bend*bend * yn*yn * H * 0.2;

  int spec = clamp(int(iVar.y + 0.5), 0, NSPEC-1);
  vec3 fol = B_FOLIAGE[clamp(int(iVar.w + 0.5), 0, NFOL-1)];
  // A petal takes the drift's colour; leaf and stem keep the palette green they were built
  // with. The biome tint lands on both, but only half strength on a petal — a cream daisy
  // in the highlands should cool down, not turn into a highland leaf.
  vec3 c = vcol * (vmat > 0.5 && vmat < 1.5 ? SPECIES[spec] : vec3(1.0));
  vC = c * mix(vec3(1.0), fol, vmat > 0.5 && vmat < 1.5 ? 0.5 : 1.0);

  vec3 wp = iPos.xyz + p;
  vW = wp; vN = normalize(n); vM = vmat;
  // Object space for the paint grain, offset per instance so two thousand plants do not
  // share one brush stroke.
  vL = position + vec3(ph*0.37);
  vec4 mv = viewMatrix * vec4(wp, 1.0);
  vDist = -mv.z;
  gl_Position = projectionMatrix * mv;
}`,vd=`
in vec3 vW; in vec3 vN; in vec3 vC; in vec3 vL; in float vM; in float vDist;
out vec4 outColor;
void main(){
  vec3 N = normalize(vN);
  // Every surface here is a single-sided sheet — a petal, a leaf — and half of them are
  // seen from below.
  if(!gl_FrontFacing) N = -N;
  vec3 V = normalize(uCamPos - vW);
  float petal = (vM > 0.5 && vM < 1.5) ? 1.0 : 0.0;
  float eye   = step(1.5, vM);

  vec3 base = vC;
  float g = pn2(vL.xz*4.3 + vL.y*3.7)*0.5+0.5;
  base *= 0.92 + 0.16*g;

  vec3 lit = base*1.12;
  vec3 mid = mix(base*0.76, K_AMB_SKY*0.22, 0.16);
  vec3 shd = mix(base*0.40, K_SHADOW*0.60, 0.44);
  // A white petal must not go grey in shadow — it goes cool and stays light, or the bed
  // turns into gravel the moment a cloud crosses it.
  shd = mix(shd, mix(base*0.66, K_AMB_SKY*0.30, 0.34), petal);
  lit = mix(lit, base*1.24 + K_SUN*0.06, petal*0.8);

  float ndl = dot(N, uSunDir);
  float sh = sunShadow(vW, ndl) * cloudShadow(vW);
  Surf s;
  s.N=N; s.V=V; s.P=vW; s.shade=shd; s.mid=mid; s.lit=lit;
  s.soft = mix(0.08, 0.19, clamp(vDist*0.006, 0.0, 1.0));
  s.jit  = (vn2(vL.xz*3.9 + vL.y*1.7) - 0.5)*0.055;
  s.shadow = sh;
  s.trans  = mix(0.45, 1.25, petal);
  s.transCol = mix(${G.cTrans}, ${G.gTrans}, petal*0.5);
  s.rim = mix(0.30, 0.66, petal);
  s.ao = mix(0.86, 1.0, petal + eye);
  s.ambient = 1.0;
  vec3 col = paint(s);
  // the warm centre, kept bright enough to read as one dot at ten metres
  col = mix(col, col*1.18 + K_SUN*0.10, eye);
  col = aerial(col, vDist, V, vW.y);
  outColor = vec4(SAFE3(col), gFogAmt);
}`;function wd(s,t){const e=wa[s];return new Ut({glslVersion:"300 es",uniforms:Zt(Object.assign({uStemH:{value:e.h},uFlex:{value:e.flex},uRing:{value:t}},Ac())),vertexShader:Kt(Dt,It,Yi,md(),gd),fragmentShader:ce(Dt,It,fs({cshSpan:cd}),Cs,ps,vd),side:ke})}class bd{constructor({seed:t,parent:e,quality:n=1,cullDistance:o=yr}){this.seed=t>>>0,this.quality=X(n,.4,2),this.cull=Math.min(o*X(this.quality,.6,1.15),yr),this.fadeFrom=Math.min(ld,this.cull*.68),this.group=new qe,this.group.name="flowers",this.group.matrixAutoUpdate=!1,e.add(this.group),this.chunks=new Map,this.batches=new Map,this._dirty=!1,this._cam=new lt,this._hasCam=!1,this.stats={chunks:0,visible:0,instances:0,tris:0,buildMs:0},this._ring=new Et(this.fadeFrom,this.cull);for(const i of Ar)this._batch(i)}_batch(t){let e=this.batches.get(t);if(e)return e;const n=pd(fd(t,Rt(Ar.indexOf(t)+1,7,6426637))),o=Math.max(128,Qu()),i=new Float32Array(o*4),a=new Float32Array(o*4),c=new ve(i,4),r=new ve(a,4);c.setUsage(hs),r.setUsage(hs),n.setAttribute("iPos",c),n.setAttribute("iVar",r),n.instanceCount=0,n.boundingSphere=new Ke(new lt,1e6);const l=new Ht(n,wd(t,this._ring));l.frustumCulled=!1,l.matrixAutoUpdate=!1,l.updateMatrix(),l.renderOrder=3,l.visible=!1,this.group.add(l);const h=n.getIndex().count/3;return e={kind:t,geom:n,mesh:l,iPos:i,iVar:a,aPos:c,aVar:r,cap:o,count:0,tri:h},this.batches.set(t,e),e}add(t,e,n,o){if(!e||!e.length||this.chunks.has(t))return;const i=new Map;for(let a=0;a<e.length;a++){const c=e[a];let r=i.get(c.kind);r||(r={pos:[],vari:[]},i.set(c.kind,r));const l=Rt(Math.round(c.x*8),Math.round(c.z*8),this.seed)/4294967296*10;r.pos.push(c.x,c.y-.04*c.scale,c.z,c.scale),r.vari.push(c.yaw,c.species,l,c.biome)}this.chunks.set(t,{mx:n,mz:o,vis:!1,kinds:i}),this.stats.chunks=this.chunks.size}remove(t){const e=this.chunks.get(t);e&&(this.chunks.delete(t),this.stats.chunks=this.chunks.size,e.vis&&(this._dirty=!0))}update(t){if(t&&(this._cam.copy(t),this._hasCam=!0),!this._hasCam)return;const e=performance.now(),n=this.cull+46;let o=0;for(const i of this.chunks.values()){const a=Math.hypot(i.mx-this._cam.x,i.mz-this._cam.z)<=n;a!==i.vis&&(i.vis=a,this._dirty=!0),a&&o++}this.stats.visible=o,this._dirty&&this._rebuild(),this.stats.buildMs=performance.now()-e}_rebuild(){this._dirty=!1;for(const n of this.batches.values())n.count=0;for(const n of this.chunks.values())if(n.vis)for(const[o,i]of n.kinds){const a=this.batches.get(o);a&&(a.count+=i.pos.length/4)}for(const n of this.batches.values()){if(n.count>n.cap){let o=n.cap;for(;o<n.count;)o*=2;n.iPos=new Float32Array(o*4),n.iVar=new Float32Array(o*4),n.aPos=new ve(n.iPos,4),n.aVar=new ve(n.iVar,4),n.aPos.setUsage(hs),n.aVar.setUsage(hs),n.geom.setAttribute("iPos",n.aPos),n.geom.setAttribute("iVar",n.aVar),n.cap=o}n.count=0}for(const n of this.chunks.values())if(n.vis)for(const[o,i]of n.kinds){const a=this.batches.get(o);a&&(a.iPos.set(i.pos,a.count*4),a.iVar.set(i.vari,a.count*4),a.count+=i.pos.length/4)}let t=0,e=0;for(const n of this.batches.values())n.geom.instanceCount=n.count,n.mesh.visible=n.count>0,n.aPos.needsUpdate=!0,n.aVar.needsUpdate=!0,t+=n.count,e+=n.count*n.tri;this.stats.instances=t,this.stats.tris=e}dispose(){for(const t of this.batches.values())this.group.remove(t.mesh),t.geom.dispose(),t.mesh.material.dispose();this.batches.clear(),this.chunks.clear(),this.group.parent&&this.group.parent.remove(this.group)}}pt.uMeanWind||(pt.uMeanWind={value:new Et(3,1)});pt.uWindSpan||(pt.uWindSpan={value:0});const xd=9200,yd=()=>({pos:[],nrm:[],clm:[],flx:[],hue:[],idx:[],n:0});function Mc(s,t,e,n,o,i,a,c,r,l,h,u){return s.pos.push(t,e,n),s.nrm.push(o,i,a),s.clm.push(c,r,l),s.flx.push(h),s.hue.push(u),s.n++}function _d(s){const t=new ca;t.setAttribute("position",new et(new Float32Array(s.pos),3)),t.setAttribute("nrm",new et(new Float32Array(s.nrm),3)),t.setAttribute("clm",new et(new Float32Array(s.clm),3)),t.setAttribute("flx",new et(new Float32Array(s.flx),1)),t.setAttribute("hue",new et(new Float32Array(s.hue),1));const e=s.n>65535?Uint32Array:Uint16Array;return t.setIndex(new et(new e(s.idx),1)),t}function ye(s,t,e,n,o){const i=[];for(let a=0;a<t.length;a++){const c=t[a];let r;a===0?r=[t[1][0]-c[0],t[1][1]-c[1],t[1][2]-c[2]]:a===t.length-1?r=[c[0]-t[a-1][0],c[1]-t[a-1][1],c[2]-t[a-1][2]]:r=[t[a+1][0]-t[a-1][0],t[a+1][1]-t[a-1][1],t[a+1][2]-t[a-1][2]];const l=Math.hypot(r[0],r[1],r[2])||1;r=[r[0]/l,r[1]/l,r[2]/l];let h=[0,1,0];Math.abs(r[1])>.94&&(h=[1,0,0]);let u=[r[1]*h[2]-r[2]*h[1],r[2]*h[0]-r[0]*h[2],r[0]*h[1]-r[1]*h[0]];const d=Math.hypot(u[0],u[1],u[2])||1;u=[u[0]/d,u[1]/d,u[2]/d];const f=[r[1]*u[2]-r[2]*u[1],r[2]*u[0]-r[0]*u[2],r[0]*u[1]-r[1]*u[0]],p=[],g=Math.pow(X(a/(t.length-1),0,1),1.6)*.55;for(let m=0;m<n;m++){const v=m/n*K,x=Math.cos(v),b=Math.sin(v),y=1+Math.sin(v*3+a)*.09+Math.cos(v*5-a*.7)*.05,A=e[a]*y,_=u[0]*x+f[0]*b,S=u[1]*x+f[1]*b,T=u[2]*x+f[2]*b;p.push(Mc(s,c[0]+_*A,c[1]+S*A,c[2]+T*A,_,S,T,c[0],c[1],c[2],g,o))}i.push(p)}for(let a=0;a<i.length-1;a++)for(let c=0;c<n;c++){const r=i[a][c],l=i[a][(c+1)%n],h=i[a+1][c],u=i[a+1][(c+1)%n];s.idx.push(r,h,l,l,h,u)}}const fi=(()=>{const s=(1+Math.sqrt(5))/2,t=[[-1,s,0],[1,s,0],[-1,-s,0],[1,-s,0],[0,-1,s],[0,1,s],[0,-1,-s],[0,1,-s],[s,0,-1],[s,0,1],[-s,0,-1],[-s,0,1]].map(a=>{const c=Math.hypot(a[0],a[1],a[2]);return[a[0]/c,a[1]/c,a[2]/c]}),e=[[0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],[1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],[3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],[4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1]],n=(a,c)=>{const r=[],l={},h=(u,d)=>{const f=u<d?`${u}_${d}`:`${d}_${u}`;if(l[f]!==void 0)return l[f];const p=[(a[u][0]+a[d][0])/2,(a[u][1]+a[d][1])/2,(a[u][2]+a[d][2])/2],g=Math.hypot(p[0],p[1],p[2]);return a.push([p[0]/g,p[1]/g,p[2]/g]),l[f]=a.length-1,l[f]};for(const u of c){const d=h(u[0],u[1]),f=h(u[1],u[2]),p=h(u[2],u[0]);r.push([u[0],d,p],[u[1],f,d],[u[2],p,f],[d,f,p])}return r},o={v:t.map(a=>a.slice()),f:e.map(a=>a.slice())};o.f=n(o.v,o.f);const i={v:o.v.map(a=>a.slice()),f:o.f.map(a=>a.slice())};return i.f=n(i.v,i.f),{L0:{v:t,f:e},L1:o,L2:i}})();function De(s,t,e,n,o,i,a,c,r,l){const h=l>=2?fi.L2:l>=1?fi.L1:fi.L0,u=s.n,d=Ee(c*7919|0),f=[d()*10,d()*10,d()*10];for(const p of h.v){const g=1+.2*Math.sin(p[0]*4.1+f[0])*Math.sin(p[1]*3.7+f[1])+.14*Math.sin(p[2]*6.3+f[2])*Math.cos(p[0]*5.1+f[1])+.09*we(p[0]*3.4+f[0],p[2]*3.4+f[2]);Mc(s,t+p[0]*o*g,e+p[1]*i*g,n+p[2]*a*g,p[0],p[1],p[2],t,e,n,1,r)}for(const p of h.f)s.idx.push(u+p[0],u+p[1],u+p[2])}const Jo={broadleaf:{h:11.5,flex:1},poplar:{h:15,flex:.8},pine:{h:14.5,flex:.52},deadpine:{h:13,flex:.26},acacia:{h:9.5,flex:.9},scrub:{h:2.5,flex:1.25},palm:{h:12.5,flex:1.6},willow:{h:9.5,flex:1.75}},Td=Object.keys(Jo);function Ad(s,t,e){const n=yd(),o=Ee(e),i=s==="poplar"?13+o()*5:s==="pine"?12+o()*6:s==="deadpine"?11+o()*5:s==="acacia"?8+o()*3.5:s==="palm"?10+o()*5:s==="scrub"?1.9+o()*1.3:s==="willow"?8+o()*3:10+o()*4,a=t>=2?8:t>=1?6:4,c=Math.max(0,t-1);if(s==="pine"){const r=[],l=[];for(let u=0;u<=6;u++){const d=u/6;r.push([Math.sin(d*2.1)*.35*d*i*.06,d*i,Math.cos(d*1.7)*.3*d*i*.06]),l.push(O(i*.035,i*.006,d))}ye(n,r,l,a,0);const h=t>=1?6:4;for(let u=0;u<h;u++){const d=.3+.68*(u/(h-1)),f=(1-d)*i*.3+i*.05;De(n,0,d*i+i*.04,0,f,f*.36,f,e+u*13,.15+o()*.7,c)}}else if(s==="poplar"){const r=[],l=[];for(let u=0;u<=7;u++){const d=u/7;r.push([Math.sin(d*3)*.5,d*i,Math.cos(d*2.2)*.45]),l.push(O(i*.028,i*.005,d))}ye(n,r,l,a,0);const h=t>=1?9:5;for(let u=0;u<h;u++){const d=.2+.78*(u/(h-1)),f=i*(.17-.08*Math.abs(d-.55)*1.4);De(n,Math.sin(d*7)*.5,d*i,Math.cos(d*6)*.45,f*.9,f*1.35,f*.9,e+u*29,.2+o()*.7,c)}}else if(s==="willow"){const r=[],l=[];for(let u=0;u<=5;u++){const d=u/5;r.push([d*d*1.7,d*i*.72,Math.sin(d*2)*.6]),l.push(O(i*.05,i*.012,d))}ye(n,r,l,a,0);const h=t>=1?12:6;for(let u=0;u<h;u++){const d=o()*K,f=Math.sqrt(o())*i*.42,p=Math.cos(d)*f+1.5,g=Math.sin(d)*f,m=i*.62+(o()-.3)*i*.22,v=i*(.13+o()*.09);De(n,p,m,g,v*1.15,v*.8,v*1.15,e+u*37,.5+o()*.5,c),t>=1&&De(n,p*1.05,m-v*1.5,g*1.05,v*.55,v*1.5,v*.55,e+u*41,.6+o()*.4,c)}}else if(s==="deadpine"){const r=[],l=[],h=(o()-.5)*.9;for(let d=0;d<=6;d++){const f=d/6;r.push([h*f*f*i*.1,f*i,Math.sin(f*2.7)*.4]),l.push(O(i*.032,i*.012,Math.pow(f,.75)))}ye(n,r,l,a,0);const u=t>=2?7:t>=1?5:3;for(let d=0;d<u;d++){const f=.34+.58*(d/Math.max(1,u-1)),p=d*2.399+o()*.6,g=i*(.3-.16*f)*(.7+o()*.6),m=[],v=[];for(let x=0;x<=2;x++){const b=x/2;m.push([Math.cos(p)*g*b,f*i+b*g*.42-b*b*g*.5,Math.sin(p)*g*b]),v.push(O(i*.012,i*.003,b))}ye(n,m,v,Math.max(3,a-3),0)}if(t>=1)for(let d=0;d<2;d++){const f=o()*K,p=i*(.09+o()*.05);De(n,Math.cos(f)*i*.1,i*(.68+d*.16),Math.sin(f)*i*.1,p,p*.22,p,e+d*61,o()*.25,c)}}else if(s==="acacia"){const r=[],l=[],h=(o()-.5)*.4;for(let p=0;p<=5;p++){const g=p/5;r.push([h*g*g*i*.2,g*i*.6,Math.cos(g*2.1)*.3]),l.push(O(i*.055,i*.02,g))}ye(n,r,l,a,0);const u=t>=1?5:3,d=i*.52;for(let p=0;p<u;p++){const g=p/u*K+o()*.8,m=d*(.72+o()*.3),v=[],x=[];for(let b=0;b<=3;b++){const y=b/3;v.push([Math.cos(g)*m*y,i*.58+Math.pow(y,.55)*i*.3,Math.sin(g)*m*y]),x.push(O(i*.02,i*.005,y))}ye(n,v,x,Math.max(3,a-2),0)}const f=t>=2?16:t>=1?10:5;for(let p=0;p<f;p++){const g=o()*K,m=Math.pow(o(),.42)*d,v=d*(.2+o()*.16)*(1-m/d*.35);De(n,Math.cos(g)*m,i*.9-m*.1+(o()-.5)*i*.05,Math.sin(g)*m,v*1.25,v*.34,v*1.25,e+p*71,o(),c)}}else if(s==="scrub"){const r=t>=1?3:2;for(let h=0;h<r;h++){const u=h/r*K+o()*1.1,d=[],f=[];for(let p=0;p<=3;p++){const g=p/3;d.push([Math.cos(u)*g*i*.22,g*i*.55,Math.sin(u)*g*i*.22]),f.push(O(i*.05,i*.018,g))}ye(n,d,f,Math.max(3,a-2),0)}const l=t>=2?9:t>=1?6:3;for(let h=0;h<l;h++){const u=o()*K,d=Math.pow(o(),.6)*i*.42,f=i*(.24+o()*.16);De(n,Math.cos(u)*d,i*.52+(o()-.35)*i*.24,Math.sin(u)*d,f*1.1,f*.78,f*1.1,e+h*83,o(),c)}}else if(s==="palm"){const r=[],l=[],h=.9+o()*1.4,u=o()*K;for(let m=0;m<=7;m++){const v=m/7,x=h*v*v;r.push([Math.cos(u)*x,v*i,Math.sin(u)*x]),l.push(O(i*.026,i*.016,v))}ye(n,r,l,a,0);const d=Math.cos(u)*h,f=Math.sin(u)*h,p=t>=2?9:t>=1?7:5,g=i*.44;for(let m=0;m<p;m++){const v=m/p*K+o()*.35,x=.8+o()*.6;for(let b=1;b<=3;b++){const y=b/3,A=g*y,_=g*(.19-.075*y);De(n,d+Math.cos(v)*A,i+g*(.26*y-.62*y*y*x),f+Math.sin(v)*A,_*1.15,_*.3,_*1.15,e+m*97+b*7,.25+o()*.6,c)}}De(n,d,i+g*.06,f,g*.22,g*.2,g*.22,e+991,.3+o()*.3,c)}else{const r=[],l=[],h=(o()-.5)*.5;for(let p=0;p<=6;p++){const g=p/6;r.push([h*g*g*i*.14+Math.sin(g*3.4)*.35,g*i*.52,Math.cos(g*2.6)*.35]),l.push(O(i*.062,i*.026,g))}ye(n,r,l,a,0);const u=t>=2?5:t>=1?4:0;for(let p=0;p<u;p++){const g=p/u*K+o()*.9,m=i*(.26+o()*.16),v=[],x=[];for(let b=0;b<=3;b++){const y=b/3;v.push([Math.cos(g)*m*y*.9,i*.5+y*m*.72-y*y*m*.12,Math.sin(g)*m*y*.9]),x.push(O(i*.02,i*.006,y))}ye(n,v,x,Math.max(3,a-2),0)}const d=t>=2?22:t>=1?12:7,f=i*.4;for(let p=0;p<d;p++){let g,m,v,x;if(p===0)g=0,m=i*.78,v=0,x=f*.72;else{const b=o()*K,y=Math.pow(o(),.55)*f*1.02;g=Math.cos(b)*y,v=Math.sin(b)*y*.92,m=i*.74+(o()-.44)*f*.95-y*.2,x=f*(.26+o()*.26)}De(n,g,m,v,x*1.12,x*.86,x*1.12,e+p*53,o(),c)}}return n}const Sc=`
uniform vec2  uMeanWind;
uniform float uWindSpan;   // metres covered by uWindTex; 0 = no target, analytic only
float windBandAnalytic(vec2 p){
  vec2 q = p - uMeanWind * (uTime * 1.22);
  float a = fbm2(q * 0.0052, 3);
  float b = pn2(q * 0.0168 + 13.0);
  float c = pn2(q * 0.055  + 41.0);
  return clamp(a*1.30 + b*0.55 + c*0.22, -1.2, 1.4);
}
vec4 windAnalytic(vec2 p){
  float band = windBandAnalytic(p);
  float gust = clamp(0.80 + band*0.95, 0.05, 2.3);
  return vec4(uMeanWind*gust, gust, clamp(band, 0.0, 1.0)*0.85);
}
// Single exit on purpose. The obvious early-return version makes the HLSL backend emit
// "use of potentially uninitialized variable", and a driver that acts on that warning turns
// a tree into a black billboard. Both fast paths survive: inside the render target the
// simulated field IS the answer and the twenty-odd hashes of the analytic fallback are pure
// waste, outside it there is no texture to fetch. Every vertex of a tree samples the same
// iPos.xz, so the branch is perfectly coherent across a warp.
vec4 windSample(vec2 p){
  vec4 res;
  vec2 uv = (p - uWindOrigin) / max(uWindSpan, 1.0) + 0.5;
  float edge = (uWindSpan > 0.0)
    ? 1.0 - smoothstep(0.40, 0.498, max(abs(uv.x-0.5), abs(uv.y-0.5)))
    : 0.0;
  if(edge <= 0.001){
    res = windAnalytic(p);
  } else if(edge >= 0.999){
    res = texture(uWindTex, clamp(uv, vec2(0.003), vec2(0.997)));
  } else {
    res = mix(windAnalytic(p), texture(uWindTex, clamp(uv, vec2(0.003), vec2(0.997))), edge);
  }
  return res;
}
// logarithmic boundary layer, normalised to the 10 m reference height
float windProfile(float z){ return log((max(z,0.015) + 0.06) / 0.06) * 0.19523; }
`;function kc(){const s=ha(),t=[];for(let e=0;e<s.count;e++)t.push(`vec3(${s.foliage[e*3].toFixed(4)},${s.foliage[e*3+1].toFixed(4)},${s.foliage[e*3+2].toFixed(4)})`);return`
const int NFOL = ${s.count};
const vec3 B_FOLIAGE[${s.count}] = vec3[${s.count}](${t.join(",")});
`}const Ec=`
uniform float uTreeH;      // nominal archetype height
uniform float uFlex;       // archetype stiffness multiplier (willow >> snag)
uniform float uCullR;      // >0 : reject instances beyond this radius of the shadow centre
in vec3 nrm; in vec3 clm; in float flx; in float hue;
in vec4 iPos;              // xyz = root, w = scale
in vec4 iVar;              // rot, hueShift, phase, biome
out vec3 vW; out vec3 vN; out float vHue; out float vLeaf; out float vDist;
out float vY; out float vAO; out vec3 vTint;
void main(){
  // The sun shadow map covers a bounded square around the car, so a tree two kilometres
  // away cannot cast into it — yet without this every instance in the world would still be
  // transformed, swayed and rasterised into it. The depth material sets uCullR; the beauty
  // material leaves it 0.
  if(uCullR > 0.0 && distance(iPos.xz, uShadowC) > uCullR){
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return;
  }
  float sc = iPos.w;
  float rot = iVar.x, ph = iVar.z;
  float c = cos(rot), s = sin(rot);
  vec3 lp  = position * sc;
  vec3 ln  = nrm;
  vec3 lc  = clm * sc;
  vec3 rp  = vec3(lp.x*c - lp.z*s, lp.y, lp.x*s + lp.z*c);
  vec3 rn  = vec3(ln.x*c - ln.z*s, ln.y, ln.x*s + ln.z*c);
  vec3 rc  = vec3(lc.x*c - lc.z*s, lc.y, lc.x*s + lc.z*c);
  float H  = uTreeH * sc;

  vec4 W = windSample(iPos.xz);
  float prof = windProfile(max(H*0.62, 0.6));
  vec2 wv = W.rg * prof;
  float gust = W.b, exc = W.a;
  float spd = length(wv);

  vec2 bd = normalize(wv + vec2(1e-5));
  float yn = clamp(rp.y / max(H, 0.5), 0.0, 1.4);

  // trunk: static bend + a resonant mode near 0.5 Hz, mass-lagged behind the grass
  float f0  = 0.40 + 0.26*fract(ph*0.31831);
  float osc = sin(uTime*6.2831853*f0 + ph);
  float bend = (spd*0.052 + (exc*0.30 + max(gust-1.0,0.0)*0.55)*0.16*osc) * uFlex;
  bend = clamp(bend, -0.55, 0.75);
  vec3 p = rp;
  p.xz += bd * (bend * yn*yn * H * 0.42);
  p.y  -= bend*bend * yn*yn * H * 0.22;   // a bent mast is a shorter mast

  // clumps: a faster secondary sway, each with its own phase
  float cph = dot(rc.xz, vec2(0.61, 0.43)) + ph*2.7;
  float f1  = 0.70 + 0.42*fract(sin(cph)*137.51);
  float csw = sin(uTime*6.2831853*f1 + cph);
  vec3  cOff = vec3(bd.x, 0.15*csw, bd.y) * csw * (0.06 + 0.34*gust) * 0.34 * flx * sc;
  p += cOff;

  // leaves flutter around their clump centre
  vec3 rel = rp - rc;
  float rl = length(rel) + 1e-4;
  float flut = sin(uTime*5.1 + dot(rel, vec3(3.3,4.9,2.7)) + cph*1.7);
  p += (rel/rl) * flut * 0.045 * flx * sc * (0.35 + 0.8*gust);

  vec3 wp = iPos.xyz + p;
  vW = wp; vN = normalize(rn); vHue = fract(hue + iVar.y);
  vLeaf = step(0.9, flx); vY = clamp(rp.y/max(H,0.5), 0.0, 1.0);
  // Cheap vertical AO: the inside of a canopy and the foot of a trunk never see the sky.
  vAO = mix(0.62, 1.0, smoothstep(0.0, 0.55, vY));
  vTint = B_FOLIAGE[clamp(int(iVar.w + 0.5), 0, NFOL-1)];
  vec4 mv = viewMatrix * vec4(wp, 1.0);
  vDist = -mv.z;
  gl_Position = projectionMatrix * mv;
}`,Md=`
in vec3 vW; in vec3 vN; in float vHue; in float vLeaf; in float vDist;
in float vY; in float vAO; in vec3 vTint;
out vec4 outColor;
void main(){
  vec3 N = normalize(vN);
  vec3 V = normalize(uCamPos - vW);
  vec3 lit, mid, shd; float trans, rim;

  if(vLeaf > 0.5){
    // four-green canopy mosaic
    vec3 base = vHue<0.26 ? ${G.cVarA} : (vHue<0.52 ? ${G.cLit} :
                (vHue<0.76 ? ${G.cVarB} : ${G.cVarC}));
    float grain = pn2(vW.xz*0.85 + vW.y*0.6)*0.5+0.5;
    lit = mix(base, ${G.cLit}, 0.42) * (1.02 + 0.24*grain);
    mid = mix(${G.cMid}, base*0.72, 0.45);
    shd = mix(${G.cShade}, ${G.cDeep}, grain*0.45);
    // Biome foliage tint: the same table the ground blends, so a highland pine and the
    // hillside it stands on go cold together.
    lit *= vTint; mid *= vTint; shd *= vTint;
    trans = 1.05; rim = 0.52;
  } else {
    float bark = pn2(vec2(atan(N.z,N.x)*3.4, vW.y*3.1))*0.5+0.5;
    vec3 wood = mix(vec3(1.0), vTint, 0.55);
    lit = ${G.trunkLit} * (0.82 + 0.34*bark) * wood;
    mid = mix(${G.trunkLit}, ${G.trunkShade}, 0.55) * wood;
    shd = ${G.trunkShade} * (0.85 + 0.3*bark) * wood;
    trans = 0.0; rim = 0.28;
  }
  // moss on the shaded north side of trunks and the underside of clumps
  float moss = smoothstep(0.15, -0.5, N.y) * (pn2(vW.xz*1.6 + vW.y)*0.5+0.5);
  shd = mix(shd, ${G.moss}*0.55, moss*0.35*(1.0-vLeaf));

  float ndl = dot(N, uSunDir);
  float sh = sunShadow(vW, ndl) * cloudShadow(vW);
  Surf s;
  s.N=N; s.V=V; s.P=vW; s.shade=shd; s.mid=mid; s.lit=lit;
  s.soft = mix(0.09, 0.20, clamp(vDist*0.004,0.0,1.0));
  s.jit = (vn2(vW.xz*3.9 + vW.y*1.7) - 0.5)*0.055;
  s.shadow = sh; s.trans = trans; s.transCol = ${G.cTrans};
  s.rim = rim; s.ao = vAO; s.ambient = 1.0;
  vec3 col = paint(s);
  col = aerial(col, vDist, V, vW.y);
  outColor = vec4(SAFE3(col), gFogAmt);
}`;function Sd(s){const t=Jo[s];return new Ut({glslVersion:"300 es",uniforms:Zt({uTreeH:{value:t.h},uFlex:{value:t.flex},uCullR:{value:0}}),vertexShader:Kt(Dt,It,Sc,kc(),Ec),fragmentShader:ce(Dt,It,fs({cshSpan:xd}),Cs,ps,Md),side:ke})}function kd(s,t){const e=Jo[s];return new Ut({glslVersion:"300 es",uniforms:Zt({uTreeH:{value:e.h},uFlex:{value:e.flex},uCullR:{value:t}}),vertexShader:Kt(Dt,It,Sc,kc(),Ec),fragmentShader:da,side:ke})}const Ed=1400,Rd=.92,zd=420,Er=2.6,Rr=512;class Cd{constructor({seed:t,scene:e,quality:n=1,cullDistance:o=Ed,bushes:i=!0,flowers:a=!0}){this.seed=t>>>0,this.scene=e,this.quality=X(n,.4,2),this.cull=o*X(this.quality,.7,1.35),this.renderBushes=i,this.group=new qe,this.group.name="flora",this.group.matrixAutoUpdate=!1,this.flowers=a?new bd({seed:this.seed,parent:this.group,quality:this.quality}):null,this.batches=new Map,this.chunks=new Map,this.pending=[],this.stats={chunks:0,instances:0,batches:0,attached:0,buildMs:0,backlog:0},this._cam=new lt,this._hasCam=!1,e.add(this.group)}_detailFor(t){return X(2-t-(this.quality<.75?1:0),0,2)}add(t,e){if(t.level>Zn)return;const n=`${t.level}:${t.cx},${t.cz}`;if(this.chunks.has(n))return;const o={key:n,level:t.level,cx:t.cx,cz:t.cz,mx:t.ox+t.size*.5,mz:t.oz+t.size*.5,props:e||null,groups:null,blocks:null,dead:!1};this.chunks.set(n,o),this.pending.push(o),this.stats.chunks=this.chunks.size}remove(t){const e=`${t.level}:${t.cx},${t.cz}`,n=this.chunks.get(e);n&&(n.dead=!0,n.blocks&&this._detach(n),this.chunks.delete(e),this.stats.chunks=this.chunks.size,this.flowers&&this.flowers.remove(e))}update(t,e){e&&(this._cam.copy(e),this._hasCam=!0),this._drain(t),this._cullPass(),this._flush(),this.flowers&&this.flowers.update(e)}_drain(t){const e=performance.now(),n=t>1/45?Er*.45:Er;let o=0;for(;this.pending.length;){const i=this.pending[0];if(i.dead){this.pending.shift();continue}if(o>0&&performance.now()-e>n)break;this.pending.shift(),this._scatter(i),o++}this.stats.buildMs=performance.now()-e,this.stats.backlog=this.pending.length}_scatter(t){const e=t.props||yc({cx:t.cx,cz:t.cz,level:t.level,seed:this.seed});t.props=null;const n=this._detailFor(t.level),o=new Map,i=(a,c,r)=>{for(let l=0;l<a.length;l++){const h=a[l],u=Jo[h.kind];if(!u){console.error("[flora] no archetype for species",h.kind,"— check BIOME_SCATTER kinds");continue}const d=`${h.kind}:${c}`;let f=o.get(d);f||(f={kind:h.kind,detail:c,pos:[],vari:[],minX:1e9,maxX:-1e9,minZ:1e9,maxZ:-1e9,minY:1e9,maxY:-1e9},o.set(d,f));const p=Rt(Math.round(h.x*4),Math.round(h.z*4),this.seed)/4294967296*10,g=h.y-r*h.scale;f.pos.push(h.x,g,h.z,h.scale),f.vari.push(h.yaw,h.hue,p,h.biome);const m=u.h*h.scale*1.25,v=m*.45;h.x-v<f.minX&&(f.minX=h.x-v),h.x+v>f.maxX&&(f.maxX=h.x+v),h.z-v<f.minZ&&(f.minZ=h.z-v),h.z+v>f.maxZ&&(f.maxZ=h.z+v),g<f.minY&&(f.minY=g),g+m>f.maxY&&(f.maxY=g+m)}};i(e.trees,n,.35),this.renderBushes&&t.level<=1&&i(e.bushes,Math.min(n,t.level===0?1:0),.18),this.flowers&&this.flowers.add(t.key,e.flowers,t.mx,t.mz),t.groups=o,(!this._hasCam||this._distance(t)<=this.cull)&&this._attach(t)}_distance(t){return Math.hypot(t.mx-this._cam.x,t.mz-this._cam.z)}_batch(t,e){const n=`${t}:${e}`;let o=this.batches.get(n);if(o)return o;const i=Rt(Td.indexOf(t)+1,e+1,1592598191),a=_d(Ad(t,e,i)),c=Math.max(64,Ju(Math.min(Zn,2-e))),r=new Float32Array(c*4),l=new Float32Array(c*4),h=new ve(r,4),u=new ve(l,4);h.setUsage(hs),u.setUsage(hs),a.setAttribute("iPos",h),a.setAttribute("iVar",u),a.instanceCount=0,a.boundingSphere=new Ke(new lt,0);const d=new Ht(a,Sd(t));return d.frustumCulled=!0,d.matrixAutoUpdate=!1,d.updateMatrix(),d.renderOrder=2,d.visible=!1,d.userData.depth=kd(t,zd),this.group.add(d),o={key:n,kind:t,detail:e,geom:a,mesh:d,iPos:r,iVar:l,aPos:h,aVar:u,cap:c,count:0,blocks:[],dirty:!1},this.batches.set(n,o),this.stats.batches=this.batches.size,o}_reserve(t,e){if(e<=t.cap)return;let n=t.cap;for(;n<e;)n*=2;const o=new Float32Array(n*4),i=new Float32Array(n*4);o.set(t.iPos.subarray(0,t.count*4)),i.set(t.iVar.subarray(0,t.count*4)),t.aPos=new ve(o,4),t.aVar=new ve(i,4),t.aPos.setUsage(hs),t.aVar.setUsage(hs),t.geom.setAttribute("iPos",t.aPos),t.geom.setAttribute("iVar",t.aVar),t.iPos=o,t.iVar=i,t.cap=n}_attach(t){if(t.blocks||!t.groups)return;const e=[];for(const n of t.groups.values()){const o=n.pos.length/4;if(!o)continue;const i=this._batch(n.kind,n.detail);this._reserve(i,i.count+o),i.iPos.set(n.pos,i.count*4),i.iVar.set(n.vari,i.count*4);const a={batch:i,start:i.count,len:o,g:n};i.blocks.push(a),i.count+=o,i.dirty=!0,e.push(a)}t.blocks=e}_detach(t){if(t.blocks){for(const e of t.blocks){const n=e.batch,o=n.blocks.indexOf(e);if(o<0)continue;if(n.count-(e.start+e.len)>0){n.iPos.copyWithin(e.start*4,(e.start+e.len)*4,n.count*4),n.iVar.copyWithin(e.start*4,(e.start+e.len)*4,n.count*4);for(let a=o+1;a<n.blocks.length;a++)n.blocks[a].start-=e.len}n.blocks.splice(o,1),n.count-=e.len,n.dirty=!0}t.blocks=null}}_cullPass(){if(!this._hasCam)return;const t=this.cull,e=this.cull*Rd;let n=0;for(const o of this.chunks.values()){if(!o.groups)continue;const i=this._distance(o);o.blocks?i>t?this._detach(o):n++:i<=e&&(this._attach(o),n++)}this.stats.attached=n,this.chunks.size>Rr&&this._evict()}_evict(){const t=[];for(const n of this.chunks.values())!n.blocks&&n.groups&&t.push(n);t.sort((n,o)=>this._distance(o)-this._distance(n));const e=Math.min(t.length,this.chunks.size-Rr);for(let n=0;n<e;n++)this.chunks.delete(t[n].key);this.stats.chunks=this.chunks.size}_flush(){let t=0;for(const e of this.batches.values()){if(t+=e.count,!e.dirty||(e.dirty=!1,e.geom.instanceCount=e.count,e.mesh.visible=e.count>0,e.aPos.needsUpdate=!0,e.aVar.needsUpdate=!0,!e.count))continue;let n=1e9,o=-1e9,i=1e9,a=-1e9,c=1e9,r=-1e9;for(const h of e.blocks){const u=h.g;u.minX<n&&(n=u.minX),u.maxX>o&&(o=u.maxX),u.minZ<i&&(i=u.minZ),u.maxZ>a&&(a=u.maxZ),u.minY<c&&(c=u.minY),u.maxY>r&&(r=u.maxY)}const l=e.geom.boundingSphere;l.center.set((n+o)*.5,(c+r)*.5,(i+a)*.5),l.radius=Math.hypot(o-n,r-c,a-i)*.5}this.stats.instances=t}dispose(){this.flowers&&this.flowers.dispose();for(const t of this.batches.values())this.group.remove(t.mesh),t.geom.dispose(),t.mesh.material.dispose(),t.mesh.userData.depth.dispose();this.batches.clear(),this.chunks.clear(),this.pending.length=0,this.group.parent&&this.group.parent.remove(this.group)}}const Ld=1900,zr=.07,_e=6,Fd=28,Dd=6,Id=.05,Pd=4,Od=`
in vec3 normal;
in vec2 aCross;   // x = -1..1 across the carriageway, y = metres travelled along it
out vec3 vWorld;
out vec3 vNormal;
out vec2 vCross;
out float vDist;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld = wp.xyz;
  vNormal = normalize(mat3(modelMatrix) * normal);
  vCross = aCross;
  vDist = length(wp.xyz - uCamPos);
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`,Nd=`
in vec3 vWorld;
in vec3 vNormal;
in vec2 vCross;
in float vDist;
out vec4 fragColor;

uniform float uLineMix;   // 0 = unmarked track, 1 = fully marked road
uniform vec3  uSurfLit;
uniform vec3  uSurfShade;

void main(){
  float across = vCross.x;          // -1 .. 1
  float along  = vCross.y;          // metres
  float a = abs(across);

  // Surface: two large wear streaks where the wheels run, plus a fine chip grain. The
  // streaks are what make a road read as USED, and used is what makes it read as a road.
  float wear  = smoothstep(0.62, 0.30, abs(a - 0.46));
  float chip  = vn2(vWorld.xz * 3.4) * 0.5 + vn2(vWorld.xz * 11.0) * 0.5;
  vec3 lit   = uSurfLit   * mix(1.0, 1.09, wear) * mix(0.95, 1.05, chip);
  vec3 shade = uSurfShade * mix(1.0, 0.93, wear);
  vec3 mid   = mix(lit, shade, 0.5);

  // ── markings ────────────────────────────────────────────────────────────
  // Generated from the ribbon's own coordinates, never from a texture: a texture would need
  // a UV atlas, a mip chain and an alignment pass, and would still shimmer at 250 km/h.
  float px = fwidth(across) * 1.6 + 1e-5;

  // continuous edge lines just inside the shoulder
  float edge = smoothstep(0.90 + px, 0.90 - px, a) * smoothstep(0.80 - px, 0.80 + px, a);
  // dashed centre line: 3 m of paint, 6 m of gap, which is close enough to real road
  // marking that it reads correctly at a glance
  float dash = step(fract(along / 9.0), 0.34);
  float centre = smoothstep(0.055 + px, 0.055 - px, a) * dash;

  // 'mark', not 'paint': paint() is the shared lighting function and a float of the same
  // name shadows it, which fails to compile with a message that points somewhere else.
  float mark = clamp(edge + centre, 0.0, 1.0) * uLineMix;
  vec3 markCol = mix(K_LINE_W, K_LINE_W * 0.86, wear * 0.7);
  lit   = mix(lit,   markCol,        mark);
  mid   = mix(mid,   markCol * 0.9,  mark);
  shade = mix(shade, markCol * 0.62, mark);

  vec3 N = normalize(vNormal);
  vec3 V = normalize(uCamPos - vWorld);
  float ndl = dot(N, uSunDir);
  float sh = sunShadow(vWorld, ndl) * cloudShadow(vWorld);

  Surf s;
  s.N = N; s.V = V; s.P = vWorld;
  s.shade = shade; s.mid = mid; s.lit = lit;
  s.soft = 0.20; s.jit = (vn2(vWorld.xz * 0.7) - 0.5) * 0.05;
  s.shadow = sh; s.trans = 0.0; s.transCol = vec3(0.0);
  s.rim = 0.08; s.ao = 1.0; s.ambient = 1.0;

  vec3 col = paint(s);
  col = aerial(col, vDist, V, vWorld.y);
  fragColor = vec4(SAFE3(col), gFogAmt);
}
`;function Bd(){return new Ut({glslVersion:"300 es",uniforms:Zt({uLineMix:{value:1},uSurfLit:{value:new lt(...ge.tarmacLit)},uSurfShade:{value:new lt(...ge.tarmacShade)}}),vertexShader:Kt(Od),fragmentShader:ce(Dt,It,Wo,fs({cshSpan:9200,cloudDeck:980}),Cs,ps,Nd),side:ia})}function Gd(s,t,e,n,o){const i=s>>>0;return{edges:new qo(t,e,n,o,i,pa(i),40,jo(i)).edges,ctx:i}}function Ud(s,t){const e=s.pts.length/2,n=t>>>0,o=new Re(n,s.minX,s.minZ,s.maxX,s.maxZ,96),i=s.width*.5,a=[];for(let x=0;x<e-1;x++){const b=s.pts[x*2],y=s.pts[x*2+1],A=s.pts[x*2+2],_=s.pts[x*2+3],S=Math.hypot(A-b,_-y),T=Math.max(1,Math.round(S/Dd)),M=(A-b)/(S||1),R=(_-y)/(S||1),P=-M,z=I=>{const H=O(b,A,I),V=O(y,_,I);return[o.height(H-R*i,V-P*i),o.height(H,V),o.height(H+R*i,V+P*i)]},L=(I,H,V)=>a.push({x:O(b,A,I),z:O(y,_,I),y:O(s.y[x],s.y[x+1],I),h:H,joint:V}),U=(I,H,V,D,$)=>{const q=(I+V)*.5,Q=z(q);let ot=0;for(let ht=0;ht<3;ht++){const rt=Math.abs((H[ht]+D[ht])*.5-Q[ht]);rt>ot&&(ot=rt)}ot<=Id||$>=Pd||(U(I,H,q,Q,$+1),L(q,Q,!1),U(q,Q,V,D,$+1))};let W=z(0);for(let I=0;I<T;I++){const H=I/T,V=(I+1)/T,D=z(V);L(H,W,I===0),U(H,W,V,D,0),W=D}}const c=e-1;a.push({x:s.pts[c*2],z:s.pts[c*2+1],y:s.y[c],h:null,joint:!0});const r=a.length,l=r*_e,h=new Float32Array(l*3),u=new Float32Array(l*3),d=new Float32Array(l*2),f=new Uint32Array((r-1)*(_e-1)*6),p=i;let g=0;for(let x=0;x<r;x++){const b=a[x],y=a[Math.min(x+1,r-1)],A=a[Math.max(x-1,0)];let _=y.x-A.x,S=y.z-A.z;const T=Math.hypot(_,S)||1;_/=T,S/=T;const M=S,k=-_;x>0&&(g+=Math.hypot(b.x-a[x-1].x,b.z-a[x-1].z));const R=b.h&&!b.joint?b.h:null;for(let z=0;z<_e;z++){const L=z/(_e-1)*2-1,U=b.x+M*L*p,W=b.z+k*L*p,I=x*_e+z;h[I*3]=U,h[I*3+2]=W;const H=R&&z===0?R[0]:R&&z===_e-1?R[2]:o.height(h[I*3],h[I*3+2]);h[I*3+1]=H+zr,u[I*3]=0,u[I*3+1]=1,u[I*3+2]=0,d[I*2]=L,d[I*2+1]=g}const P=x*_e+(_e>>1);b.y=b.h?b.h[1]:(h[(P-1)*3+1]+h[P*3+1])*.5-zr}let m=0;for(let x=0;x<r-1;x++)for(let b=0;b<_e-1;b++){const y=x*_e+b,A=y+1,_=y+_e,S=_+1;f[m++]=y,f[m++]=_,f[m++]=A,f[m++]=A,f[m++]=_,f[m++]=S}const v=new $e;return v.setAttribute("position",new et(h,3)),v.setAttribute("normal",new et(u,3)),v.setAttribute("aCross",new et(d,2)),v.setIndex(new et(f,1)),v.computeBoundingSphere(),{geometry:v,ring:a,half:p}}function Hd(s,t,e,n){const o=[];let i=0,a=1/0,c=0;for(let r=1;r<t.length;r++){const l=t[r],h=t[r-1],u=Math.hypot(l.x-h.x,l.z-h.z);i+=u,a+=u;let d=l.x-h.x,f=l.z-h.z;const p=Math.hypot(d,f)||1;d/=p,f/=p;const g=f,m=-d;let v=0,x=r,b=0;for(;x<t.length-1&&b<18;)b+=Math.hypot(t[x+1].x-t[x].x,t[x+1].z-t[x].z),x++;if(x>r){let y=t[x].x-l.x,A=t[x].z-l.z;const _=Math.hypot(y,A)||1;y/=_,A/=_,v=d*A-f*y}if(i>=Fd){i=0;const y=c++&1?1:-1;o.push({kind:"post",x:l.x+g*y*(e+1.5),z:l.z+m*y*(e+1.5),y:l.y,yaw:Math.atan2(d,f)})}if(Math.abs(v)>.22&&a>=24){a=0;const y=v>0?-1:1;o.push({kind:"chevron",x:l.x+g*y*(e+2.4),z:l.z+m*y*(e+2.4),y:l.y,yaw:Math.atan2(-g*y,-m*y),flip:v>0?1:-1})}}return o}function Wd(){const s=Xt();C(s,[0,0,0],[0,1.05,0],.075,.065,6,[.94,.9,.82],w.MATTE,!0,!0),E(s,0,.92,.042,.055,.11,.01,0,[.92,.32,.22],w.MATTE);const t=Xt();return C(t,[0,0,0],[0,1.35,0],.055,.05,6,[.42,.38,.33],w.MATTE,!0,!0),E(t,0,1.45,0,.6,.34,.035,0,[.95,.93,.86],w.MATTE),E(t,-.13,1.45,.04,.16,.24,.01,.5,[.18,.2,.24],w.MATTE),E(t,.17,1.45,.04,.16,.24,.01,.5,[.18,.2,.24],w.MATTE),{post:cn(s),chevron:cn(t)}}class $d{constructor({seed:t,scene:e,range:n=Ld}){this.seed=t>>>0,this.range=n,this.group=new qe,this.group.name="roads",e.add(this.group),this.material=Bd(),this.paintedMaterial=Zo(),this.furniture=Wd(),this.live=new Map,this._lastX=1/0,this._lastZ=1/0,this.stats={edges:0,tris:0}}update(t,e){if(Math.hypot(t-this._lastX,e-this._lastZ)<180)return;this._lastX=t,this._lastZ=e;const n=this.range,{edges:o,ctx:i}=Gd(this.seed,t-n,e-n,t+n,e+n),a=new Set;for(const c of o){if(a.add(c.key),this.live.has(c.key))continue;const{geometry:r,ring:l,half:h}=Ud(c,i),u=new Ht(r,this.material);u.frustumCulled=!0,u.matrixAutoUpdate=!1,u.renderOrder=1,this.group.add(u);const d=Hd(c,l,h,this.seed),f=d.filter(m=>m.kind==="post"),p=d.filter(m=>m.kind==="chevron"),g={mesh:u,instanced:[]};for(const[m,v]of[[this.furniture.post,f],[this.furniture.chevron,p]]){if(!v.length)continue;const x=new q0(m,this.paintedMaterial,v.length),b=new on,y=new la,A=new lt,_=new lt(1,1,1);v.forEach((S,T)=>{A.set(S.x,S.y,S.z),y.setFromAxisAngle(new lt(0,1,0),S.yaw),b.compose(A,y,_),x.setMatrixAt(T,b)}),x.instanceMatrix.needsUpdate=!0,x.frustumCulled=!1,this.group.add(x),g.instanced.push(x)}this.live.set(c.key,g)}for(const[c,r]of this.live)if(!a.has(c)){this.group.remove(r.mesh),r.mesh.geometry.dispose();for(const l of r.instanced)this.group.remove(l),l.dispose();this.live.delete(c)}this.stats.edges=this.live.size}dispose(){for(const[t,e]of this.live){e.mesh.geometry.dispose();for(const n of e.instanced)n.dispose();this.live.delete(t)}this.material.dispose()}}const Kd=4400,Xi=1.5,qd=[{cs:12,near:0,far:26,dn:7,grid:7,lat:8,segs:3,wpx:1.7,hs:1,prepass:!0},{cs:28,near:22,far:88,dn:22,grid:9,lat:10,segs:2,wpx:2,hs:1.08,prepass:!0},{cs:80,near:80,far:300,dn:80,grid:9,lat:14,segs:1,wpx:3.8,hs:1.36,prepass:!1},{cs:160,near:270,far:560,dn:270,grid:9,lat:14,segs:1,wpx:6,hs:1.95,prepass:!1}],jd=.004,Cr=2;function Vd(s){if(s<=0)return 0;if(s>=1)return 1;const t=Math.ceil(Math.log2(s)*Cr);return Math.min(1,Math.pow(2,t/Cr))}const Yd=.74,Xd=.85,Zd=.45,fo=930,Lr=100,Jd=2.5,Fr=1/65535,Qd=1/4294967296,tf=$o.map(s=>s.grass),ef=us.map(s=>s.dryness),sf=us.map(s=>s.snow),nf=us.map(s=>s.wet),pi=s=>`vec3(${s[0].toFixed(4)},${s[1].toFixed(4)},${s[2].toFixed(4)})`,of=`
const vec3 F_DRY  = ${pi(us[rs.STEPPE].foliage)};
const vec3 F_COLD = ${pi(us[rs.HIGHLAND].foliage)};
const vec3 F_WET  = ${pi(us[rs.WETLAND].foliage)};
`;function af(s){const t=Math.max(1,s),e=2*t+1,n=new Float32Array(e*3);let o=0;for(let r=0;r<t;r++){const l=r/t;n[o++]=0,n[o++]=l,n[o++]=0,n[o++]=1,n[o++]=l,n[o++]=0}n[o++]=.5,n[o++]=1,n[o++]=0;const i=new Uint16Array((t-1)*6+3);let a=0;for(let r=0;r<t-1;r++){const l=r*2;i[a++]=l,i[a++]=l+2,i[a++]=l+1,i[a++]=l+1,i[a++]=l+2,i[a++]=l+3}const c=(t-1)*2;return i[a++]=c,i[a++]=2*t,i[a++]=c+1,{position:new et(n,3),index:new et(i,1)}}function rf(s,t){const e=Ee(t),n=new Uint16Array(s*2),o=Math.ceil(Math.sqrt(s)),i=1/o;let a=0;for(let c=0;c<s;c++){const r=c%o,l=c/o|0;n[a++]=Math.min(65535,(r+e())*i*65535)|0,n[a++]=Math.min(65535,(l+e())*i*65535)|0}for(let c=s-1;c>0;c--){const r=e()*(c+1)|0,l=n[c*2],h=n[c*2+1];n[c*2]=n[r*2],n[c*2+1]=n[r*2+1],n[r*2]=l,n[r*2+1]=h}return n}const Dr=s=>`
uniform float uChunkSize;
uniform vec4  uLod;            // near, nearWidth, far, farWidth
uniform vec3  uLodB;           // widthBoost(angular), heightScale, ringDistance
uniform float uWindGain;
uniform float uPlayerPush;
in vec2  iPos;
in float iGrd;
in vec4  iTint;                // dryness, snow, wetness, lushness
${s?"":`
out vec3  vW;
out vec3  vN;
out float vT;        // height along the blade 0..1
out float vBend;     // how far the blade is laid over 0..1
out vec3  vTint;     // swale, tussock, dryness
out vec2  vBio;      // snow, wetness
out float vSide;     // -1..1 across the blade
out float vOccl;     // shaded by taller neighbours
out float vVar;      // per-blade value/hue jitter, seed head packed in
`}
void degenerate(){ gl_Position = vec4(2.0, 2.0, 2.0, 1.0); }

void main(){
  vec2 vtx = position.xy;              // x = across the blade, y = along it
  // The chunk origin comes straight out of the model matrix (three keeps that up to date
  // per object for free), so all of a ring's chunks share ONE material with ZERO per-draw
  // uniform traffic. Riding along with it: the density fraction the CPU drew in the X
  // scale and the chunk's ground-height range in the Y scale, both constant per chunk and
  // both otherwise a uniform upload per draw.
  vec2 cCen = vec2(modelMatrix[3][0], modelMatrix[3][2]);
  vec2 wxz  = (cCen - vec2(uChunkSize*0.5)) + iPos*uChunkSize;
  vec2 toB  = wxz - uCamPos.xz;
  float d2  = dot(toB, toB);
  float invD = inversesqrt(max(d2, 1e-4));
  float dist = d2*invD;

  /*  Lateral view-cone rejection, per blade, as the very first thing the shader does —
      five instructions, no memory access, no hashing. Culling happens per CHUNK on the
      CPU, and a chunk is a coarse unit: the one the car is standing in is always kept, yet
      more than half of its blades are behind you. uCull.xy is the view direction flattened
      onto the ground and uCull.z the cosine of the widest frustum corner, with a pad for
      blade width and wind lean. Blades within about five metres are exempt, since at that
      range a blade's own width subtends more than the pad. */
  if(d2 > 30.0 && dot(toB, uCull.xy)*invD < uCull.z){ degenerate(); return; }

  // ── overlapping LOD fades: blades grow in and shrink out, never pop ─────
  float fadeIn  = uLod.x <= 0.01 ? 1.0 : smoothstep(uLod.x - uLod.y, uLod.x + uLod.y, dist);
  float fadeOut = uLod.z <= 0.0  ? 1.0 : 1.0 - smoothstep(uLod.z - uLod.w, uLod.z, dist);
  float fade = fadeIn * fadeOut;
  if(fade < 0.006){ degenerate(); return; }

  // ── the density law, resolved per blade ────────────────────────────────
  // The CPU already thinned this chunk to the density its NEAREST corner deserves (it
  // deliberately over-draws), so all that is left here is to reject the surplus against
  // this blade's own true distance. The result is a perfectly smooth radial density
  // gradient with no chunk banding at all — which is what lets the far ring use 160 m
  // chunks and a few dozen draw calls.
  float rQ = hash12(wxz*1.317 + 7.71);
  float dn = uLodB.z;
  float chunkKeep = modelMatrix[0][0];
  // the exponent is 1.5 exactly so this is x·x·inversesqrt(x): three cheap instructions
  float xr = min(dn/max(dist, dn), 1.0);
  float bladeKeep = xr*xr*inversesqrt(max(xr, 1e-6));
  float need = rQ*chunkKeep;
  if(need > bladeKeep){ degenerate(); return; }   // conservative early gate

  /*  The pen issued three vertex texture fetches here — height, meadow, wind — carefully
      arranged so their addresses did not depend on each other. Two of the three are gone:
      the ground and everything the meadow texture used to carry now arrive as instance
      attributes, which cost no latency at all. What is left is the wind, sampled a little
      UPWIND of the blade: a spatial stand-in for the blade's own response lag, so a gust
      front visibly SWEEPS across the field instead of switching on. */
  float ground = modelMatrix[3][1] + iGrd * modelMatrix[1][1];
  vec4  Wsam   = windSample(wxz - uWindLag);

  float dryv  = iTint.x;
  float snowv = iTint.y;
  float lush  = iTint.w;
  // No grass mask gate: the CPU deleted every blade with no business existing — on the
  // carriageway, on a cliff, in the sand. What survives from the pen is the growth ramp,
  // because a hard accept/reject makes a blade POP into existence as you drive at it, and
  // a field full of popping blades shimmers.
  float thr  = bladeKeep*(0.78 + 0.22*lush);
  float grow = clamp((thr - need) / max(thr*0.22, 1e-5), 0.0, 1.0);
  if(grow <= 0.004){ degenerate(); return; }
  fade *= grow;

  // per-blade randomness hashed from WORLD position: the template is shared by every chunk
  // of this ring, yet nothing visibly tiles
  vec3 h3 = hash32(wxz*0.9173 + 11.0);
  float rH = h3.x, rO = h3.y, rS = h3.z;
  float rP = hash12(wxz*2.713 + 31.4);
  // Grass is negatively gravitropic — the stem grows toward vertical whatever the slope
  // does. Being correct here also removes four heightmap taps per vertex.
  vec3 up = vec3(0.0, 1.0, 0.0);

  // ── tussocks: height, hue and lean cluster at metre and decametre scales
  // The pen baked these two bands into its meadow texture because it could not afford
  // gradient noise on twelve million vertices. At a fifth of that count, two value-noise
  // taps are cheaper than the texture fetch they replace — and they stream for free.
  float clumpA = vn2(wxz * 0.0147);          // ~68 m tussock band
  float clumpB = vn2(wxz * 0.00342 + 17.3);  // ~292 m swales

  // a wild hay meadow, not a lawn
  float hgt = (0.30 + rH*0.30);
  hgt *= 0.68 + 0.74*clumpB;
  hgt *= 0.84 + 0.38*clumpA;
  hgt *= mix(1.24, 0.82, dryv);          // dry biomes carry a shorter sward
  hgt *= mix(0.55, 1.0, lush);
  // snow packs a sward flat long before it buries it
  hgt *= mix(1.0, 0.42, snowv * smoothstep(120.0, 240.0, ground));
  hgt *= uLodB.y;
  hgt  = max(hgt, 0.08);

  float wid = (0.0082 + rS*0.0070) * (0.84 + 0.40*clumpA);
  // angular floor: a blade is never allowed to fall below ~1 screen pixel wide
  wid = max(wid, dist * uLodB.x);

  float stiff = 0.52 + rS*0.46 + clumpB*0.10;

  // ── frame ──────────────────────────────────────────────────────────────
  float orient = rO*6.2831853 + clumpA*2.4;
  vec3 axis = vec3(cos(orient), 0.0, sin(orient));
  // at distance, swing the blade to present its face to the eye so it can never disappear
  // edge-on
  vec3 toCam = normalize(vec3(uCamPos.x - wxz.x, 0.0, uCamPos.z - wxz.y) + vec3(1e-5));
  float faceCam = smoothstep(16.0, 80.0, dist);
  axis = normalize(mix(axis, normalize(cross(vec3(0.0,1.0,0.0), toCam)), faceCam*0.88));

  vec3 sideV = normalize(cross(up, axis) + vec3(1e-6));
  vec3 front = normalize(cross(sideV, up));

  vec3 p0  = vec3(wxz.x, ground - 0.035, wxz.y);
  vec3 iv2 = p0 + up*hgt*0.965 + front*hgt*(0.20 + rH*0.34);

  // ── forces ─────────────────────────────────────────────────────────────
  vec2 wv = Wsam.rg; float gustN = Wsam.b, excite = Wsam.a;
  float prof = windProfile(hgt*0.70);
  vec3 wind3 = vec3(wv.x, 0.0, wv.y) * prof;

  vec3 gE = vec3(0.0,-1.0,0.0) * (1.6 + 1.4*rH);
  vec3 gF = 0.25 * length(gE) * front;
  vec3 gv = (gE + gF) * 0.048;

  vec3 dir0 = normalize(iv2 - p0);
  float fd = 1.0 - abs(dot(normalize(wind3 + vec3(1e-5)), dir0));   // alignment
  float fr = clamp(dot(iv2 - p0, up)/hgt, 0.0, 1.0);                // straightness
  vec3 wf = wind3 * (0.30 + 0.95*fd) * fr * uWindGain * (0.55 + 0.75*hgt);

  // quasi-static equilibrium of recovery + gravity + wind (Hooke)
  vec3 v2 = iv2 + (gv + wf) / max(stiff, 0.18);

  // ── ringing: a gust front leaves the blade quivering at its own frequency
  float fB = 1.85 + rS*1.55;
  float ph = rQ*6.2831853;
  float osc = sin(uTime*6.2831853*fB + ph);
  float amp = (excite*0.50 + max(gustN-0.85,0.0)*0.42) * (0.040 + 0.075*(1.0-stiff));
  vec2  wdirn = normalize(wv + vec2(1e-5));
  v2 += vec3(wdirn.x, 0.0, wdirn.y) * osc * amp * hgt;
  // never frozen: a low flutter always present
  v2 += sideV * sin(uTime*7.4*(0.65+rS) + ph*2.3) * hgt * 0.020 * (0.35 + gustN*0.65);

  // ── whatever is standing in the sward parts it ─────────────────────────
  // The pen pushed the grass aside around a walker. Here it is the camera: in a bumper or
  // bonnet view it is a metre off the ground and the sward opens around it; in a chase view
  // the vertical test switches it off, which is correct — the car is five metres ahead.
  if(uPlayerPush > 0.0){
    vec2 dp = wxz - uCamPos.xz;
    float pd = length(dp);
    if(pd < 2.4){
      float vert = 1.0 - smoothstep(1.3, 2.8, abs(uCamPos.y - ground));
      float push = smoothstep(1.85, 0.15, pd) * vert * uPlayerPush;
      v2 += vec3(dp.x, -0.55, dp.y)/max(pd, 0.02) * push * hgt * 0.85;
    }
  }

  // ── state corrections (Jahrmann §5.2) ──────────────────────────────────
  v2 -= up * min(dot(up, v2 - p0), 0.0);
  vec3 d20 = v2 - p0;
  float lproj = length(d20 - up*dot(d20, up));
  vec3 v1 = p0 + hgt*up*max(1.0 - lproj/hgt, 0.05*max(lproj/hgt, 1.0));
  float L0 = length(v2 - p0);
  float L1 = length(v1 - p0) + length(v2 - v1);
  float L  = (2.0*L0 + L1)/3.0;
  float rr = hgt / max(L, 1e-4);
  v1 = p0 + rr*(v1 - p0);
  v2 = v1 + rr*(v2 - v1);

  // ── evaluate the Bézier ────────────────────────────────────────────────
  float head = step(0.895, rP);     // one blade in ten carries a seed head
  float t = vtx.y;
  vec3 a = mix(p0, v1, t);
  vec3 b = mix(v1, v2, t);
  vec3 c = mix(a, b, t);
  vec3 tang = normalize(b - a + vec3(0.0,1e-5,0.0));

  // sqrt rather than pow(x, 0.40): the profile differs by a couple of percent over the
  // length of a blade and it is one transcendental fewer per vertex
  float wprof = sqrt(1.0 - t) * (0.60 + 0.42*smoothstep(0.0, 0.16, t));
  wprof = mix(wprof, wprof*1.9, head*smoothstep(0.80, 0.99, t));
  float u = (vtx.x - 0.5);
  vec3 sideW = normalize(sideV - tang*dot(sideV, tang) + vec3(1e-6));
  vec3 pos = c + sideW * (u * wid * wprof * 2.0 * fade);
  // shrink the whole blade as it fades, so LOD changes are invisible
  pos = mix(p0 + vec3(0.0, 0.02, 0.0), pos, 0.30 + 0.70*fade);

  // ── curved cross-section: two triangles wide, shades like a rolled leaf
  vec3 faceN = normalize(cross(sideW, tang));
  vec3 N = normalize(faceN + sideW*(u*2.0)*0.66);

${s?"":`
  vBend = clamp(1.0 - dot(normalize(v2-p0), up), 0.0, 1.0);
  vT    = t;
  vSide = u*2.0;
  vW    = pos;
  vN    = N;
  // a blade shorter than its neighbours sits in their shade: this is what gives a dense
  // sward its internal depth instead of one flat wall of green
  vOccl = smoothstep(0.18, 1.05, hgt / (0.42 + 0.72*clumpB));
  // the seed-head flag rides in the integer part of vVar
  vVar  = rS*0.6 + rH*0.4 + head*2.0;

  // per-blade hue: the meadow is a mosaic, never one green. The dryness gets a per-blade
  // wobble so a biome border reads as grass drying out patch by patch, not as a gradient.
  vTint = vec3(clumpB, clumpA, clamp(dryv + (rH-0.5)*0.22, 0.0, 1.0));
  vBio  = vec2(snowv, iTint.z);
`}
  gl_Position = projectionMatrix * viewMatrix * vec4(pos, 1.0);
}`,cf=s=>`
in vec3 vW; in vec3 vN; in float vT; in float vBend;
in vec3 vTint; in vec2 vBio; in float vSide; in float vOccl; in float vVar;
out vec4 outColor;

void main(){
  vec3 N = normalize(vN);
  vec3 toEye = uCamPos - vW;
  float vDist = length(toEye);
  vec3 V = toEye / max(vDist, 1e-4);
  if(!gl_FrontFacing) N = -N;
  float vHead = step(1.5, vVar);
  float vVarF = vVar - vHead*2.0;
  float vAO   = mix(0.34, 1.0, pow(vT, 0.55));

  // ── vertical hue path: teal at the root, yellow-green at the tip ───────
  float t = vT;
  vec3 lit = mix(${G.gLow}, ${G.gMid}, smoothstep(0.00, 0.26, t));
  lit = mix(lit, ${G.gUpper}, smoothstep(0.20, 0.66, t));
  lit = mix(lit, ${G.gTip},   smoothstep(0.80, 1.00, t));
  vec3 mid = mix(${G.gBase}, ${G.gMid}, smoothstep(0.05, 0.80, t));
  vec3 shd = mix(${G.gBase}*0.82, ${G.gLow}, smoothstep(0.15, 0.95, t));

  // meadow mosaic
  lit = mix(lit, ${G.gPatchC}, smoothstep(0.35,0.85,vTint.x)*0.45);
  lit = mix(lit, ${G.gPatchA}, smoothstep(0.65,0.15,vTint.x)*0.35);
  mid = mix(mid, ${G.gPatchB}, smoothstep(0.3,0.8,vTint.y)*0.40);
  shd = mix(shd, ${G.tHollow}, smoothstep(0.4,0.9,vTint.y)*0.35);

  // ── the biome, as three scalars rather than five branches ──────────────
  // Dryness bleeds the greens toward straw from the tip down, because that is the order a
  // blade actually cures in. It is a hue rotation and not a desaturation: dead grass is
  // yellow, not grey.
  float dryB = vTint.z;
  float dry = smoothstep(0.10, 0.95, dryB) * smoothstep(0.30, 0.98, t);
  lit = mix(lit, ${G.gDry},      dry*0.72);
  mid = mix(mid, ${G.gDry}*0.72, dry*0.48);
  shd = mix(shd, ${G.gDry}*0.36, dry*0.30);

  // BIOME_TINT's foliage multipliers, along the three axes the instance carries.
  float snowB = vBio.x, wetB = vBio.y;
  vec3 fol = mix(vec3(1.0), F_DRY,  dryB);
  fol *= mix(vec3(1.0), F_COLD, snowB);
  fol *= mix(vec3(1.0), F_WET,  wetB);
  lit *= fol; mid *= fol; shd *= fol;

  // Snow above the line, on the same curve the terrain material uses so a snowfield and
  // the grass poking through it agree about where the line is.
  float snowC = snowB * smoothstep(120.0, 240.0, vW.y);
  lit = mix(lit, vec3(0.95,0.96,0.99), snowC*0.86);
  mid = mix(mid, vec3(0.80,0.85,0.94), snowC*0.86);
  shd = mix(shd, vec3(0.58,0.66,0.82), snowC*0.86);

  // no two blades in a meadow are the same green
  float vj = 0.84 + 0.34*vVarF;
  lit *= vj; mid *= vj*0.98; shd *= 0.92 + 0.20*vVarF;
  lit = mix(lit, ${G.gPatchB}, smoothstep(0.72, 1.0, vVarF)*0.30);

  float ndl = dot(N, uSunDir);
${s<=1?"  float sh = sunShadow(vW, ndl) * cloudShadow(vW);":s===2?"  float sh = sunShadowFast(vW, ndl) * cloudShadow(vW);":"  float sh = cloudShadow(vW);"}
  float selfShadow = mix(0.62, 1.0, pow(t, 0.75));

  // Everything that varies ACROSS the width of a blade — the fanned normal, the rim, the
  // wind flash, the midrib — is sub-pixel detail once a blade is only two or three pixels
  // wide, and sub-pixel detail does not resolve, it sparkles. nearK retires those terms
  // with distance and leaves the ones that vary ALONG the blade, which stay several pixels
  // tall much further out.
  float nearK = 1.0 - smoothstep(55.0, 240.0, vDist);
  N = normalize(mix(vec3(0.0,1.0,0.0), N, 0.34 + 0.66*nearK));

  Surf s;
  s.N=N; s.V=V; s.P=vW;
  s.shade=shd; s.mid=mid; s.lit=lit;
  s.soft = ${s<=1?"mix(0.11, 0.24, clamp(vDist*0.008,0.0,1.0))":"0.20"};
  s.jit  = ${s<=1?"(vn2(vW.xz*3.9 + vW.y*1.7) - 0.5)*0.055":"(vVarF-0.5)*0.05"};
  s.shadow = sh*selfShadow*mix(0.52, 1.0, vOccl);
  s.trans  = 1.00*smoothstep(0.12,0.68,t);
  s.transCol = ${G.gTrans};
  s.rim = 0.34*(0.25 + 0.75*nearK); s.ao = vAO; s.ambient = 1.0;
  vec3 col = paint(s);

  // ── the wind flash ─────────────────────────────────────────────────────
  // a blade laid over by a gust turns its broad face up and catches the light: this is what
  // makes a gust visible as a pale band racing across the field
  float geom = pow(clamp(1.0 - abs(dot(N,V)), 0.0, 1.0), 1.9)*0.45
             + pow(clamp(dot(N, normalize(uSunDir + V)), 0.0, 1.0), 3.2)*0.55;
  float flash = smoothstep(0.34, 0.86, vBend) * smoothstep(0.14, 0.78, t);
  col = mix(col, ${G.gSheen}, geom*flash*0.55*(0.30 + 0.70*sh)*(0.32 + 0.68*nearK));

  // seed head: a warm bronze plume on one blade in ten
  if(vHead > 0.5){
    float hd = smoothstep(0.78, 0.94, t);
    col = mix(col, mix(${G.gDry}, vec3(0.32,0.22,0.14), 0.42)*1.25, hd*0.82);
  }
  // a hint of the midrib, and the deep interior of the sward
  col *= 1.0 - abs(vSide)*0.13*nearK;
  col *= mix(0.46, 1.0, vOccl*0.55 + 0.45);

  // Out past a hundred metres a blade is only two or three pixels wide, and full contrast
  // against the ground behind it is what makes distant grass crawl and sparkle as the
  // camera moves. Converging it toward the sward mean keeps every bit of the texture and
  // takes the edge energy out of it — which is, not coincidentally, exactly what a painter
  // does at that depth.
  col = mix(col, mix(col, ${G.tMid}, 0.62), smoothstep(90.0, 430.0, vDist)*0.42);

  col = aerial(col, vDist, V, vW.y);
  outColor = vec4(SAFE3(col), gFogAmt);
}`;class lf{constructor(t,e){this.cap=e,this.count=0,this.cx=0,this.cz=0,this.wx=0,this.wy=0,this.wz=0,this.frac=1,this.wantFrac=1,this.dirty=!0,this.stamp=-1,this.built=0,this.minY=0,this.ySpan=1,this.lat=new Float32Array((t.R.lat+1)*(t.R.lat+1)*5),this.iPos=new Uint16Array(e*2),this.iGrd=new Uint16Array(e),this.iTint=new Uint8Array(e*4);const n=new ca;n.setAttribute("position",t.blade.position),n.setIndex(t.blade.index),this.aPos=new ve(this.iPos,2,!0),this.aGrd=new ve(this.iGrd,1,!0),this.aTint=new ve(this.iTint,4,!0),n.setAttribute("iPos",this.aPos),n.setAttribute("iGrd",this.aGrd),n.setAttribute("iTint",this.aTint),n.boundingSphere=new Ke(new lt,1e6),n.instanceCount=0,this.geom=n;const o=new Ht(n,t.mat);if(o.frustumCulled=!1,o.renderOrder=4+t.index,o.visible=!1,this.mesh=o,t.preMat){const i=new Ht(n,t.preMat);i.frustumCulled=!1,i.renderOrder=-20+t.index,this.pre=i,o.add(i)}else this.pre=null}dispose(){this.geom.dispose()}}class hf{constructor({seed:t,scene:e,quality:n=1,wind:o=null}={}){this.seed=t>>>0,this.quality=X(n,.25,2),this.wind=o,this.budgetMs=Jd,this.angPerPx=1.012/1080,this._group=new qe,this._group.matrixAutoUpdate=!1,this._group.name="grass",e&&e.add(this._group),this._terrain=null,this._regionX=1/0,this._regionZ=1/0,this.stats={chunks:0,dirty:0,drawn:0,built:0,extended:0,buildMs:0,bytes:0},this._rings=qd.map((i,a)=>this._buildRing(i,a))}get group(){return this._group}setAngular(t){this.angPerPx=t;for(const e of this._rings)e.uni.uLodB.value.x=t*e.R.wpx;return this}_buildRing(t,e){const n=af(t.segs),o=Math.max(64,Math.round(Kd/Math.pow(t.dn,Xi)*t.cs*t.cs*this.quality)),i=rf(o,7e3+e*131+this.seed),a=Zt(Object.assign({uChunkSize:{value:t.cs},uLod:{value:new Fo(t.near,Math.max(7,t.near*.26),t.far,t.far*.26)},uLodB:{value:new lt(this.angPerPx*t.wpx,t.hs,t.dn)},uWindGain:{value:.235},uPlayerPush:{value:e===0?1:0}},Ac())),c=fs({cshSpan:9200,cloudDeck:980}),r=new Ut({glslVersion:"300 es",uniforms:a,vertexShader:Kt(Dt,It,Yi,Dr(!1)),fragmentShader:ce(Dt,It,of,c,Cs,ps,cf(e)),side:ke}),l=t.prepass?new Ut({glslVersion:"300 es",uniforms:a,vertexShader:Kt(Dt,It,Yi,Dr(!0)),fragmentShader:da,side:ke,colorWrite:!1}):null,h=t.grid,u=(h-1)/2,d=new Int32Array(h*h),f=new Float32Array(h*h),p=[];for(let m=-u;m<=u;m++)for(let v=-u;v<=u;v++){const x=(m+u)*h+(v+u),b=uf(t,v,m),y=b<jd?0:Vd(b);f[x]=y,d[x]=y<=0?0:Math.max(48,Math.round(o*y)),d[x]>0&&p.push(x)}return p.sort((m,v)=>{const x=m%h-u,b=(m/h|0)-u,y=v%h-u,A=(v/h|0)-u;return Math.max(Math.abs(x),Math.abs(b))-Math.max(Math.abs(y),Math.abs(A))}),{R:t,index:e,blade:n,tpl:i,full:o,uni:a,mat:r,preMat:l,grid:h,half:u,cap:d,capFrac:f,order:p,slots:new Array(h*h).fill(null),scratch:new Array(h*h).fill(null),pool:[],ox:0,oz:0,stamp:0,ready:!1}}update(t,e,n,o){this.wind&&this.wind.update(o,{x:t,y:n,z:e});const i=performance.now();this._ensureRegion(t,e);for(const c of this._rings)this._recentre(c,t,e);const a=this._drainQueue(i);this.stats.buildMs=performance.now()-i,this.stats.built+=a,this._draw(t,e,n)}_ensureRegion(t,e){this._terrain&&Math.abs(t-this._regionX)<Lr&&Math.abs(e-this._regionZ)<Lr||(this._terrain=new Re(this.seed,t-fo,e-fo,t+fo,e+fo,90),this._regionX=t,this._regionZ=e)}_recentre(t,e,n){const o=t.R.cs,i=Math.floor(e/o),a=Math.floor(n/o);if(t.ready&&i===t.ox&&a===t.oz)return;const c=t.grid,r=t.half;if(t.ready){const l=i-t.ox,h=a-t.oz,u=t.slots,d=t.scratch,f=++t.stamp;d.fill(null);for(let p=-r;p<=r;p++){const g=p+h;if(!(g<-r||g>r))for(let m=-r;m<=r;m++){const v=m+l;if(v<-r||v>r)continue;const x=u[(g+r)*c+(v+r)];x&&(x.stamp=f,d[(p+r)*c+(m+r)]=x)}}for(let p=0;p<u.length;p++){const g=u[p];g&&g.stamp!==f&&this._release(t,g)}t.slots=d,t.scratch=u}t.ox=i,t.oz=a,t.ready=!0;for(let l=0;l<t.order.length;l++){const h=t.order[l],u=t.cap[h],d=t.slots[h];if(d&&d.cap>=u)continue;const f=h%c-r,p=(h/c|0)-r,g=this._acquire(t,u);d?(this._carryOver(d,g),this._release(t,d),this.stats.extended++):(g.cx=i+f,g.cz=a+p),g.wantFrac=t.capFrac[h],t.slots[h]=g}}_carryOver(t,e){e.iPos.set(t.iPos.subarray(0,t.count*2)),e.iGrd.set(t.iGrd.subarray(0,t.count)),e.iTint.set(t.iTint.subarray(0,t.count*4)),e.lat.set(t.lat),e.count=t.count,e.built=t.built,e.cx=t.cx,e.cz=t.cz,e.wx=t.wx,e.wy=t.wy,e.wz=t.wz,e.minY=t.minY,e.ySpan=t.ySpan,e.frac=t.frac,e.mesh.position.copy(t.mesh.position),e.mesh.scale.y=t.ySpan,e.aPos.needsUpdate=!0,e.aGrd.needsUpdate=!0,e.aTint.needsUpdate=!0,e.dirty=!0}_acquire(t,e){let n=-1;for(let i=0;i<t.pool.length;i++){const a=t.pool[i];a.cap<e||(n<0||a.cap<t.pool[n].cap)&&(n=i)}if(n>=0){const i=t.pool.splice(n,1)[0];return i.count=0,i.built=0,i.dirty=!0,i}const o=new lf(t,e);return this._group.add(o.mesh),this.stats.chunks++,this.stats.bytes+=e*10,o}_release(t,e){e.mesh.visible=!1,e.dirty=!0,t.pool.push(e);const n=t.grid+2;for(;t.pool.length>n;){let o=0;for(let a=1;a<t.pool.length;a++)t.pool[a].cap>t.pool[o].cap&&(o=a);const i=t.pool.splice(o,1)[0];this._group.remove(i.mesh),i.dispose(),this.stats.chunks--,this.stats.bytes-=i.cap*10}}_drainQueue(t){let e=0,n=0;for(const o of this._rings)for(let i=0;i<o.order.length;i++){const a=o.slots[o.order[i]];!a||!a.dirty||(n++,!(performance.now()-t>=this.budgetMs)&&(this._buildChunk(o,a),e++))}return this.stats.dirty=n,e}_buildChunk(t,e){const n=t.R,o=n.cs,i=n.lat,a=i+1,c=e.lat,r=e.cx*o,l=e.cz*o;if(e.built===0){const A=this._terrain,_=o/i,S=Bn(r,l,this.seed),T=Bn(r+o,l,this.seed),M=Bn(r,l+o,this.seed),k=Bn(r+o,l+o,this.seed);let R=1/0,P=-1/0;for(let z=0;z<a;z++){const L=l+z*_,U=z/i,W=S+(M-S)*U,I=T+(k-T)*U;for(let H=0;H<a;H++){const V=r+H*_,D=W+(I-W)*(H/i),$=A.height(V,L),q=A.weights(V,L).w;let Q=0,ot=0,ht=0,rt=0;for(let Wt=0;Wt<_t;Wt++){const Ot=q[Wt];Ot<.002||(Q+=Ot*tf[Wt],ot+=Ot*ef[Wt],ht+=Ot*sf[Wt],rt+=Ot*nf[Wt])}const Tt=A.roads.carve(V,L).edge,Pt=(z*a+H)*5;c[Pt]=$,c[Pt+1]=Q*(1-N(Tt))*(1-Zd*D),c[Pt+2]=ot,c[Pt+3]=ht,c[Pt+4]=rt,$<R&&(R=$),$>P&&(P=$)}}for(let z=0;z<a;z++){const L=z>0?z-1:z,U=z<a-1?z+1:z,W=(U-L)*_;for(let I=0;I<a;I++){const H=I>0?I-1:I,V=I<a-1?I+1:I,D=(V-H)*_,$=(c[(z*a+H)*5]-c[(z*a+V)*5])/D,q=(c[(L*a+I)*5]-c[(U*a+I)*5])/W,Q=1/Math.sqrt($*$+q*q+1);c[(z*a+I)*5+1]*=mt(Yd,Xd,Q)}}e.minY=R,e.ySpan=Math.max(P-R,.5),e.wx=r+o*.5,e.wz=l+o*.5,e.wy=R+e.ySpan*.5,e.count=0}const h=e.minY,u=1/e.ySpan,d=t.tpl,f=e.cap,p=e.iPos,g=e.iGrd,m=e.iTint,v=this.seed,x=e.cx,b=e.cz;let y=e.count;for(let A=e.built;A<f;A++){const _=d[A*2],S=d[A*2+1],T=_*Fr*i,M=S*Fr*i;let k=T|0;k>i-1&&(k=i-1);let R=M|0;R>i-1&&(R=i-1);const P=T-k,z=M-R,L=(R*a+k)*5,U=L+5,W=L+a*5,I=W+5,H=(1-P)*(1-z),V=P*(1-z),D=(1-P)*z,$=P*z,q=c[L+1]*H+c[U+1]*V+c[W+1]*D+c[I+1]*$;if(q<=.004||Es(x,b,A,v)*Qd>q)continue;const Q=c[L]*H+c[U]*V+c[W]*D+c[I]*$,ot=c[L+2]*H+c[U+2]*V+c[W+2]*D+c[I+2]*$,ht=c[L+3]*H+c[U+3]*V+c[W+3]*D+c[I+3]*$,rt=c[L+4]*H+c[U+4]*V+c[W+4]*D+c[I+4]*$;p[y*2]=_,p[y*2+1]=S,g[y]=(Q-h)*u*65535|0;const Tt=y*4;m[Tt]=N(ot)*255|0,m[Tt+1]=N(ht)*255|0,m[Tt+2]=N(rt)*255|0,m[Tt+3]=N(q)*255|0,y++}e.count=y,e.built=f,e.aPos.needsUpdate=!0,e.aGrd.needsUpdate=!0,e.aTint.needsUpdate=!0,e.mesh.position.set(e.wx,e.minY,e.wz),e.mesh.scale.y=e.ySpan,e.frac=e.wantFrac,e.dirty=!1}_draw(t,e,n){const o=pt.uCull.value;let i=0;for(const a of this._rings){const c=a.R,r=c.cs,l=Math.max(7,c.near*.26),h=c.far*.26,u=a.slots;for(let d=0;d<u.length;d++){const f=u[d];if(!f)continue;const p=f.mesh;if(f.count===0){p.visible=!1;continue}const g=f.wx-t,m=f.wy-n,v=f.wz-e,x=Math.sqrt(g*g+m*m+v*v);if(x-r*.75>c.far){p.visible=!1;continue}if(x+r*.75<c.near-l){p.visible=!1;continue}if(x>r*1.6){const R=1/Math.sqrt(g*g+v*v||1),P=r*.75/x;if((g*o.x+v*o.y)*R<o.z-P){p.visible=!1;continue}}const b=Math.max(Math.abs(g)-r*.5,0),y=Math.max(Math.abs(v)-r*.5,0),A=Math.max(Math.sqrt(b*b+y*y+m*m),c.dn),_=Math.min(1,Math.pow(c.dn/A,Xi));let S=1;c.near>.01&&(S*=mt(c.near-l-r*.6,c.near+l,x)),S*=1-mt(c.far-h,c.far+r*.6,x);const T=f.frac,M=Math.min(_,T),k=Math.round(f.count*(M/T)*N(S));if(k<=0){p.visible=!1;continue}p.visible=!0,p.scale.x=M,f.geom.instanceCount=k,i+=k}}this.stats.drawn=i}dispose(){for(const t of this._rings){for(const e of t.slots)e&&e.dispose();for(const e of t.pool)e.dispose();t.slots.fill(null),t.pool.length=0,t.mat.dispose(),t.preMat&&t.preMat.dispose()}this._group.clear(),this._group.parent&&this._group.parent.remove(this._group),this._rings.length=0,this.stats.chunks=0,this.stats.bytes=0}}function uf(s,t,e){const n=Math.max(7,s.near*.26),o=s.far*.26,i=Math.hypot(Math.max(Math.abs(t)-1,0)*s.cs,Math.max(Math.abs(e)-1,0)*s.cs);if(i>s.far)return 0;const a=Math.hypot((Math.abs(t)+1)*s.cs,(Math.abs(e)+1)*s.cs);let c=0;const r=24;for(let l=0;l<=r;l++){const h=i+(a-i)*l/r,u=Math.min(1,Math.pow(s.dn/Math.max(h,s.dn),Xi)),d=s.near<=.01?1:mt(s.near-n,s.near+n,h),f=1-mt(s.far-o,s.far,h),p=u*d*f;p>c&&(c=p)}return c}const df=1.7,Ir=520;class ff{constructor({seed:t,material:e,depthMaterial:n=null,workers:o=0,viewDistance:i=7e3,onChunk:a=null,onRelease:c=null,terrain:r="rolling"}){this.seed=t>>>0,this.material=e,this.depthMaterial=n,this.viewDistance=i,this.onChunk=a,this.onRelease=c,this.terrainPreset=r,this.group=new qe,this.group.name="terrain",this.group.matrixAutoUpdate=!1,this.live=new Map,this.pending=new Map,this.queue=[],this.stats={built:0,queued:0,live:0,workers:0,lastMs:0};const l=o||Math.max(2,Math.min(6,(navigator.hardwareConcurrency||4)-2));this.workers=[],this.busy=[];for(let h=0;h<l;h++){const u=new Worker(new URL(""+new URL("chunkWorker-06o6wN8L.js",import.meta.url).href,import.meta.url),{type:"module"});u.onmessage=d=>this._onWorkerMessage(h,d.data),u.onerror=d=>console.error("[streamer] worker error",d.message),this.workers.push(u),this.busy.push(null)}this.stats.workers=l,this._jobId=1,this._camera=new lt,this._maxLevel=Math.min(Mu-1,Math.max(0,Math.ceil(Math.log2(i/Nn))))}_select(t,e){const n=new Map,o=this._maxLevel,i=ds(o),a=Math.ceil(this.viewDistance/i)+1,c=Math.floor(t/i),r=Math.floor(e/i),l=[];for(let h=r-a;h<=r+a;h++)for(let u=c-a;u<=c+a;u++)l.push([u,h,o]);for(;l.length;){const[h,u,d]=l.pop(),f=ds(d),p=(h+.5)*f,g=(u+.5)*f,m=Math.max(Math.abs(t-p)-f*.5,0),v=Math.max(Math.abs(e-g)-f*.5,0),x=Math.hypot(m,v);if(!(x>this.viewDistance))if(d>0&&x<f*df){const b=d-1;l.push([h*2,u*2,b]),l.push([h*2+1,u*2,b]),l.push([h*2,u*2+1,b]),l.push([h*2+1,u*2+1,b])}else n.set(`${d}:${h},${u}`,{cx:h,cz:u,level:d,d:x})}return n}update(t,e){const n=performance.now(),o=this._select(t,e);this.queue.length=0;for(const[i,a]of o)this.live.has(i)||this.pending.has(i)||this.queue.push({key:i,...a});this.queue.sort((i,a)=>i.d-a.d);for(const[i,a]of this.live)o.has(i)||this._release(i,a);if(this.live.size>Ir){const i=[...this.live.entries()].sort((a,c)=>{const r=Math.hypot(a[1].ox+a[1].size*.5-t,a[1].oz+a[1].size*.5-e);return Math.hypot(c[1].ox+c[1].size*.5-t,c[1].oz+c[1].size*.5-e)-r});for(let a=0;a<i.length-Ir;a++)this._release(i[a][0],i[a][1])}this._pump(),this.stats.queued=this.queue.length,this.stats.live=this.live.size,this.stats.lastMs=performance.now()-n}_pump(){for(let t=0;t<this.workers.length&&this.queue.length;t++){if(this.busy[t])continue;const e=this.queue.shift();if(this.live.has(e.key)||this.pending.has(e.key)){t--;continue}const n=this._jobId++;this.busy[t]=e.key,this.pending.set(e.key,n),this.workers[t].postMessage({jobId:n,cx:e.cx,cz:e.cz,level:e.level,seed:this.seed,terrain:this.terrainPreset})}}_onWorkerMessage(t,e){const n=this.busy[t];if(this.busy[t]=null,e.type==="error"){console.error("[streamer] chunk build failed",e.message),n&&this.pending.delete(n),this._pump();return}if(e.type!=="chunk")return;const o=`${e.level}:${e.cx},${e.cz}`;this.pending.delete(o),this.live.has(o)||this._adopt(o,e),this._pump()}_adopt(t,e){const n=new $e;n.setAttribute("position",new et(e.position,3)),n.setAttribute("normal",new et(e.normal,3)),n.setAttribute("aBiome",new et(e.biome,4,!0)),n.setAttribute("aRoad",new et(e.road,2,!0)),n.setIndex(new et(e.index,1));const o=Math.hypot(e.size,e.maxY-e.minY)*.72;n.boundingSphere=new Ke(new lt(e.size*.5,(e.minY+e.maxY)*.5,e.size*.5),o);const i=new Ht(n,this.material);i.position.set(e.ox,0,e.oz),i.frustumCulled=!0,i.matrixAutoUpdate=!1,i.updateMatrix(),i.userData.level=e.level,i.renderOrder=-e.level,this.group.add(i);const a={mesh:i,level:e.level,cx:e.cx,cz:e.cz,size:e.size,ox:e.ox,oz:e.oz,step:e.step,grid:e.grid,minY:e.minY,maxY:e.maxY,heights:e.heights||null,water:e.water||null};this.live.set(t,a),this.stats.built++,this.onChunk&&this.onChunk(a,e)}_release(t,e){this.onRelease&&this.onRelease(e),this.group.remove(e.mesh),e.mesh.geometry.dispose(),this.live.delete(t)}sampleHeight(t,e){const n=Nn,o=`0:${Math.floor(t/n)},${Math.floor(e/n)}`,i=this.live.get(o);if(!i||!i.heights)return null;const a=(t-i.ox)/i.step,c=(e-i.oz)/i.step;let r=Math.floor(a),l=Math.floor(c);const h=i.grid||Eu;if(r<0||l<0||r>h-2||l>h-2)return null;const u=a-r,d=c-l,f=i.heights,p=f[l*h+r],g=f[l*h+r+1],m=f[(l+1)*h+r],v=f[(l+1)*h+r+1];return(p*(1-u)+g*u)*(1-d)+(m*(1-u)+v*u)*d}isReady(t,e){return this.sampleHeight(t,e)!==null}forceChunk(t,e){const n=Math.floor(t/Nn),o=Math.floor(e/Nn),i=`0:${n},${o}`;if(this.live.has(i))return;const a=Ru({cx:n,cz:o,level:0,seed:this.seed});this.pending.delete(i),this._adopt(i,a)}dispose(){for(const t of this.workers)t.terminate();for(const[t,e]of this.live)this._release(t,e)}}const Pr=["gt","sports","hyper"],Or=[{name:"Persimmon",body:B("paintA"),accent:B("paintD")},{name:"Barley",body:B("paintB"),accent:B("paintF")},{name:"Cobalt",body:B("paintC"),accent:B("paintD")},{name:"Chalk",body:B("paintD"),accent:B("paintF")},{name:"Verdigris",body:B("paintE"),accent:B("paintD")},{name:"Ink",body:B("paintF"),accent:B("paintB")},{name:"Rust",body:ut(B("paintA"),B("paintF"),.42),accent:B("paintB")},{name:"Seafoam",body:ut(B("paintE"),B("paintD"),.45),accent:B("paintC")}],pf={gt:{hull:[{z:2.35,yb:.34,yt:.74,wb:.56,wt:.62},{z:1.98,yb:.26,yt:.8,wb:.78,wt:.82},{z:1.39,yb:.22,yt:.86,wb:.86,wt:.92},{z:.6,yb:.22,yt:.9,wb:.88,wt:.92},{z:-.1,yb:.22,yt:.94,wb:.88,wt:.92},{z:-.95,yb:.24,yt:.96,wb:.88,wt:.9},{z:-1.39,yb:.26,yt:.94,wb:.86,wt:.88},{z:-2.35,yb:.44,yt:.82,wb:.62,wt:.66}],cabin:[{z:.58,yb:.86,yt:.99,wb:.84,wt:.66},{z:-.14,yb:.9,yt:1.36,wb:.82,wt:.62},{z:-.86,yb:.92,yt:1.36,wb:.82,wt:.62},{z:-2.06,yb:.84,yt:.98,wb:.74,wt:.5}],axle:[1.39,-1.39],track:[.8,.8],wheel:{rf:.34,rr:.35,wf:.145,wr:.155},lamps:"round",tail:"blocks",wing:"none",intakes:!1},sports:{hull:[{z:2.15,yb:.26,yt:.6,wb:.54,wt:.64},{z:1.72,yb:.2,yt:.7,wb:.8,wt:.88},{z:1.28,yb:.18,yt:.76,wb:.86,wt:.94},{z:.45,yb:.18,yt:.84,wb:.88,wt:.94},{z:-.35,yb:.2,yt:.96,wb:.9,wt:.96},{z:-1.05,yb:.22,yt:1.02,wb:.9,wt:.96},{z:-1.28,yb:.24,yt:1.02,wb:.88,wt:.94},{z:-2.15,yb:.46,yt:.88,wb:.7,wt:.74}],cabin:[{z:.42,yb:.8,yt:.88,wb:.8,wt:.58},{z:-.18,yb:.86,yt:1.24,wb:.78,wt:.56},{z:-.66,yb:.9,yt:1.24,wb:.76,wt:.54},{z:-1.02,yb:.92,yt:1.02,wb:.72,wt:.46}],axle:[1.28,-1.28],track:[.8,.82],wheel:{rf:.33,rr:.35,wf:.15,wr:.175},lamps:"slim",tail:"blocks",wing:"lip",intakes:!0},hyper:{hull:[{z:2.3,yb:.16,yt:.48,wb:.64,wt:.76},{z:1.85,yb:.14,yt:.58,wb:.92,wt:1},{z:1.35,yb:.13,yt:.66,wb:.96,wt:1.03},{z:.5,yb:.13,yt:.74,wb:.96,wt:1.02},{z:-.3,yb:.14,yt:.88,wb:.98,wt:1.03},{z:-1.05,yb:.16,yt:.96,wb:.98,wt:1.03},{z:-1.35,yb:.18,yt:.96,wb:.96,wt:1},{z:-2.3,yb:.36,yt:.84,wb:.78,wt:.84}],cabin:[{z:.46,yb:.7,yt:.8,wb:.82,wt:.54},{z:-.14,yb:.8,yt:1.16,wb:.8,wt:.5},{z:-.62,yb:.84,yt:1.16,wb:.78,wt:.48},{z:-1.06,yb:.86,yt:.98,wb:.72,wt:.42}],axle:[1.35,-1.35],track:[.84,.85],wheel:{rf:.34,rr:.36,wf:.165,wr:.2},lamps:"slim",tail:"bar",wing:"high",intakes:!0}},Nr=s=>[[s.wb,s.yb,s.z],[-s.wb,s.yb,s.z],[-s.wt,s.yt,s.z],[s.wt,s.yt,s.z]];function Br(s,t,e,n,o=!0,i=!0){let a=Nr(t[0]);o&&Me(s,a[0],a[1],a[2],a[3],e,n,[0,0,1]);for(let c=1;c<t.length;c++){const r=Nr(t[c]);Me(s,a[0],a[3],r[3],r[0],e,n,[1,0,0]),Me(s,a[1],a[2],r[2],r[1],e,n,[-1,0,0]),Me(s,a[3],a[2],r[2],r[3],e,n,[0,1,0]),Me(s,a[0],a[1],r[1],r[0],e,n,[0,-1,0]),a=r}i&&Me(s,a[0],a[1],a[2],a[3],e,n,[0,0,-1])}function mi(s,t){if(t>=s[0].z)return s[0];for(let e=1;e<s.length;e++)if(t>=s[e].z){const n=s[e-1],o=s[e],i=(n.z-t)/(n.z-o.z);return{z:t,yb:O(n.yb,o.yb,i),yt:O(n.yt,o.yt,i),wb:O(n.wb,o.wb,i),wt:O(n.wt,o.wt,i)}}return s[s.length-1]}function po(s,t,e,n,o,i,a,c){for(let r=0;r<o;r++){const l=r/o*K,h=(r+1)/o*K,u=Math.cos(l),d=Math.sin(l),f=Math.cos(h),p=Math.sin(h);Me(s,[t,e*u,e*d],[t,e*f,e*p],[t,n*f,n*p],[t,n*u,n*d],i,a,[c,0,0])}}function Gr(s,t){const e=Xt(),n=B("tyre"),o=ut(B("chrome"),B("paintF"),.34),i=Ue(B("chrome"),.72),a=ut(B("tyre"),B("tail"),.34);C(e,[-t,0,0],[t,0,0],s,s,14,n,w.MATTE,!1,!1),po(e,t,s,s*.68,14,Ue(n,1.18),w.MATTE,1),po(e,-t,s,s*.68,14,Ue(n,1.18),w.MATTE,-1),C(e,[-t*.92,0,0],[t*.92,0,0],s*.68,s*.68,8,Ue(o,.7),w.METAL,!1,!1),po(e,t*.92,s*.68,s*.52,12,o,w.METAL,1),po(e,-t*.92,s*.68,s*.52,12,o,w.METAL,-1);for(let c=0;c<5;c++){const r=c/5*K,l=Math.cos(r),h=Math.sin(r);for(const u of[-1,1]){const d=u*t*.9;C(e,[d,s*.18*l,s*.18*h],[d,s*.56*l,s*.56*h],s*.07,s*.06,4,o,w.METAL,!1,!1)}}return C(e,[-t*.96,0,0],[t*.96,0,0],s*.19,s*.19,8,i,w.METAL,!0,!0),C(e,[-t*.42,0,0],[t*.42,0,0],s*.6,s*.6,12,a,w.LAMP_C,!0,!0),cn(e)}function mf(s,t,e){const n=Xt(),o=t.body,i=t.accent,a=B("paintF"),c=B("chrome"),r=B("glass"),l=B("head"),h=B("tail"),u=s.hull[0].z,d=s.hull[s.hull.length-1].z,f=s.hull[0],p=s.hull[s.hull.length-1];Br(n,s.hull,o,w.BODY),Br(n,s.cabin,r,w.GLASS);const g=s.cabin[1],m=s.cabin[2];E(n,0,g.yt+.012,(g.z+m.z)*.5,g.wt*.94,.02,Math.abs(g.z-m.z)*.5+.05,0,o,w.BODY);const v=(s.axle[0]+s.axle[1])*.5,x=mi(s.hull,v);for(const S of[-1,1])E(n,S*(x.wb+.01),x.yb+.07,v,.035,.07,(s.axle[0]-s.axle[1])*.5-.34,0,a,w.MATTE);E(n,0,f.yb+.015,u-.14,f.wb*1.02,.025,.18,0,a,w.MATTE),E(n,0,O(f.yb,f.yt,.28),u-.03,f.wb*.72,.09,.06,0,a,w.GLASS);const b=O(f.yt,f.yb,.26);for(const S of[-1,1]){const T=S*(f.wt*.62);s.lamps==="round"?(C(n,[T,b,u-.12],[T,b,u+.03],.115,.105,8,l,w.LAMP_A,!1,!0),C(n,[T,b,u-.14],[T,b,u-.11],.125,.125,8,c,w.METAL,!1,!0)):(E(n,T,b,u-.02,.2,.045,.08,0,l,w.LAMP_A),E(n,T,b-.055,u-.03,.2,.02,.07,0,a,w.MATTE))}E(n,0,p.yb+.17,d+.015,p.wb*.94,.06,.04,0,a,w.MATTE);const y=O(p.yt,p.yb,.34);if(s.tail==="bar")E(n,0,y,d+.02,p.wt*.82,.035,.05,0,h,w.LAMP_B);else for(const S of[-1,1])E(n,S*p.wt*.55,y,d+.02,.22,.05,.05,0,h,w.LAMP_B);if(s.wing==="lip")E(n,0,p.yt+.04,d+.16,p.wt*.9,.035,.14,0,o,w.BODY);else if(s.wing==="high"){const S=d+.24,T=p.yt+.3;E(n,0,T,S,p.wt*.92,.025,.16,0,o,w.BODY);for(const M of[-1,1])E(n,M*p.wt*.92,T-.02,S,.02,.1,.2,0,i,w.BODY),E(n,M*.3,T-.16,S-.02,.03,.16,.05,0,a,w.METAL)}if(s.intakes){const S=s.axle[1]+.62,T=mi(s.hull,S);for(const M of[-1,1])E(n,M*(O(T.wb,T.wt,.55)+.005),O(T.yb,T.yt,.58),S,.03,.1,.26,0,a,w.GLASS),E(n,M*(O(T.wb,T.wt,.55)+.02),O(T.yb,T.yt,.58),S+.28,.02,.11,.05,0,i,w.BODY)}const A=s.cabin[0].z+.06,_=mi(s.hull,A);for(const S of[-1,1]){const T=S*(_.wt+.02);C(n,[T,_.yt+.02,A],[T+S*.09,_.yt+.09,A-.02],.018,.018,4,a,w.MATTE,!1,!1),E(n,T+S*.11,_.yt+.1,A-.03,.035,.045,.075,0,o,w.BODY)}if(!e){const S=s.cabin[1];for(const T of[-1,1])E(n,T*.32,S.yt-.22,S.z-.16,.13,.11,.05,0,a,w.MATTE),E(n,T*.32,S.yt-.4,S.z-.02,.17,.1,.2,0,Ue(a,1.5),w.MATTE);E(n,0,S.yb+.06,s.cabin[0].z-.1,S.wb*.8,.05,.12,0,Ue(a,1.2),w.MATTE);for(let T=-1;T<=1;T++)E(n,T*p.wb*.42,p.yb+.06,d+.18,.025,.06,.18,0,a,w.MATTE);for(const T of[-1,1])C(n,[T*.22,p.yb+.06,d+.12],[T*.22,p.yb+.06,d-.03],.042,.047,6,Ue(c,.72),w.METAL,!1,!0)}return cn(n)}function Rc(s,t,e){const n=typeof s=="number"?Pr[s]||"sports":Pr.indexOf(s)>=0?s:"sports",o=pf[n],i=Or.length,a=Or[((t|0)%i+i)%i],c=Zo(e?{ghost:!0,opacity:.85}:{}),r=nd(),l=[],h=mf(o,a,e),u=Gr(o.wheel.rf,o.wheel.wf),d=Gr(o.wheel.rr,o.wheel.wr);l.push(h,u,d);const f=new Qe;f.name=`car:${n}`;const p=new Qe;p.name="chassis",f.add(p);const g=new Ht(h,c);g.userData.depth=r,p.add(g);const m=[],v=[],x=(M,k)=>{const R=M?u:d,P=M?o.axle[0]:o.axle[1],z=k*o.track[M?0:1],L=M?o.wheel.rf:o.wheel.rr,U=new Ht(R,c);if(U.userData.depth=r,M){const W=new Qe;W.position.set(z,L,P),f.add(W),W.add(U),m.push(W)}else U.position.set(z,L,P),f.add(U);v.push(U)};x(!0,1),x(!0,-1),x(!1,1),x(!1,-1);const b=c.uniforms.uLamp.value;let y=!1,A=0;const _=()=>{b.x=y?1:0,b.y=Math.max(y?.28:0,A),b.z=A},S=M=>M.getIndex().count/3|0,T=S(h)+2*S(u)+2*S(d);return{group:f,wheels:v,setSteer(M){m[0].rotation.y=M,m[1].rotation.y=M},setWheelSpin(M){for(const k of v)k.rotation.x=M},setBrakeGlow(M){A=N(M),_()},setLights(M){y=!!M,_()},setBodyRoll(M,k){p.rotation.z=M,p.rotation.x=k},triangles:T,dispose(){for(const M of l)M.dispose();c.dispose(),r.dispose(),f.parent&&f.parent.remove(f)}}}function gf({tier:s="sports",paint:t=0}={}){return Rc(s,t,!1)}function vf({tier:s="sports",paint:t=0}={}){return Rc(s,t,!0)}function Ur(s,t){if(t===il)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),s;if(t===Ni||t===j0){let e=s.getIndex();if(e===null){const a=[],c=s.getAttribute("position");if(c!==void 0){for(let r=0;r<c.count;r++)a.push(r);s.setIndex(a),e=s.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),s}const n=e.count-2,o=[];if(t===Ni)for(let a=1;a<=n;a++)o.push(e.getX(0)),o.push(e.getX(a)),o.push(e.getX(a+1));else for(let a=0;a<n;a++)a%2===0?(o.push(e.getX(a)),o.push(e.getX(a+1)),o.push(e.getX(a+2))):(o.push(e.getX(a+2)),o.push(e.getX(a+1)),o.push(e.getX(a)));o.length/3!==n&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");const i=s.clone();return i.setIndex(o),i.clearGroups(),i}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",t),s}class wf extends al{constructor(t){super(t),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(e){return new Tf(e)}),this.register(function(e){return new Af(e)}),this.register(function(e){return new Ff(e)}),this.register(function(e){return new Df(e)}),this.register(function(e){return new If(e)}),this.register(function(e){return new Sf(e)}),this.register(function(e){return new kf(e)}),this.register(function(e){return new Ef(e)}),this.register(function(e){return new Rf(e)}),this.register(function(e){return new _f(e)}),this.register(function(e){return new zf(e)}),this.register(function(e){return new Mf(e)}),this.register(function(e){return new Lf(e)}),this.register(function(e){return new Cf(e)}),this.register(function(e){return new xf(e)}),this.register(function(e){return new Pf(e)}),this.register(function(e){return new Of(e)})}load(t,e,n,o){const i=this;let a;if(this.resourcePath!=="")a=this.resourcePath;else if(this.path!==""){const l=Hn.extractUrlBase(t);a=Hn.resolveURL(l,this.path)}else a=Hn.extractUrlBase(t);this.manager.itemStart(t);const c=function(l){o?o(l):console.error(l),i.manager.itemError(t),i.manager.itemEnd(t)},r=new V0(this.manager);r.setPath(this.path),r.setResponseType("arraybuffer"),r.setRequestHeader(this.requestHeader),r.setWithCredentials(this.withCredentials),r.load(t,function(l){try{i.parse(l,a,function(h){e(h),i.manager.itemEnd(t)},c)}catch(h){c(h)}},n,c)}setDRACOLoader(t){return this.dracoLoader=t,this}setKTX2Loader(t){return this.ktx2Loader=t,this}setMeshoptDecoder(t){return this.meshoptDecoder=t,this}register(t){return this.pluginCallbacks.indexOf(t)===-1&&this.pluginCallbacks.push(t),this}unregister(t){return this.pluginCallbacks.indexOf(t)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(t),1),this}parse(t,e,n,o){let i;const a={},c={},r=new TextDecoder;if(typeof t=="string")i=JSON.parse(t);else if(t instanceof ArrayBuffer)if(r.decode(new Uint8Array(t,0,4))===zc){try{a[at.KHR_BINARY_GLTF]=new Nf(t)}catch(u){o&&o(u);return}i=JSON.parse(a[at.KHR_BINARY_GLTF].content)}else i=JSON.parse(r.decode(t));else i=t;if(i.asset===void 0||i.asset.version[0]<2){o&&o(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}const l=new Zf(i,{path:e||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});l.fileLoader.setRequestHeader(this.requestHeader);for(let h=0;h<this.pluginCallbacks.length;h++){const u=this.pluginCallbacks[h](l);u.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),c[u.name]=u,a[u.name]=!0}if(i.extensionsUsed)for(let h=0;h<i.extensionsUsed.length;++h){const u=i.extensionsUsed[h],d=i.extensionsRequired||[];switch(u){case at.KHR_MATERIALS_UNLIT:a[u]=new yf;break;case at.KHR_DRACO_MESH_COMPRESSION:a[u]=new Bf(i,this.dracoLoader);break;case at.KHR_TEXTURE_TRANSFORM:a[u]=new Gf;break;case at.KHR_MESH_QUANTIZATION:a[u]=new Uf;break;default:d.indexOf(u)>=0&&c[u]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+u+'".')}}l.setExtensions(a),l.setPlugins(c),l.parse(n,o)}parseAsync(t,e){const n=this;return new Promise(function(o,i){n.parse(t,e,o,i)})}}function bf(){let s={};return{get:function(t){return s[t]},add:function(t,e){s[t]=e},remove:function(t){delete s[t]},removeAll:function(){s={}}}}const at={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"};class xf{constructor(t){this.parser=t,this.name=at.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){const t=this.parser,e=this.parser.json.nodes||[];for(let n=0,o=e.length;n<o;n++){const i=e[n];i.extensions&&i.extensions[this.name]&&i.extensions[this.name].light!==void 0&&t._addNodeRef(this.cache,i.extensions[this.name].light)}}_loadLight(t){const e=this.parser,n="light:"+t;let o=e.cache.get(n);if(o)return o;const i=e.json,r=((i.extensions&&i.extensions[this.name]||{}).lights||[])[t];let l;const h=new We(16777215);r.color!==void 0&&h.setRGB(r.color[0],r.color[1],r.color[2],be);const u=r.range!==void 0?r.range:0;switch(r.type){case"directional":l=new ll(h),l.target.position.set(0,0,-1),l.add(l.target);break;case"point":l=new cl(h),l.distance=u;break;case"spot":l=new rl(h),l.distance=u,r.spot=r.spot||{},r.spot.innerConeAngle=r.spot.innerConeAngle!==void 0?r.spot.innerConeAngle:0,r.spot.outerConeAngle=r.spot.outerConeAngle!==void 0?r.spot.outerConeAngle:Math.PI/4,l.angle=r.spot.outerConeAngle,l.penumbra=1-r.spot.innerConeAngle/r.spot.outerConeAngle,l.target.position.set(0,0,-1),l.add(l.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+r.type)}return l.position.set(0,0,0),Ne(l,r),r.intensity!==void 0&&(l.intensity=r.intensity),l.name=e.createUniqueName(r.name||"light_"+t),o=Promise.resolve(l),e.cache.add(n,o),o}getDependency(t,e){if(t==="light")return this._loadLight(e)}createNodeAttachment(t){const e=this,n=this.parser,i=n.json.nodes[t],c=(i.extensions&&i.extensions[this.name]||{}).light;return c===void 0?null:this._loadLight(c).then(function(r){return n._getNodeRef(e.cache,c,r)})}}class yf{constructor(){this.name=at.KHR_MATERIALS_UNLIT}getMaterialType(){return Ln}extendParams(t,e,n){const o=[];t.color=new We(1,1,1),t.opacity=1;const i=e.pbrMetallicRoughness;if(i){if(Array.isArray(i.baseColorFactor)){const a=i.baseColorFactor;t.color.setRGB(a[0],a[1],a[2],be),t.opacity=a[3]}i.baseColorTexture!==void 0&&o.push(n.assignTexture(t,"map",i.baseColorTexture,an))}return Promise.all(o)}}class _f{constructor(t){this.parser=t,this.name=at.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(t,e){const o=this.parser.json.materials[t];if(!o.extensions||!o.extensions[this.name])return Promise.resolve();const i=o.extensions[this.name].emissiveStrength;return i!==void 0&&(e.emissiveIntensity=i),Promise.resolve()}}class Tf{constructor(t){this.parser=t,this.name=at.KHR_MATERIALS_CLEARCOAT}getMaterialType(t){const n=this.parser.json.materials[t];return!n.extensions||!n.extensions[this.name]?null:je}extendMaterialParams(t,e){const n=this.parser,o=n.json.materials[t];if(!o.extensions||!o.extensions[this.name])return Promise.resolve();const i=[],a=o.extensions[this.name];if(a.clearcoatFactor!==void 0&&(e.clearcoat=a.clearcoatFactor),a.clearcoatTexture!==void 0&&i.push(n.assignTexture(e,"clearcoatMap",a.clearcoatTexture)),a.clearcoatRoughnessFactor!==void 0&&(e.clearcoatRoughness=a.clearcoatRoughnessFactor),a.clearcoatRoughnessTexture!==void 0&&i.push(n.assignTexture(e,"clearcoatRoughnessMap",a.clearcoatRoughnessTexture)),a.clearcoatNormalTexture!==void 0&&(i.push(n.assignTexture(e,"clearcoatNormalMap",a.clearcoatNormalTexture)),a.clearcoatNormalTexture.scale!==void 0)){const c=a.clearcoatNormalTexture.scale;e.clearcoatNormalScale=new Et(c,c)}return Promise.all(i)}}class Af{constructor(t){this.parser=t,this.name=at.KHR_MATERIALS_DISPERSION}getMaterialType(t){const n=this.parser.json.materials[t];return!n.extensions||!n.extensions[this.name]?null:je}extendMaterialParams(t,e){const o=this.parser.json.materials[t];if(!o.extensions||!o.extensions[this.name])return Promise.resolve();const i=o.extensions[this.name];return e.dispersion=i.dispersion!==void 0?i.dispersion:0,Promise.resolve()}}class Mf{constructor(t){this.parser=t,this.name=at.KHR_MATERIALS_IRIDESCENCE}getMaterialType(t){const n=this.parser.json.materials[t];return!n.extensions||!n.extensions[this.name]?null:je}extendMaterialParams(t,e){const n=this.parser,o=n.json.materials[t];if(!o.extensions||!o.extensions[this.name])return Promise.resolve();const i=[],a=o.extensions[this.name];return a.iridescenceFactor!==void 0&&(e.iridescence=a.iridescenceFactor),a.iridescenceTexture!==void 0&&i.push(n.assignTexture(e,"iridescenceMap",a.iridescenceTexture)),a.iridescenceIor!==void 0&&(e.iridescenceIOR=a.iridescenceIor),e.iridescenceThicknessRange===void 0&&(e.iridescenceThicknessRange=[100,400]),a.iridescenceThicknessMinimum!==void 0&&(e.iridescenceThicknessRange[0]=a.iridescenceThicknessMinimum),a.iridescenceThicknessMaximum!==void 0&&(e.iridescenceThicknessRange[1]=a.iridescenceThicknessMaximum),a.iridescenceThicknessTexture!==void 0&&i.push(n.assignTexture(e,"iridescenceThicknessMap",a.iridescenceThicknessTexture)),Promise.all(i)}}class Sf{constructor(t){this.parser=t,this.name=at.KHR_MATERIALS_SHEEN}getMaterialType(t){const n=this.parser.json.materials[t];return!n.extensions||!n.extensions[this.name]?null:je}extendMaterialParams(t,e){const n=this.parser,o=n.json.materials[t];if(!o.extensions||!o.extensions[this.name])return Promise.resolve();const i=[];e.sheenColor=new We(0,0,0),e.sheenRoughness=0,e.sheen=1;const a=o.extensions[this.name];if(a.sheenColorFactor!==void 0){const c=a.sheenColorFactor;e.sheenColor.setRGB(c[0],c[1],c[2],be)}return a.sheenRoughnessFactor!==void 0&&(e.sheenRoughness=a.sheenRoughnessFactor),a.sheenColorTexture!==void 0&&i.push(n.assignTexture(e,"sheenColorMap",a.sheenColorTexture,an)),a.sheenRoughnessTexture!==void 0&&i.push(n.assignTexture(e,"sheenRoughnessMap",a.sheenRoughnessTexture)),Promise.all(i)}}class kf{constructor(t){this.parser=t,this.name=at.KHR_MATERIALS_TRANSMISSION}getMaterialType(t){const n=this.parser.json.materials[t];return!n.extensions||!n.extensions[this.name]?null:je}extendMaterialParams(t,e){const n=this.parser,o=n.json.materials[t];if(!o.extensions||!o.extensions[this.name])return Promise.resolve();const i=[],a=o.extensions[this.name];return a.transmissionFactor!==void 0&&(e.transmission=a.transmissionFactor),a.transmissionTexture!==void 0&&i.push(n.assignTexture(e,"transmissionMap",a.transmissionTexture)),Promise.all(i)}}class Ef{constructor(t){this.parser=t,this.name=at.KHR_MATERIALS_VOLUME}getMaterialType(t){const n=this.parser.json.materials[t];return!n.extensions||!n.extensions[this.name]?null:je}extendMaterialParams(t,e){const n=this.parser,o=n.json.materials[t];if(!o.extensions||!o.extensions[this.name])return Promise.resolve();const i=[],a=o.extensions[this.name];e.thickness=a.thicknessFactor!==void 0?a.thicknessFactor:0,a.thicknessTexture!==void 0&&i.push(n.assignTexture(e,"thicknessMap",a.thicknessTexture)),e.attenuationDistance=a.attenuationDistance||1/0;const c=a.attenuationColor||[1,1,1];return e.attenuationColor=new We().setRGB(c[0],c[1],c[2],be),Promise.all(i)}}class Rf{constructor(t){this.parser=t,this.name=at.KHR_MATERIALS_IOR}getMaterialType(t){const n=this.parser.json.materials[t];return!n.extensions||!n.extensions[this.name]?null:je}extendMaterialParams(t,e){const o=this.parser.json.materials[t];if(!o.extensions||!o.extensions[this.name])return Promise.resolve();const i=o.extensions[this.name];return e.ior=i.ior!==void 0?i.ior:1.5,Promise.resolve()}}class zf{constructor(t){this.parser=t,this.name=at.KHR_MATERIALS_SPECULAR}getMaterialType(t){const n=this.parser.json.materials[t];return!n.extensions||!n.extensions[this.name]?null:je}extendMaterialParams(t,e){const n=this.parser,o=n.json.materials[t];if(!o.extensions||!o.extensions[this.name])return Promise.resolve();const i=[],a=o.extensions[this.name];e.specularIntensity=a.specularFactor!==void 0?a.specularFactor:1,a.specularTexture!==void 0&&i.push(n.assignTexture(e,"specularIntensityMap",a.specularTexture));const c=a.specularColorFactor||[1,1,1];return e.specularColor=new We().setRGB(c[0],c[1],c[2],be),a.specularColorTexture!==void 0&&i.push(n.assignTexture(e,"specularColorMap",a.specularColorTexture,an)),Promise.all(i)}}class Cf{constructor(t){this.parser=t,this.name=at.EXT_MATERIALS_BUMP}getMaterialType(t){const n=this.parser.json.materials[t];return!n.extensions||!n.extensions[this.name]?null:je}extendMaterialParams(t,e){const n=this.parser,o=n.json.materials[t];if(!o.extensions||!o.extensions[this.name])return Promise.resolve();const i=[],a=o.extensions[this.name];return e.bumpScale=a.bumpFactor!==void 0?a.bumpFactor:1,a.bumpTexture!==void 0&&i.push(n.assignTexture(e,"bumpMap",a.bumpTexture)),Promise.all(i)}}class Lf{constructor(t){this.parser=t,this.name=at.KHR_MATERIALS_ANISOTROPY}getMaterialType(t){const n=this.parser.json.materials[t];return!n.extensions||!n.extensions[this.name]?null:je}extendMaterialParams(t,e){const n=this.parser,o=n.json.materials[t];if(!o.extensions||!o.extensions[this.name])return Promise.resolve();const i=[],a=o.extensions[this.name];return a.anisotropyStrength!==void 0&&(e.anisotropy=a.anisotropyStrength),a.anisotropyRotation!==void 0&&(e.anisotropyRotation=a.anisotropyRotation),a.anisotropyTexture!==void 0&&i.push(n.assignTexture(e,"anisotropyMap",a.anisotropyTexture)),Promise.all(i)}}class Ff{constructor(t){this.parser=t,this.name=at.KHR_TEXTURE_BASISU}loadTexture(t){const e=this.parser,n=e.json,o=n.textures[t];if(!o.extensions||!o.extensions[this.name])return null;const i=o.extensions[this.name],a=e.options.ktx2Loader;if(!a){if(n.extensionsRequired&&n.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return e.loadTextureImage(t,i.source,a)}}class Df{constructor(t){this.parser=t,this.name=at.EXT_TEXTURE_WEBP}loadTexture(t){const e=this.name,n=this.parser,o=n.json,i=o.textures[t];if(!i.extensions||!i.extensions[e])return null;const a=i.extensions[e],c=o.images[a.source];let r=n.textureLoader;if(c.uri){const l=n.options.manager.getHandler(c.uri);l!==null&&(r=l)}return n.loadTextureImage(t,a.source,r)}}class If{constructor(t){this.parser=t,this.name=at.EXT_TEXTURE_AVIF}loadTexture(t){const e=this.name,n=this.parser,o=n.json,i=o.textures[t];if(!i.extensions||!i.extensions[e])return null;const a=i.extensions[e],c=o.images[a.source];let r=n.textureLoader;if(c.uri){const l=n.options.manager.getHandler(c.uri);l!==null&&(r=l)}return n.loadTextureImage(t,a.source,r)}}class Pf{constructor(t){this.name=at.EXT_MESHOPT_COMPRESSION,this.parser=t}loadBufferView(t){const e=this.parser.json,n=e.bufferViews[t];if(n.extensions&&n.extensions[this.name]){const o=n.extensions[this.name],i=this.parser.getDependency("buffer",o.buffer),a=this.parser.options.meshoptDecoder;if(!a||!a.supported){if(e.extensionsRequired&&e.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return i.then(function(c){const r=o.byteOffset||0,l=o.byteLength||0,h=o.count,u=o.byteStride,d=new Uint8Array(c,r,l);return a.decodeGltfBufferAsync?a.decodeGltfBufferAsync(h,u,d,o.mode,o.filter).then(function(f){return f.buffer}):a.ready.then(function(){const f=new ArrayBuffer(h*u);return a.decodeGltfBuffer(new Uint8Array(f),h,u,d,o.mode,o.filter),f})})}else return null}}class Of{constructor(t){this.name=at.EXT_MESH_GPU_INSTANCING,this.parser=t}createNodeMesh(t){const e=this.parser.json,n=e.nodes[t];if(!n.extensions||!n.extensions[this.name]||n.mesh===void 0)return null;const o=e.meshes[n.mesh];for(const l of o.primitives)if(l.mode!==me.TRIANGLES&&l.mode!==me.TRIANGLE_STRIP&&l.mode!==me.TRIANGLE_FAN&&l.mode!==void 0)return null;const a=n.extensions[this.name].attributes,c=[],r={};for(const l in a)c.push(this.parser.getDependency("accessor",a[l]).then(h=>(r[l]=h,r[l])));return c.length<1?null:(c.push(this.parser.createNodeMesh(t)),Promise.all(c).then(l=>{const h=l.pop(),u=h.isGroup?h.children:[h],d=l[0].count,f=[];for(const p of u){const g=new on,m=new lt,v=new la,x=new lt(1,1,1),b=new q0(p.geometry,p.material,d);for(let y=0;y<d;y++)r.TRANSLATION&&m.fromBufferAttribute(r.TRANSLATION,y),r.ROTATION&&v.fromBufferAttribute(r.ROTATION,y),r.SCALE&&x.fromBufferAttribute(r.SCALE,y),b.setMatrixAt(y,g.compose(m,v,x));for(const y in r)if(y==="_COLOR_0"){const A=r[y];b.instanceColor=new ve(A.array,A.itemSize,A.normalized)}else y!=="TRANSLATION"&&y!=="ROTATION"&&y!=="SCALE"&&p.geometry.setAttribute(y,r[y]);qe.prototype.copy.call(b,p),this.parser.assignFinalMaterial(b),f.push(b)}return h.isGroup?(h.clear(),h.add(...f),h):f[0]}))}}const zc="glTF",Tn=12,Hr={JSON:1313821514,BIN:5130562};class Nf{constructor(t){this.name=at.KHR_BINARY_GLTF,this.content=null,this.body=null;const e=new DataView(t,0,Tn),n=new TextDecoder;if(this.header={magic:n.decode(new Uint8Array(t.slice(0,4))),version:e.getUint32(4,!0),length:e.getUint32(8,!0)},this.header.magic!==zc)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");const o=this.header.length-Tn,i=new DataView(t,Tn);let a=0;for(;a<o;){const c=i.getUint32(a,!0);a+=4;const r=i.getUint32(a,!0);if(a+=4,r===Hr.JSON){const l=new Uint8Array(t,Tn+a,c);this.content=n.decode(l)}else if(r===Hr.BIN){const l=Tn+a;this.body=t.slice(l,l+c)}a+=c}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}}class Bf{constructor(t,e){if(!e)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=at.KHR_DRACO_MESH_COMPRESSION,this.json=t,this.dracoLoader=e,this.dracoLoader.preload()}decodePrimitive(t,e){const n=this.json,o=this.dracoLoader,i=t.extensions[this.name].bufferView,a=t.extensions[this.name].attributes,c={},r={},l={};for(const h in a){const u=Zi[h]||h.toLowerCase();c[u]=a[h]}for(const h in t.attributes){const u=Zi[h]||h.toLowerCase();if(a[h]!==void 0){const d=n.accessors[t.attributes[h]],f=en[d.componentType];l[u]=f.name,r[u]=d.normalized===!0}}return e.getDependency("bufferView",i).then(function(h){return new Promise(function(u,d){o.decodeDracoFile(h,function(f){for(const p in f.attributes){const g=f.attributes[p],m=r[p];m!==void 0&&(g.normalized=m)}u(f)},c,l,be,d)})})}}class Gf{constructor(){this.name=at.KHR_TEXTURE_TRANSFORM}extendTexture(t,e){return(e.texCoord===void 0||e.texCoord===t.channel)&&e.offset===void 0&&e.rotation===void 0&&e.scale===void 0||(t=t.clone(),e.texCoord!==void 0&&(t.channel=e.texCoord),e.offset!==void 0&&t.offset.fromArray(e.offset),e.rotation!==void 0&&(t.rotation=e.rotation),e.scale!==void 0&&t.repeat.fromArray(e.scale),t.needsUpdate=!0),t}}class Uf{constructor(){this.name=at.KHR_MESH_QUANTIZATION}}class Cc extends Ll{constructor(t,e,n,o){super(t,e,n,o)}copySampleValue_(t){const e=this.resultBuffer,n=this.sampleValues,o=this.valueSize,i=t*o*3+o;for(let a=0;a!==o;a++)e[a]=n[i+a];return e}interpolate_(t,e,n,o){const i=this.resultBuffer,a=this.sampleValues,c=this.valueSize,r=c*2,l=c*3,h=o-e,u=(n-e)/h,d=u*u,f=d*u,p=t*l,g=p-l,m=-2*f+3*d,v=f-d,x=1-m,b=v-d+u;for(let y=0;y!==c;y++){const A=a[g+y+c],_=a[g+y+r]*h,S=a[p+y+c],T=a[p+y]*h;i[y]=x*A+b*_+m*S+v*T}return i}}const Hf=new la;class Wf extends Cc{interpolate_(t,e,n,o){const i=super.interpolate_(t,e,n,o);return Hf.fromArray(i).normalize().toArray(i),i}}const me={POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6},en={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},Wr={9728:Y0,9729:te,9984:ml,9985:pl,9986:fl,9987:ra},$r={33071:Se,33648:gl,10497:Bi},gi={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},Zi={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},ns={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},$f={CUBICSPLINE:void 0,LINEAR:J0,STEP:zl},vi={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function Kf(s){return s.DefaultMaterial===void 0&&(s.DefaultMaterial=new X0({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:ia})),s.DefaultMaterial}function ms(s,t,e){for(const n in e.extensions)s[n]===void 0&&(t.userData.gltfExtensions=t.userData.gltfExtensions||{},t.userData.gltfExtensions[n]=e.extensions[n])}function Ne(s,t){t.extras!==void 0&&(typeof t.extras=="object"?Object.assign(s.userData,t.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+t.extras))}function qf(s,t,e){let n=!1,o=!1,i=!1;for(let l=0,h=t.length;l<h;l++){const u=t[l];if(u.POSITION!==void 0&&(n=!0),u.NORMAL!==void 0&&(o=!0),u.COLOR_0!==void 0&&(i=!0),n&&o&&i)break}if(!n&&!o&&!i)return Promise.resolve(s);const a=[],c=[],r=[];for(let l=0,h=t.length;l<h;l++){const u=t[l];if(n){const d=u.POSITION!==void 0?e.getDependency("accessor",u.POSITION):s.attributes.position;a.push(d)}if(o){const d=u.NORMAL!==void 0?e.getDependency("accessor",u.NORMAL):s.attributes.normal;c.push(d)}if(i){const d=u.COLOR_0!==void 0?e.getDependency("accessor",u.COLOR_0):s.attributes.color;r.push(d)}}return Promise.all([Promise.all(a),Promise.all(c),Promise.all(r)]).then(function(l){const h=l[0],u=l[1],d=l[2];return n&&(s.morphAttributes.position=h),o&&(s.morphAttributes.normal=u),i&&(s.morphAttributes.color=d),s.morphTargetsRelative=!0,s})}function jf(s,t){if(s.updateMorphTargets(),t.weights!==void 0)for(let e=0,n=t.weights.length;e<n;e++)s.morphTargetInfluences[e]=t.weights[e];if(t.extras&&Array.isArray(t.extras.targetNames)){const e=t.extras.targetNames;if(s.morphTargetInfluences.length===e.length){s.morphTargetDictionary={};for(let n=0,o=e.length;n<o;n++)s.morphTargetDictionary[e[n]]=n}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function Vf(s){let t;const e=s.extensions&&s.extensions[at.KHR_DRACO_MESH_COMPRESSION];if(e?t="draco:"+e.bufferView+":"+e.indices+":"+wi(e.attributes):t=s.indices+":"+wi(s.attributes)+":"+s.mode,s.targets!==void 0)for(let n=0,o=s.targets.length;n<o;n++)t+=":"+wi(s.targets[n]);return t}function wi(s){let t="";const e=Object.keys(s).sort();for(let n=0,o=e.length;n<o;n++)t+=e[n]+":"+s[e[n]]+";";return t}function Ji(s){switch(s){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function Yf(s){return s.search(/\.jpe?g($|\?)/i)>0||s.search(/^data\:image\/jpeg/)===0?"image/jpeg":s.search(/\.webp($|\?)/i)>0||s.search(/^data\:image\/webp/)===0?"image/webp":s.search(/\.ktx2($|\?)/i)>0||s.search(/^data\:image\/ktx2/)===0?"image/ktx2":"image/png"}const Xf=new on;class Zf{constructor(t={},e={}){this.json=t,this.extensions={},this.plugins={},this.options=e,this.cache=new bf,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let n=!1,o=-1,i=!1,a=-1;if(typeof navigator<"u"){const c=navigator.userAgent;n=/^((?!chrome|android).)*safari/i.test(c)===!0;const r=c.match(/Version\/(\d+)/);o=n&&r?parseInt(r[1],10):-1,i=c.indexOf("Firefox")>-1,a=i?c.match(/Firefox\/([0-9]+)\./)[1]:-1}typeof createImageBitmap>"u"||n&&o<17||i&&a<98?this.textureLoader=new hl(this.options.manager):this.textureLoader=new ul(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new V0(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(t){this.extensions=t}setPlugins(t){this.plugins=t}parse(t,e){const n=this,o=this.json,i=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(a){return a._markDefs&&a._markDefs()}),Promise.all(this._invokeAll(function(a){return a.beforeRoot&&a.beforeRoot()})).then(function(){return Promise.all([n.getDependencies("scene"),n.getDependencies("animation"),n.getDependencies("camera")])}).then(function(a){const c={scene:a[0][o.scene||0],scenes:a[0],animations:a[1],cameras:a[2],asset:o.asset,parser:n,userData:{}};return ms(i,c,o),Ne(c,o),Promise.all(n._invokeAll(function(r){return r.afterRoot&&r.afterRoot(c)})).then(function(){for(const r of c.scenes)r.updateMatrixWorld();t(c)})}).catch(e)}_markDefs(){const t=this.json.nodes||[],e=this.json.skins||[],n=this.json.meshes||[];for(let o=0,i=e.length;o<i;o++){const a=e[o].joints;for(let c=0,r=a.length;c<r;c++)t[a[c]].isBone=!0}for(let o=0,i=t.length;o<i;o++){const a=t[o];a.mesh!==void 0&&(this._addNodeRef(this.meshCache,a.mesh),a.skin!==void 0&&(n[a.mesh].isSkinnedMesh=!0)),a.camera!==void 0&&this._addNodeRef(this.cameraCache,a.camera)}}_addNodeRef(t,e){e!==void 0&&(t.refs[e]===void 0&&(t.refs[e]=t.uses[e]=0),t.refs[e]++)}_getNodeRef(t,e,n){if(t.refs[e]<=1)return n;const o=n.clone(),i=(a,c)=>{const r=this.associations.get(a);r!=null&&this.associations.set(c,r);for(const[l,h]of a.children.entries())i(h,c.children[l])};return i(n,o),o.name+="_instance_"+t.uses[e]++,o}_invokeOne(t){const e=Object.values(this.plugins);e.push(this);for(let n=0;n<e.length;n++){const o=t(e[n]);if(o)return o}return null}_invokeAll(t){const e=Object.values(this.plugins);e.unshift(this);const n=[];for(let o=0;o<e.length;o++){const i=t(e[o]);i&&n.push(i)}return n}getDependency(t,e){const n=t+":"+e;let o=this.cache.get(n);if(!o){switch(t){case"scene":o=this.loadScene(e);break;case"node":o=this._invokeOne(function(i){return i.loadNode&&i.loadNode(e)});break;case"mesh":o=this._invokeOne(function(i){return i.loadMesh&&i.loadMesh(e)});break;case"accessor":o=this.loadAccessor(e);break;case"bufferView":o=this._invokeOne(function(i){return i.loadBufferView&&i.loadBufferView(e)});break;case"buffer":o=this.loadBuffer(e);break;case"material":o=this._invokeOne(function(i){return i.loadMaterial&&i.loadMaterial(e)});break;case"texture":o=this._invokeOne(function(i){return i.loadTexture&&i.loadTexture(e)});break;case"skin":o=this.loadSkin(e);break;case"animation":o=this._invokeOne(function(i){return i.loadAnimation&&i.loadAnimation(e)});break;case"camera":o=this.loadCamera(e);break;default:if(o=this._invokeOne(function(i){return i!=this&&i.getDependency&&i.getDependency(t,e)}),!o)throw new Error("Unknown type: "+t);break}this.cache.add(n,o)}return o}getDependencies(t){let e=this.cache.get(t);if(!e){const n=this,o=this.json[t+(t==="mesh"?"es":"s")]||[];e=Promise.all(o.map(function(i,a){return n.getDependency(t,a)})),this.cache.add(t,e)}return e}loadBuffer(t){const e=this.json.buffers[t],n=this.fileLoader;if(e.type&&e.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+e.type+" buffer type is not supported.");if(e.uri===void 0&&t===0)return Promise.resolve(this.extensions[at.KHR_BINARY_GLTF].body);const o=this.options;return new Promise(function(i,a){n.load(Hn.resolveURL(e.uri,o.path),i,void 0,function(){a(new Error('THREE.GLTFLoader: Failed to load buffer "'+e.uri+'".'))})})}loadBufferView(t){const e=this.json.bufferViews[t];return this.getDependency("buffer",e.buffer).then(function(n){const o=e.byteLength||0,i=e.byteOffset||0;return n.slice(i,i+o)})}loadAccessor(t){const e=this,n=this.json,o=this.json.accessors[t];if(o.bufferView===void 0&&o.sparse===void 0){const a=gi[o.type],c=en[o.componentType],r=o.normalized===!0,l=new c(o.count*a);return Promise.resolve(new et(l,a,r))}const i=[];return o.bufferView!==void 0?i.push(this.getDependency("bufferView",o.bufferView)):i.push(null),o.sparse!==void 0&&(i.push(this.getDependency("bufferView",o.sparse.indices.bufferView)),i.push(this.getDependency("bufferView",o.sparse.values.bufferView))),Promise.all(i).then(function(a){const c=a[0],r=gi[o.type],l=en[o.componentType],h=l.BYTES_PER_ELEMENT,u=h*r,d=o.byteOffset||0,f=o.bufferView!==void 0?n.bufferViews[o.bufferView].byteStride:void 0,p=o.normalized===!0;let g,m;if(f&&f!==u){const v=Math.floor(d/f),x="InterleavedBuffer:"+o.bufferView+":"+o.componentType+":"+v+":"+o.count;let b=e.cache.get(x);b||(g=new l(c,v*f,o.count*f/h),b=new dl(g,f/h),e.cache.add(x,b)),m=new Cl(b,r,d%f/h,p)}else c===null?g=new l(o.count*r):g=new l(c,d,o.count*r),m=new et(g,r,p);if(o.sparse!==void 0){const v=gi.SCALAR,x=en[o.sparse.indices.componentType],b=o.sparse.indices.byteOffset||0,y=o.sparse.values.byteOffset||0,A=new x(a[1],b,o.sparse.count*v),_=new l(a[2],y,o.sparse.count*r);c!==null&&(m=new et(m.array.slice(),m.itemSize,m.normalized)),m.normalized=!1;for(let S=0,T=A.length;S<T;S++){const M=A[S];if(m.setX(M,_[S*r]),r>=2&&m.setY(M,_[S*r+1]),r>=3&&m.setZ(M,_[S*r+2]),r>=4&&m.setW(M,_[S*r+3]),r>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}m.normalized=p}return m})}loadTexture(t){const e=this.json,n=this.options,i=e.textures[t].source,a=e.images[i];let c=this.textureLoader;if(a.uri){const r=n.manager.getHandler(a.uri);r!==null&&(c=r)}return this.loadTextureImage(t,i,c)}loadTextureImage(t,e,n){const o=this,i=this.json,a=i.textures[t],c=i.images[e],r=(c.uri||c.bufferView)+":"+a.sampler;if(this.textureCache[r])return this.textureCache[r];const l=this.loadImageSource(e,n).then(function(h){h.flipY=!1,h.name=a.name||c.name||"",h.name===""&&typeof c.uri=="string"&&c.uri.startsWith("data:image/")===!1&&(h.name=c.uri);const d=(i.samplers||{})[a.sampler]||{};return h.magFilter=Wr[d.magFilter]||te,h.minFilter=Wr[d.minFilter]||ra,h.wrapS=$r[d.wrapS]||Bi,h.wrapT=$r[d.wrapT]||Bi,h.generateMipmaps=!h.isCompressedTexture&&h.minFilter!==Y0&&h.minFilter!==te,o.associations.set(h,{textures:t}),h}).catch(function(){return null});return this.textureCache[r]=l,l}loadImageSource(t,e){const n=this,o=this.json,i=this.options;if(this.sourceCache[t]!==void 0)return this.sourceCache[t].then(u=>u.clone());const a=o.images[t],c=self.URL||self.webkitURL;let r=a.uri||"",l=!1;if(a.bufferView!==void 0)r=n.getDependency("bufferView",a.bufferView).then(function(u){l=!0;const d=new Blob([u],{type:a.mimeType});return r=c.createObjectURL(d),r});else if(a.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+t+" is missing URI and bufferView");const h=Promise.resolve(r).then(function(u){return new Promise(function(d,f){let p=d;e.isImageBitmapLoader===!0&&(p=function(g){const m=new Fa(g);m.needsUpdate=!0,d(m)}),e.load(Hn.resolveURL(u,i.path),p,void 0,f)})}).then(function(u){return l===!0&&c.revokeObjectURL(r),Ne(u,a),u.userData.mimeType=a.mimeType||Yf(a.uri),u}).catch(function(u){throw console.error("THREE.GLTFLoader: Couldn't load texture",r),u});return this.sourceCache[t]=h,h}assignTexture(t,e,n,o){const i=this;return this.getDependency("texture",n.index).then(function(a){if(!a)return null;if(n.texCoord!==void 0&&n.texCoord>0&&(a=a.clone(),a.channel=n.texCoord),i.extensions[at.KHR_TEXTURE_TRANSFORM]){const c=n.extensions!==void 0?n.extensions[at.KHR_TEXTURE_TRANSFORM]:void 0;if(c){const r=i.associations.get(a);a=i.extensions[at.KHR_TEXTURE_TRANSFORM].extendTexture(a,c),i.associations.set(a,r)}}return o!==void 0&&(a.colorSpace=o),t[e]=a,a})}assignFinalMaterial(t){const e=t.geometry;let n=t.material;const o=e.attributes.tangent===void 0,i=e.attributes.color!==void 0,a=e.attributes.normal===void 0;if(t.isPoints){const c="PointsMaterial:"+n.uuid;let r=this.cache.get(c);r||(r=new vl,ai.prototype.copy.call(r,n),r.color.copy(n.color),r.map=n.map,r.sizeAttenuation=!1,this.cache.add(c,r)),n=r}else if(t.isLine){const c="LineBasicMaterial:"+n.uuid;let r=this.cache.get(c);r||(r=new wl,ai.prototype.copy.call(r,n),r.color.copy(n.color),r.map=n.map,this.cache.add(c,r)),n=r}if(o||i||a){let c="ClonedMaterial:"+n.uuid+":";o&&(c+="derivative-tangents:"),i&&(c+="vertex-colors:"),a&&(c+="flat-shading:");let r=this.cache.get(c);r||(r=n.clone(),i&&(r.vertexColors=!0),a&&(r.flatShading=!0),o&&(r.normalScale&&(r.normalScale.y*=-1),r.clearcoatNormalScale&&(r.clearcoatNormalScale.y*=-1)),this.cache.add(c,r),this.associations.set(r,this.associations.get(n))),n=r}t.material=n}getMaterialType(){return X0}loadMaterial(t){const e=this,n=this.json,o=this.extensions,i=n.materials[t];let a;const c={},r=i.extensions||{},l=[];if(r[at.KHR_MATERIALS_UNLIT]){const u=o[at.KHR_MATERIALS_UNLIT];a=u.getMaterialType(),l.push(u.extendParams(c,i,e))}else{const u=i.pbrMetallicRoughness||{};if(c.color=new We(1,1,1),c.opacity=1,Array.isArray(u.baseColorFactor)){const d=u.baseColorFactor;c.color.setRGB(d[0],d[1],d[2],be),c.opacity=d[3]}u.baseColorTexture!==void 0&&l.push(e.assignTexture(c,"map",u.baseColorTexture,an)),c.metalness=u.metallicFactor!==void 0?u.metallicFactor:1,c.roughness=u.roughnessFactor!==void 0?u.roughnessFactor:1,u.metallicRoughnessTexture!==void 0&&(l.push(e.assignTexture(c,"metalnessMap",u.metallicRoughnessTexture)),l.push(e.assignTexture(c,"roughnessMap",u.metallicRoughnessTexture))),a=this._invokeOne(function(d){return d.getMaterialType&&d.getMaterialType(t)}),l.push(Promise.all(this._invokeAll(function(d){return d.extendMaterialParams&&d.extendMaterialParams(t,c)})))}i.doubleSided===!0&&(c.side=ke);const h=i.alphaMode||vi.OPAQUE;if(h===vi.BLEND?(c.transparent=!0,c.depthWrite=!1):(c.transparent=!1,h===vi.MASK&&(c.alphaTest=i.alphaCutoff!==void 0?i.alphaCutoff:.5)),i.normalTexture!==void 0&&a!==Ln&&(l.push(e.assignTexture(c,"normalMap",i.normalTexture)),c.normalScale=new Et(1,1),i.normalTexture.scale!==void 0)){const u=i.normalTexture.scale;c.normalScale.set(u,u)}if(i.occlusionTexture!==void 0&&a!==Ln&&(l.push(e.assignTexture(c,"aoMap",i.occlusionTexture)),i.occlusionTexture.strength!==void 0&&(c.aoMapIntensity=i.occlusionTexture.strength)),i.emissiveFactor!==void 0&&a!==Ln){const u=i.emissiveFactor;c.emissive=new We().setRGB(u[0],u[1],u[2],be)}return i.emissiveTexture!==void 0&&a!==Ln&&l.push(e.assignTexture(c,"emissiveMap",i.emissiveTexture,an)),Promise.all(l).then(function(){const u=new a(c);return i.name&&(u.name=i.name),Ne(u,i),e.associations.set(u,{materials:t}),i.extensions&&ms(o,u,i),u})}createUniqueName(t){const e=bl.sanitizeNodeName(t||"");return e in this.nodeNamesUsed?e+"_"+ ++this.nodeNamesUsed[e]:(this.nodeNamesUsed[e]=0,e)}loadGeometries(t){const e=this,n=this.extensions,o=this.primitiveCache;function i(c){return n[at.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(c,e).then(function(r){return Kr(r,c,e)})}const a=[];for(let c=0,r=t.length;c<r;c++){const l=t[c],h=Vf(l),u=o[h];if(u)a.push(u.promise);else{let d;l.extensions&&l.extensions[at.KHR_DRACO_MESH_COMPRESSION]?d=i(l):d=Kr(new $e,l,e),o[h]={primitive:l,promise:d},a.push(d)}}return Promise.all(a)}loadMesh(t){const e=this,n=this.json,o=this.extensions,i=n.meshes[t],a=i.primitives,c=[];for(let r=0,l=a.length;r<l;r++){const h=a[r].material===void 0?Kf(this.cache):this.getDependency("material",a[r].material);c.push(h)}return c.push(e.loadGeometries(a)),Promise.all(c).then(function(r){const l=r.slice(0,r.length-1),h=r[r.length-1],u=[];for(let f=0,p=h.length;f<p;f++){const g=h[f],m=a[f];let v;const x=l[f];if(m.mode===me.TRIANGLES||m.mode===me.TRIANGLE_STRIP||m.mode===me.TRIANGLE_FAN||m.mode===void 0)v=i.isSkinnedMesh===!0?new xl(g,x):new Ht(g,x),v.isSkinnedMesh===!0&&v.normalizeSkinWeights(),m.mode===me.TRIANGLE_STRIP?v.geometry=Ur(v.geometry,j0):m.mode===me.TRIANGLE_FAN&&(v.geometry=Ur(v.geometry,Ni));else if(m.mode===me.LINES)v=new yl(g,x);else if(m.mode===me.LINE_STRIP)v=new _l(g,x);else if(m.mode===me.LINE_LOOP)v=new Tl(g,x);else if(m.mode===me.POINTS)v=new Al(g,x);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+m.mode);Object.keys(v.geometry.morphAttributes).length>0&&jf(v,i),v.name=e.createUniqueName(i.name||"mesh_"+t),Ne(v,i),m.extensions&&ms(o,v,m),e.assignFinalMaterial(v),u.push(v)}for(let f=0,p=u.length;f<p;f++)e.associations.set(u[f],{meshes:t,primitives:f});if(u.length===1)return i.extensions&&ms(o,u[0],i),u[0];const d=new Qe;i.extensions&&ms(o,d,i),e.associations.set(d,{meshes:t});for(let f=0,p=u.length;f<p;f++)d.add(u[f]);return d})}loadCamera(t){let e;const n=this.json.cameras[t],o=n[n.type];if(!o){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return n.type==="perspective"?e=new Z0(Ml.radToDeg(o.yfov),o.aspectRatio||1,o.znear||1,o.zfar||2e6):n.type==="orthographic"&&(e=new Sl(-o.xmag,o.xmag,o.ymag,-o.ymag,o.znear,o.zfar)),n.name&&(e.name=this.createUniqueName(n.name)),Ne(e,n),Promise.resolve(e)}loadSkin(t){const e=this.json.skins[t],n=[];for(let o=0,i=e.joints.length;o<i;o++)n.push(this._loadNodeShallow(e.joints[o]));return e.inverseBindMatrices!==void 0?n.push(this.getDependency("accessor",e.inverseBindMatrices)):n.push(null),Promise.all(n).then(function(o){const i=o.pop(),a=o,c=[],r=[];for(let l=0,h=a.length;l<h;l++){const u=a[l];if(u){c.push(u);const d=new on;i!==null&&d.fromArray(i.array,l*16),r.push(d)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',e.joints[l])}return new kl(c,r)})}loadAnimation(t){const e=this.json,n=this,o=e.animations[t],i=o.name?o.name:"animation_"+t,a=[],c=[],r=[],l=[],h=[];for(let u=0,d=o.channels.length;u<d;u++){const f=o.channels[u],p=o.samplers[f.sampler],g=f.target,m=g.node,v=o.parameters!==void 0?o.parameters[p.input]:p.input,x=o.parameters!==void 0?o.parameters[p.output]:p.output;g.node!==void 0&&(a.push(this.getDependency("node",m)),c.push(this.getDependency("accessor",v)),r.push(this.getDependency("accessor",x)),l.push(p),h.push(g))}return Promise.all([Promise.all(a),Promise.all(c),Promise.all(r),Promise.all(l),Promise.all(h)]).then(function(u){const d=u[0],f=u[1],p=u[2],g=u[3],m=u[4],v=[];for(let b=0,y=d.length;b<y;b++){const A=d[b],_=f[b],S=p[b],T=g[b],M=m[b];if(A===void 0)continue;A.updateMatrix&&A.updateMatrix();const k=n._createAnimationTracks(A,_,S,T,M);if(k)for(let R=0;R<k.length;R++)v.push(k[R])}const x=new El(i,void 0,v);return Ne(x,o),x})}createNodeMesh(t){const e=this.json,n=this,o=e.nodes[t];return o.mesh===void 0?null:n.getDependency("mesh",o.mesh).then(function(i){const a=n._getNodeRef(n.meshCache,o.mesh,i);return o.weights!==void 0&&a.traverse(function(c){if(c.isMesh)for(let r=0,l=o.weights.length;r<l;r++)c.morphTargetInfluences[r]=o.weights[r]}),a})}loadNode(t){const e=this.json,n=this,o=e.nodes[t],i=n._loadNodeShallow(t),a=[],c=o.children||[];for(let l=0,h=c.length;l<h;l++)a.push(n.getDependency("node",c[l]));const r=o.skin===void 0?Promise.resolve(null):n.getDependency("skin",o.skin);return Promise.all([i,Promise.all(a),r]).then(function(l){const h=l[0],u=l[1],d=l[2];d!==null&&h.traverse(function(f){f.isSkinnedMesh&&f.bind(d,Xf)});for(let f=0,p=u.length;f<p;f++)h.add(u[f]);return h})}_loadNodeShallow(t){const e=this.json,n=this.extensions,o=this;if(this.nodeCache[t]!==void 0)return this.nodeCache[t];const i=e.nodes[t],a=i.name?o.createUniqueName(i.name):"",c=[],r=o._invokeOne(function(l){return l.createNodeMesh&&l.createNodeMesh(t)});return r&&c.push(r),i.camera!==void 0&&c.push(o.getDependency("camera",i.camera).then(function(l){return o._getNodeRef(o.cameraCache,i.camera,l)})),o._invokeAll(function(l){return l.createNodeAttachment&&l.createNodeAttachment(t)}).forEach(function(l){c.push(l)}),this.nodeCache[t]=Promise.all(c).then(function(l){let h;if(i.isBone===!0?h=new Rl:l.length>1?h=new Qe:l.length===1?h=l[0]:h=new qe,h!==l[0])for(let u=0,d=l.length;u<d;u++)h.add(l[u]);if(i.name&&(h.userData.name=i.name,h.name=a),Ne(h,i),i.extensions&&ms(n,h,i),i.matrix!==void 0){const u=new on;u.fromArray(i.matrix),h.applyMatrix4(u)}else i.translation!==void 0&&h.position.fromArray(i.translation),i.rotation!==void 0&&h.quaternion.fromArray(i.rotation),i.scale!==void 0&&h.scale.fromArray(i.scale);if(!o.associations.has(h))o.associations.set(h,{});else if(i.mesh!==void 0&&o.meshCache.refs[i.mesh]>1){const u=o.associations.get(h);o.associations.set(h,{...u})}return o.associations.get(h).nodes=t,h}),this.nodeCache[t]}loadScene(t){const e=this.extensions,n=this.json.scenes[t],o=this,i=new Qe;n.name&&(i.name=o.createUniqueName(n.name)),Ne(i,n),n.extensions&&ms(e,i,n);const a=n.nodes||[],c=[];for(let r=0,l=a.length;r<l;r++)c.push(o.getDependency("node",a[r]));return Promise.all(c).then(function(r){for(let h=0,u=r.length;h<u;h++)i.add(r[h]);const l=h=>{const u=new Map;for(const[d,f]of o.associations)(d instanceof ai||d instanceof Fa)&&u.set(d,f);return h.traverse(d=>{const f=o.associations.get(d);f!=null&&u.set(d,f)}),u};return o.associations=l(i),i})}_createAnimationTracks(t,e,n,o,i){const a=[],c=t.name?t.name:t.uuid,r=[];ns[i.path]===ns.weights?t.traverse(function(d){d.morphTargetInfluences&&r.push(d.name?d.name:d.uuid)}):r.push(c);let l;switch(ns[i.path]){case ns.weights:l=Ia;break;case ns.rotation:l=Pa;break;case ns.translation:case ns.scale:l=Da;break;default:switch(n.itemSize){case 1:l=Ia;break;case 2:case 3:default:l=Da;break}break}const h=o.interpolation!==void 0?$f[o.interpolation]:J0,u=this._getArrayFromAccessor(n);for(let d=0,f=r.length;d<f;d++){const p=new l(r[d]+"."+ns[i.path],e.array,u,h);o.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(p),a.push(p)}return a}_getArrayFromAccessor(t){let e=t.array;if(t.normalized){const n=Ji(e.constructor),o=new Float32Array(e.length);for(let i=0,a=e.length;i<a;i++)o[i]=e[i]*n;e=o}return e}_createCubicSplineTrackInterpolant(t){t.createInterpolant=function(n){const o=this instanceof Pa?Wf:Cc;return new o(this.times,this.values,this.getValueSize()/3,n)},t.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}}function Jf(s,t,e){const n=t.attributes,o=new So;if(n.POSITION!==void 0){const c=e.json.accessors[n.POSITION],r=c.min,l=c.max;if(r!==void 0&&l!==void 0){if(o.set(new lt(r[0],r[1],r[2]),new lt(l[0],l[1],l[2])),c.normalized){const h=Ji(en[c.componentType]);o.min.multiplyScalar(h),o.max.multiplyScalar(h)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;const i=t.targets;if(i!==void 0){const c=new lt,r=new lt;for(let l=0,h=i.length;l<h;l++){const u=i[l];if(u.POSITION!==void 0){const d=e.json.accessors[u.POSITION],f=d.min,p=d.max;if(f!==void 0&&p!==void 0){if(r.setX(Math.max(Math.abs(f[0]),Math.abs(p[0]))),r.setY(Math.max(Math.abs(f[1]),Math.abs(p[1]))),r.setZ(Math.max(Math.abs(f[2]),Math.abs(p[2]))),d.normalized){const g=Ji(en[d.componentType]);r.multiplyScalar(g)}c.max(r)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}o.expandByVector(c)}s.boundingBox=o;const a=new Ke;o.getCenter(a.center),a.radius=o.min.distanceTo(o.max)/2,s.boundingSphere=a}function Kr(s,t,e){const n=t.attributes,o=[];function i(a,c){return e.getDependency("accessor",a).then(function(r){s.setAttribute(c,r)})}for(const a in n){const c=Zi[a]||a.toLowerCase();c in s.attributes||o.push(i(n[a],c))}if(t.indices!==void 0&&!s.index){const a=e.getDependency("accessor",t.indices).then(function(c){s.setIndex(c)});o.push(a)}return Oa.workingColorSpace!==be&&"COLOR_0"in n&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${Oa.workingColorSpace}" not supported.`),Ne(s,t),Jf(s,t,e),Promise.all(o).then(function(){return t.targets!==void 0?qf(s,t.targets,e):s})}const Qf=120,Gn=1/Qf,Qi=5,qr={gt:{name:"Grand Tourer",mass:1520,izz:2600,wheelbase:2.72,track:1.6,cgHeight:.45,weightRear:.5,power:165,peakTorque:235,redline:6800,cdA:1.9,rollPerG:3.4,topSpeed:135,zeroTo100:9.5,ratios:[4.1,2.62,1.9,1.47,1.15,.98],finalDrive:4.1,wheelRadius:.34,drive:"rwd"},sports:{name:"Sports",mass:1450,izz:2300,wheelbase:2.65,track:1.62,cgHeight:.42,weightRear:.53,power:300,peakTorque:370,redline:7200,cdA:1.62,rollPerG:2.5,topSpeed:165,zeroTo100:7,ratios:[3.9,2.5,1.81,1.4,1.1,.93],finalDrive:3.95,wheelRadius:.34,drive:"rwd"},hyper:{name:"Hyper",mass:1400,izz:2150,wheelbase:2.7,track:1.68,cgHeight:.38,weightRear:.56,power:380,peakTorque:405,redline:8200,cdA:1.48,rollPerG:1.7,topSpeed:190,zeroTo100:5.6,ratios:[3.7,2.38,1.77,1.4,1.12,.94],finalDrive:3.9,wheelRadius:.35,drive:"awd"}},bt={peakSlipFront:8*Math.PI/180,peakSlipRear:9*Math.PI/180,tailFloor:.55,muLatFront:1.3,muLatRear:1.34,muLongPeak:1.42,peakSlipRatio:.12,awdCap:1.36,speedFadeAt:110,speedFade:.1,downforce:.22,ellipseExp:1.85,liftoffDrop:.06,liftoffHold:.25,liftoffRecover:.6,liftoffMinLatG:.4},nt={maxAngle:40*Math.PI/180,minAngle:8*Math.PI/180,taperSpeed:16,taperPow:1.5,comfortG:8.4,attackG:14,minRadius:7,buildBase:2.4,buildBonus:4.2,buildFalloff:18,returnRate:8.5,padRateLimit:900*Math.PI/180,padDeadzone:.04,padSaturation:.95,padCurve:1.5,satGain:.3,satDamping:.55,trailPeak:.9,trailPostPeak:.25,driftLow:12*Math.PI/180,driftBonus:.18,driftYawDamp:1.9,spinYawDamp:4.2,spinAngle:42*Math.PI/180},An={throttleUp:1/.25,throttleDown:1/.15,throttleCurve:1.4,brakeUp:1/.07,brakeDown:1/.1},oe={torque:15500,baseTorque:15500,splitFront:.68,splitFrontDive:.76,absHz:18,absRelease:.16,lockedLatFloor:.35,handbrakeTorque:2200,handbrakeRearMu:.55,handbrakeRecover:.35,handbrakeYawCap:130*Math.PI/180},Te={shiftTimeAuto:.14,shiftTorqueCut:.25,downshiftHysteresis:900,upshiftAtThrottle:[[0,.38],[.2,.42],[.5,.62],[1,.97]],idleRpm:900,driveLoss:.12},tp=[[0,.42],[.12,.55],[.3,.88],[.55,1],[.8,.95],[1,.8]];function jr(s,t){if(t<=s[0][0])return s[0][1];for(let e=1;e<s.length;e++)if(t<=s[e][0]){const[n,o]=s[e-1],[i,a]=s[e],c=(t-n)/(i-n||1);return o+(a-o)*c}return s[s.length-1][1]}const St={rollOmega:8.4,rollZeta:.85,pitchOmega:10.5,pitchZeta:.85,divePerG:1.6*Math.PI/180,squatPerG:1*Math.PI/180,rollClamp:5.5*Math.PI/180,pitchClamp:3*Math.PI/180,rollRate:50*Math.PI/180,pitchRate:35*Math.PI/180,visualRollMul:1.3,loadTauPitch:.12,loadTauRoll:.15},jt={gravity:9.81,extraMin:.1,extraMax:1,extraDelay:.1,extraRamp:.1},gs={restLength:.36,travel:.22,stiffness:42e3,damping:4200},bi={cruise:{counterSteer:.95,stability:.35,tcs:.4,abs:.8,autoGears:!0,lockFloor:10*Math.PI/180,brakeMul:1,airborne:1},sport:{counterSteer:.7,stability:.2,tcs:.2,abs:.6,autoGears:!0,lockFloor:nt.minAngle,brakeMul:1,airborne:1},off:{counterSteer:.3,stability:.05,tcs:0,abs:.3,autoGears:!0,lockFloor:nt.minAngle,brakeMul:1,airborne:1},hardcore:{counterSteer:0,stability:0,tcs:0,abs:0,autoGears:!1,lockFloor:nt.minAngle,brakeMul:.82,airborne:0}},os={csKeyboard:.85,csGamepad:.45,csLag:.06,csMinSlip:4*Math.PI/180,csMinSpeed:8/3.6,csClamp:.75,stabilityYawGain:1.4},Gs={cruise:{behind:6,above:1.85,lookAhead:1,lookHeight:.9,yawTau:.35,velocityBlend:0,fov:64,fovGain:0,stretch:0,rise:0,shake:0},sport:{behind:6.2,above:1.9,lookAhead:1,lookHeight:.9,yawTau:.22,velocityBlend:.62,lookIntoCorner:.18,lookIntoClamp:9*Math.PI/180,springOmega:7.7,springZeta:.85,stretch:1.8,rise:.25,fov:62,fovGain:17,fovPow:.7,fovRate:12*Math.PI/180,fovKick:5,fovKickTau:.6,lateralClamp:.12,pitchRate:20*Math.PI/180,pitchClamp:6*Math.PI/180,shake:.35*Math.PI/180,shakeHz:11,shakeFrom:145/3.6},hood:{behind:-.35,above:1.15,lookAhead:6,lookHeight:1.1,yawTau:.05,velocityBlend:0,fov:58,fovGain:0}},es=[{id:"estate",file:"estate.glb",label:"Estate",blurb:"Soft, slow and forgiving. The one you learn the roads in.",unlockAt:0,tier:"gt",length:4.6,feel:{comfortG:7,assist:"cruise",rearGrip:1.06,buildRate:2.6,brakeMul:1.15}},{id:"hatch",file:"hatch.glb",label:"Hatch",blurb:"Light and eager. Turns in more sharply than it has any right to.",unlockAt:1e3,tier:"gt",length:4,feel:{comfortG:8.2,assist:"cruise",rearGrip:1,buildRate:3,brakeMul:1.1}},{id:"coupe",file:"coupe.glb",label:"Coupe",blurb:"The road car. Quick enough to be interesting, calm enough to cruise.",unlockAt:3e3,tier:"sports",length:4.3,feel:{comfortG:9.2,assist:"sport",rearGrip:1,buildRate:2.8,brakeMul:1}},{id:"sedan",file:"sedan.glb",label:"Sedan",blurb:"Long wheelbase, loose rear. It will hold a slide if you ask nicely.",unlockAt:8e3,tier:"sports",length:4.5,feel:{comfortG:10.4,assist:"sport",rearGrip:.9,buildRate:3.2,brakeMul:1}},{id:"rally",file:"rally.glb",label:"Rally",blurb:"Made for the gravel. The only one that is genuinely happy off the tarmac.",unlockAt:2e4,tier:"sports",length:4.2,feel:{comfortG:11.6,assist:"sport",rearGrip:.94,buildRate:3.6,brakeMul:1.05,offRoad:1.35}},{id:"taxi",file:"taxi.glb",label:"Taxi",blurb:"Somebody has to. Slow, indestructible, oddly relaxing.",unlockAt:45e3,tier:"gt",length:4.5,feel:{comfortG:7.6,assist:"cruise",rearGrip:1.04,buildRate:2.4,brakeMul:1.2}},{id:"patrol",file:"patrol.glb",label:"Patrol",blurb:"All-wheel drive and the strongest brakes in the fleet. The long-distance one.",unlockAt:1e5,tier:"hyper",length:4.6,feel:{comfortG:9.8,assist:"sport",rearGrip:1.02,buildRate:2.8,brakeMul:1.3}}],Qn=Object.fromEntries(es.map(s=>[s.id,s])),ep=es[0].id,Lc="wanderoad.unlocks.v1";function qn(){try{return new URLSearchParams(location.search).has("cheat")||localStorage.getItem(Lc+".cheat")==="1"}catch{return!1}}function Fc(s){try{localStorage.setItem(Lc+".cheat",s?"1":"0")}catch{}}function sn(){try{const s=localStorage.getItem("wanderoad.streak.v1");return s&&+JSON.parse(s).best||0}catch{return 0}}function to(s,t=sn()){return qn()||t>=s.unlockAt}function sp(s=sn()){if(qn())return null;for(const t of es)if(s<t.unlockAt)return{car:t,remaining:t.unlockAt-s,progress:s/t.unlockAt};return null}function Dc(s){const t=s.feel;return nt.comfortG=t.comfortG,nt.attackG=t.comfortG*1.6,nt.buildBase=t.buildRate,nt.buildBonus=t.buildRate*1.6,bt.muLatRear=1.34*t.rearGrip,oe.torque=oe.baseTorque*(t.brakeMul||1),t}function np(s=location.search){const t=new URLSearchParams(s).get("car"),e=sn(),n=Qn[t];return n&&to(n,e)?n:Qn[ep]}function Ic(s){return s<1e3?`${Math.round(s)} m`:`${(s/1e3).toFixed(s<1e4?1:0)} km`}const Bo=Object.fromEntries(es.map(s=>[s.id,{file:s.file,label:s.label,tier:s.tier,length:s.length}]));es.map(s=>s.id);const op=s=>{const t=new We(s).convertSRGBToLinear();return[t.r,t.g,t.b]},Vr=["paintA","paintB","paintC","paintD","paintE","paintF"];function ip(s){const t=Vr.length;return ge[Vr[((s|0)%t+t)%t]]}function ap(s,t){const e=(s||"").toLowerCase();return e.includes("window")||e.includes("glass")?{col:ge.glass,mat:w.METAL}:e.includes("headlight")?{col:ge.head,mat:w.EMIT}:e.includes("taillight")||e.includes("brakelight")?{col:ge.tail,mat:w.EMIT}:e.includes("whitelight")?{col:ge.head,mat:w.EMIT}:e.includes("bluelight")?{col:op("#5A8BD6"),mat:w.EMIT}:e.includes("black")?{col:ge.tyre,mat:w.MATTE}:e.includes("grey")||e.includes("gray")||e.includes("chrome")||e.includes("metal")?{col:ge.chrome,mat:w.METAL}:e.includes("rust")?{col:ge.trunkShade,mat:w.MATTE}:{col:t,mat:w.BODY}}let xi=null;const yi=new Map;function rp(){return xi||(xi=new wf),xi}function cp(s){if(yi.has(s))return yi.get(s);const t=new Promise((e,n)=>rp().load(s,o=>e(o),void 0,n));return yi.set(s,t),t}async function Yr({car:s="coupe",paint:t=0,base:e="./models/cars/",ghost:n=!1}={}){const o=Bo[s]||Bo.coupe,a=(await cp(e+o.file)).scene.clone(!0),c=ip(t),r=Zo(n?{ghost:!0,opacity:.85}:{});a.traverse(b=>{if(!b.isMesh)return;const y=Array.isArray(b.material)?b.material[0]:b.material,{col:A,mat:_}=ap(y&&y.name,c),S=b.geometry,T=S.attributes.position.count,M=new Float32Array(T*3),k=new Float32Array(T);for(let R=0;R<T;R++)M[R*3]=A[0],M[R*3+1]=A[1],M[R*3+2]=A[2],k[R]=_;S.setAttribute("vcol",new et(M,3)),S.setAttribute("vmat",new et(k,1)),!S.attributes.nrm&&S.attributes.normal&&S.setAttribute("nrm",S.attributes.normal),S.attributes.nrm||(S.computeVertexNormals(),S.setAttribute("nrm",S.attributes.normal)),b.material=r,b.castShadow=!1,b.receiveShadow=!1});const l=new So().setFromObject(a),h=new lt;l.getSize(h);const u=Math.max(h.x,h.z),d=u>.001?o.length/u:1;a.scale.setScalar(d),a.updateMatrixWorld(!0);const f=new So().setFromObject(a);a.position.y-=f.min.y;const p=new Qe;p.name=`car:${s}`,p.add(a);const g=new Map,m=[];a.traverse(b=>{b.isMesh&&/wheel/i.test(b.name||"")&&m.push(b)});for(const b of m){const y=(b.name||"").toLowerCase(),A=y.includes("frontleft")?"fl":y.includes("frontright")?"fr":y.includes("rearleft")?"rl":y.includes("rearright")?"rr":y.includes("front")?"f":"r";g.has(A)||g.set(A,[]),g.get(A).push(b)}const v={steer:[],spin:[],all:[]};for(const[b,y]of g){const A=new So;for(const R of y)R.updateMatrixWorld(!0),A.expandByObject(R);const _=new lt;A.getCenter(_);const S=y[0].parent,T=S.worldToLocal(_.clone()),M=new Qe;M.name=`wheel:${b}:steer`,M.position.copy(T),S.add(M);const k=new Qe;k.name=`wheel:${b}:spin`,M.add(k);for(const R of y){const P=R.position.clone().sub(T);k.add(R),R.position.copy(P)}v.all.push(k),v.spin.push(k),(b==="fl"||b==="fr"||b==="f")&&v.steer.push(M)}return{group:p,wheels:v.all,steerNodes:v.steer,source:s,label:o.label,tier:o.tier,setSteer(b){for(const y of v.steer)y.rotation.y=-b},setWheelSpin(b){const y=b%(Math.PI*2);for(const A of v.spin)A.rotation.x=y},setBrakeGlow(){},setLights(){},setBodyRoll(b,y){p.rotation.z=b,p.rotation.x=y},dispose(){a.traverse(b=>{b.isMesh&&b.geometry.dispose()}),r.dispose()}}}const Xr=(s,t)=>Rt(Math.round(s),Math.round(t),24301)/4294967296*2-1,Mn=Math.PI*2,lp=.62,hp=1.45;function up(s,t){return s<=1?Math.sin(Math.PI/2*Math.pow(s,lp)):t+(1-t)*Math.exp(-.125*Math.pow(s-1,hp))}const Zr=.5,Bt={liftFrom:.65,liftTo:1.15,commit:1.02,damp:2.2,rightAfter:1.2,rightMax:5,rightRate:3,digFrom:3,digK:.55,digMax:40,digFlat:.6,bankRate:.6,scrapeFrom:.85};function Jr(s,t){const e=Math.abs(s)/t;return Math.sign(s)*up(e,bt.tailFloor)}class dp{constructor({tier:t="sports",terrain:e=null,preset:n="sport"}={}){this.setTier(t),this.terrain=e,this.assist={...bi[n]},this.presetName=n,this.x=0,this.y=0,this.z=0,this.yaw=0,this.roll=0,this.pitch=0,this.vx=0,this.vy=0,this.vz=0,this.yawRate=0,this.steer=0,this.throttle=0,this.brake=0,this.handbrake=0,this.gear=1,this.rpm=Te.idleRpm,this.reverse=!1,this._shiftTimer=0,this._shiftHold=0,this._absPhase=0,this._liftoff=0,this._liftoffTimer=0,this._airTime=0,this._loadLong=0,this._loadLat=0,this._rollV=0,this._pitchV=0,this._csState=0,this._hbRelease=1,this._acc=0,this._prevSpeed=0,this._lean=0,this._leanV=0,this._dive=0,this._diveV=0,this._tip=0,this._tipV=0,this._righting=!1,this._rollTimer=0,this._prevGroundRoll=0,this._gRate=0,this._gRatePrev=0,this._carve={mask:0,y:0,edge:0,d:1/0,tier:0,tx:1,tz:0,width:0},this._probedX=1/0,this._probedZ=1/0,this._probedYaw=0,this.speed=0,this.slip=0,this.limit=0,this.wheelSpin=0,this.longAccel=0,this.latAccel=0,this.onGround=!0,this.surfaceKind="ground",this.gripScale=1,this.rough=0,this.onRoad=1,this.onRoadMin=1,this.offRoad=0,this.wheelsOffRoad=0,this.groundPitch=0,this.groundRoll=0,this.rolled=!1,this.forces={drive:0,brake:0,contact:1,traction:0,drag:0,rr:0,engBrake:0,trip:0,net:0,gear:1,ratio:0,latAvail:1},this.wheels=[{x:0,y:0,z:0,compression:0,load:0,slipAngle:0,slipRatio:0,contact:!0,onRoad:1},{x:0,y:0,z:0,compression:0,load:0,slipAngle:0,slipRatio:0,contact:!0,onRoad:1},{x:0,y:0,z:0,compression:0,load:0,slipAngle:0,slipRatio:0,contact:!0,onRoad:1},{x:0,y:0,z:0,compression:0,load:0,slipAngle:0,slipRatio:0,contact:!0,onRoad:1}]}get tipAngle(){return Math.atan2(this.track*.5,this.spec.cgHeight)}setTier(t){this.tier=t;const e=qr[t]||qr.sports;this.spec=e,this.mass=e.mass,this.izz=e.izz,this.wb=e.wheelbase,this.track=e.track,this.a=e.wheelbase*e.weightRear,this.b=e.wheelbase*(1-e.weightRear),this.muCapAwd=e.drive==="awd"}setPreset(t){bi[t]&&(this.presetName=t,this.assist={...bi[t]})}placeAt(t,e,n=0){this.x=t,this.z=e,this.yaw=n;const o=this.terrain?this.terrain.surface(t,e):null;this.y=(o?o.y:0)+gs.restLength,this.vx=this.vy=this.vz=0,this.yawRate=0,this.gear=1,this.rpm=Te.idleRpm,this._tip=0,this._tipV=0,this._lean=this._leanV=this._dive=this._diveV=0,this.rolled=!1,this._righting=!1,this._rollTimer=0,this._probeWheels(),this._prevGroundRoll=this.groundRoll,this.roll=this.groundRoll,this.pitch=this.groundPitch}_probeWheels(){const t=this.terrain,e=Math.cos(this.yaw),n=Math.sin(this.yaw),o=this.track*.5,i=e*o,a=-n*o,c=this.x+n*this.a,r=this.z+e*this.a,l=this.x-n*this.b,h=this.z-e*this.b;let u=0,d=1,f=0;for(let x=0;x<4;x++){const b=this.wheels[x],y=x<2,A=(x&1)===0;b.x=(y?c:l)+(A?i:-i),b.z=(y?r:h)+(A?a:-a);let _=0,S=1;if(t)if(t.roads&&t.roads.carve)_=t.height(b.x,b.z),S=t.roads.carve(b.x,b.z,this._carve).edge;else{const T=t.surface(b.x,b.z);_=T.y,S=T.onRoad!==void 0?T.onRoad:1}b.y=_,b.onRoad=S,u+=S,S<d&&(d=S),S<Zr&&f++}this.onRoad=u*.25,this.onRoadMin=d,this.offRoad=1-d,this.wheelsOffRoad=f;const p=(this.wheels[0].y+this.wheels[1].y)*.5,g=(this.wheels[2].y+this.wheels[3].y)*.5,m=(this.wheels[0].y+this.wheels[2].y)*.5,v=(this.wheels[1].y+this.wheels[3].y)*.5;this.groundPitch=-Math.atan2(p-g,this.wb),this.groundRoll=Math.atan2(m-v,this.track),this._probedX=this.x,this._probedZ=this.z,this._probedYaw=this.yaw}maxSteerAngle(t=!1){const e=Math.abs(this.speed),n=nt.minAngle+(nt.maxAngle-nt.minAngle)/(1+Math.pow(e/nt.taperSpeed,nt.taperPow)),o=t?nt.attackG:nt.comfortG,i=e>1?Math.atan(this.wb*o/(e*e)):nt.maxAngle,a=1-N((e-5)/7),c=Math.atan(this.wb/nt.minRadius)*a,r=Math.max(i,c);let l=Math.min(n,r);return l=Math.max(l,this.assist.lockFloor*.35,nt.minAngle*.22),Math.abs(this.slip)>nt.driftLow&&(l=Math.max(l,n*(1+nt.driftBonus))),l}update(t,e){this._acc+=Math.min(t,Qi*Gn);let n=0;for(;this._acc>=Gn&&n<Qi;)this._step(Gn,e),this._acc-=Gn,n++;return n}_step(t,e){const n=this.assist,o=Math.pow(N(e.throttle),An.throttleCurve);this.throttle=kt(this.throttle,o,o>this.throttle?An.throttleUp:An.throttleDown,t);const i=N(e.brake);this.brake=kt(this.brake,i,i>this.brake?An.brakeUp:An.brakeDown,t),this.handbrake=N(e.handbrake||0);const a=Math.abs(this.speed);if(e.analogue){const J=nt.padRateLimit/nt.maxAngle*t,vt=X(e.steer,-1,1);this.steer+=X(vt-this.steer,-J,J)}else{const J=X(e.steer,-1,1);if(J===0||Math.sign(J)!==Math.sign(this.steer)){const vt=nt.returnRate*t;if(this.steer+=X(-this.steer,-vt,vt),J!==0){const Jt=(nt.buildBase+nt.buildBonus/(1+Math.pow(a/nt.buildFalloff,2)))*t;this.steer+=X(J-this.steer,-Jt,Jt)}}else{const vt=(nt.buildBase+nt.buildBonus/(1+Math.pow(a/nt.buildFalloff,2)))*t;this.steer+=X(J-this.steer,-vt,vt)}}this.steer=X(this.steer,-1,1);const c=Math.cos(this.yaw),r=Math.sin(this.yaw);let l=this.vz*c+this.vx*r,h=this.vx*c-this.vz*r;this.speed=l;const u=Math.hypot(l,h);this.slip=u>.6?Math.atan2(h,Math.abs(l)+.001):0;let d=this.steer*this.maxSteerAngle(!!e.attack);const f=n.counterSteer*(e.analogue?os.csGamepad:os.csKeyboard)*1.18;if(f>0&&Math.abs(this.slip)>os.csMinSlip&&u>os.csMinSpeed){const J=X(this.slip*f,-.75*this.maxSteerAngle(),os.csClamp*this.maxSteerAngle());this._csState=kt(this._csState,J,1/os.csLag,t)}else this._csState=kt(this._csState,0,1/os.csLag,t);d=X(d+this._csState,-this.maxSteerAngle()*1.35,this.maxSteerAngle()*1.35),this.steerAngle=d;const p=this.terrain?this.terrain.surface(this.x,this.z):null,g=p?p.y:0;this.gripScale=p?p.grip:1,this._probeWheels();const m=this.onRoad;this.surfaceKind=this.onRoadMin>Zr&&p?p.surfaceKind:"ground";const v=p?p.nx:0,x=p?Math.max(p.ny,.2):1,b=p?p.nz:0;this.slopeAngle=Math.acos(Math.min(1,x));const y=Math.cos(this.yaw),A=Math.sin(this.yaw),_=jt.gravity*x*(v*A+b*y),S=jt.gravity*x*(v*y-b*A),T=N((this.slopeAngle-.42)/.34);this.gripScale*=1-.85*T;const M=g+gs.restLength,R=this.y-M>.06;this.onGround=!R;let P=jt.gravity;if(R){if(this._airTime+=t,n.airborne>0&&this._airTime>jt.extraDelay){const J=N((this._airTime-jt.extraDelay)/jt.extraRamp);P+=jt.gravity*O(jt.extraMin,jt.extraMax,J)*n.airborne}this.vy-=P*t}else{this._airTime=0;const J=X(M-this.y,-.22,gs.travel),vt=gs.stiffness*4*J/this.mass,Jt=gs.damping*4*-this.vy/this.mass;this.vy+=(vt+Jt-P)*t,this.vy>2&&(this.vy=2)}this.y+=this.vy*t,this.y<M-gs.travel&&(this.y=M-gs.travel,this.vy<0&&(this.vy=0));const z=X(this.longAccel/jt.gravity,-1.2,1.2),L=X(this.latAccel/jt.gravity,-1.5,1.5);this._loadLong=kt(this._loadLong,z,1/St.loadTauPitch,t),this._loadLat=kt(this._loadLat,L,1/St.loadTauRoll,t);const U=this.mass*jt.gravity+(R?0:bt.downforce*u*u),W=this.spec.cgHeight/this.wb;let I=U*(this.b/this.wb)-U*W*this._loadLong,H=U-I;I=Math.max(I,U*.08),H=Math.max(H,U*.08);const V=this.tipAngle,D=Math.abs(this._tip),$=N(1-(D-Bt.liftFrom*V)/((Bt.liftTo-Bt.liftFrom)*V)),q=R?0:$,Q=u>.5?Math.atan2(h+this.yawRate*this.a,Math.abs(l)+.001)-d:0,ot=u>.5?Math.atan2(h-this.yawRate*this.b,Math.abs(l)+.001):0;if(this.throttle<.12&&Math.abs(this.latAccel)>bt.liftoffMinLatG*jt.gravity&&this._liftoffTimer<=0&&(this._liftoffTimer=bt.liftoffHold+bt.liftoffRecover),this._liftoffTimer>0){this._liftoffTimer-=t;const J=this._liftoffTimer>bt.liftoffRecover;this._liftoff=J?bt.liftoffDrop:bt.liftoffDrop*N(this._liftoffTimer/bt.liftoffRecover)}else this._liftoff=0;this.handbrake>.01?this._hbRelease=0:this._hbRelease=N(this._hbRelease+t/oe.handbrakeRecover);const ht=1-Math.pow(1-this._hbRelease,3),rt=O(oe.handbrakeRearMu,1,this.handbrake>.01?0:ht),Tt=1-bt.speedFade*Math.min(u/bt.speedFadeAt,1),Pt=this.muCapAwd?bt.awdCap:1e9,Wt=Math.min(bt.muLatFront,Pt)*this.gripScale*Tt,Ot=Math.min(bt.muLatRear,Pt)*this.gripScale*Tt*(1-this._liftoff)*rt;let le=-Jr(Q,bt.peakSlipFront)*Wt*I*q,ze=-Jr(ot,bt.peakSlipRear)*Ot*H*q;const gt=this.spec,Fs=gt.ratios[this.gear-1]*gt.finalDrive,Ds=l/gt.wheelRadius;let un=Math.abs(Ds)*Fs*(60/Mn);if(this.rpm=X(Math.max(un,Te.idleRpm),Te.idleRpm,gt.redline*1.02),this._shiftTimer>0&&(this._shiftTimer-=t),this._shiftHold>0&&(this._shiftHold-=t),n.autoGears&&this._shiftTimer<=0&&this._shiftHold<=0&&!this.reverse){const J=jr(Te.upshiftAtThrottle,this.throttle)*gt.redline;if(this.throttle>.06&&this.rpm>J&&this.gear<gt.ratios.length)this.gear++,this._shiftTimer=Te.shiftTimeAuto,this._shiftHold=.5;else if(this.gear>1){const vt=gt.ratios[this.gear-2]*gt.finalDrive,Jt=Math.abs(Ds)*vt*(60/Mn),Le=this.rpm<Te.idleRpm+Te.downshiftHysteresis*.9,oi=this.throttle<.05&&Jt<gt.redline*.7;Jt<gt.redline*.92&&(Le||oi)&&(this.gear--,this._shiftTimer=Te.shiftTimeAuto,this._shiftHold=.5)}}const dn=this._shiftTimer>0?Te.shiftTorqueCut:1,Is=N(this.rpm/gt.redline),so=this.rpm>=gt.redline?.15:1;let Lt=gt.peakTorque*jr(tp,Is)*this.throttle*dn*so*Fs/gt.wheelRadius*(1-Te.driveLoss);!e.auto&&Math.abs(l)<.6&&this.brake>.35&&this.throttle<.05?this.reverse=!0:this.throttle>.15&&l>-3&&(this.reverse=!1),this.reverse&&(Lt=-Math.max(Math.abs(Lt),this.brake*2600)*.5);const Y=gt.drive==="awd"?U:H,j=bt.muLongPeak*this.gripScale*Y;n.tcs>0&&Math.abs(Lt)>j&&(Lt-=Math.sign(Lt)*(Math.abs(Lt)-j)*n.tcs);const Nt=j*1.15;Math.abs(Lt)>Nt&&(Lt=Math.sign(Lt)*Nt);const Ps=gt.topSpeed/3.6;l>Ps-4.2&&(Lt*=N((Ps-l)/4.2));const ti=j>1?X(Lt/j,-3,3)*bt.peakSlipRatio:0;let Ce=0;if(this.brake>.001&&u>.2){O(oe.splitFront,oe.splitFrontDive,N(-this._loadLong));let J=oe.torque*this.brake*n.brakeMul;if(n.abs>0){const Jt=J/gt.wheelRadius,Le=bt.muLongPeak*this.gripScale*U;if(Jt>Le){this._absPhase+=t*oe.absHz*Mn;const oi=1-oe.absRelease*(.5+.5*Math.sin(this._absPhase))*n.abs;J=Math.min(J,Le*gt.wheelRadius*1.02)*oi}}Ce=-Math.sign(l)*(J/gt.wheelRadius);const vt=N(1-n.abs)*N(this.brake*1.4-.5);vt>0&&(le*=O(1,oe.lockedLatFloor,vt))}this.handbrake>.01&&u>.2&&(Ce+=-Math.sign(l)*(oe.handbrakeTorque*this.handbrake/gt.wheelRadius));const ss=O(12.2,200,N(m*1.4));q&&l>ss&&Lt>0&&(Lt=0);const fn=(Lt+Ce)*q,he=bt.muLongPeak*this.gripScale*U,xe=Math.pow(Math.min(Math.abs(fn)/Math.max(he,1),1),bt.ellipseExp),Ve=Math.pow(Math.max(1-xe,.04),1/bt.ellipseExp);le*=Ve,ze*=Ve;const pn=.5*1.225*gt.cdA*l*Math.abs(l),ba=O(.145,.014,N(m))*this.mass*jt.gravity*Math.sign(l)+O(9.5,1.4,N(m))*l,Vc=Math.max(0,1-this.throttle*4),xa=this._shiftTimer>0?0:Vc*95*(.3+.7*Is)*(Fs/gt.wheelRadius)*Math.sign(l)*q;if(q&&m<.6){const J=1-m,vt=Xr(this.x*.31,this.z*.31)*.6+Xr(this.x*1.13+11.7,this.z*1.13-4.2)*.4;this.vy+=vt*J*Math.min(u,24)*.055*t*60,le*=1-.34*J,ze*=1-.28*J,this.rough=J}else this.rough=0;let ei=0;if(q>0&&m<.75&&Math.abs(h)>Bt.digFrom){const J=N((.75-m)/.75),vt=Math.abs(h)-Bt.digFrom,Jt=N(Math.sign(h)*this.groundRoll/.35),Le=Math.min(Bt.digK*vt*vt,Bt.digMax)*J*(Bt.digFlat+(1-Bt.digFlat)*Jt);ei=-Math.sign(h)*Le*this.mass*q}const ya=fn-pn-ba-xa;this.forces.drive=Lt,this.forces.brake=Ce,this.forces.contact=q,this.forces.traction=j,this.forces.drag=pn,this.forces.rr=ba,this.forces.engBrake=xa,this.forces.trip=ei,this.forces.net=ya,this.forces.gear=this.gear,this.forces.ratio=Fs,this.forces.latAvail=Ve;const si=le*Math.cos(d)+ze+ei,_a=ya/this.mass+this.yawRate*h+_*q,Ta=si/this.mass-this.yawRate*l+S*q;l+=_a*t,h+=Ta*t;let ni=le*Math.cos(d)*this.a-ze*this.b;if(n.stability>0&&u>3){const J=l/Math.max(this.wb,.1)*Math.tan(d);ni-=(this.yawRate-J)*this.izz*os.stabilityYawGain*n.stability}const Aa=Math.abs(this.slip);if(Aa>nt.driftLow){const J=Aa>nt.spinAngle?nt.spinYawDamp:nt.driftYawDamp;ni-=this.yawRate*this.izz*J}this.handbrake>.01&&(this.yawRate=X(this.yawRate,-oe.handbrakeYawCap,oe.handbrakeYawCap)),this.yawRate+=ni/this.izz*t*q;const Ma=(Wt*I+Ot*H)/this.mass/Math.max(u,4)*1.35,Sa=Math.abs(this.yawRate);if(q&&Sa>Ma){const J=1-Math.exp(-7.5*t);this.yawRate-=Math.sign(this.yawRate)*(Sa-Ma)*J}const Yc=O(nt.trailPeak,nt.trailPostPeak,N(Math.abs(Q)/bt.peakSlipFront-1));this.yawRate-=this.yawRate*nt.satDamping*nt.satGain*Yc*t,u<.25&&this.throttle<.02&&Math.abs(_)<.55&&(l*=.9,h*=.9,this.yawRate*=.85);const ka=N((D-Bt.scrapeFrom*V)/(.35*V));if(!R&&ka>0){const J=Math.exp(-3.4*ka*t);l*=J,h*=J,this.yawRate*=J}this.yaw+=this.yawRate*t,this.yaw>Math.PI?this.yaw-=Mn:this.yaw<-Math.PI&&(this.yaw+=Mn);const Ea=Math.cos(this.yaw),Ra=Math.sin(this.yaw);this.vz=l*Ea-h*Ra,this.vx=l*Ra+h*Ea,this.x+=this.vx*t,this.z+=this.vz*t,this.longAccel=_a,this.latAccel=Ta,this.speed=l;const Xc=X(this._loadLat*this.spec.rollPerG,-St.rollClamp,St.rollClamp),Zc=X(this._loadLong>0?-this._loadLong*St.squatPerG:-this._loadLong*St.divePerG,-St.pitchClamp,St.pitchClamp),Jc=(Xc-this._lean)*St.rollOmega*St.rollOmega-this._leanV*2*St.rollZeta*St.rollOmega;this._leanV=X(this._leanV+Jc*t,-St.rollRate,St.rollRate),this._lean+=this._leanV*t;const Qc=(Zc-this._dive)*St.pitchOmega*St.pitchOmega-this._diveV*2*St.pitchZeta*St.pitchOmega;this._diveV=X(this._diveV+Qc*t,-St.pitchRate,St.pitchRate),this._dive+=this._diveV*t;const mn=this.track*.5,gn=this.spec.cgHeight,za=gn*gn+mn*mn,Ca=jt.gravity*x;this._gRate=kt(this._gRate,(this.groundRoll-this._prevGroundRoll)/t,22,t);const La=Math.sign(this._gRate)*Math.max(0,Math.abs(this._gRate)-Bt.bankRate);if(this.rolled){const J=Math.sign(this._tip)||1;if(this._rollTimer+=t,this._righting)this._tip=kt(this._tip,0,Bt.rightRate,t),this._tipV=0,this.vx*=.9,this.vz*=.9,this.yawRate*=.9,Math.abs(this._tip)<.04&&(this._tip=0,this.rolled=!1,this._righting=!1,this._rollTimer=0);else{const vt=Math.abs(this._tip);this._tipV+=J*Ca*(gn*Math.sin(vt)-mn*Math.cos(vt))/za*t,this._tip+=this._tipV*t,Math.abs(this._tip)>=Math.PI&&(this._tip=J*Math.PI,this._tipV=0),(Math.abs(Math.abs(this._tip)-Math.PI)<.2&&u<2.5&&this._rollTimer>Bt.rightAfter||this._rollTimer>Bt.rightMax)&&(this._righting=!0)}}else if(R)this._tip-=this.groundRoll-this._prevGroundRoll,this._tip+=this._tipV*t;else{this._tipV-=La-this._gRatePrev;const J=this._tip!==0?Math.sign(this._tip):Math.sign(this._tipV)||Math.sign(si)||1,vt=Math.abs(this._tip),Jt=J*si/this.mass*(mn*Math.sin(vt)+gn*Math.cos(vt))-Ca*(mn*Math.cos(vt)-gn*Math.sin(vt));this._tipV+=J*Jt/za*t,this._tipV-=this._tipV*Bt.damp*N(1-vt/(Bt.liftFrom*V))*t;const Le=this._tip+this._tipV*t;Le===0||Math.sign(Le)!==J?(this._tip=0,this._tipV=0):this._tip=Le,Math.abs(this._tip)>Bt.commit*V&&(this.rolled=!0,this._rollTimer=0)}this._gRatePrev=La,this._prevGroundRoll=this.groundRoll,this.roll=this.groundRoll+this._lean*St.visualRollMul+this._tip,this.pitch=this.groundPitch+this._dive,this.limit=N(Math.max(Math.abs(Q)/bt.peakSlipFront,Math.abs(ot)/bt.peakSlipRear,Math.abs(ti)/bt.peakSlipRatio)),this.wheelSpin+=l/gt.wheelRadius*t,this.wheels[0].slipAngle=Q,this.wheels[1].slipAngle=Q,this.wheels[2].slipAngle=ot,this.wheels[3].slipAngle=ot,this.wheels[0].load=this.wheels[1].load=I*.5,this.wheels[2].load=this.wheels[3].load=H*.5}get kph(){return Math.abs(this.speed)*3.6}groundTilt(){return this.terrain?((Math.abs(this.x-this._probedX)>.25||Math.abs(this.z-this._probedZ)>.25||Math.abs(ks(this._probedYaw,this.yaw))>.05)&&this._probeWheels(),{pitch:this.groundPitch,roll:this.groundRoll}):{pitch:0,roll:0}}}const Qr={steerLeft:["KeyA","ArrowLeft"],steerRight:["KeyD","ArrowRight"],throttle:["KeyW","ArrowUp"],brake:["KeyS","ArrowDown"],handbrake:["Space"],shiftUp:["KeyE","ShiftRight"],shiftDown:["KeyQ"],camera:["KeyC"],reset:["KeyR","KeyT"],reverse:["KeyB"],nextCar:["KeyV"],radio:["KeyN"],autodrive:["KeyG"],horn:["KeyH"],fine:["ShiftLeft"],attack:["ControlLeft"]};class fp{constructor(t=window){this.keys=new Set,this.pressed=new Set,this.analogue=!1,this.padIndex=null,this._lastDevice="keyboard",this._deviceSince=0,this.state={steer:0,throttle:0,brake:0,handbrake:0,analogue:!1,fine:!1,attack:!1},this._onDown=e=>{e.repeat||(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.code)&&e.preventDefault(),this.keys.add(e.code),this.pressed.add(e.code))},this._onUp=e=>this.keys.delete(e.code),this._onBlur=()=>this.keys.clear(),t.addEventListener("keydown",this._onDown,{passive:!1}),t.addEventListener("keyup",this._onUp),t.addEventListener("blur",this._onBlur),t.addEventListener("gamepadconnected",e=>{this.padIndex=e.gamepad.index}),t.addEventListener("gamepaddisconnected",()=>{this.padIndex=null}),this._target=t,this.touch={steer:0,throttle:0,brake:0,active:!1}}tapped(t){const e=Qr[t]||[];for(const n of e)if(this.pressed.has(n))return!0;return!1}held(t){const e=Qr[t]||[];for(const n of e)if(this.keys.has(n))return!0;return!1}poll(){const t=this.state;let e=(this.held("steerLeft")?1:0)-(this.held("steerRight")?1:0),n=this.held("throttle")?1:0,o=this.held("brake")?1:0,i=this.held("handbrake")?1:0,a=0,c=0,r=0,l=0,h=!1;const u=navigator.getGamepads?navigator.getGamepads():[];for(const d of u){if(!d||!d.connected)continue;h=!0;const f=-(d.axes[0]||0),p=Math.abs(f);if(p>nt.padDeadzone){const g=N((p-nt.padDeadzone)/(nt.padSaturation-nt.padDeadzone));a=Math.sign(f)*Math.pow(g,nt.padCurve)}c=d.buttons[7]?d.buttons[7].value:0,r=d.buttons[6]?d.buttons[6].value:0,l=d.buttons[0]&&d.buttons[0].pressed?1:0;break}return t.steer=Math.abs(a)>Math.abs(e)?a:e,this.touch.active&&Math.abs(this.touch.steer)>Math.abs(t.steer)&&(t.steer=this.touch.steer),t.throttle=Math.max(n,c,this.touch.throttle),t.brake=Math.max(o,r,this.touch.brake),t.handbrake=Math.max(i,l),t.analogue=h&&Math.abs(a)>=Math.abs(e)&&Math.abs(a)>.001,this.touch.active&&(t.analogue=!0),t.fine=this.held("fine"),t.attack=this.held("attack"),t.fine&&(t.throttle=Math.min(t.throttle,.45),t.steer*=.6),t.attack&&(t.steer=X(t.steer*1.25,-1,1)),t}endFrame(){this.pressed.clear()}attachTouch(t){const e=()=>t.getBoundingClientRect(),n=o=>{const i=e();let a=0,c=0,r=0,l=!1;for(const h of o.touches){l=!0;const u=(h.clientX-i.left)/i.width,d=(h.clientY-i.top)/i.height;u<.5?a=X(-(u/.5-.5)*2.4,-1,1):d>.55?r=1:c=1}this.touch.active=l,this.touch.steer=l?a:0,this.touch.throttle=c,this.touch.brake=r,l&&o.preventDefault()};t.addEventListener("touchstart",n,{passive:!1}),t.addEventListener("touchmove",n,{passive:!1}),t.addEventListener("touchend",n,{passive:!1}),t.addEventListener("touchcancel",n,{passive:!1})}dispose(){this._target.removeEventListener("keydown",this._onDown),this._target.removeEventListener("keyup",this._onUp),this._target.removeEventListener("blur",this._onBlur)}}const _i=["sport","hood"],Gt={inTau:3.4,outSecs:1.2,yawA:.62,yawP:41,yawA2:.16,yawP2:19,boomBase:7.5,boomA:6,boomP:29,liftBase:2.6,liftA:2.2,liftP:23.5,lookA:1.6,lookP:31,lookUpA:1.1,lookUpP:21.5,fov:3.5};class pp{constructor(t,{mode:e="sport"}={}){this.camera=t,this.mode=e,this.yaw=0,this.px=0,this.py=0,this.pz=0,this.vxs=0,this.vys=0,this.vzs=0,this.fov=Gs.sport.fov,this.pitch=0,this._kick=0,this._shakeT=0,this._first=!0,this._lookX=0,this._lookY=0,this._lookZ=0,this.driftW=0,this._driftT=0}cycle(){return this.mode=_i[(_i.indexOf(this.mode)+1)%_i.length],this.mode}restPose(t,e={},n=null){const o=Gs[this.mode]||Gs.sport,i=Math.sin(t.yaw),a=Math.cos(t.yaw);return e.yaw=t.yaw,e.px=t.x-i*o.behind,e.py=t.y+o.above,e.pz=t.z-a*o.behind,n&&(e.py=Math.max(e.py,this._floor(e.px,e.pz,t,n))),e.lx=t.x+i*o.lookAhead,e.ly=t.y+o.lookHeight,e.lz=t.z+a*o.lookAhead,e.fov=o.fov,e}_floor(t,e,n,o){let i=o(t,e);for(let a=1;a<=4;a++){const c=a/5,l=o(t+(n.x-t)*c,e+(n.z-e)*c)+1.2;l>i&&(i=l)}return i+1.2}update(t,e,n,o=null){const i=Gs[this.mode]||Gs.sport,a=Math.abs(t.speed),c=N(a/(250/3.6));let r=t.yaw;if(i.velocityBlend>0&&a>3){const W=Math.atan2(t.vx,t.vz);r=t.yaw+ks(t.yaw,W)*i.velocityBlend}if(i.lookIntoCorner){const W=X(i.lookIntoCorner*t.steer*t.maxSteerAngle()*4,-i.lookIntoClamp,i.lookIntoClamp);r+=W}this.yaw=this._first?r:uh(this.yaw,r,1/i.yawTau,e);const l=o&&o.drift?1:0;this.driftW===0&&l&&(this._driftT=0),this._driftT+=e,this._first?this.driftW=l:l?this.driftW=kt(this.driftW,1,1/Gt.inTau,e):this.driftW=Math.max(0,this.driftW-e/Gt.outSecs);const h=i.behind>1?this.driftW:0,u=this._driftT,d=h*(Gt.yawA*Math.sin(u/Gt.yawP*K)+Gt.yawA2*Math.sin(u/Gt.yawP2*K)),f=h*(Gt.boomBase-Gt.boomA*Math.cos(u/Gt.boomP*K)),p=h*(Gt.liftBase-Gt.liftA*Math.cos(u/Gt.liftP*K)),g=h*Gt.lookA*Math.sin(u/Gt.lookP*K),m=h*Gt.lookUpA*Math.sin(u/Gt.lookUpP*K),v=i.behind+(i.stretch||0)*c+f,x=i.above+(i.rise||0)*c+p,b=Math.sin(this.yaw+d),y=Math.cos(this.yaw+d);let A=t.x-b*v,_=t.z-y*v,S=t.y+x;if(this._first)this.px=A,this.py=S,this.pz=_,this._first=!1;else if(i.springOmega){const W=i.springOmega,I=i.springZeta,H=(V,D,$)=>{const q=($-V)*W*W-D*2*I*W,Q=D+q*e;return[V+Q*e,Q]};[this.px,this.vxs]=H(this.px,this.vxs,A),[this.py,this.vys]=H(this.py,this.vys,S),[this.pz,this.vzs]=H(this.pz,this.vzs,_)}else this.px=kt(this.px,A,6.5,e),this.py=kt(this.py,S,6.5,e),this.pz=kt(this.pz,_,6.5,e);if(i.lateralClamp){const W=t.x-this.px,I=t.z-this.pz,H=W*y-I*b,V=i.lateralClamp*v*2;if(Math.abs(H)>V*.75){const D=(Math.abs(H)-V*.75)/(V*.25),$=N(D),q=$*$*(3-2*$),Q=Math.sign(H)*(Math.abs(H)-V*.75)*q;this.px+=y*Q,this.pz-=b*Q}}if(n){const W=this._floor(this.px,this.pz,t,n);this.py<W&&(this.py=W)}const T=t.x+Math.sin(t.yaw)*i.lookAhead+y*g,M=t.z+Math.cos(t.yaw)*i.lookAhead-b*g,k=t.y+i.lookHeight+m;this._lookX=kt(this._lookX||T,T,14,e),this._lookY=kt(this._lookY||k,k,10,e),this._lookZ=kt(this._lookZ||M,M,14,e);let R=i.fov;i.fovGain&&(R=i.fov+i.fovGain*Math.pow(c,i.fovPow),t.longAccel>.5*9.81&&(this._kick=5),this._kick=kt(this._kick,0,1/Gs.sport.fovKickTau,e),R+=this._kick),R+=Gt.fov*h;const P=12*e;this.fov+=X(R-this.fov,-P,P);let z=0,L=0;if(i.shake&&a>i.shakeFrom){this._shakeT+=e*i.shakeHz*Math.PI*2;const W=i.shake*N((a-i.shakeFrom)/30)*(.6+.8*t.limit);z=Math.sin(this._shakeT)*W,L=Math.sin(this._shakeT*1.37+1.1)*W*.6}const U=this.camera;return U.position.set(this.px,this.py,this.pz),U.up.set(Math.sin(z)*.06,1,0),U.lookAt(this._lookX+z*8,this._lookY+L*8,this._lookZ),Math.abs(U.fov-this.fov)>.01&&(U.fov=this.fov,U.updateProjectionMatrix()),c}reset(){this._first=!0,this.vxs=this.vys=this.vzs=0}}const Ti=.95,mp=1.15,t0=4.2,gp=2.9,Ai=3.2,vp=9,e0=new WeakMap;function ta(s){const t=e0.get(s);if(t)return t;const e=s.segs,n=s.pts,o=new Float64Array(e),i=new Float64Array(e+1),a=new Float64Array(e),c=new Float64Array(e);let r=0;for(let h=0;h<e;h++){const u=n[h*2+2]-n[h*2],d=n[h*2+3]-n[h*2+1],f=Math.hypot(u,d)||1e-6;o[h]=f,i[h+1]=i[h]+f,c[h]=i[h]+f*.5;const p=Math.atan2(u,d);a[h]=r=h?r+ks(r,p):p}const l={n:e,len:o,cum:i,th:a,mid:c,total:i[e]};return e0.set(s,l),l}const s0=new WeakMap;function wp(s,t,e,n){let o=s0.get(t);o||s0.set(t,o={});const i=n>0?"fwd":"back";if(i in o)return o[i];const a=e.n,c=n>0?t.pts[a*2]:t.pts[0],r=n>0?t.pts[a*2+1]:t.pts[1],l=n>0?e.th[a-1]:e.th[0]+Math.PI;let h=null,u=.35;for(const d of s.edges){if(d===t)continue;const f=d.segs;for(let p=0;p<2;p++){const g=p?d.pts[f*2]:d.pts[0],m=p?d.pts[f*2+1]:d.pts[1];if(Math.abs(g-c)>2||Math.abs(m-r)>2)continue;const v=ta(d),x=p?-1:1,b=x>0?v.th[0]:v.th[f-1]+Math.PI,y=Math.cos(b-l);y>u&&(u=y,h={edge:d,path:v,dir:x})}}return o[i]=h,h}function Go(s,t){const e=s.n;if(e<2)return s.th[0];if(t<=s.mid[0]){const i=(s.th[1]-s.th[0])/(s.mid[1]-s.mid[0]||1);return s.th[0]-i*Math.min(s.mid[0]-t,s.mid[0])}if(t>=s.mid[e-1]){const i=(s.th[e-1]-s.th[e-2])/(s.mid[e-1]-s.mid[e-2]||1);return s.th[e-1]+i*Math.min(t-s.mid[e-1],s.total-s.mid[e-1])}let n=1;for(;n<e-1&&s.mid[n]<t;)n++;const o=s.mid[n]-s.mid[n-1]||1;return s.th[n-1]+(s.th[n]-s.th[n-1])*((t-s.mid[n-1])/o)}function n0(s,t,e,n){const o=s.pts;let i=1/0,a=0,c=o[0],r=o[1];for(let l=0;l<t.n;l++){const h=o[l*2],u=o[l*2+1],d=o[l*2+2]-h,f=o[l*2+3]-u,p=d*d+f*f||1e-9;let g=((e-h)*d+(n-u)*f)/p;g=g<0?0:g>1?1:g;const m=h+d*g,v=u+f*g,x=e-m,b=n-v,y=x*x+b*b;y<i&&(i=y,a=t.cum[l]+t.len[l]*g,c=m,r=v)}return{s:a,d:Math.sqrt(i),x:c,z:r}}function ea(s,t){return s.dir>0?Go(s.path,s.from+t):Go(s.path,s.from-t)+Math.PI}function mo(s,t,e){for(let n=0;n<t;n++){const o=s[n],i=e-o.start;if(i<=o.len||n===t-1)return ea(o,i<0?0:i>o.len?o.len:i)+o.base}return 0}class bp{constructor({cruise:t=16}={}){this.on=!1,this.cruise=t,this.lastReason="",this._lostFor=0,this._steer=0,this._field=null,this._edge=null,this._key="",this._dir=1,this._hops=[{path:null,dir:1,from:0,len:0,base:0,start:0},{path:null,dir:1,from:0,len:0,base:0,start:0},{path:null,dir:1,from:0,len:0,base:0,start:0}],this._nHops=0,this.tel={lateral:0,err:0,kappa:0,kMax:0,target:0,delta:0,maxA:0,hops:0,road:""}}toggle(t){return this.on=!this.on,this._lostFor=0,this._steer=t?.steer||0,this._edge=null,this._key="",this._field=null,this._dir=1,this.on&&(this.cruise=Math.max(11,Math.min(Math.abs(t?.speed||0)||16,22))),this.on}off(t=""){return this.on?(this.on=!1,this.lastReason=t,!0):!1}_track(t,e,n,o,i){t!==this._field&&(this._field=t,this._edge=this._key&&t.edges.find(u=>u.key===this._key)||null);let a=this._edge,c=a?ta(a):null,r=a?n0(a,c,e,n):null;if(r&&r.d<a.width*.5+a.verge+8&&r.s>.5&&r.s<c.total-.5)return{edge:a,path:c,at:r};const h=t.query(e,n).edge;if(h&&h!==a){const u=ta(h),d=n0(h,u,e,n),f=Go(u,d.s);(Math.abs(Math.sin(f)*o+Math.cos(f)*i)>.5||!a)&&(this._edge=a=h,this._key=h.key,c=u,r=d)}return a?{edge:a,path:c,at:r}:null}_horizon(t,e,n,o,i,a){const c=this._hops,r=c[0];r.path=n,r.dir=o,r.from=i,r.len=Math.max(o>0?n.total-i:i,0),r.base=0,r.start=0;let l=1,h=r,u=e;for(;l<c.length&&h.start+h.len<a;){const d=wp(t,u,h.path,h.dir);if(!d)break;const f=c[l];f.path=d.path,f.dir=d.dir,f.from=d.dir>0?0:d.path.total,f.len=d.path.total,f.start=h.start+h.len,f.base=ea(h,h.len)+h.base-ea(f,0),h=f,u=d.edge,l++}return this._nHops=l,l}update(t,e,n){if(!this.on)return null;if(Math.abs(e.steer)>.12||e.brake>.15||e.throttle>.5||e.handbrake>.1)return this.off("you took over"),null;const o=t.terrain;if(!o||!o.roads)return null;const i=Math.min(Math.max(n,1/240),.1),a=Math.sin(t.yaw),c=Math.cos(t.yaw),r=this._track(o.roads,t.x,t.z,a,c),l=r?r.edge.width:6,h=r?r.at.d:1/0;if(!r||!isFinite(h)||h>l*2.2+14)return this._lostFor+=i,this._steer+=X(-this._steer,-Ai*i,Ai*i),this._lostFor>4&&this.off("lost the road"),{steer:this._steer,throttle:0,brake:.35,handbrake:0,analogue:!0,auto:!0};this._lostFor=0;const{edge:u,path:d,at:f}=r,p=Go(d,f.s),g=Math.sin(p)*a+Math.cos(p)*c;g>.15?this._dir=1:g<-.15&&(this._dir=-1);const m=this._dir,v=Math.abs(t.speed),x=Math.max(v,4),b=t.wb||2.7,y=X(v*2.4+30,45,130),A=this._hops,_=this._horizon(o.roads,u,d,m,f.s,y),S=mo(A,_,0),T=Math.sin(S),M=Math.cos(S),k=(t.x-f.x)*M-(t.z-f.z)*T,R=ks(t.yaw,S),P=X(v*.8,9,26),z=(mo(A,_,P)-S)/P,L=X(-Ti*Ti*k+2*mp*Ti*x*R,-t0,t0),U=Math.atan(b*L/(x*x))+Math.atan(b*z),W=typeof t.maxSteerAngle=="function"?t.maxSteerAngle():.09,I=X(U/Math.max(W,.001),-1,1),H=Ai*i;this._steer+=X(I-this._steer,-H,H);const V=X(this._steer,-1,1);let D=Math.abs(z);for(let Tt=0;Tt+45<=y;Tt+=15){const Pt=mo(A,_,Tt+45)-mo(A,_,Tt);D=Math.max(D,Math.abs(Pt)/45)}const $=Math.max(Math.min(this.cruise,D>1e-5?Math.sqrt(gp/D):1/0),vp),q=$-v,Q=q<=0?0:q>$*.25?N(.45+q/12):N(q/5),ot=v-$,ht=ot>1.5?N((ot-1.5)/7)*.5:0,rt=this.tel;return rt.lateral=k,rt.err=R,rt.kappa=z,rt.kMax=D,rt.target=$,rt.delta=U,rt.maxA=W,rt.hops=_,rt.road=this._key,{steer:V,throttle:Q,brake:ht,handbrake:0,analogue:!0,auto:!0}}}const Mi=100,Sn=56,xp=1.35,yp=Math.max(...es.map(s=>s.unlockAt))||1e5,_p=`
in float aT;      // 0 at the car, 1 at the tail
in float aSide;   // -1 or +1 across the ribbon
out float vT;
out float vSide;
out vec3 vWorld;
void main(){
  vT = aT;
  vSide = aSide;
  vWorld = position;
  gl_Position = projectionMatrix * viewMatrix * vec4(position, 1.0);
}
`,Tp=`
in float vT;
in float vSide;
in vec3 vWorld;
out vec4 fragColor;

uniform float uDepth;   // 0 pale .. 1 deep — how long the streak is
uniform float uAlive;   // 1 while the streak runs, falls to 0 as it is reeled in
uniform float uBreak;   // 1 at the instant it broke, decaying — the red blip

void main(){
  // Pale sky blue to a deep ink blue. Both are in the game's own palette range so the trail
  // never looks like a UI element that wandered into the scene.
  vec3 pale = vec3(0.66, 0.82, 0.94);
  vec3 deep = vec3(0.10, 0.26, 0.62);
  vec3 col = mix(pale, deep, uDepth);

  // The break flash. One red pulse, brightest at the car end, so it reads as something
  // letting go rather than the whole world changing colour.
  col = mix(col, vec3(0.86, 0.22, 0.16), uBreak * (1.0 - vT * 0.6));

  // Soft edges across the ribbon and a fade towards the tail.
  float edge = 1.0 - abs(vSide);
  float a = smoothstep(0.0, 0.35, edge) * (1.0 - vT * vT) * uAlive;
  // A gentle glow while it is alive: the operator asked for things to "illumine a little bit"
  // when the streak is running.
  col += vec3(0.10, 0.16, 0.24) * uAlive * (1.0 - vT);

  if (a < 0.01) discard;
  fragColor = vec4(SAFE3(col), a * 0.72);
}
`;class Ap{constructor({scene:t}){this.points=[],this.alive=0,this.breakFlash=0,this.depth=0;const e=Sn;this.pos=new Float32Array(e*2*3);const n=new Float32Array(e*2),o=new Float32Array(e*2);for(let c=0;c<e;c++)n[c*2]=n[c*2+1]=c/(e-1),o[c*2]=-1,o[c*2+1]=1;const i=new Uint16Array((e-1)*6);for(let c=0,r=0;c<e-1;c++){const l=c*2;i[r++]=l,i[r++]=l+2,i[r++]=l+1,i[r++]=l+1,i[r++]=l+2,i[r++]=l+3}const a=new $e;a.setAttribute("position",new et(this.pos,3)),a.setAttribute("aT",new et(n,1)),a.setAttribute("aSide",new et(o,1)),a.setIndex(new et(i,1)),a.frustumCulled=!1,this.geometry=a,this.material=new Ut({glslVersion:"300 es",uniforms:Zt({uDepth:{value:0},uAlive:{value:0},uBreak:{value:0}}),vertexShader:Kt(_p),fragmentShader:ce(Tp),transparent:!0,depthWrite:!1,side:ke}),this.mesh=new Ht(a,this.material),this.mesh.frustumCulled=!1,this.mesh.name="streakTrail",this.mesh.renderOrder=6,t.add(this.mesh),this._prevDistance=0}update(t,e,n){const o=n.distance||0;this._prevDistance>Mi&&o<this._prevDistance*.5&&(this.breakFlash=1),this._prevDistance=o,this.breakFlash=Math.max(0,this.breakFlash-t*.9);const i=o>Mi;this.alive=i?Math.min(1,this.alive+t*2.2):Math.max(0,this.alive-t*.9);const a=N((o-Mi)/900);if(this.depth=N(Math.log10(1+o/220)/Math.log10(1+yp/220)),this.material.uniforms.uAlive.value=this.alive,this.material.uniforms.uDepth.value=this.depth,this.material.uniforms.uBreak.value=this.breakFlash,this.alive<.005){this.mesh.visible=!1;return}this.mesh.visible=!0;const c=2.2,r=e.x-Math.sin(e.yaw)*c,l=e.z-Math.cos(e.yaw)*c,h=e.y+.35;if(!this.points.length)for(let f=0;f<Sn;f++)this.points.push({x:r,y:h,z:l});this.points[0].x=r,this.points[0].y=h,this.points[0].z=l;const u=xp*(.35+.65*a);for(let f=1;f<Sn;f++){const p=this.points[f],g=this.points[f-1];let m=p.x-g.x,v=p.y-g.y,x=p.z-g.z;const b=Math.hypot(m,v,x)||1e-5,y=(b-u)/b;p.x-=m*y,p.y-=v*y,p.z-=x*y,p.y=O(p.y,g.y-.06,Math.min(1,t*6))}const d=O(.1,.34,a);for(let f=0;f<Sn;f++){const p=this.points[f],g=this.points[Math.min(f+1,Sn-1)],m=this.points[Math.max(f-1,0)];let v=g.x-m.x,x=g.z-m.z;const b=Math.hypot(v,x)||1;v/=b,x/=b;const y=x*d,A=-v*d,_=f*6;this.pos[_]=p.x-y,this.pos[_+1]=p.y,this.pos[_+2]=p.z-A,this.pos[_+3]=p.x+y,this.pos[_+4]=p.y,this.pos[_+5]=p.z+A}this.geometry.attributes.position.needsUpdate=!0}reset(t){const n=t.x-Math.sin(t.yaw)*2.2,o=t.z-Math.cos(t.yaw)*2.2;for(const i of this.points)i.x=n,i.y=t.y+.35,i.z=o}dispose(){this.geometry.dispose(),this.material.dispose()}}const Mp=.45,go=.55,Sp=8,kn=[{at:0,mul:1,label:null},{at:1e3,mul:1.25,label:"a kilometre without leaving the road"},{at:2500,mul:1.5,label:"two and a half"},{at:5e3,mul:2,label:"five kilometres. settling in"},{at:1e4,mul:2.75,label:"ten. the road is yours"},{at:2e4,mul:3.5,label:"twenty kilometres"},{at:4e4,mul:4.5,label:"forty. still going"},{at:8e4,mul:6,label:"eighty kilometres without a wheel off"}];function kp(s){const t=s*3.6;return t<30?0:.35+.85*Math.pow(N((t-30)/220),.72)}class Ep{constructor({storageKey:t="wanderoad.streak.v1"}={}){this.storageKey=t,this.distance=0,this.score=0,this.total=0,this.best=0,this.bestScore=0,this.multiplier=1,this.onRoad=!1,this.tier=0,this._off=0,this._announced=0,this._events=[],this._lastBreakAt=0,this._savedBest=0,this.load()}load(){try{const t=localStorage.getItem(this.storageKey);if(!t)return;const e=JSON.parse(t);this.total=+e.total||0,this.best=+e.best||0,this.bestScore=+e.bestScore||0,this._savedBest=this.best}catch{}}save(){try{localStorage.setItem(this.storageKey,JSON.stringify({total:this.total,best:this.best,bestScore:this.bestScore})),this._savedBest=this.best}catch{}}get state(){return{distance:this.distance,km:this.distance/1e3,score:this.score,total:this.total,best:this.best,bestScore:this.bestScore,multiplier:this.multiplier,onRoad:this.onRoad,grace:this._off>0&&this._off<go,graceLeft:Math.max(0,go-this._off),tier:this.tier}}drain(){return this._events.length?this._events.shift():null}update(t,e,n){const o=Math.abs(e.speed||0),i=(n?n.onRoad:0)>=Mp&&e.onGround!==!1;if(this.onRoad=i,!i){this._off+=t,e.onGround===!1&&(this._off=Math.min(this._off,go*.4)),this._off>=go&&(this.distance>250&&this._events.push({kind:"break",distance:this.distance,score:this.score}),this._commit());return}if(this._off=0,o<Sp)return;const a=o*t;this.distance+=a,this.distance>this.best&&(this.best=this.distance,this.best-this._savedBest>250&&this.save());let c=0;for(let d=kn.length-1;d>=0;d--)if(this.distance>=kn[d].at){c=d;break}this.tier=c;const r=kn[c],l=kn[Math.min(c+1,kn.length-1)],h=Math.max(l.at-r.at,1),u=N((this.distance-r.at)/h);this.multiplier=O(r.mul,l.mul,u*.6),c>this._announced&&(this._announced=c,r.label&&this._events.push({kind:"milestone",text:r.label,distance:this.distance})),this.score+=a*kp(o)*this.multiplier*.1}_commit(){this.distance>this.best&&(this.best=this.distance),this.score>this.bestScore&&(this.bestScore=this.score),this.total+=this.score,this.save(),this.distance=0,this.score=0,this.multiplier=1,this.tier=0,this._announced=0,this._off=0}flush(){this.distance>0?this._commit():this.save()}}function Rp(s){return s<1e3?String(Math.floor(s)):s<1e5?(s/1e3).toFixed(1)+"k":Math.round(s/1e3)+"k"}function Si(s){return s<1e3?`${Math.round(s)} m`:`${(s/1e3).toFixed(s<1e4?2:1)} km`}const zp={cruiser:{label:"Cruiser",blurb:"Calm and planted. Full stick is 0.7 g, the camera never moves in a hurry. This is the cozy default.",comfortG:7,assist:"cruise",camera:"cruise",rearGrip:1.04,buildRate:1.6,tier:"gt",car:"estate"},road:{label:"Road",blurb:"The default. A fast road car: 0.96 g at full stick, sport aids, the chase camera looks into the corner.",comfortG:9.4,assist:"sport",camera:"sport",rearGrip:1,buildRate:2,tier:"sports",car:"coupe"},sharp:{label:"Sharp",blurb:"More lock, faster hands. 1.25 g at full stick and a quicker steering ramp — quick, still not twitchy.",comfortG:12.2,assist:"sport",camera:"sport",rearGrip:.98,buildRate:3.2,tier:"sports",car:"rally"},drift:{label:"Drift",blurb:"Loose rear end and a lot of lock. Made for holding a slide, not for lap times.",comfortG:13.5,assist:"off",camera:"sport",rearGrip:.86,buildRate:3.6,tier:"sports",car:"sedan"},sim:{label:"Raw",blurb:"No assists at all, no comfort limit — the full 40° rack, tapered only by speed. Hard.",comfortG:40,assist:"hardcore",camera:"sport",rearGrip:1,buildRate:4,tier:"sports",car:"coupe"},hyper:{label:"Hyper",blurb:"All-wheel drive, 800 hp, 340 km/h. Planted at speed, and quick enough to need the calm camera.",comfortG:10.5,assist:"sport",camera:"sport",rearGrip:1.02,buildRate:2.2,tier:"hyper",car:"patrol"}},zs={meadow:{label:"Meadow",blurb:"The pen’s own valley. Soft rolling hills, wide sightlines, nothing you cannot drive over.",amp:.95,wave:1.12,peak:1,bias:[2.2,1,.35,.3,.8]},rolling:{label:"Rolling",blurb:"The default mix. Meadow and steppe with hills and the occasional mountain on the horizon.",amp:1,wave:1,peak:1,bias:[1,1,1,1,1]},alpine:{label:"Alpine",blurb:"Mountains close in. Switchbacks, cuttings and long climbs — the most dramatic and the least forgiving.",amp:1.12,wave:.97,peak:1.7,bias:[.6,.5,3,.2,.5]},plains:{label:"Plains",blurb:"Almost flat. Kilometres of straight road under a huge sky — the best place to feel top speed.",amp:.9,wave:1.18,peak:.78,bias:[.8,3,.15,1.2,.7]},dunes:{label:"Dunes",blurb:"Rose and ochre sand sea. Loose grip, long crests, the road half-buried.",amp:.9,wave:1.1,peak:.8,bias:[.3,.9,.2,3.5,.2]},marsh:{label:"Wetland",blurb:"Flooded reed flats under standing mist. Dead flat, causeways and mirrors.",amp:.75,wave:1.15,peak:.75,bias:[.7,.3,.2,.1,3.5]}};function Cp(s){const t=zs[s]||zs.rolling;Be.__base||(Be.__base=Be.map(n=>({...n})));const e=Be.__base;for(let n=0;n<Be.length;n++)Be[n].amp=e[n].amp*t.amp,Be[n].wave=e[n].wave*t.wave;return cu(t.peak??1),t}function Lp(s){return(zs[s]||zs.rolling).bias}function Fp(s=location.search){const t=new URLSearchParams(s),e=zp[t.get("feel")]?t.get("feel"):"road",n=Dp(t.get("terrain"))?t.get("terrain"):"rolling";return{feel:e,terrain:n,debug:t.has("debug"),offline:t.has("offline"),cheat:t.has("cheat")}}const Dp=s=>!!zs[s],Ip=Qi*Gn,Pp=.02,Op=4,Np=2.5,Bp=.35,Gp=.03,Up=.35,Pc={broadleaf:1.1,poplar:.89,pine:.5,deadpine:.48,acacia:.88,palm:.38,willow:.65},Hp={broadleaf:11.5,poplar:15,pine:14.5,deadpine:13,acacia:9.5,palm:12.5,willow:9.5};class Wp{static solidSpecies=Pc;constructor({cell:t=64}={}){this.cell=t,this.grid=new Map,this.byChunk=new Map,this.lastHit=null,this._px=null,this._pz=null}_key(t,e){return`${Math.floor(t/this.cell)},${Math.floor(e/this.cell)}`}addChunk(t,e){if(this.byChunk.has(t)&&this.removeChunk(t),!(!e||!e.length)){this.byChunk.set(t,e);for(const n of e){const o=this._key(n.x,n.z);let i=this.grid.get(o);i||(i=[],this.grid.set(o,i)),i.push(n)}}}removeChunk(t){const e=this.byChunk.get(t);if(e){for(const n of e){const o=this._key(n.x,n.z),i=this.grid.get(o);if(!i)continue;const a=i.indexOf(n);a>=0&&i.splice(a,1),i.length||this.grid.delete(o)}this.byChunk.delete(t)}}clear(){this.grid.clear(),this.byChunk.clear(),this._px=this._pz=null}get count(){let t=0;for(const e of this.byChunk.values())t+=e.length;return t}resolve(t,e=1.05,n=1/60){const o=Math.floor(t.x/this.cell),i=Math.floor(t.z/this.cell);let a=null;const c=this._px,r=this._pz;if(c!==null){const l=t.x-c,h=t.z-r,u=l*l+h*h,d=Math.hypot(t.vx,t.vz)*Math.max(n,Ip)*1.5+.5;if(u>1e-8&&u<=d*d){let f=1/0,p=null;for(let g=-1;g<=1;g++)for(let m=-1;m<=1;m++){const v=this.grid.get(`${o+m},${i+g}`);if(v)for(const x of v){if(x.h&&t.y-.4>x.y+x.h)continue;const b=x.r+e,y=c-x.x,A=r-x.z,_=y*y+A*A-b*b;let S;if(_<=0)S=0;else{const T=u,M=2*(y*l+A*h),k=M*M-4*T*_;if(k<=0||(S=(-M-Math.sqrt(k))/(2*T),S<0||S>1))continue}S<f&&(f=S,p=x)}}if(p){t.x=c+l*f,t.z=r+h*f;let g=t.x-p.x,m=t.z-p.z;const v=Math.hypot(g,m)||1e-4;g/=v,m/=v;const x=p.r+e+Gp;v<x&&(t.x=p.x+g*x,t.z=p.z+m*x),a=this._respond(t,p,g,m,a)}}}for(let l=-1;l<=1;l++)for(let h=-1;h<=1;h++){const u=this.grid.get(`${o+h},${i+l}`);if(u)for(const d of u){const f=t.x-d.x,p=t.z-d.z,g=d.r+e,m=f*f+p*p;if(m>=g*g||d.h&&t.y-.4>d.y+d.h)continue;const v=Math.sqrt(m)||1e-4,x=g-v;if(x<Pp)continue;const b=f/v,y=p/v;t.x+=b*x,t.z+=y*x,a=this._respond(t,d,b,y,a)}}return this._px=t.x,this._pz=t.z,this.lastHit=a,a}_respond(t,e,n,o,i){const a=t.vx*n+t.vz*o;if(a>=0)return i;const c=Math.hypot(t.vx,t.vz),r=N(-a/Math.max(c,.001));if(e.solid&&-a>=Np&&r>=Bp)t.vx=0,t.vz=0,t.yawRate=0;else{const l=t.vx-a*n,h=t.vz-a*o,u=e.kind==="rock"?.18:.06,d=1-.55*r;t.vx=l*d-a*n*u,t.vz=h*d-a*o*u,t.yawRate*=1-.6*r}return c>Op&&(!i||r*c>i.severity*i.speed)?{kind:e.kind,speed:c,severity:r,x:e.x,z:e.z}:i}}function $p(s,t){const e=[];if(!s||!s.trees)return e;for(const n of s.trees){const o=Pc[n.kind];if(o===void 0)continue;const i=n.scale||1,a=n.y!==void 0?n.y:0;e.push({x:n.x,y:a-Up*i,z:n.z,r:o*i,h:Hp[n.kind]*i,kind:"tree",solid:!0})}return e}const Kp=.6,qp=1,jp=1,Vp=3,Yp=12,Xp=.45,Zp=.28;function Jp(s){if(!s||!s.w)return 0;const t=Ls(s.w,s.y);return t===null?0:t-s.y}class Qp{constructor({recover:t,say:e=null,deep:n=Kp,hold:o=qp,lift:i=jp,cooldown:a=Vp,keepHeading:c=!0}={}){this.recover=t,this.say=e,this.deep=n,this.hold=o,this.lift=i,this.cooldown=a,this.keepHeading=c,this.state="dry",this.t=0,this.depth=0,this.since=1/0}reset(){this.state="dry",this.t=0,this.depth=0}_place(t){const e=this.since>Yp,n=t.x,o=t.z,i=t.yaw;if(this.recover(),this.since=0,!this.keepHeading||t.x===n&&t.z===o)return;if(e)return void t.placeAt(t.x,t.z,i);const a=t.terrain?t.terrain.surface(t.x,t.z):null;if(!a||!isFinite(a.roadDist))return;let c=a.roadTx,r=a.roadTz;Math.sin(i)*c+Math.cos(i)*r<0&&(c=-c,r=-r),t.placeAt(t.x,t.z,Math.atan2(c,r))}update(t,e,n){const o=Jp(n);this.depth=o,this.since+=t;const i=o>this.deep&&(n?n.onRoad:0)<Xp;if(this.state==="dry")return i?(this.t+=t,this.t>=this.hold&&(this.state="lifting",this.t=0,this.say&&this.say("the water has you — drifting back to the road",2.6))):this.t=0,!1;if(this.state==="lifting"){if(o<=0)return this.reset(),!1;const a=Math.exp(-t/Zp);return e.vx*=a,e.vz*=a,e.yawRate*=a,this.t+=t,this.t>=this.lift?(this.state="settling",this.t=0,this._place(e),!0):!1}return this.t+=t,this.t>=this.cooldown&&this.reset(),!1}}const o0=38,i0=[.17,.24],t1=1347571536,e1=1347373361,s1=1179995185,n1=1/4294967296,a0=2.2,Us=150,F=(s,t,e,n,o,i,a,c,r,l,h,u)=>({id:s,label:t,group:e,w:n,off:o,foot:i,face:a,slope:c,r,h:l,wet:h,biome:u}),ct=.985,Z=.95,Ie=.9,He=[F("torii_red","vermilion torii","shrine",5,[7,22],2.6,"road",Z,.5,5.2,"dry",null),F("torii_stone","stone torii","shrine",4,[8,30],2.4,"road",Z,.5,4.4,"dry",null),F("torii_moss","mossy torii","shrine",3,[10,40],1.8,"road",Z,.42,3.4,"any",[0,4]),F("jizo_trio","three jizo","shrine",7,[5,12],1.1,"road",Ie,0,0,"dry",null),F("jizo_single","a jizo in a bib","shrine",8,[4,10],.6,"road",Ie,0,0,"dry",null),F("stone_lantern","stone lantern","shrine",7,[4,14],.8,"road",Z,.4,2.1,"dry",null),F("lantern_pair","a pair of lanterns","shrine",4,[6,16],2.2,"road",Z,.4,2.1,"dry",null),F("paper_lanterns","strung paper lanterns","shrine",3,[6,18],3.4,"along",Z,0,0,"dry",null),F("wayside_shrine","wayside shrine","shrine",5,[6,18],1.6,"road",ct,1.1,2.6,"dry",null),F("ema_rack","ema boards","shrine",3,[6,16],1.4,"road",Z,0,0,"dry",null),F("shimenawa_post","a roped stone","shrine",4,[5,20],1,"free",Ie,.8,1.8,"any",null),F("fox_statue","a stone fox","shrine",4,[4,12],.7,"road",Ie,0,0,"dry",null),F("cat_statue","a beckoning cat","shrine",3,[4,11],.6,"road",Ie,0,0,"dry",null),F("moss_buddha","a buddha under moss","shrine",2,[8,30],1.2,"road",Ie,.8,1.6,"any",[0,4]),F("prayer_cairn","a prayer cairn","shrine",6,[5,40],1,"free",Ie,.7,1.4,"any",[2,3]),F("standing_stones","standing stones","shrine",2,[30,130],6,"free",Z,1,3.4,"dry",[1,2]),F("stone_arch","a ruined arch","shrine",2,[20,90],4,"road",ct,1.2,5,"dry",null),F("barn","a red barn","farm",4,[22,90],6.5,"road",ct,6,7.5,"dry",[0,1]),F("shed","a tool shed","farm",6,[10,40],2.2,"road",ct,2,2.6,"dry",null),F("potting_shed","a potting shed","farm",4,[10,36],2.4,"road",ct,2.2,2.8,"dry",[0]),F("grain_silo","a grain silo","farm",3,[25,100],3.2,"free",ct,3,9,"dry",[0,1]),F("charcoal_kiln","a charcoal kiln","farm",3,[14,60],2.4,"free",Z,2.2,3,"dry",[0,2]),F("hay_bales","stacked hay bales","farm",6,[12,70],2.6,"along",Z,2.4,2.4,"dry",[0,1]),F("hay_cart","a hay cart","farm",5,[8,30],2.4,"along",Z,1.6,2.2,"dry",[0,1]),F("hand_cart","a hand cart","farm",5,[6,20],1.4,"free",Z,0,0,"dry",null),F("scarecrow","a scarecrow","farm",6,[10,60],.7,"road",Z,0,0,"dry",[0,1]),F("beehives","a row of beehives","farm",5,[10,45],2,"along",Z,0,0,"dry",[0]),F("milk_churns","milk churns on a stand","farm",5,[4,14],1.2,"road",Z,0,0,"dry",[0]),F("water_trough","a stone trough","farm",5,[5,20],1.3,"along",Z,.9,.7,"any",null),F("drystone_wall","a drystone wall","farm",6,[6,22],5.5,"along",Z,0,0,"any",[0,2]),F("pasture_fence","a pasture fence","farm",7,[6,24],6,"along",Z,0,0,"dry",[0,1]),F("wooden_gate","a five-bar gate","farm",6,[5,16],2.2,"road",Z,0,0,"dry",[0,1]),F("washing_line","a washing line","farm",4,[10,40],3.4,"along",Z,0,0,"dry",[0]),F("sunflower_patch","sunflowers","farm",5,[6,40],3,"free",Z,0,0,"dry",[0,1]),F("flower_bed","a bed of flowers","farm",6,[4,20],2.4,"free",Z,0,0,"dry",[0]),F("topiary","a clipped topiary","farm",3,[6,24],1.4,"free",Z,0,0,"dry",[0]),F("hedge_arch","a hedge arch","farm",3,[7,26],2.4,"road",Z,0,0,"dry",[0]),F("tractor","an old tractor","farm",4,[8,34],2,"free",Z,1.5,2.4,"dry",[0,1]),F("plough","a rusting plough","farm",4,[8,34],1.4,"free",Z,0,0,"dry",[0,1]),F("bus_shelter","a bus shelter","roadside",5,[5,11],2.2,"road",ct,0,0,"dry",null),F("bus_stop_sign","a bus stop","roadside",6,[4,9],.4,"road",Z,0,0,"dry",null),F("bench","a bench with a view","roadside",8,[5,22],1.2,"road",Z,0,0,"dry",null),F("picnic_table","a picnic table","roadside",6,[7,30],1.5,"free",ct,0,0,"dry",null),F("picnic_shelter","a picnic shelter","roadside",3,[10,40],2.8,"road",ct,0,0,"dry",null),F("phone_box","a telephone box","roadside",4,[4,12],.6,"road",ct,.6,2.6,"dry",null),F("vending_machine","a lit vending machine","roadside",5,[4,10],.7,"road",ct,.7,1.9,"dry",null),F("post_box","a post box","roadside",6,[4,9],.4,"road",Z,0,0,"dry",null),F("letterbox_post","a letterbox on a post","roadside",6,[4,12],.3,"road",Z,0,0,"dry",null),F("notice_board","a parish notice board","roadside",5,[4,12],.8,"road",Z,0,0,"dry",null),F("fingerpost","a fingerpost","roadside",8,[4,10],.5,"free",Z,0,0,"dry",null),F("village_sign","a village sign","roadside",5,[4,12],1,"road",Z,0,0,"dry",null),F("milestone_big","a milestone","roadside",6,[3.5,8],.4,"road",Ie,0,0,"any",null),F("water_pump","a village pump","roadside",4,[4,14],.6,"road",Z,0,0,"any",null),F("electrical_cabinet","a green cabinet","roadside",4,[4,10],.6,"road",ct,0,0,"dry",null),F("bicycle","a leaning bicycle","roadside",5,[4,12],.9,"along",Z,0,0,"dry",null),F("telegraph_pole","a telegraph pole","roadside",8,[5,14],.4,"along",Z,.24,7.5,"dry",null),F("flag_pole","a flagpole","roadside",3,[6,24],.4,"free",Z,.2,7,"dry",null),F("windsock","a windsock","roadside",3,[10,60],.5,"free",Z,.2,5.5,"dry",[1,3]),F("bird_house_pole","a bird house","roadside",6,[4,20],.35,"free",Z,0,0,"dry",null),F("weather_vane","a weather vane","roadside",4,[6,26],.4,"free",Z,0,0,"dry",null),F("wind_chime_arch","a wind-chime arch","roadside",3,[6,20],1.8,"road",Z,0,0,"dry",null),F("sundial","a sundial","roadside",3,[5,18],.7,"free",Z,0,0,"dry",null),F("stone_steps","steps going up","roadside",4,[4,14],1.6,"road",Ie,0,0,"dry",[0,2]),F("crate_stack","stacked crates","roadside",5,[4,16],1.2,"free",Z,0,0,"dry",null),F("barrel_stack","stacked barrels","roadside",5,[4,16],1.3,"free",Z,0,0,"dry",null),F("market_stall","a shuttered market stall","roadside",3,[6,20],2,"road",ct,0,0,"dry",null),F("cottage","a cottage","dwelling",4,[16,70],4.6,"road",ct,4.2,5.5,"dry",[0]),F("log_cabin","a log cabin","dwelling",4,[18,80],4,"road",ct,3.6,4.6,"dry",[0,2]),F("tea_house","a tea house","dwelling",3,[12,50],3.4,"road",ct,3,4,"dry",null),F("chapel","a small chapel","dwelling",3,[18,80],3.8,"road",ct,3.4,7,"dry",null),F("dovecote","a dovecote","dwelling",3,[12,50],1.8,"free",ct,1.6,5,"dry",[0]),F("gazebo","a gazebo","dwelling",3,[12,50],2.6,"free",ct,0,0,"dry",[0]),F("bandstand","a bandstand","dwelling",2,[16,70],3.6,"free",ct,0,0,"dry",[0]),F("yurt","a yurt","dwelling",3,[14,70],2.8,"free",ct,2.6,3,"dry",[1,2]),F("signal_box","a signal box","dwelling",2,[14,60],2.4,"road",ct,2.2,4.2,"dry",null),F("clock_tower","a clock tower","dwelling",2,[22,110],2.6,"road",ct,2.4,14,"dry",null),F("water_tower","a water tower","dwelling",2,[25,120],3,"free",ct,2.6,15,"dry",[1]),F("windmill","a windmill","dwelling",2,[40,150],4.4,"road",ct,4,16,"dry",[0,1]),F("watermill","a watermill","dwelling",2,[20,70],4.2,"road",ct,3.8,7,"shore",[0,4]),F("lighthouse","a lighthouse","dwelling",1,[30,140],3.2,"free",ct,3,18,"shore",[3,4]),F("mooring_mast","an airship mast","dwelling",1,[35,150],2.4,"free",ct,1.4,20,"dry",[1,2]),F("ruined_tower","a ruined tower","ruin",2,[25,130],3,"free",Z,2.8,8,"dry",[2]),F("ruined_wall","a ruined wall","ruin",3,[16,90],4,"free",Z,0,0,"any",[1,2]),F("rusted_truck","a truck going back to the earth","ruin",3,[8,34],2.6,"along",Z,1.8,2.4,"dry",null),F("caravan","a parked caravan","ruin",3,[8,30],2.6,"along",ct,2,2.8,"dry",null),F("rail_trolley","a rail trolley on a stub of track","ruin",2,[10,45],2.2,"along",ct,0,0,"dry",null),F("jetty","a wooden jetty","water",4,[8,40],3.6,"free",Z,0,0,"shore",[4,3]),F("rowboat","a rowing boat","water",4,[6,34],1.8,"free",Z,0,0,"shore",[4,0]),F("upturned_boat","an upturned boat","water",4,[6,34],1.8,"free",Z,0,0,"any",[4,3]),F("fishing_hut","a fishing hut","water",3,[10,45],2.4,"road",ct,2.2,3,"shore",[4]),F("boathouse","a boathouse","water",2,[12,55],3.4,"road",ct,3,4,"shore",[4]),F("crab_pots","stacked crab pots","water",4,[5,24],1.2,"free",Z,0,0,"shore",[3,4]),F("buoy_cluster","a huddle of buoys","water",3,[5,26],1.2,"free",Z,0,0,"shore",[3,4]),F("giant_mushrooms","improbable mushrooms","wild",4,[6,40],2.2,"free",Z,0,0,"any",[0,4]),F("giant_acorn","an acorn the size of a car","wild",2,[8,45],1.6,"free",Z,1.4,2.2,"dry",[0]),F("bamboo_clump","a clump of bamboo","wild",4,[6,36],2,"free",Z,0,0,"dry",[0,4]),F("tree_stump_axe","a stump with an axe in it","wild",5,[5,26],1,"free",Z,0,0,"dry",[0,2]),F("fallen_log","a fallen log","wild",6,[6,40],3.2,"free",Z,0,0,"any",[0,2]),F("log_pile","a stack of cut logs","wild",6,[6,30],1.8,"along",Z,1.6,1.4,"dry",[0,2]),F("erratic_boulder","a boulder left by a glacier","wild",4,[8,60],2.6,"free",Ie,2.4,3,"any",[2,1])];He.map(s=>s.id);const o1=Object.fromEntries(He.map(s=>[s.id,s]));He.length!==100&&console.warn(`[props] catalogue has ${He.length} kinds, not 100`);function Oc(s){const t=s.pts.length/2,e=new Float32Array(t);for(let n=1;n<t;n++){const o=s.pts[n*2]-s.pts[n*2-2],i=s.pts[n*2+1]-s.pts[n*2-1];e[n]=e[n-1]+Math.hypot(o,i)}return e}function Nc(s,t,e,n){const o=t.length;let i=1;for(;i<o-1&&t[i]<e;)i++;const a=t[i-1],c=t[i]-a||1,r=N((e-a)/c),l=s.pts[i*2-2],h=s.pts[i*2-1],u=s.pts[i*2],d=s.pts[i*2+1];n.x=l+(u-l)*r,n.z=h+(d-h)*r;const f=Math.hypot(u-l,d-h)||1;return n.tx=(u-l)/f,n.tz=(d-h)/f,n.k=i,n.t=r,n}const i1=/^(\d+):(-?\d+),(-?\d+),(\d+)$/;function Bc(s){const t=i1.exec(s.key);return t?{tier:+t[1],i:+t[2],j:+t[3],dir:+t[4]}:(console.error("[props] road edge key format changed:",s.key),{tier:0,i:0,j:0,dir:0})}const a1=8,sa=[];for(let s=0;s<a1;s++){const t=new Float64Array(He.length);let e=0;for(let n=0;n<He.length;n++){const o=He[n];e+=o.biome?o.biome.includes(s)?o.w*4:o.w*.25:o.w,t[n]=e}sa.push(t)}function r1(s,t){const e=sa[t]||sa[0],n=s*e[e.length-1];for(let o=0;o<e.length;o++)if(n<=e[o])return He[o];return He[He.length-1]}function c1(s,t,e,n,o,i,a=null){const c=i.site,r=i.height||((f,p)=>i.site(f,p).y),l=[],h=f=>{a&&(a[f]=(a[f]||0)+1)},u=Ko(s-Us,t-Us,e+Us,n+Us,o,20),d={x:0,z:0,tx:1,tz:0,k:0,t:0};for(const f of u){const p=Bc(f),g=Oc(f),m=g[g.length-1],v=i0[p.tier]??i0[0],x=f.width*.5,b=Math.floor(m/o0),y=p.i*4+p.dir*2+p.tier;for(let A=0;A<b;A++){if(Es(y,p.j,A,o^e1)*n1>=v)continue;const _=Ee(Es(y,p.j,A,o^t1));if(h("candidates"),Nc(f,g,(A+.15+_()*.7)*o0,d),d.x<s-Us||d.x>e+Us)continue;const S=c(d.x,d.z),T=r1(_(),S.dominant),M=_()<.5?1:-1,k=.9+_()*.24,R=T.foot*k,P=Math.max(T.off[0],x+a0+R),z=Math.max(P+1,T.off[1]),L=P+Math.pow(_(),1.4)*(z-P),U=d.tz*M,W=-d.tx*M,I=d.x+U*L,H=d.z+W*L;if(I<s||I>=e||H<t||H>=n){h("outsideBox");continue}if(!h1(u,I,H,a0+R)){h("rejectRoad");continue}const V=c(I,H);if(!d1(T.wet,V.y,V.wy)){h("rejectWater");continue}const D=Math.max(R*1.15,.6),$=u1(r,V.y,I,H,D);if($.hi-$.lo>l1(T,D)){h("rejectSlope");continue}const q=Math.atan2(d.tx,d.tz),Q=T.face==="road"?Math.atan2(-U,-W):T.face==="along"?q:_()*K;h("placed"),l.push({id:T.id,group:T.group,y:$.lo-.04-R*.03,x:I,z:H,yaw:Q+(_()-.5)*.12,scale:k,hue:_(),dominant:V.dominant,edgeKey:f.key,slot:A})}}return l}function l1(s,t){return Math.min(t*2*Math.tan(Math.acos(s.slope)),.3+s.foot*.16)}function h1(s,t,e,n){for(const o of s){const i=o.width*.5+n;if(t<o.minX-i||t>o.maxX+i||e<o.minZ-i||e>o.maxZ+i)continue;const a=i*i,c=o.pts;for(let r=0;r<c.length-2;r+=2){const l=c[r],h=c[r+1],u=c[r+2]-l,d=c[r+3]-h,f=u*u+d*d;let p=f>0?((t-l)*u+(e-h)*d)/f:0;p<0?p=0:p>1&&(p=1);const g=t-(l+u*p),m=e-(h+d*p);if(g*g+m*m<a)return!1}}return!0}function u1(s,t,e,n,o){let i=t,a=t;for(let c=0;c<4;c++){const r=s(c===0?e+o:c===1?e-o:e,c===2?n+o:c===3?n-o:n);r<i&&(i=r),r>a&&(a=r)}return{lo:i,hi:a}}function d1(s,t,e){return s==="any"?e===null||t>=e-.2:s==="shore"?e!==null?t>=e-.1&&t<=e+2.6:!1:e===null||t>=e+.6}const f1=[.72,.1],p1=[.22,.36,.5,.64,.78],m1=.06,g1=15.5,v1=11;let r0=null,c0=null,l0=null;function w1(s){return l0!==s&&(l0=s,r0=pa(s),c0=jo(s)),{land:r0,water:c0}}function b1(s,t,e,n,o){const i=[],{land:a,water:c}=w1(o),r=Ko(s-60,t-60,e+60,n+60,o,20),l={x:0,z:0,tx:1,tz:0,k:0,t:0};for(const h of r){const u=Bc(h),d=f1[u.tier]??0,f=Ee(Es(u.i*4+u.dir*2+u.tier,u.j,90,o^s1));if(f()>=d)continue;su(h,o,a,c);const p=Oc(h),g=p[p.length-1];let m=null;for(const T of p1){Nc(h,p,T*g,l);const M=l.k,k=Math.max(1,p[Math.min(M+1,p.length-1)]-p[Math.max(M-1,0)]),P=Math.abs(h.y[Math.min(M+1,h.y.length-1)]-h.y[Math.max(M-1,0)])/k;if(!(P>m1)&&(!m||P<m.grade)){const z=h.y[M-1]+(h.y[M]-h.y[M-1])*l.t;m={grade:P,x:l.x,z:l.z,tx:l.tx,tz:l.tz,y:z}}}if(!m)continue;const v=c(m.x,m.z);if(v!==null&&m.y<v+1.6)continue;const x=f()<.5?1:-1,b=m.tz*x,y=-m.tx*x,A=h.width*.5+g1,_=m.x+b*A,S=m.z+y*A;_<s||_>=e||S<t||S>=n||i.push({key:`st:${h.key}`,x:_,z:S,y:m.y,roadX:m.x,roadZ:m.z,yaw:Math.atan2(-b,-y),along:Math.atan2(m.tx,m.tz),side:x,grade:m.grade})}return i}const x1=384,y1=1180,_1=1/45,h0=192,st=B("timber"),yt=B("trunkLit"),tt=B("trunkShade"),ki=B("postWood"),Vt=B("postPaint"),Yt=B("sB"),Ge=B("sC"),na=B("sA"),At=B("sShade"),vo=B("sDeep"),T1=B("mortar"),Ae=B("wallA"),Hs=B("wallB"),Ro=B("roofA"),Un=B("roofB"),xt=B("roofSlate"),Ws=B("thatch"),Qt=B("moss");B("lichen");const ae=B("windowGlow"),hn=B("glass"),ie=B("chrome"),A1=B("tyre"),En=B("cMid"),wo=B("cLit"),zo=B("cShade"),$s=B("gDry"),Co=B("paintA"),Ze=B("paintB"),Ks=B("paintC"),it=B("paintD"),ee=B("paintE"),ft=B("paintF");B("gravelLit");const M1=B("gravelShade"),S1=B("tarmacLit"),k1=B("tarmacShade"),E1=B("lineWhite"),Ct=ut(Un,tt,.35),wt=ut(Co,Ze,.18),Xs=ut(zo,ft,.35);function dt(s,t,e,n,o,i,a,c,r,l=7,h=4){const u=[];for(let d=0;d<=h;d++){const f=d/h*Math.PI,p=Math.cos(f),g=Math.sin(f),m=[];for(let v=0;v<l;v++){const x=v/l*K,b=Math.cos(x)*g,y=Math.sin(x)*g;m.push(Mt(s,t+b*o,e+p*i,n+y*a,b,p,y,c,r))}u.push(m)}for(let d=0;d<h;d++)for(let f=0;f<l;f++){const p=(f+1)%l;Rs(s,u[d][f],u[d][p],u[d+1][p],u[d+1][f])}}function Gc(s,t,e,n,o,i,a,c){C(s,[t-i*.5,e,n],[t+i*.5,e,n],o,o,8,a,w.MATTE,!0,!0),c&&C(s,[t-i*.62,e,n],[t+i*.62,e,n],o*.34,o*.34,6,c,w.METAL,!0,!0)}function Je(s,t,e,n,o,i,a){const c=Math.cos(i),r=Math.sin(i),l=s.n;for(let h=0;h<t.n;h++){const u=t.pos[h*3]*a,d=t.pos[h*3+1]*a,f=t.pos[h*3+2]*a;s.pos.push(e+u*c-f*r,n+d,o+u*r+f*c);const p=t.nrm[h*3],g=t.nrm[h*3+1],m=t.nrm[h*3+2];s.nrm.push(p*c-m*r,g,p*r+m*c),s.col.push(t.col[h*3],t.col[h*3+1],t.col[h*3+2]),s.mat.push(t.mat[h]),s.n++}for(let h=0;h<t.idx.length;h++)s.idx.push(l+t.idx[h])}function ne(s,t){const e=t.w,n=t.d,o=t.h;t.plinth&&E(s,0,t.plinth*.5,0,e*.5+.14,t.plinth*.5,n*.5+.14,0,t.plinthCol||At,w.MATTE);const i=t.plinth||0;if(E(s,0,i+o*.5,0,e*.5,o*.5,n*.5,0,t.wall,w.MATTE),t.frame){for(const a of[-1,1])for(const c of[-1,1])E(s,a*(e*.5-.06),i+o*.5,c*(n*.5-.06),.075,o*.5,.075,0,t.frameCol||st,w.MATTE);E(s,0,i+o-.09,0,e*.5+.01,.09,n*.5+.01,0,t.frameCol||st,w.MATTE)}if(Xo(s,0,i+o,0,e*.5+t.eave,n*.5+t.eave,t.pitch,0,t.roof,w.MATTE),t.door!==!1&&E(s,t.doorX||0,i+.92,n*.5+.03,.42,.92,.05,0,t.doorCol||tt,w.MATTE),t.windows)for(const a of t.windows)E(s,a,i+o*.62,n*.5+.04,.3,.26,.05,0,t.lit?ae:hn,t.lit?w.EMIT:w.GLASS),E(s,a,i+o*.62,n*.5+.03,.35,.31,.03,0,t.frameCol||st,w.MATTE);if(t.chimney&&(E(s,e*.28,i+o+t.pitch*.55,0,.17,t.pitch*.62,.17,0,t.chimCol||At,w.MATTE),E(s,e*.28,i+o+t.pitch*1.18,0,.21,.06,.21,0,T1,w.MATTE)),t.porch){const a=i+o*.82;E(s,0,a,n*.5+.55,e*.42,.06,.58,0,t.roof,w.MATTE);for(const c of[-1,1])C(s,[c*e*.36,i,n*.5+1],[c*e*.36,a,n*.5+1],.06,.05,5,t.frameCol||st,w.MATTE,!1,!1)}}function bo(s,t){const e=t.seg||9;C(s,[0,0,0],[0,t.h,0],t.r,t.r*(t.taper??1),e,t.wall,w.MATTE,!1,!1),t.band&&C(s,[0,t.h*.55,0],[0,t.h*.55+.12,0],t.r*1.03,t.r*1.03,e,t.band,w.MATTE,!1,!1),t.roofH&&C(s,[0,t.h,0],[0,t.h+t.roofH,0],t.r*(t.taper??1)+(t.eave??.2),.04,e,t.roof,w.MATTE,!0,!0),t.door!==!1&&E(s,0,.82,t.r*.98,.36,.82,.06,0,t.doorCol||tt,w.MATTE)}function xo(s,t){const e=t.tiers||3;let n=0,o=t.r;for(let i=0;i<e;i++){const a=t.h/e,c=O(t.r,t.rTop??t.r*.72,(i+1)/e);C(s,[0,n,0],[0,n+a,0],o,c,t.seg||9,i%2&&t.band?t.band:t.wall,w.MATTE,!1,!1),n+=a,o=c}if(t.gallery&&(C(s,[0,n,0],[0,n+.12,0],o*1.45,o*1.45,t.seg||9,t.galleryCol||xt,w.MATTE,!0,!0),C(s,[0,n+.12,0],[0,n+.55,0],o*1.4,o*1.4,t.seg||9,t.galleryCol||xt,w.MATTE,!1,!1),n+=.55),t.lamp&&(C(s,[0,n,0],[0,n+t.lamp,0],o*.92,o*.92,t.seg||9,ae,w.EMIT,!1,!1),n+=t.lamp),t.cap&&C(s,[0,n,0],[0,n+t.cap,0],o*1.2,.04,t.seg||9,t.roof||xt,w.MATTE,!0,!0),t.clock)for(const i of[1,-1])C(s,[0,n-t.cap-.9,i*o*.9],[0,n-t.cap-.9,i*o*1.02],.42,.42,9,it,w.MATTE,!1,!0),E(s,0,n-t.cap-.75,i*o*1.05,.03,.22,.02,0,ft,w.MATTE),E(s,.14,n-t.cap-.9,i*o*1.05,.16,.03,.02,0,ft,w.MATTE)}function yo(s,t){const e=t.w,n=t.d,o=t.h,i=e*.5-.1,a=n*.5-.1;for(const c of[-1,1])for(const r of[-1,1])t.round?C(s,[c*i,0,r*a],[c*i,o,r*a],t.postR||.09,(t.postR||.09)*.9,6,t.post,w.MATTE,!0,!1):E(s,c*i,o*.5,r*a,t.postR||.08,o*.5,t.postR||.08,0,t.post,w.MATTE);if(t.flat?E(s,0,o+.09,0,e*.5+t.eave,.09,n*.5+t.eave,0,t.roof,w.MATTE):Xo(s,0,o,0,e*.5+t.eave,n*.5+t.eave,t.pitch||.6,0,t.roof,w.MATTE),t.back&&E(s,0,o*.5,-n*.5,e*.5,o*.5,.06,0,t.backCol||t.post,w.MATTE),t.bench){E(s,0,.44,-n*.22,e*.42,.045,.16,0,t.benchCol||st,w.MATTE);for(const c of[-1,1])E(s,c*e*.34,.22,-n*.22,.05,.22,.05,0,t.benchCol||st,w.MATTE)}}function u0(s,t){const e=t.h;t.round?C(s,[0,0,0],[0,e,0],t.r||.06,(t.r||.06)*.85,6,t.post,w.MATTE,!0,!0):E(s,0,e*.5,0,t.r||.06,e*.5,t.r||.06,0,t.post,w.MATTE),t.twin&&E(s,t.w,e*.5,0,t.r||.06,e*.5,t.r||.06,0,t.post,w.MATTE);for(const n of t.boards)E(s,n[4]||0,n[0],.02,n[1],n[2],.025,n[5]||0,n[3],w.MATTE);t.finial&&dt(s,0,e+.06,0,.08,.09,.08,t.post,w.MATTE,6,3)}function _o(s,t){const e=t.w,n=t.d,o=t.h;if(E(s,0,.05,0,e*.5+.05,.05,n*.5+.05,0,t.base||At,w.MATTE),E(s,0,o*.5+.1,0,e*.5,o*.5,n*.5,0,t.body,w.MATTE),t.face&&E(s,0,o*.58,n*.5+.02,e*.4,o*.3,.03,0,t.face,t.faceMat??w.MATTE),t.glazed)for(const i of[-1,1])E(s,i*e*.24,o*.62,n*.5+.02,e*.19,o*.26,.03,0,hn,w.GLASS);t.cap&&E(s,0,o+.14,0,e*.5+.06,.06,n*.5+.06,0,t.capCol||t.body,w.MATTE),t.dome&&dt(s,0,o+.1,0,e*.5,.22,n*.5,t.capCol||t.body,w.MATTE,8,3)}function d0(s,t){const e=t.n||5,n=t.len/(e-1);for(let o=0;o<e;o++){const i=-t.len*.5+o*n;E(s,i,t.h*.5,0,.055,t.h*.5,.055,t.lean?o%2?.04:-.03:0,t.post,w.MATTE)}for(const o of t.rails)E(s,0,t.h*o,0,t.len*.5,.035,.03,0,t.rail||t.post,w.MATTE)}function Ei(s,t,e){const n=t.courses||5,o=t.h/n;for(let i=0;i<n;i++){const a=i/n*t.batter;let c=-t.len*.5;for(;c<t.len*.5;){const r=.16+e()*.22,l=Math.min(r,t.len*.5-c);if(l<.04)break;const h=e(),u=h<.34?Yt:h<.68?Ge:na;E(s,c+l*.5,o*(i+.5),0,l*.5,o*.52,t.d*.5-a,(e()-.5)*.08,u,w.MATTE),c+=l*2}}if(t.cap)for(let i=-t.len*.5;i<t.len*.5;i+=.24)E(s,i+.12,t.h+.07,0,.11,.08,t.d*.4,.5+(e()-.5)*.3,At,w.MATTE)}function qs(s,t){const e=t.w,n=t.d;if(E(s,0,t.bedY,0,e*.5,t.bedH*.5,n*.5,0,t.body,w.MATTE),t.sides){for(const o of[-1,1])E(s,0,t.bedY+t.bedH*.5+t.sides*.5,o*(n*.5-.04),e*.5,t.sides*.5,.045,0,t.body,w.MATTE);for(const o of[-1,1])E(s,o*(e*.5-.04),t.bedY+t.bedH*.5+t.sides*.5,0,.045,t.sides*.5,n*.5,0,t.body,w.MATTE)}t.cab&&(E(s,0,t.bedY+t.bedH*.5+t.cab*.5,n*.5-t.cabD*.5,e*.44,t.cab*.5,t.cabD*.5,0,t.cabCol||t.body,w.MATTE),E(s,0,t.bedY+t.bedH*.5+t.cab*.72,n*.5-t.cabD+.02,e*.36,t.cab*.2,.04,0,hn,w.GLASS));for(const o of t.wheels)Gc(s,o[0]*(e*.5+.04),o[2],o[1],o[3],.13,t.tyre||A1,t.hub);if(t.shafts)for(const o of[-1,1])C(s,[o*e*.32,t.bedY,n*.5],[o*e*.28,t.bedY*.55,n*.5+t.shafts],.045,.035,5,st,w.MATTE,!0,!0)}function is(s,t,e){let n=0;for(let o=0;o<t.rows;o++){const i=Math.max(1,t.per-o);for(let a=0;a<i;a++){const c=(a-(i-1)*.5)*t.step,r=t.h*(o+.5),l=(e()-.5)*t.jitter,h=(e()-.5)*.06,u=t.cols[(n+o)%t.cols.length];t.round==="x"?C(s,[c-t.w*.5,r+h,l],[c+t.w*.5,r+h,l],t.h*.48,t.h*.48,8,u,w.MATTE,!0,!0):t.round==="y"?C(s,[c,r-t.h*.5+h,l],[c,r+t.h*.5+h,l],t.w*.5,t.w*.5*(t.taper??1),8,u,w.MATTE,!0,!0):E(s,c,r+h,l,t.w*.5,t.h*.48,t.d*.5,(e()-.5)*t.yaw,u,w.MATTE),n++}}}function Rn(s,t){if(C(s,[0,0,0],[0,t.h,0],t.r||.11,(t.r||.11)*.72,7,t.post,w.MATTE,!0,!0),t.arms)for(const e of t.arms){E(s,0,t.h*e,0,t.armW,.035,.035,0,t.arm||t.post,w.MATTE);for(const n of[-1,1])C(s,[n*t.armW*.8,t.h*e+.04,0],[n*t.armW*.8,t.h*e+.14,0],.035,.03,5,hn,w.GLASS,!0,!0)}if(t.flag)for(let e=0;e<3;e++){const n=e/3;E(s,.16+e*.3,t.h-.36,Math.sin(e*1.4)*.07,.16,.22-n*.03,.02,Math.sin(e*1.4)*.35,t.flag,w.MATTE)}if(t.sock){for(let e=0;e<4;e++){const n=.22-e*.035;C(s,[e*.26,t.h-.1-e*.04,0],[(e+1)*.26,t.h-.12-(e+1)*.05,0],n,n-.035,7,e%2?wt:it,w.MATTE,!1,!1)}C(s,[0,t.h-.1,0],[0,t.h+.16,0],.24,.24,9,ie,w.METAL,!1,!1)}if(t.box&&(E(s,0,t.h+.16,0,.17,.16,.15,0,t.boxCol||yt,w.MATTE),Xo(s,0,t.h+.32,0,.22,.2,.14,0,t.roof||Ro,w.MATTE),C(s,[0,t.h+.2,.14],[0,t.h+.2,.17],.05,.05,6,ft,w.MATTE,!1,!0)),t.vane){C(s,[0,t.h,0],[0,t.h+.44,0],.02,.02,5,ft,w.MATTE,!0,!0),E(s,.24,t.h+.34,0,.22,.12,.012,0,ft,w.MATTE),C(s,[-.2,t.h+.34,0],[.02,t.h+.34,0],.02,.02,4,ft,w.MATTE,!0,!0);for(const[e,n]of[[.3,0],[-.3,0],[0,.3],[0,-.3]])C(s,[0,t.h+.1,0],[e,t.h+.1,n],.015,.015,4,ft,w.MATTE,!1,!0)}}function To(s,t,e){for(let n=0;n<t.n;n++){const o=n/t.n*K+e()*.9,i=Math.pow(e(),.6)*t.spread,a=Math.cos(o)*i,c=Math.sin(o)*i,r=t.min+e()*(t.max-t.min);t.stalk&&C(s,[a,0,c],[a+(e()-.5)*.1*r,t.stalkH*r,c+(e()-.5)*.1*r],t.stalkR*r,t.stalkR*.82*r,6,t.stalkCol,w.MATTE,!0,!1);const l=t.stalk?t.stalkH*r:t.capR*r*.85;if(t.cone)C(s,[a,l,c],[a,l+t.capR*r*1.25,c],t.capR*r,.03,8,t.capCol,w.MATTE,!0,!0);else{const h=t.capCols?t.capCols[(n+(e()*3|0))%t.capCols.length]:t.capCol;dt(s,a,l,c,t.capR*r,t.capR*r*(t.squash??.7),t.capR*r,h,w.MATTE,7,3)}t.gills&&C(s,[a,l-.02*r,c],[a,l+.02*r,c],t.capR*r*.86,t.capR*r*.86,8,it,w.MATTE,!1,!1)}}function f0(s,t){const e=t.len*.5,n=[];for(let o=0;o<=5;o++){const i=o/5,a=t.beam*Math.sin(Math.PI*(.14+i*.72));n.push({z:-e+i*t.len,b:a,h:t.depth*(.72+.28*Math.sin(Math.PI*i))})}for(let o=0;o<5;o++){const i=n[o],a=n[o+1];for(const c of[-1,1])Me(s,[c*i.b,i.h,i.z],[c*a.b,a.h,a.z],[c*a.b*.35,0,a.z],[c*i.b*.35,0,i.z],t.hull,w.MATTE,[c,.2,0]);Me(s,[-i.b*.35,0,i.z],[-a.b*.35,0,a.z],[a.b*.35,0,a.z],[i.b*.35,0,i.z],t.hull,w.MATTE,[0,-1,0]),t.upturned||Me(s,[-i.b,i.h,i.z],[i.b,i.h,i.z],[a.b,a.h,a.z],[-a.b,a.h,a.z],t.inner||Ue(t.hull,.7),w.MATTE,[0,1,0])}if(t.thwarts)for(const o of[.34,.66]){const i=n[Math.round(o*5)];E(s,0,i.h-.06,i.z,i.b*.92,.03,.08,0,t.inner||yt,w.MATTE)}}function R1(s,t){const n=t.span*.5;for(const i of[-1,1])E(s,i*(n+t.pier*.5),t.spring*.5,0,t.pier*.5,t.spring*.5,t.d*.5,0,t.stone,w.MATTE);const o=t.seg||9;for(let i=0;i<o;i++){const a=Math.PI*(i/o),c=Math.PI*((i+1)/o),r=(a+c)*.5,l=-Math.cos(r)*n,h=t.spring+Math.sin(r)*n,u=Math.PI*n/o*.55;E(s,l,h,0,t.thick*.5,u,t.d*.5,0,i%2?t.stone:t.stone2||t.stone,w.MATTE),Me(s,[l-Math.sin(r)*t.thick*.5,h+Math.cos(r)*t.thick*.5,t.d*.5],[l+Math.sin(r)*t.thick*.5,h-Math.cos(r)*t.thick*.5,t.d*.5],[l+Math.sin(r)*t.thick*.5,h-Math.cos(r)*t.thick*.5,-t.d*.5],[l-Math.sin(r)*t.thick*.5,h+Math.cos(r)*t.thick*.5,-t.d*.5],i%2&&t.stone2||t.stone,w.MATTE,[Math.cos(r),Math.sin(r),0])}}function Ri(s,t){const e=t.w,n=t.h;for(const o of[-1,1])C(s,[o*e,0,0],[o*e*.94,n,0],t.r,t.r*.86,8,t.col,w.MATTE,!0,!0);for(let o=-2;o<=2;o++){const i=o/2;E(s,i*e*.62,n+.1+(1-i*i)*t.curve,0,e*.31,t.r*.52,t.r*1.15,0,t.col,w.MATTE)}if(E(s,0,n+.1+t.curve+t.r*.5,0,e*1.25,t.r*.3,t.r*.8,0,t.col2||t.col,w.MATTE),E(s,0,n*.72,0,e*1.06,t.r*.55,t.r*.7,0,t.col,w.MATTE),E(s,0,n*.86,0,t.r*.8,n*.14,t.r*.7,0,t.col2||t.col,w.MATTE),t.moss)for(const o of[-1,1])C(s,[o*e,0,0],[o*e*.98,n*.28,0],t.r*1.04,t.r*.98,8,Qt,w.MATTE,!1,!1)}function zi(s,t){const e=t.s;C(s,[0,0,0],[0,.16*e,0],.3*e,.26*e,8,t.col,w.MATTE,!1,!0),C(s,[0,.16*e,0],[0,.86*e,0],.11*e,.1*e,7,t.col,w.MATTE,!1,!1),C(s,[0,.86*e,0],[0,1.02*e,0],.26*e,.24*e,8,t.col,w.MATTE,!1,!0),E(s,0,1.24*e,0,.2*e,.22*e,.2*e,.4,t.col,w.MATTE);for(const[n,o]of[[.205,0],[-.205,0],[0,.205],[0,-.205]])E(s,n*e*1,1.24*e,o*e*1,.1*e,.11*e,.1*e,.4,ae,w.EMIT);C(s,[0,1.46*e,0],[0,1.74*e,0],.4*e,.06*e,6,t.col2||t.col,w.MATTE,!0,!0),dt(s,0,1.8*e,0,.08*e,.11*e,.08*e,t.col2||t.col,w.MATTE,6,3)}function zn(s,t){const e=t.s;if(E(s,0,.08*e,0,.26*e,.08*e,.24*e,0,t.plinth||At,w.MATTE),C(s,[0,.16*e,0],[0,.62*e,0],.17*e,.15*e,8,t.col,w.MATTE,!1,!1),dt(s,0,.74*e,0,.17*e,.19*e,.17*e,t.col,w.MATTE,8,4),t.ears)for(const n of[-1,1])C(s,[n*.1*e,.84*e,0],[n*.13*e,1*e,-.02*e],.055*e,.01,5,t.col,w.MATTE,!0,!0);t.bib&&C(s,[0,.52*e,0],[0,.6*e,0],.2*e,.17*e,8,t.bib,w.MATTE,!1,!0),t.hat&&C(s,[0,.86*e,0],[0,.98*e,0],.26*e,.05*e,8,t.hat,w.MATTE,!0,!0),t.moss&&dt(s,0,.2*e,.02,.2*e,.12*e,.2*e,Qt,w.MATTE,7,3)}function vs(s,t,e){for(let n=0;n<t.n;n++){const o=n/t.n*K+e()*1.4,i=t.stack?0:Math.pow(e(),.5)*t.spread,a=Math.cos(o)*i,c=Math.sin(o)*i,r=t.min+e()*(t.max-t.min),l=t.stack?t.step*(n+.5):r*(t.upright?.5:.34),h=e()<.4?Yt:e()<.7?Ge:At;t.upright?(E(s,a,l,c,r*.32,r*.5,r*.24,e()*K,h,w.MATTE),E(s,a,l*1.75,c,r*.24,r*.28,r*.18,e()*K,h,w.MATTE)):dt(s,a,l,c,r*.5,r*(t.flat?.24:.36),r*.44,h,w.MATTE,7,3),t.moss&&e()<.5&&dt(s,a,l+r*.2,c,r*.34,r*.1,r*.3,Qt,w.MATTE,6,3)}}function z1(s,t){for(let e=0;e<t.n;e++)E(s,0,t.rise*(e+.5),-.34*(e+.5),t.w*.5,t.rise*.55,t.tread*.5,0,e%2?Yt:Ge,w.MATTE)}const Uc={torii_red:(s,t)=>Ri(s,{w:1.5,h:3.6,r:.17,curve:.16,col:wt,col2:ft}),torii_stone:(s,t)=>Ri(s,{w:1.4,h:3.1,r:.19,curve:.1,col:Yt,col2:At}),torii_moss:(s,t)=>Ri(s,{w:1.1,h:2.4,r:.15,curve:.09,col:At,col2:vo,moss:!0}),jizo_trio:(s,t)=>{for(let e=-1;e<=1;e++){const n=Xt();zn(n,{s:.85+t()*.25,col:Ge,bib:wt,hat:t()<.5?wt:null,moss:t()<.4}),Je(s,n,e*.52,0,(t()-.5)*.12,t()*.5,1)}},jizo_single:(s,t)=>zn(s,{s:1,col:Ge,bib:wt,hat:t()<.6?wt:null,moss:t()<.5}),stone_lantern:s=>zi(s,{s:1.2,col:Yt,col2:At}),lantern_pair:(s,t)=>{for(const e of[-1,1]){const n=Xt();zi(n,{s:1.1+t()*.2,col:Yt,col2:At}),Je(s,n,e*1.5,0,0,0,1)}},paper_lanterns:(s,t)=>{for(const e of[-1,1])C(s,[e*2.6,0,0],[e*2.6,2.5,0],.08,.07,6,tt,w.MATTE,!0,!0);for(let e=0;e<7;e++){const n=e/6,o=O(-2.6,2.6,n),i=Math.sin(n*Math.PI)*.34;C(s,[o,2.42-i,0],[o,2.06-i,0],.15+t()*.03,.13,8,e%2?it:wt,w.EMIT,!0,!0)}},wayside_shrine:(s,t)=>{ne(s,{w:1.1,d:.9,h:1.1,wall:yt,roof:xt,pitch:.45,eave:.24,plinth:.5,door:!1,frame:!0,frameCol:tt}),E(s,0,1.1,.46,.34,.34,.03,0,ae,w.EMIT),t()<.6&&E(s,0,.28,.5,.2,.06,.14,0,wt,w.MATTE)},ema_rack:(s,t)=>{for(const e of[-1,1])C(s,[e*.9,0,0],[e*.9,1.5,0],.06,.055,6,st,w.MATTE,!0,!0);E(s,0,1.44,0,1,.05,.05,0,st,w.MATTE);for(let e=0;e<9;e++){const n=-.8+e*.2;E(s,n,1.24-t()*.04,.02,.075,.09,.012,(t()-.5)*.25,e%3===0?it:yt,w.MATTE)}},shimenawa_post:(s,t)=>{vs(s,{n:1,spread:0,min:1.5,max:1.7,upright:!0,moss:t()<.5},t),C(s,[-.42,.92,0],[.42,.92,0],.075,.075,6,it,w.MATTE,!0,!0);for(let e=0;e<4;e++)E(s,-.3+e*.2,.76,0,.035,.1,.01,.2,it,w.MATTE)},fox_statue:(s,t)=>zn(s,{s:.85,col:Ge,ears:!0,bib:wt,moss:t()<.3}),cat_statue:(s,t)=>zn(s,{s:.8,col:it,ears:!0,bib:wt,moss:t()<.2}),moss_buddha:(s,t)=>zn(s,{s:1.35,col:At,moss:!0,hat:t()<.4?Qt:null}),prayer_cairn:(s,t)=>vs(s,{n:5+(t()*3|0),stack:!0,step:.22,min:.5,max:.8,flat:!0,moss:!0},t),standing_stones:(s,t)=>vs(s,{n:6,spread:5,min:2.2,max:3.4,upright:!0,moss:!0},t),stone_arch:(s,t)=>{R1(s,{span:3.4,pier:.7,spring:1.9,d:.8,thick:.42,stone:Yt,stone2:na,seg:9}),t()<.6&&dt(s,-1.9,1.2,.3,.4,.16,.34,Qt,w.MATTE,7,3)},barn:(s,t)=>{ne(s,{w:9,d:6.5,h:4.2,wall:ut(Co,tt,.25),roof:xt,pitch:2,eave:.4,frame:!0,frameCol:it,doorX:0,windows:[-3,3],lit:t()<.35}),E(s,0,2.4,3.3,1.5,2.4,.08,0,tt,w.MATTE),E(s,0,5.6,3.3,.4,.5,.12,0,st,w.MATTE)},shed:(s,t)=>ne(s,{w:2.6,d:2.2,h:1.9,wall:st,roof:xt,pitch:.6,eave:.22,frame:!0,windows:t()<.6?[.85]:null}),potting_shed:(s,t)=>{ne(s,{w:2.6,d:2.4,h:1.8,wall:yt,roof:hn,pitch:.75,eave:.16,frame:!0,frameCol:Vt,windows:[-.8,.8],lit:!1}),is(s,{rows:1,per:4,step:.28,w:.2,h:.24,d:.2,jitter:.1,yaw:.5,cols:[Un,Ro]},t)},grain_silo:s=>bo(s,{r:1.9,h:7.2,wall:ie,band:At,roofH:1.5,roof:xt,eave:.14,seg:12,door:!1}),charcoal_kiln:(s,t)=>{bo(s,{r:1.5,h:1.5,wall:At,roofH:1.3,roof:vo,eave:.05,seg:10,taper:.75}),t()<.7&&C(s,[0,2.8,0],[0,3.3,0],.16,.14,6,vo,w.MATTE,!1,!0)},hay_bales:(s,t)=>is(s,{rows:2,per:3,step:1.15,w:1.05,h:1,d:.55,jitter:.14,yaw:.12,round:"x",cols:[$s,Ws,ut($s,Ws,.5)]},t),hay_cart:(s,t)=>{qs(s,{w:1.8,d:3.2,bedY:.85,bedH:.16,sides:.55,body:st,wheels:[[-1,1,.55,.55],[1,1,.55,.55],[-1,-1,.45,.45],[1,-1,.45,.45]],shafts:1.2,hub:tt}),is(s,{rows:1,per:3,step:.6,w:.55,h:.5,d:.55,jitter:.12,yaw:.4,cols:[$s,Ws]},t)},hand_cart:s=>qs(s,{w:1,d:1.5,bedY:.5,bedH:.12,sides:.3,body:yt,wheels:[[-1,-.3,.36,.36],[1,-.3,.36,.36]],shafts:.9}),scarecrow:(s,t)=>{C(s,[0,0,0],[0,1.7,0],.06,.05,5,tt,w.MATTE,!0,!0),E(s,0,1.28,0,.62,.04,.04,0,tt,w.MATTE),E(s,0,1.1,0,.24,.3,.14,0,t()<.5?Ks:Un,w.MATTE),dt(s,0,1.55,0,.16,.17,.16,$s,w.MATTE,7,3),C(s,[0,1.62,0],[0,1.72,0],.34,.1,8,Ws,w.MATTE,!0,!0)},beehives:(s,t)=>{for(let e=0;e<3;e++){const n=(e-1)*1.1;E(s,n,.12,0,.34,.12,.3,0,tt,w.MATTE);for(let o=0;o<3;o++)E(s,n,.28+o*.26,0,.3,.13,.27,0,o%2?it:Vt,w.MATTE);C(s,[n,1.06,0],[n,1.2,0],.4,.08,4,t()<.5?Ro:xt,w.MATTE,!0,!0)}},milk_churns:(s,t)=>{E(s,0,.35,0,.9,.06,.4,0,st,w.MATTE);for(const e of[-1,1])for(const n of[-1,1])E(s,e*.8,.17,n*.32,.06,.17,.06,0,st,w.MATTE);for(let e=0;e<3;e++){const n=(e-1)*.5+(t()-.5)*.08;C(s,[n,.41,0],[n,.85,0],.16,.13,8,ie,w.METAL,!0,!1),C(s,[n,.85,0],[n,.94,0],.09,.1,8,ie,w.METAL,!1,!0)}},water_trough:(s,t)=>{E(s,0,.28,0,1.1,.28,.42,0,Yt,w.MATTE),E(s,0,.5,0,.98,.08,.32,0,B("wMid"),w.GLASS),t()<.5&&dt(s,-1,.16,.3,.24,.1,.2,Qt,w.MATTE,6,3)},drystone_wall:(s,t)=>Ei(s,{len:9,h:1,d:.5,batter:.06,courses:5,cap:!0},t),pasture_fence:s=>d0(s,{len:10,h:1.15,n:7,rails:[.4,.72,.98],post:ki,lean:!0}),wooden_gate:s=>{for(const t of[-1,1])C(s,[t*1.6,0,0],[t*1.6,1.4,0],.11,.1,6,ki,w.MATTE,!0,!0);for(const t of[.28,.52,.76,1,1.22])E(s,0,t,0,1.55,.045,.035,0,Vt,w.MATTE);E(s,0,.75,0,1.5,.04,.03,.72,Vt,w.MATTE)},washing_line:(s,t)=>{for(const e of[-1,1])C(s,[e*3,0,0],[e*3,2,0],.06,.05,5,st,w.MATTE,!0,!0),E(s,e*3,1.85,0,.22,.03,.03,0,st,w.MATTE);for(let e=0;e<6;e++){const n=(e+.5)/6,o=O(-2.7,2.7,n),i=Math.sin(n*Math.PI)*.2,a=.16+t()*.1;E(s,o,1.85-i-.22,0,a,.22,.012,(t()-.5)*.16,[it,Ks,Un,ee][e%4],w.MATTE)}},sunflower_patch:(s,t)=>To(s,{n:12,spread:1.8,min:.85,max:1.25,stalk:!0,stalkH:1.6,stalkR:.035,stalkCol:zo,capR:.24,squash:.35,capCols:[Ze,ut(Ze,Co,.25)]},t),flower_bed:(s,t)=>{Ei(s,{len:2.2,h:.3,d:.34,batter:0,courses:2,cap:!1},t),To(s,{n:14,spread:1,min:.5,max:.9,stalk:!0,stalkH:.42,stalkR:.022,stalkCol:zo,capR:.1,squash:.9,capCols:[it,wt,Ze,Ks,Ae]},t)},topiary:(s,t)=>{C(s,[0,0,0],[0,.5,0],.11,.1,6,tt,w.MATTE,!0,!1),dt(s,0,.95,0,.55,.5,.55,En,w.MATTE,9,4),dt(s,0,1.6+t()*.12,0,.36,.34,.36,wo,w.MATTE,8,4)},hedge_arch:(s,t)=>{for(const e of[-1,1])dt(s,e*1.35,.95,0,.5,.95,.45,En,w.MATTE,8,4);for(let e=0;e<5;e++){const n=Math.PI*(.1+.8*(e/4));dt(s,-Math.cos(n)*1.35,1.85+Math.sin(n)*.5,0,.34+t()*.05,.3,.42,e%2?En:wo,w.MATTE,7,3)}},tractor:(s,t)=>{qs(s,{w:1.3,d:2.6,bedY:.8,bedH:.4,body:t()<.5?Co:ee,cab:.55,cabD:.9,cabCol:ft,wheels:[[-1,-.7,.72,.72],[1,-.7,.72,.72],[-1,.9,.4,.4],[1,.9,.4,.4]],hub:it}),C(s,[.42,1.2,.7],[.42,1.85,.7],.075,.07,6,ft,w.MATTE,!0,!0),E(s,0,1.35,-.5,.34,.04,.3,.5,ft,w.MATTE)},plough:(s,t)=>{E(s,0,.55,0,.09,.07,1.1,0,Ct,w.MATTE);for(let e=0;e<3;e++){const n=-.7+e*.7;E(s,.1,.3,n,.05,.28,.07,0,Ct,w.MATTE),dt(s,.24,.12,n,.24,.1,.14,ie,w.METAL,6,3)}Gc(s,-.5,.42,.9,.42,.08,Ct,null),t()<.5&&dt(s,-.4,.1,-.7,.3,.1,.24,Qt,w.MATTE,6,3)},bus_shelter:(s,t)=>{yo(s,{w:2.8,d:1.5,h:2.2,eave:.16,flat:!0,post:Vt,roof:xt,back:!0,backCol:t()<.5?Ae:yt,bench:!0,benchCol:st}),E(s,0,1.45,-.72,.6,.4,.03,0,hn,w.GLASS)},bus_stop_sign:s=>u0(s,{h:2.4,r:.05,round:!0,post:Vt,boards:[[2.15,.28,.2,it],[1.75,.2,.12,Ks]]}),bench:(s,t)=>{for(const e of[-1,1])E(s,e*.72,.22,0,.06,.22,.22,0,t()<.5?At:tt,w.MATTE),E(s,e*.72,.62,-.2,.05,.24,.05,0,tt,w.MATTE);for(let e=0;e<3;e++)E(s,0,.46,-.16+e*.16,.85,.03,.06,0,yt,w.MATTE);for(let e=0;e<2;e++)E(s,0,.68+e*.16,-.24,.85,.06,.03,0,yt,w.MATTE)},picnic_table:s=>{E(s,0,.74,0,.85,.04,.4,0,yt,w.MATTE);for(const t of[-1,1])E(s,0,.42,t*.66,.85,.035,.16,0,yt,w.MATTE);for(const t of[-1,1])E(s,t*.6,.37,.3,.05,.37,.05,.35,st,w.MATTE),E(s,t*.6,.37,-.3,.05,.37,.05,-.35,st,w.MATTE)},picnic_shelter:s=>yo(s,{w:3.4,d:3,h:2.2,eave:.4,pitch:.9,post:st,roof:Ws,round:!0,postR:.11,bench:!0}),phone_box:s=>_o(s,{w:.92,d:.9,h:2.3,body:wt,glazed:!0,cap:!0,capCol:ut(wt,ft,.3)}),vending_machine:(s,t)=>_o(s,{w:1.05,d:.62,h:1.75,body:t()<.5?Ks:wt,face:ae,faceMat:w.EMIT,cap:!0}),post_box:s=>_o(s,{w:.44,d:.44,h:1.1,body:wt,dome:!0,face:ft}),letterbox_post:s=>{C(s,[0,0,0],[0,1.1,0],.055,.05,6,st,w.MATTE,!0,!0),E(s,0,1.25,0,.2,.13,.14,0,it,w.MATTE),C(s,[-.2,1.32,0],[.2,1.32,0],.13,.13,8,it,w.MATTE,!1,!1),E(s,.21,1.5,0,.02,.1,.03,0,wt,w.MATTE)},notice_board:(s,t)=>{for(const e of[-1,1])E(s,e*.55,.75,0,.05,.75,.05,0,st,w.MATTE);E(s,0,1.35,0,.62,.42,.05,0,yt,w.MATTE),E(s,0,1.35,.055,.55,.36,.01,0,it,w.MATTE);for(let e=0;e<4;e++)E(s,-.32+e%2*.36,1.5-(e/2|0)*.28,.07,.13,.1,.005,(t()-.5)*.16,Hs,w.MATTE);Xo(s,0,1.78,0,.68,.12,.14,0,xt,w.MATTE)},fingerpost:(s,t)=>{const e=2+(t()*3|0);u0(s,{h:2.6,r:.07,round:!0,post:Vt,boards:[],finial:!0});for(let n=0;n<e;n++){const o=2.2-n*.3,i=t()*K,a=Xt();E(a,.44,o,0,.44,.075,.02,0,Vt,w.MATTE),E(a,.88,o,0,.075,.055,.02,.78,Vt,w.MATTE),Je(s,a,0,0,0,i,1)}},village_sign:(s,t)=>{for(const e of[-1,1])C(s,[e*.75,0,0],[e*.75,2,0],.075,.065,6,st,w.MATTE,!0,!0);E(s,0,1.95,0,.85,.05,.05,0,st,w.MATTE),E(s,0,1.55,0,.66,.33,.03,0,t()<.5?it:Ae,w.MATTE),E(s,0,1.55,.035,.6,.27,.01,0,ut(ee,ft,.3),w.MATTE)},milestone_big:(s,t)=>{E(s,0,.34,0,.24,.34,.16,0,Ge,w.MATTE),C(s,[0,.68,0],[0,.78,0],.24,.16,7,Ge,w.MATTE,!1,!0),E(s,0,.42,.17,.16,.16,.015,0,ft,w.MATTE),t()<.5&&dt(s,0,.1,-.1,.2,.08,.12,Qt,w.MATTE,6,3)},water_pump:s=>{E(s,0,.22,0,.34,.22,.3,0,Yt,w.MATTE),C(s,[0,.44,0],[0,1.35,0],.11,.09,7,Xs,w.METAL,!1,!0),C(s,[0,1.1,0],[0,1.1,.34],.05,.04,6,Xs,w.METAL,!1,!0),E(s,-.28,1.28,0,.28,.035,.03,.25,Xs,w.METAL)},electrical_cabinet:s=>_o(s,{w:.7,d:.42,h:1.15,body:Xs,cap:!0,face:Ue(Xs,1.2)}),bicycle:(s,t)=>{for(const e of[-1,1])C(s,[0,.34,e*.52],[.04,.34,e*.52],.34,.34,12,ft,w.MATTE,!1,!1);C(s,[.02,.34,-.5],[.02,.62,.15],.025,.025,5,t()<.5?ee:wt,w.MATTE,!0,!0),C(s,[.02,.62,.15],[.02,.34,.5],.025,.025,5,t()<.5?ee:wt,w.MATTE,!0,!0),C(s,[.02,.34,.5],[.02,.95,.42],.022,.022,5,ft,w.MATTE,!0,!0),E(s,.02,.98,.42,.16,.02,.02,0,ft,w.MATTE),E(s,.02,.68,.05,.05,.03,.12,0,tt,w.MATTE)},telegraph_pole:s=>Rn(s,{h:7.2,r:.13,post:ki,arms:[.86,.94],armW:.65,arm:tt}),flag_pole:(s,t)=>Rn(s,{h:6.5,r:.09,post:Vt,flag:[it,wt,Ks,ee][t()*4|0]}),windsock:s=>Rn(s,{h:5,r:.1,post:Vt,sock:!0}),bird_house_pole:(s,t)=>Rn(s,{h:1.9,r:.05,post:st,box:!0,boxCol:t()<.5?yt:Ae,roof:t()<.5?Ro:xt}),weather_vane:s=>Rn(s,{h:2.6,r:.06,post:st,vane:!0}),wind_chime_arch:(s,t)=>{for(const e of[-1,1])C(s,[e*1.1,0,0],[e*1,2.3,0],.07,.06,6,st,w.MATTE,!0,!0);E(s,0,2.3,0,1.15,.05,.05,0,st,w.MATTE);for(let e=0;e<6;e++){const n=-.85+e*.34,o=.3+t()*.35;C(s,[n,2.25-o,0],[n,2.25,0],.022,.022,5,ie,w.METAL,!0,!0),E(s,n,2.25-o-.06,0,.05,.06,.008,0,it,w.MATTE)}},sundial:s=>{C(s,[0,0,0],[0,.85,0],.18,.13,8,Yt,w.MATTE,!1,!1),C(s,[0,.85,0],[0,.95,0],.34,.34,10,Ge,w.MATTE,!1,!0),E(s,0,1.08,-.06,.02,.14,.16,0,ie,w.METAL)},stone_steps:s=>z1(s,{n:5,rise:.19,tread:.34,w:1.5}),crate_stack:(s,t)=>is(s,{rows:3,per:3,step:.52,w:.48,h:.44,d:.44,jitter:.14,yaw:.35,cols:[yt,st,ut(st,$s,.4)]},t),barrel_stack:(s,t)=>is(s,{rows:2,per:3,step:.62,w:.56,h:.78,d:.56,jitter:.1,yaw:0,round:"y",taper:.88,cols:[tt,st,Ct]},t),market_stall:(s,t)=>{yo(s,{w:2.4,d:1.6,h:2,eave:.3,pitch:.35,post:st,roof:t()<.5?wt:ee,round:!0,postR:.06}),E(s,0,.85,0,1.1,.05,.7,0,yt,w.MATTE),E(s,0,.45,-.6,1.1,.45,.05,0,st,w.MATTE),is(s,{rows:1,per:3,step:.6,w:.22,h:.2,d:.2,jitter:.1,yaw:.4,cols:[Un,En,Ze]},t)},cottage:(s,t)=>ne(s,{w:5.4,d:4.2,h:2.6,wall:t()<.5?Ae:Hs,roof:Ws,pitch:1.9,eave:.42,plinth:.2,plinthCol:At,frame:!0,chimney:!0,windows:[-1.5,1.5],lit:!0,porch:t()<.5}),log_cabin:(s,t)=>{ne(s,{w:4.4,d:3.6,h:2.3,wall:st,roof:xt,pitch:1.5,eave:.5,frame:!1,chimney:!0,chimCol:Yt,windows:[-1.2,1.2],lit:t()<.7});for(let e=0;e<6;e++)C(s,[-2.3,.2+e*.38,1.8],[2.3,.2+e*.38,1.8],.19,.19,6,e%2?st:yt,w.MATTE,!0,!0)},tea_house:(s,t)=>{if(ne(s,{w:3.4,d:3,h:2.1,wall:Ae,roof:xt,pitch:1.15,eave:.75,plinth:.45,plinthCol:tt,frame:!0,frameCol:tt,windows:[-.9,.9],lit:!0,door:!1}),E(s,0,1.05,1.55,.5,.9,.04,0,ae,w.EMIT),t()<.6){const e=Xt();zi(e,{s:.7,col:Yt,col2:At}),Je(s,e,2.1,0,1.6,0,1)}},chapel:s=>{ne(s,{w:3.4,d:5,h:2.8,wall:Hs,roof:xt,pitch:1.7,eave:.3,plinth:.25,plinthCol:At,frame:!1,windows:[-1,1],lit:!0}),E(s,0,3.4,-2.2,.55,1.4,.55,0,Hs,w.MATTE),C(s,[0,4.8,-2.2],[0,6.2,-2.2],.75,.05,6,xt,w.MATTE,!0,!0),E(s,0,1.7,2.55,.28,.5,.03,0,ae,w.EMIT)},dovecote:(s,t)=>{bo(s,{r:1.2,h:3.2,wall:Ae,roofH:1.2,roof:xt,eave:.3,seg:10,taper:.9});for(let e=0;e<8;e++){const n=e/8*K;E(s,Math.cos(n)*1.08,2.3+e%2*.35,Math.sin(n)*1.08,.1,.1,.1,-n,ft,w.MATTE)}t()<.5&&dt(s,0,4.5,0,.14,.16,.2,it,w.MATTE,6,3)},gazebo:s=>{yo(s,{w:3,d:3,h:2.3,eave:.45,pitch:1,post:Vt,roof:xt,round:!0,postR:.1,bench:!0,benchCol:Vt}),E(s,0,.1,0,1.7,.1,1.7,0,yt,w.MATTE)},bandstand:s=>{C(s,[0,0,0],[0,.55,0],2.3,2.3,10,Ge,w.MATTE,!1,!0);for(let t=0;t<8;t++){const e=t/8*K;C(s,[Math.cos(e)*2,.55,Math.sin(e)*2],[Math.cos(e)*2,3,Math.sin(e)*2],.09,.08,6,Vt,w.MATTE,!0,!0)}C(s,[0,3,0],[0,4.1,0],2.5,.2,10,xt,w.MATTE,!0,!0),C(s,[0,4.1,0],[0,4.5,0],.12,.04,5,ie,w.METAL,!0,!0)},yurt:s=>{bo(s,{r:2.2,h:1.5,wall:it,roofH:1.1,roof:Hs,eave:.12,seg:12,band:ut(wt,Ze,.4)}),C(s,[0,2.6,0],[0,2.85,0],.3,.3,8,tt,w.MATTE,!1,!1)},signal_box:s=>{ne(s,{w:2.6,d:2,h:1.4,wall:tt,roof:xt,pitch:.5,eave:.35,plinth:1.4,plinthCol:ut(tt,ft,.4),door:!1,frame:!0,frameCol:it});for(const t of[1,-1])E(s,0,2.2,t*1.02,1.15,.5,.04,0,ae,w.EMIT);E(s,1.4,1.1,0,.06,1.1,.5,0,tt,w.MATTE)},clock_tower:s=>xo(s,{r:1.3,rTop:1.05,h:10.5,tiers:3,seg:8,wall:na,band:Yt,cap:1.9,roof:xt,gallery:!0,galleryCol:At,clock:!0}),water_tower:s=>{for(const[t,e]of[[1,1],[-1,1],[1,-1],[-1,-1]])C(s,[t*1.5,0,e*1.5],[t*.85,8.5,e*.85],.14,.11,5,Ct,w.MATTE,!0,!0);for(const t of[2.5,5.5])for(const[e,n]of[[1,0],[0,1]])E(s,e?0:1.2,t,n?0:1.2,e?1.3:.05,.05,n?1.3:.05,0,Ct,w.MATTE);C(s,[0,8.5,0],[0,12.4,0],2.1,2.1,12,ut(ie,ee,.3),w.METAL,!0,!1),C(s,[0,12.4,0],[0,13.4,0],2.2,.1,12,xt,w.MATTE,!0,!0)},windmill:(s,t)=>{xo(s,{r:2.3,rTop:1.5,h:8.5,tiers:3,seg:10,wall:Ae,band:Hs}),C(s,[0,8.5,0],[0,10.3,0],1.7,.6,10,xt,w.MATTE,!0,!0);const e=[0,9.1,1.6];C(s,[0,9.1,1.2],e,.2,.16,6,tt,w.MATTE,!0,!0);const n=t()*K;for(let o=0;o<4;o++){const i=n+o/4*K,a=Math.cos(i),c=Math.sin(i);C(s,e,[a*4.4,9.1+c*4.4,1.7],.09,.06,5,tt,w.MATTE,!0,!0);for(let r=1;r<=4;r++){const l=r/4.6;E(s,a*4.4*l,9.1+c*4.4*l,1.78,.42,.42,.02,i,it,w.MATTE)}}},watermill:(s,t)=>{ne(s,{w:4.2,d:3.4,h:3,wall:Ae,roof:xt,pitch:1.5,eave:.4,plinth:.3,plinthCol:Yt,frame:!0,frameCol:tt,windows:[-1.1,1.1],lit:!0});const e=2.5;C(s,[e-.35,1.6,0],[e+.35,1.6,0],1.55,1.55,12,tt,w.MATTE,!1,!1);for(let n=0;n<12;n++){const o=n/12*K;E(s,e,1.6+Math.sin(o)*1.5,Math.cos(o)*1.5,.36,.16,.06,0,n%3?yt:st,w.MATTE)}t()<.7&&dt(s,e,.4,1.2,.5,.16,.4,Qt,w.MATTE,7,3)},lighthouse:s=>xo(s,{r:2,rTop:1.25,h:12.5,tiers:4,seg:12,wall:it,band:wt,gallery:!0,galleryCol:ft,lamp:1.6,cap:1.2,roof:ft}),mooring_mast:s=>{for(let t=0;t<3;t++){const e=t/3*K;C(s,[Math.cos(e)*1.5,0,Math.sin(e)*1.5],[0,16,0],.16,.06,5,Ct,w.MATTE,!0,!0)}for(const t of[4,8,12]){const e=1.5*(1-t/17);C(s,[e,t,0],[-e*.5,t,e*.87],.05,.05,4,Ct,w.MATTE,!0,!0),C(s,[-e*.5,t,e*.87],[-e*.5,t,-e*.87],.05,.05,4,Ct,w.MATTE,!0,!0),C(s,[-e*.5,t,-e*.87],[e,t,0],.05,.05,4,Ct,w.MATTE,!0,!0)}C(s,[0,16,0],[0,17.2,0],.35,.22,8,ie,w.METAL,!0,!0),dt(s,0,17.4,0,.2,.2,.2,ae,w.EMIT,6,3)},ruined_tower:(s,t)=>{xo(s,{r:1.7,rTop:1.45,h:5.5,tiers:3,seg:9,wall:At,band:Yt});for(let e=0;e<9;e++){const n=e/9*K,o=.15+t()*1.1;E(s,Math.cos(n)*1.4,5.5+o*.5,Math.sin(n)*1.4,.34,o*.5,.3,-n,e%2?At:vo,w.MATTE)}vs(s,{n:4,spread:2.6,min:.4,max:.8,moss:!0},t)},ruined_wall:(s,t)=>{Ei(s,{len:6,h:1.6,d:.7,batter:.1,courses:7,cap:!1},t);for(let e=0;e<3;e++)E(s,-2+e*2+t(),1.7+t()*.7,0,.3,.5,.3,t(),At,w.MATTE);vs(s,{n:5,spread:2.4,min:.3,max:.7,moss:!0},t)},rusted_truck:(s,t)=>{qs(s,{w:1.9,d:4.2,bedY:1,bedH:.5,sides:.4,body:Ct,cab:.9,cabD:1.3,cabCol:ut(Ct,ee,.35),wheels:[[-1,-1.2,.5,.5],[1,-1.2,.5,.5],[-1,1.3,.5,.5],[1,1.3,.5,.5]],hub:Ct}),dt(s,0,1.6,-.6,.8,.3,.9,Qt,w.MATTE,8,3),t()<.6&&To(s,{n:4,spread:.9,min:.5,max:.9,stalk:!0,stalkH:.5,stalkR:.02,stalkCol:zo,capR:.12,capCols:[it,Ze]},t)},caravan:(s,t)=>{qs(s,{w:2,d:3.4,bedY:1.2,bedH:.85,body:t()<.5?it:ut(ee,it,.5),wheels:[[-1,-.4,.42,.42],[1,-.4,.42,.42]],hub:ie}),C(s,[-2,2.05,0],[2,2.05,0],1,1,8,Ae,w.MATTE,!1,!1);for(const e of[1,-1])E(s,0,1.55,e*1.68,.5,.3,.04,0,ae,w.EMIT);C(s,[0,.5,1.9],[0,.2,2.6],.05,.05,5,ft,w.MATTE,!0,!0),t()<.6&&E(s,1.5,1.2,-1,.6,.02,.02,.2,it,w.MATTE)},rail_trolley:(s,t)=>{for(const e of[-1,1])E(s,e*.72,.09,0,.06,.09,3,0,Ct,w.MATTE);for(let e=0;e<9;e++)E(s,0,.05,-2.7+e*.7,1.05,.05,.14,0,tt,w.MATTE);qs(s,{w:1.3,d:1.5,bedY:.55,bedH:.14,sides:.28,body:st,wheels:[[-1,-.5,.24,.24],[1,-.5,.24,.24],[-1,.5,.24,.24],[1,.5,.24,.24]],hub:Ct}),C(s,[0,.7,0],[0,1.25,0],.05,.05,5,Ct,w.MATTE,!0,!0),E(s,0,1.25+(t()-.5)*.1,0,.5,.045,.045,0,Ct,w.MATTE)},jetty:(s,t)=>{for(let e=0;e<5;e++){const n=-2.4+e*1.2;for(const o of[-1,1])C(s,[o*.75,-.6,n],[o*.75,.42,n],.1,.09,6,tt,w.MATTE,!0,!0)}for(let e=0;e<7;e++)E(s,0,.48,-2.7+e*.9,.85,.045,.4,0,e%2?yt:st,w.MATTE);t()<.5&&d0(s,{len:5.4,h:.9,n:4,rails:[.75],post:tt})},rowboat:(s,t)=>{f0(s,{len:3.6,beam:.72,depth:.5,hull:t()<.5?Vt:ee,inner:yt,thwarts:!0}),C(s,[.5,.55,-.6],[-.4,.2,1.4],.04,.06,5,st,w.MATTE,!0,!0)},upturned_boat:(s,t)=>{const e=Xt();f0(e,{len:3.4,beam:.7,depth:.5,hull:t()<.5?ut(ee,tt,.4):tt,upturned:!0});for(let n=0;n<e.n;n++)e.pos[n*3+1]=.55-e.pos[n*3+1],e.nrm[n*3+1]=-e.nrm[n*3+1];Je(s,e,0,0,0,0,1),t()<.6&&dt(s,.3,.6,-.4,.4,.1,.5,Qt,w.MATTE,7,3)},fishing_hut:(s,t)=>{ne(s,{w:2.4,d:2,h:1.9,wall:tt,roof:Ct,pitch:.5,eave:.3,plinth:.5,plinthCol:tt,frame:!0,windows:[.6],lit:t()<.6});for(let e=0;e<3;e++)E(s,-1.2,1.2+e*.3,1.05,.03,.12,.3,.3,it,w.MATTE)},boathouse:s=>{ne(s,{w:3.6,d:4.4,h:2.2,wall:st,roof:xt,pitch:1.1,eave:.45,plinth:.35,plinthCol:tt,door:!1,frame:!0}),E(s,0,1,2.24,1.1,1,.06,0,ft,w.MATTE);for(const t of[-1,1])C(s,[t*1.9,-.7,2.6],[t*1.9,.4,2.6],.12,.1,6,tt,w.MATTE,!0,!0)},crab_pots:(s,t)=>is(s,{rows:2,per:3,step:.62,w:.55,h:.4,d:.5,jitter:.16,yaw:.6,cols:[ut(tt,ft,.3),tt,Ct]},t),buoy_cluster:(s,t)=>{for(let e=0;e<5;e++){const n=t()*K,o=Math.pow(t(),.6)*.9,i=.22+t()*.14;dt(s,Math.cos(n)*o,i*.9,Math.sin(n)*o,i,i*1.15,i,[wt,it,Ze,ee][t()*4|0],w.MATTE,8,4),C(s,[Math.cos(n)*o,i*2,Math.sin(n)*o],[Math.cos(n)*o,i*2.4,Math.sin(n)*o],.025,.025,4,ft,w.MATTE,!0,!0)}},giant_mushrooms:(s,t)=>To(s,{n:5,spread:1.4,min:.7,max:1.5,stalk:!0,stalkH:.85,stalkR:.14,stalkCol:it,capR:.55,squash:.55,gills:!0,capCols:[wt,ut(wt,Ze,.4),ut(it,yt,.4)]},t),giant_acorn:(s,t)=>{dt(s,0,.85,0,.72,.9,.72,ut(yt,$s,.4),w.MATTE,9,5),C(s,[0,1.35,0],[0,1.72,0],.76,.5,9,tt,w.MATTE,!1,!0),C(s,[0,1.72,0],[0,2,0],.09,.06,5,tt,w.MATTE,!0,!0),t()<.5&&dt(s,.5,.35,.3,.3,.12,.26,Qt,w.MATTE,6,3)},bamboo_clump:(s,t)=>{for(let e=0;e<11;e++){const n=t()*K,o=Math.pow(t(),.5)*1.1,i=3.4+t()*2.6,a=Math.cos(n)*o,c=Math.sin(n)*o,r=(t()-.5)*.5;C(s,[a,0,c],[a+r,i,c+r*.6],.055,.038,5,e%3?En:wo,w.MATTE,!0,!0);for(let l=0;l<3;l++){const h=.55+l*.15;dt(s,a+r*h,i*h,c+r*.6*h,.28,.08,.28,wo,w.MATTE,6,3)}}},tree_stump_axe:(s,t)=>{C(s,[0,0,0],[0,.62,0],.5,.44,9,tt,w.MATTE,!1,!0),C(s,[0,.62,0],[0,.64,0],.42,.42,9,yt,w.MATTE,!1,!0),C(s,[.1,.6,.05],[-.35,1.35,-.1],.035,.03,5,st,w.MATTE,!0,!0),E(s,-.36,1.36,-.1,.13,.1,.04,.5,ie,w.METAL),t()<.6&&dt(s,.42,.2,.2,.3,.12,.26,Qt,w.MATTE,6,3)},fallen_log:(s,t)=>{C(s,[-2.4,.42,0],[2.6,.34,.2],.42,.34,9,tt,w.MATTE,!0,!0);for(let e=0;e<3;e++){const n=-1.6+e*1.5;C(s,[n,.5,0],[n+(t()-.5),.9+t()*.4,(t()-.5)*.8],.08,.04,5,tt,w.MATTE,!0,!0)}dt(s,.3,.66,.1,1.3,.16,.34,Qt,w.MATTE,9,3)},log_pile:(s,t)=>is(s,{rows:3,per:4,step:.42,w:1.5,h:.4,d:.4,jitter:.06,yaw:0,round:"x",cols:[tt,st,yt]},t),erratic_boulder:(s,t)=>{vs(s,{n:1,spread:0,min:2.4,max:3,moss:!0},t),vs(s,{n:3,spread:2.2,min:.4,max:.9,moss:!0},t)}};function C1(s,t,e){const i=Math.max(.35,e);E(s,0,-i*.5,0,9.5,i*.5,7,0,S1,w.MATTE),E(s,0,.005,0,9.5-.15,.01,7-.15,0,k1,w.MATTE);for(let u=-2;u<=2;u++)E(s,u*2.1,.02,7-.6,.9,.012,.09,0,E1,w.MATTE);const a=5.2,c=3.4,r=4.3;for(const u of[-1,1])for(const d of[-1,1])C(s,[u*a,0,d*c+1],[u*a,r,d*c+1],.16,.15,8,it,w.MATTE,!1,!1);E(s,0,r+.22,1,a+.9,.22,c+.9,0,it,w.MATTE),E(s,0,r+.5,1,a+.95,.14,c+.95,0,wt,w.MATTE),E(s,0,r-.02,1,a*.72,.03,c*.5,0,ae,w.EMIT),E(s,0,.14,1,2,.14,.9,0,M1,w.MATTE);for(const u of[-1,1]){const d=u*1.15;E(s,d,.95,1,.42,.81,.32,0,it,w.MATTE),E(s,d,1.5,1+u*.34,.3,.24,.03,0,ae,w.EMIT),E(s,d,1.82,1,.44,.06,.36,0,wt,w.MATTE),C(s,[d+u*.4,1.4,1],[d+u*.62,.95,1],.035,.035,5,ft,w.MATTE,!0,!0),C(s,[d+u*.62,.95,1],[d+u*.52,.55,1],.035,.03,5,ft,w.MATTE,!0,!0)}const l=Xt();ne(l,{w:4,d:2.8,h:2.4,wall:Ae,roof:xt,pitch:.9,eave:.45,plinth:.16,plinthCol:At,frame:!0,frameCol:st,windows:[-1.1,1.1],lit:!0,porch:!0}),Je(s,l,0,0,-7+2.2,Math.PI,1);const h=Xt();Uc.bench(h,t),Je(s,h,-9.5+2,0,-7+2.6,.4,1),C(s,[9.5-1.4,0,7-1.6],[9.5-1.4,5.4,7-1.6],.17,.15,8,it,w.MATTE,!0,!1),E(s,9.5-1.4,5.9,7-1.6,1.25,.75,.16,0,wt,w.MATTE),E(s,9.5-1.4,5.9,7-1.42,1,.55,.04,0,ae,w.EMIT),E(s,-9.5+1.2,.55,1.2,.22,.55,.22,0,Xs,w.MATTE),C(s,[-9.5+1.2,1.1,1.2],[-9.5+1.2,1.35,1.2],.1,.08,6,ie,w.METAL,!1,!0)}class L1{constructor({seed:t,scene:e,solids:n=null,range:o=y1,tile:i=x1}){this.seed=t>>>0,this.scene=e,this.solids=n,this.range=o,this.tile=i,this.group=new qe,this.group.name="props",this.group.matrixAutoUpdate=!1,e.add(this.group),this.material=Zo(),this.live=new Map,this.pending=[],this._job=null,this._lastCx=1/0,this._lastCz=1/0,this.stations=[],this.known=new Map,this.stats={tiles:0,props:0,stations:0,verts:0,tris:0,buildMs:0,backlog:0},this._scratchW=new Float32Array(_t)}nearestStation(t,e){let n=null,o=1/0;for(const i of this.known.values()){const a=Math.hypot(i.x-t,i.z-e);a<o&&(o=a,n=i)}return n?{...n,dist:o}:null}update(t,e,n){const o=Math.floor(e/this.tile),i=Math.floor(n/this.tile);(o!==this._lastCx||i!==this._lastCz)&&(this._lastCx=o,this._lastCz=i,this._reshape(e,n)),this._drain(t)}_reshape(t,e){const n=Math.ceil(this.range/this.tile),o=new Set,i=this._lastCx,a=this._lastCz;for(let c=-n;c<=n;c++)for(let r=-n;r<=n;r++){const l=i+r,h=a+c,u=Math.max(0,Math.abs((l+.5)*this.tile-t)-this.tile*.5),d=Math.max(0,Math.abs((h+.5)*this.tile-e)-this.tile*.5);Math.hypot(u,d)>this.range||o.add(`${l},${h}`)}for(const c of o){if(this.live.has(c)||this._job&&this._job.key===c||this.pending.some(h=>h.key===c))continue;const[r,l]=c.split(",").map(Number);this.pending.push({key:c,tx:r,tz:l})}this.pending.sort((c,r)=>this._d2(c,t,e)-this._d2(r,t,e));for(const[c,r]of this.live)o.has(c)||this._release(c,r);this.pending=this.pending.filter(c=>o.has(c.key)),this._job&&!o.has(this._job.key)&&(this._job=null)}_d2(t,e,n){const o=(t.tx+.5)*this.tile-e,i=(t.tz+.5)*this.tile-n;return o*o+i*i}_drain(t){if(this.stats.buildMs=0,this.stats.backlog=this.pending.length+(this._job?1:0),t>_1)return;if(!this._job){if(!this.pending.length)return;this._job=this.pending.shift(),this._job.phase=0}const e=performance.now();this._step(this._job),this.stats.buildMs=performance.now()-e,this.stats.backlog=this.pending.length+(this._job?1:0)}_step(t){const e=this.tile,n=t.tx*e,o=t.tz*e;switch(t.phase){case 0:{t.terr=new Re(this.seed,n,o,n+e,o+e,40);const i=this._scratchW;t.probe={site:(a,c)=>{const r=t.terr.weights(a,c);i.set(r.w);const l=r.dominant;return{y:t.terr.height(a,c),dominant:l,wy:Ls(i,-1/0)}},height:(a,c)=>t.terr.height(a,c)},t.phase=1;return}case 1:t.props=c1(n,o,n+e,o+e,this.seed,t.probe),t.phase=2;return;case 2:t.stations=b1(n,o,n+e,o+e,this.seed),t.phase=3;return;default:this._bake(t),this._job=null}}_bake(t){const{key:e,props:n,stations:o}=t,i=t.probe.height,a=Xt();for(const r of n){const l=Uc[r.id];if(!l){console.error("[props] no geometry for kind",r.id,"— src/world/props.js and src/render/props.js disagree");continue}const h=Xt(),u=Ee(Es(Math.round(r.x*4),Math.round(r.z*4),40503,this.seed));l(h,u,r.hue),Je(a,h,r.x,r.y,r.z,r.yaw,r.scale)}for(const r of o){let l=1/0,h=-1/0;for(const[f,p]of[[0,0],[9,6],[-9,6],[9,-6],[-9,-6],[0,7],[0,-7]]){const g=Math.cos(r.yaw),m=Math.sin(r.yaw),v=i(r.x+f*g-p*m,r.z+f*m+p*g);v<l&&(l=v),v>h&&(h=v)}const u=X(h+.04,r.y-.7,r.y+.3),d=Xt();C1(d,Ee(Es(Math.round(r.x),Math.round(r.z),22343,this.seed)),u-l+.4),Je(a,d,r.x,u,r.z,r.yaw,1),r.padY=u,r.tile=e}let c=null;if(a.n){const r=cn(a);c=new Ht(r,this.material),c.frustumCulled=!0,c.matrixAutoUpdate=!1,c.updateMatrix(),c.renderOrder=2,this.group.add(c)}if(this.solids){const r=F1(n);r.length&&this.solids.addChunk(`prop:${e}`,r)}for(const r of o)this.stations.push(r),this.known.set(r.key,r);this.known.size>h0&&this._forgetFurthest(),this.live.set(e,{mesh:c,props:n,stations:o,verts:a.n,tris:a.idx.length/3}),this._recount()}_release(t,e){e.mesh&&(this.group.remove(e.mesh),e.mesh.geometry.dispose()),this.solids&&this.solids.removeChunk(`prop:${t}`),e.stations.length&&(this.stations=this.stations.filter(n=>n.tile!==t)),this.live.delete(t),this._recount()}_forgetFurthest(){const t=(this._lastCx+.5)*this.tile,e=(this._lastCz+.5)*this.tile,n=[...this.known.values()].sort((o,i)=>Math.hypot(o.x-t,o.z-e)-Math.hypot(i.x-t,i.z-e));for(let o=h0;o<n.length;o++)this.known.delete(n[o].key)}_recount(){let t=0,e=0,n=0;for(const o of this.live.values())t+=o.props.length,e+=o.verts,n+=o.tris;this.stats.tiles=this.live.size,this.stats.props=t,this.stats.stations=this.stations.length,this.stats.verts=e,this.stats.tris=n}dispose(){this._job=null,this.pending.length=0,this.known.clear();for(const[t,e]of[...this.live])this._release(t,e);this.material.dispose(),this.group.parent&&this.group.parent.remove(this.group)}}function F1(s){const t=[];for(const e of s){const n=o1[e.id];!n||!n.r||t.push({x:e.x,z:e.z,y:e.y,r:n.r*e.scale,h:n.h*e.scale,kind:"prop"})}return t}const ws=360,D1=26.4,I1=.288,Hc=.14,Wc=.4,P1=(1-Hc-Wc)/I1,O1=5,N1=1.6,B1=6,G1=4,U1=75,H1=.16,oa=.18;class W1{constructor({findStation:t=null,say:e=null,start:n=.72}={}){this.findStation=t,this.say=e||(()=>{}),this.seconds=ws*N(n),this.power=1,this.refuelling=!1,this.dry=!1,this.nearest=null,this._dryFor=0,this._stoppedFor=0,this._nextScan=0,this._saidLow=!1,this._saidDry=!1,this._visiting=!1,this.stats={burned:0,filled:0,rescues:0,refuels:0,drySeconds:0}}get fraction(){return N(this.seconds/ws)}minutesLeft(t){const e=t?Math.max(.05,this.rate(t)):1;return this.seconds/e/60}rate(t){const e=Math.abs(t.speed||0),n=N(t.throttle||0),o=e/D1;return Hc+P1*n+Wc*o*o}update(t,e){if(!(t>0))return;const n=Math.abs(e.speed||0);if(this._nextScan-=t,this.findStation&&this._nextScan<=0&&(this._nextScan=.5,this.nearest=this.findStation(e.x,e.z)),!!this.nearest&&this.nearest.dist<=v1&&n<=N1){if(this.refuelling=this.seconds<ws-.001,this.refuelling){this._visiting||(this._visiting=!0,this.stats.refuels++,this.say("filling up — take your time",3));const i=this.seconds;this.seconds=Math.min(ws,this.seconds+ws/O1*t),this.stats.filled+=this.seconds-i}else this._visiting&&(this._visiting=!1,this.say("full tank",2.4));this._clearDry(),this.power=kt(this.power,1,4,t);return}if(this.refuelling=!1,this._visiting=!1,this.seconds>0){const i=this.rate(e)*t;this.seconds=Math.max(0,this.seconds-i),this.stats.burned+=i}if(!this._saidLow&&this.fraction<=oa&&this.seconds>0){this._saidLow=!0;const i=this.nearest;this.say(i?`running low — pumps ${p0(i.dist)} away`:"running low on fuel",4)}if(this.seconds>0){this._clearDry(),this.power=kt(this.power,1,4,t);return}if(this.dry=!0,this._dryFor+=t,this.stats.drySeconds+=t,this._saidDry||(this._saidDry=!0,this.say("out of fuel — coasting",3.4)),this.power=X(1-this._dryFor/B1,0,1),n<.8?this._stoppedFor+=t:this._stoppedFor=0,this._stoppedFor>=G1||this._dryFor>=U1){this.seconds=ws*H1,this.stats.rescues++,this._clearDry(),this.power=.35;const i=this.nearest;this.say(i?`someone shares a can — pumps ${p0(i.dist)} away`:"someone shares a can",4.2)}}_clearDry(){this.dry=!1,this._dryFor=0,this._stoppedFor=0,this._saidDry=!1,this._saidLow=this.fraction<=oa}gate(t){return!t||this.power>=.999?t:{...t,throttle:(t.throttle||0)*this.power}}fill(t=1){this.seconds=ws*N(t),this._clearDry(),this.power=1}}function p0(s){return s>=1e3?`${(s/1e3).toFixed(1)} km`:`${Math.round(s/10)*10} m`}const Xe="http://www.w3.org/2000/svg",bs=60,$1=`
#fuelGauge{
  position:absolute; right:18px; bottom:74px; width:104px; height:70px;
  pointer-events:none; opacity:.82; transition:opacity .5s ease;
  font:500 11px/1.2 ui-rounded,-apple-system,Segoe UI,Roboto,sans-serif;
  color:#F6ECD8; text-shadow:0 1px 3px rgba(28,34,48,.55);
}
#fuelGauge.low{ opacity:1; animation:fuelBreathe 3.4s ease-in-out infinite; }
#fuelGauge.filling{ opacity:1; }
#fuelGauge .lbl{ position:absolute; left:0; right:0; bottom:-2px; text-align:center; letter-spacing:.08em; }
#fuelGauge .mins{ position:absolute; left:0; right:0; bottom:10px; text-align:center; opacity:.72; font-size:10px; }
@keyframes fuelBreathe{ 0%,100%{opacity:.72} 50%{opacity:1} }
@media (max-width:640px){ #fuelGauge{ width:78px; height:54px; right:10px; bottom:60px; } }
`;class K1{constructor(t){if(!document.getElementById("fuelGaugeCss")){const u=document.createElement("style");u.id="fuelGaugeCss",u.textContent=$1,document.head.appendChild(u)}this.root=document.createElement("div"),this.root.id="fuelGauge";const e=document.createElementNS(Xe,"svg");e.setAttribute("viewBox","0 0 104 70"),e.setAttribute("width","100%"),e.setAttribute("height","100%");const n=document.createElementNS(Xe,"linearGradient");n.setAttribute("id","fuelArc"),n.setAttribute("x1","0"),n.setAttribute("x2","1");for(const[u,d]of[["0%","#C8503F"],["38%","#E0B14E"],["100%","#93B84E"]]){const f=document.createElementNS(Xe,"stop");f.setAttribute("offset",u),f.setAttribute("stop-color",d),n.appendChild(f)}const o=document.createElementNS(Xe,"defs");o.appendChild(n),e.appendChild(o);const i=52,a=62,c=40,r=document.createElementNS(Xe,"path");r.setAttribute("d",j1(i,a,c,-bs,bs)),r.setAttribute("fill","none"),r.setAttribute("stroke","url(#fuelArc)"),r.setAttribute("stroke-width","7"),r.setAttribute("stroke-linecap","round"),r.setAttribute("opacity","0.9"),e.appendChild(r);for(const u of[0,.5,1]){const d=(-bs+u*bs*2)*(Math.PI/180),f=document.createElementNS(Xe,"line"),p=i+Math.sin(d)*(c-9),g=a-Math.cos(d)*(c-9),m=i+Math.sin(d)*(c-14),v=a-Math.cos(d)*(c-14);f.setAttribute("x1",p.toFixed(2)),f.setAttribute("y1",g.toFixed(2)),f.setAttribute("x2",m.toFixed(2)),f.setAttribute("y2",v.toFixed(2)),f.setAttribute("stroke","#F6ECD8"),f.setAttribute("stroke-width","1.6"),f.setAttribute("opacity","0.55"),e.appendChild(f)}this.needle=document.createElementNS(Xe,"g");const l=document.createElementNS(Xe,"path");l.setAttribute("d",`M ${i} ${a} L ${i-2.6} ${a-4} L ${i} ${a-c+8} L ${i+2.6} ${a-4} Z`),l.setAttribute("fill","#F6ECD8"),this.needle.appendChild(l);const h=document.createElementNS(Xe,"circle");h.setAttribute("cx",String(i)),h.setAttribute("cy",String(a)),h.setAttribute("r","3.6"),h.setAttribute("fill","#F6ECD8"),this.needle.appendChild(h),e.appendChild(this.needle),this.root.appendChild(e),this.mins=document.createElement("div"),this.mins.className="mins",this.root.appendChild(this.mins),this.label=document.createElement("div"),this.label.className="lbl",this.label.textContent="FUEL",this.root.appendChild(this.label),this._cx=i,this._cy=a,this._shown=1,this._angle=bs,t.appendChild(this.root)}needleAngle(){return this._angle}update(t,e,n){const o=e.fraction;this._shown+=(o-this._shown)*Math.min(1,t*2.4),this._angle=-bs+this._shown*bs*2,this.needle.setAttribute("transform",`rotate(${this._angle.toFixed(2)} ${this._cx} ${this._cy})`);const i=o<=oa;i!==this._low&&(this._low=i,this.root.classList.toggle("low",i));const a=e.refuelling;a!==this._filling&&(this._filling=a,this.root.classList.toggle("filling",a));let c="";if(a)c=`${Math.round(o*100)}%`;else if(e.dry)c="empty";else if(o<.34){const r=e.minutesLeft(n);c=r>=1?`${r.toFixed(0)} min`:`${Math.round(r*60)} s`,o<.12&&e.nearest&&(c=q1(e.nearest.dist))}c!==this._text&&(this._text=c,this.mins.textContent=c)}dispose(){this.root.parentNode&&this.root.parentNode.removeChild(this.root)}}function q1(s){return s>=1e3?`${(s/1e3).toFixed(1)} km`:`${Math.round(s/10)*10} m`}function j1(s,t,e,n,o){const i=u=>{const d=u*(Math.PI/180);return[s+Math.sin(d)*e,t-Math.cos(d)*e]},[a,c]=i(n),[r,l]=i(o),h=Math.abs(o-n)>180?1:0;return`M ${a.toFixed(2)} ${c.toFixed(2)} A ${e} ${e} 0 ${h} 1 ${r.toFixed(2)} ${l.toFixed(2)}`}const V1="0.4";function de(s,t,e){const n=document.createElement(s);return t&&(t[0]==="."?n.className=t.slice(1):n.id=t),e!==void 0&&(n.textContent=e),n}class Y1{constructor(){this.root=document.getElementById("hud"),this.kph=document.getElementById("kph"),this.gear=document.getElementById("gear"),this.biome=document.getElementById("biome"),this.coords=document.getElementById("coords"),this.players=document.getElementById("players"),this.toast=document.getElementById("toast"),this.bar=de("div","unlockBar"),this.barNext=de("div","unlockNext","the road ahead"),this.barTrack=de("div",".track"),this.barFill=de("div",".fill"),this.barMark=de("div",".mark"),this.barTrack.appendChild(this.barFill),this.barTrack.appendChild(this.barMark),this.bar.appendChild(this.barNext),this.bar.appendChild(this.barTrack),this.root.appendChild(this.bar),this.streakEl=de("div","streak");const t=de("div",".figure");this.streakKm=de("span","streakKm","0 m"),this.streakMul=de("span","streakMul"),t.appendChild(this.streakKm),t.appendChild(this.streakMul);const e=de("div",".cap");this.streakCap=de("span","streakCap","stay on the road"),this.streakPts=de("span","streakPts"),e.appendChild(this.streakCap),e.appendChild(this.streakPts),this.streakEl.appendChild(t),this.streakEl.appendChild(e),this.root.appendChild(this.streakEl),this._blip=0,this._toastT=0,this._lastGear=null,this._lastBiome=-1,this._shownKm=0,this._nextId=""}say(t,e=3.6){this.toast.textContent=t,this.toast.classList.add("show"),this._toastT=e}setCinematic(t){this.root&&(this.root.style.transition=t?"none":"opacity 1.2s ease",this.root.style.opacity=t?V1:"",this.root.style.pointerEvents=t?"none":"")}update(t,{car:e,streak:n,surface:o,remotes:i,netState:a}){const c=Math.round(e.kph);this.kph.textContent=c;const r=e.reverse?"R":Math.abs(e.speed)<.6?"N":String(e.gear);r!==this._lastGear&&(this.gear.textContent=r,this._lastGear=r),o&&o.dominant!==this._lastBiome&&(this._lastBiome=o.dominant,this.biome.textContent=Wi[o.dominant],this.say(Wi[o.dominant],2.8)),this.coords.textContent=`${Math.round(e.x)}, ${Math.round(e.z)}`;const l=n.state,h=l.distance>0;this.streakEl.classList.toggle("live",h),this.streakEl.classList.toggle("grace",h&&!!l.grace),h?(this._shownKm+=(l.km-this._shownKm)*Math.min(1,t*9),this.streakKm.textContent=Si(this._shownKm*1e3),this.streakCap.textContent=l.grace?"off the road…":"without leaving the road",this.streakMul.textContent=l.multiplier>1.02?`×${l.multiplier.toFixed(2)}`:"",this.streakPts.textContent=l.score>5?Rp(l.score):""):(this._shownKm=0,this.streakKm.textContent=Si(l.best),this.streakCap.textContent=l.best>0?"your longest run":"stay on the road",this.streakMul.textContent="",this.streakPts.textContent="");const u=Math.max(l.best,l.distance),d=sp(u);if(this.bar.classList.toggle("live",h),d){const g=d.car.unlockAt,m=N(l.distance/g),v=N(l.best/g);this.barFill.style.width=`${(Math.max(h?m:v,.004)*100).toFixed(1)}%`,this.barMark.style.left=`${(v*100).toFixed(1)}%`,this.barMark.classList.toggle("on",h&&v>.01&&v<.99&&l.distance<l.best),this.barNext.textContent=`${d.car.label} · ${Ic(d.remaining)} to go`}else this.barFill.style.width="100%",this.barMark.classList.remove("on"),this.barNext.textContent="every car unlocked";const f=d?d.car.id:"__all__";if(this._nextId&&f!==this._nextId){const g=Qn[this._nextId];g&&u>=g.unlockAt&&this.say(`${g.label} unlocked`,4)}this._nextId=f,this._blip>0&&(this._blip-=t,this._blip<=0&&(this.bar.classList.remove("broke"),this.streakEl.classList.remove("broke")));const p=n.drain();if(p&&(p.kind==="milestone"?this.say(p.text,3.2):p.kind==="break"&&(this.say(`${Si(p.distance)} — streak ended`,3),this.bar.classList.add("broke"),this.streakEl.classList.add("broke"),this._blip=1.2)),i){const g=i.list?i.list():[];g.length?this.players.innerHTML=g.slice(0,6).map(m=>`<div>${X1(m.name)} <span class="dist">${Math.round(m.dist)} m</span></div>`).join(""):this.players.childNodes.length&&(this.players.innerHTML="")}a&&a!==this._lastNet&&(this._lastNet=a,this.root.dataset.net=a),this._toastT>0&&(this._toastT-=t,this._toastT<=0&&this.toast.classList.remove("show"))}}function X1(s){return String(s).replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}const js={land:10.5,water:9.5,road:9.5,car:8.5},m0=.55,g0=6.5,v0=26,Z1=13,J1=1.6,fe=s=>Math.sin(s),pe=s=>Math.cos(s),xs=s=>Math.cos(s),ys=s=>-Math.sin(s);function Cn(s,t=.2){const e=1-t;if(s<=0)return 0;if(s>=1)return 1;if(s<t)return s*s/(2*t)/e;if(s>1-t){const n=1-s;return(e-n*n/(2*t))/e}return(s-t/2)/e}const Q1=()=>({px:0,py:0,pz:0,lx:0,ly:0,lz:0,fov:60});class tm{constructor({camera:t,seed:e,spawn:n,terrain:o=null,chase:i=null,groundAt:a=null,hud:c=null,mode:r=null,onEnd:l=null}){this.camera=t,this.seed=e>>>0,this.spawn=n,this.terrain=o,this.chase=i,this.groundAt=a,this.hud=c,this.onEnd=l,this.mode=r||om(),this.shots=[],this.duration=0,this.t=0,this.shotIndex=-1,this.skipped=!1,this._running=!1,this._pose=Q1(),this._rest={},this._hint=null,this._watchdog=0,this._onAny=null,this.mode!=="off"&&this._scout()}get active(){return this._running}get remaining(){return Math.max(0,this.duration-this.t)}get shotName(){return this.shots[this.shotIndex]?.name??""}begin(){return this._running||this.mode==="off"||!this.shots.length?(this._end(),!1):(this._running=!0,this.t=0,this.shotIndex=-1,this._attach(),this._hint=am(),this.hud?.setCinematic?.(!0),im(),typeof setTimeout=="function"&&(this._watchdog=setTimeout(()=>this._end(),(this.duration+12)*1e3)),!0)}update(t,e){if(!this._running)return!1;this.t+=t;let n=this.t,o=0;for(;o<this.shots.length-1&&n>=this.shots[o].dur;)n-=this.shots[o].dur,o++;this.shotIndex=o;const i=this.shots[o],a=N(n/i.dur),c=this._pose;i.pose(a,e,c,this);const r=this.camera;return r.position.set(c.px,c.py,c.pz),r.up.set(0,1,0),r.lookAt(c.lx,c.ly,c.lz),Math.abs(r.fov-c.fov)>.01&&(r.fov=c.fov,r.updateProjectionMatrix()),this.t>=this.duration&&this._end(),this._running}skip(){if(!this._running||this.skipped)return!1;if(this.skipped=!0,this.shotIndex<0)return this._end(),!0;const t={...this._pose};return this.shots=[{name:"handoff",dur:m0,pose:(e,n,o,i)=>{const a=i._restPose(n),c=ri(0,1,e);o.px=O(t.px,a.px,c),o.py=O(t.py,a.py,c),o.pz=O(t.pz,a.pz,c),o.lx=O(t.lx,a.lx,c),o.ly=O(t.ly,a.ly,c),o.lz=O(t.lz,a.lz,c),o.fov=O(t.fov,a.fov,c)}}],this.duration=m0,this.t=0,this.shotIndex=0,this._hint?.remove(),this._hint=null,!0}_end(){const t=this._running;this._running=!1,this._detach(),this._watchdog&&typeof clearTimeout=="function"&&clearTimeout(this._watchdog),this._watchdog=0,this._hint?.remove(),this._hint=null,this.hud?.setCinematic?.(!1),t&&this.onEnd?.()}stop(){this._end()}_restPose(t){if(this.chase?.restPose)return this.chase.restPose(t,this._rest,this.groundAt);const e=this._rest;return e.px=t.x-Math.sin(t.yaw)*6.2,e.py=t.y+1.9,e.pz=t.z-Math.cos(t.yaw)*6.2,e.lx=t.x+Math.sin(t.yaw),e.ly=t.y+.9,e.lz=t.z+Math.cos(t.yaw),e.fov=62,e}_scout(){const t=this.seed,e=this.spawn.x,n=this.spawn.z,o=(h,u)=>Xn(h,u,t),i=Number.isFinite(this.spawn.y)?this.spawn.y:o(e,n),a=this.mode==="full",c=a?em(e,n,t):null,r=a?sm(e,n,t,o):null;this.subjects={landmark:c,water:r,spawnY:i};const l=[];a&&(l.push(this._shotLand(c,o,i)),l.push(r?this._shotWater(r,o):this._shotRise(c,o,i)),l.push(this._shotRoad(o))),l.push(this._shotCar(nm(e,n,v0,o,12))),this.shots=l.filter(Boolean),this.duration=this.shots.reduce((h,u)=>h+u.dur,0)}_shotLand(t,e,n){const o=Math.atan2(t.x-this.spawn.x,t.z-this.spawn.z),i={x:this.spawn.x-fe(o)*300,z:this.spawn.z-pe(o)*300},a={x:this.spawn.x-fe(o)*120,z:this.spawn.z-pe(o)*120};i.x+=xs(o)*60,i.z+=ys(o)*60;const c=Ci(i,a,e,18),r=Math.max(c,n)+86,l=Math.max(c,n)+48,h=e(t.x,t.z),u=Math.min(t.d,2600),d={x:this.spawn.x+fe(o)*u,z:this.spawn.z+pe(o)*u},f=O(Math.max(n,e(d.x,d.z)),h,.45);return{name:"land",dur:js.land,pose:(p,g,m)=>{const v=Cn(p,.26);m.px=O(i.x,a.x,v),m.pz=O(i.z,a.z,v),m.py=O(r,l,v);const x=(1-v)*90;m.lx=d.x+xs(o)*x,m.lz=d.z+ys(o)*x,m.ly=f,m.fov=52}}}_shotWater(t,e){const n=Math.atan2(this.spawn.x-t.x,this.spawn.z-t.z),o={x:t.x-fe(n)*85,z:t.z-pe(n)*85},i={x:t.x+fe(n)*40,z:t.z+pe(n)*40},a=Ci(o,i,e,14),c=Math.max(t.y,a),r=c+12.5,l=c+g0+1.5,h=190,u={x:i.x+fe(n)*h,z:i.z+pe(n)*h},d=t.y+2,f=Math.max(t.y,e(u.x,u.z))+26;return{name:"water",dur:js.water,pose:(p,g,m)=>{const v=Cn(p,.3);m.px=O(o.x,i.x,v),m.pz=O(o.z,i.z,v),m.py=O(r,l,v),m.lx=u.x,m.lz=u.z,m.ly=O(d,f,ri(0,1,v)),m.fov=58}}}_shotRise(t,e,n){const o=Math.atan2(t.x-this.spawn.x,t.z-this.spawn.z),i={x:this.spawn.x-fe(o)*115+xs(o)*75,z:this.spawn.z-pe(o)*115+ys(o)*75},a={x:this.spawn.x+xs(o)*30,z:this.spawn.z+ys(o)*30},c=Ci(i,a,e,16),r=c+26,l=c+g0+4,h={x:this.spawn.x+fe(o)*700,z:this.spawn.z+pe(o)*700},u=Math.max(n,e(h.x,h.z))+24;return{name:"rise",dur:js.water,pose:(d,f,p)=>{const g=Cn(d,.3);p.px=O(i.x,a.x,g),p.pz=O(i.z,a.z,g),p.py=O(r,l,g),p.lx=h.x,p.lz=h.z,p.ly=u,p.fov=55}}}_shotRoad(t){const e=this.seed,n=this.terrain?.roads??null,o=(T,M)=>this.terrain?this.terrain.height(T,M):Xn(T,M,e),i=5,a=30,c=[];let r=this.spawn.x,l=this.spawn.z,h=this.spawn.heading;for(let T=0;T<a;T++){c.push({x:r,z:l,h}),r-=fe(h)*i,l-=pe(h)*i;const M=n?.query(r,l);if(M&&isFinite(M.d)&&M.d<M.width*1.8){let k=M.tx,R=M.tz;fe(h)*k+pe(h)*R<0&&(k=-k,R=-R);const P=Math.atan2(k,R);let z=P-h;for(;z>Math.PI;)z-=K;for(;z<-Math.PI;)z+=K;Math.hypot(M.qx-r,M.qz-l)<i*1.2&&Math.abs(z)<.35&&(r=M.qx,l=M.qz,h=P)}}c.reverse();const u=12;let d=0,f=0;for(let T=0;T<c.length;T+=4){const M=c[T],k=o(M.x,M.z);d+=X(k-t(M.x+xs(M.h)*u,M.z+ys(M.h)*u),-14,14),f+=X(k-t(M.x-xs(M.h)*u,M.z-ys(M.h)*u),-14,14)}const p=d>=f?1:-1,g=T=>T.map(M=>{const k=M.x+xs(M.h)*u*p,R=M.z+ys(M.h)*u*p,P=o(M.x,M.z),z=t(k,R);return{x:k,z:R,y:Math.max(P,z)+3.4,rx:M.x,rz:M.z,ry:P}});let m=g(c),v=0;for(let T=1;T<m.length;T++)v=Math.max(v,Math.hypot(m[T].x-m[T-1].x,m[T].z-m[T-1].z));if(this.roadKink=v,v>i*2){const T=this.spawn.heading;m=g(c.map((M,k)=>({x:this.spawn.x-fe(T)*i*(a-1-k),z:this.spawn.z-pe(T)*i*(a-1-k),h:T})))}const x=8,b=m.length-1-(x-4),y=(T,M,k)=>{const R=X(Math.floor(M),0,T.length-2),P=N(M-R);return O(k(T[R]),k(T[R+1]),P)},A=[0];for(let T=1;T<m.length;T++)A.push(A[T-1]+Math.hypot(m[T].x-m[T-1].x,m[T].z-m[T-1].z));const _=T=>{let M=0;for(;M<b-1&&A[M+1]<T;)M++;const k=A[M+1]-A[M];return M+(k>0?N((T-A[M])/k):0)},S=Math.min(A[b],13*js.road);return{name:"road",dur:js.road,pose:(T,M,k)=>{const R=Cn(T,.24),P=_(R*S);k.px=y(m,P,L=>L.x),k.py=y(m,P,L=>L.y),k.pz=y(m,P,L=>L.z);const z=Math.min(P+x,m.length-1.001);k.lx=y(m,z,L=>L.rx),k.lz=y(m,z,L=>L.rz),k.ly=y(m,z,L=>L.ry)+1.7,k.fov=47}}}_shotCar(t){const e=J1,n=v0,o=Z1,i=t+4.5;return{name:"car",dur:js.car,pose:(a,c,r,l)=>{const h=l._restPose(c),u=Cn(a,.34),d=ri(0,1,u),f=h.px-c.x,p=h.pz-c.z,g=Math.hypot(f,p)||6.2,v=Math.atan2(-f,-p)+e*(1-d),x=O(n,g,d);r.px=c.x-fe(v)*x,r.pz=c.z-pe(v)*x,r.py=Math.max(O(c.y+o,h.py,d),O(i,h.py,d)),r.lx=O(c.x,h.lx,d),r.ly=O(c.y+1.1,h.ly,d),r.lz=O(c.z,h.lz,d),r.fov=O(55,h.fov,d)}}}_attach(){if(!(typeof window>"u"||this._onAny)){this._onAny=()=>this.skip();for(const t of["keydown","pointerdown","touchstart","wheel"])window.addEventListener(t,this._onAny,{passive:!0})}}_detach(){if(!(typeof window>"u"||!this._onAny)){for(const t of["keydown","pointerdown","touchstart","wheel"])window.removeEventListener(t,this._onAny);this._onAny=null}}}function em(s,t,e){const n=i=>i.h-i.d*.016;let o=rr(s,t,e);o.d=Math.hypot(o.x-s,o.z-t);for(const i of[2600,5200])for(let a=0;a<8;a++){const c=a/8*K,r=rr(s+Math.cos(c)*i,t+Math.sin(c)*i,e);r.d=Math.hypot(r.x-s,r.z-t),n(r)>n(o)&&(o=r)}return o}function sm(s,t,e,n){const o=jo(e);for(let i=120;i<=1500;i+=90){const a=Math.max(10,Math.round(K*i/140));for(let c=0;c<a;c++){const r=c/a*K+i*.017,l=s+Math.cos(r)*i,h=t+Math.sin(r)*i,u=o(l,h);if(u!==null&&u-n(l,h)>2)return{x:l,y:u,z:h,d:i}}}return null}function Ci(s,t,e,n){let o=-1/0;for(let i=0;i<=n;i++){const a=i/n,c=e(O(s.x,t.x,a),O(s.z,t.z,a));c>o&&(o=c)}return o}function nm(s,t,e,n,o){let i=-1/0;for(let a=0;a<o;a++){const c=a/o*K,r=n(s+Math.cos(c)*e,t+Math.sin(c)*e);r>i&&(i=r)}return i}const $c="wanderoad.intro.seen";function om(){let s=null;try{s=new URLSearchParams(location.search).get("intro")}catch{}if(s==="full"||s==="short"||s==="off")return s;try{return localStorage.getItem($c)?"short":"full"}catch{return"full"}}function im(){try{localStorage.setItem($c,"1")}catch{}}function am(){if(typeof document>"u"||!document.body)return null;const s=document.createElement("div");return s.id="introSkip",s.textContent="any key to drive",s.style.cssText=["position:fixed","left:0","right:0","bottom:6vh","z-index:30","text-align:center","font-family:var(--serif),Georgia,serif","font-size:0.95rem","letter-spacing:0.18em","color:rgba(246,236,216,0.7)","text-shadow:0 1px 12px rgba(0,0,0,0.55)","pointer-events:none","opacity:0","transition:opacity 1.8s ease"].join(";"),document.body.appendChild(s),setTimeout(()=>{s.style.opacity="1"},2600),s}const rm=new Uint32Array([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]),Pe=(s,t)=>(s>>>t|s<<32-t)>>>0;function cm(s){if(typeof TextEncoder<"u")return new TextEncoder().encode(s);const t=[];for(let e=0;e<s.length;e++){const n=s.charCodeAt(e);n<128?t.push(n):n<2048?t.push(192|n>>6,128|n&63):t.push(224|n>>12,128|n>>6&63,128|n&63)}return new Uint8Array(t)}function Kc(s){const t=typeof s=="string"?cm(s):s,e=t.length,n=new Uint8Array((e+8>>6)+1<<6);n.set(t),n[e]=128;const o=new DataView(n.buffer);o.setUint32(n.length-8,Math.floor(e/536870912)),o.setUint32(n.length-4,e<<3>>>0);const i=new Uint32Array([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),a=new Uint32Array(64);for(let r=0;r<n.length;r+=64){for(let v=0;v<16;v++)a[v]=o.getUint32(r+v*4);for(let v=16;v<64;v++){const x=a[v-15],b=a[v-2],y=(Pe(x,7)^Pe(x,18)^x>>>3)>>>0,A=(Pe(b,17)^Pe(b,19)^b>>>10)>>>0;a[v]=a[v-16]+y+a[v-7]+A>>>0}let l=i[0],h=i[1],u=i[2],d=i[3],f=i[4],p=i[5],g=i[6],m=i[7];for(let v=0;v<64;v++){const x=(Pe(f,6)^Pe(f,11)^Pe(f,25))>>>0,b=(f&p^~f&g)>>>0,y=m+x+b+rm[v]+a[v]>>>0,A=(Pe(l,2)^Pe(l,13)^Pe(l,22))>>>0,_=(l&h^l&u^h&u)>>>0,S=A+_>>>0;m=g,g=p,p=f,f=d+y>>>0,d=u,u=h,h=l,l=y+S>>>0}i[0]=i[0]+l>>>0,i[1]=i[1]+h>>>0,i[2]=i[2]+u>>>0,i[3]=i[3]+d>>>0,i[4]=i[4]+f>>>0,i[5]=i[5]+p>>>0,i[6]=i[6]+g>>>0,i[7]=i[7]+m>>>0}let c="";for(let r=0;r<8;r++)c+=i[r].toString(16).padStart(8,"0");return c}const lm="wanderoad.secret",hm="wanderoad.name",um="wanderoad.look",Uo=new Map;function Li(s){try{const t=globalThis.localStorage?.getItem(s);if(t!=null)return t}catch{}return Uo.has(s)?Uo.get(s):null}function Ao(s,t){Uo.set(s,t);try{globalThis.localStorage?.setItem(s,t)}catch{}}function w0(){const s=new Uint8Array(32),t=globalThis.crypto;if(t&&typeof t.getRandomValues=="function")t.getRandomValues(s);else{const n=`${Date.now()}:${globalThis.performance?.now?.()??0}:${Math.random()}:${Math.random()}`,o=Kc(n);for(let i=0;i<32;i++)s[i]=parseInt(o.slice(i*2,i*2+2),16)}let e="";for(let n=0;n<32;n++)e+=s[n].toString(16).padStart(2,"0");return e}const b0=["Amber","Cobalt","Dusty","Quiet","Distant","Salt","Paper","Copper","Slow","Wandering","Kite","Rain","Pale","Ember","Hollow","Lantern"],x0=["Fox","Heron","Kestrel","Pilot","Drifter","Sparrow","Comet","Wren","Otter","Moth","Rider","Finch","Marten","Hare","Swift","Crane"];function dm(s){const t=parseInt(s.slice(0,3),16)%b0.length,e=parseInt(s.slice(3,6),16)%x0.length,n=parseInt(s.slice(6,9),16)%100;return`${b0[t]} ${x0[e]} ${n}`}function y0(s){let t="";for(const e of String(s??"")){const n=e.codePointAt(0);n<32||n>=127&&n<=159||n>=8203&&n<=8207||n>=8232&&n<=8238||n>=8294&&n<=8297||(t+=e)}return t.replace(/\s+/g," ").trim().slice(0,18)||"Wanderer"}function fm(s){const t=String(s??"").replace(/[^a-z0-9]/gi,"").slice(0,8);return t===""||t==="1"?"":`.seat${t}`}function pm(){try{const s=new URLSearchParams(globalThis.location.search);return s.has("seat")?s.get("seat")||"2":""}catch{return""}}function mm(s=""){const t=fm(s),e=lm+t,n=hm+t,o=um+t;let i=null,a=null;function c(){if(i)return i;let g=Li(e);return(typeof g!="string"||!/^[0-9a-f]{64}$/.test(g))&&(g=w0(),Ao(e,g)),i=g,g}function r(){return a||(a=Kc(c()).slice(0,12),a)}function l(){const g=Li(n);return g?y0(g):dm(r())}function h(g){const m=y0(g);return Ao(n,m),m}function u(){const g=Li(o);if(g)try{const m=JSON.parse(g);return{tier:m.tier|0,paint:m.paint|0}}catch{}return{tier:0,paint:parseInt(r().slice(9,12),16)%8}}function d(g={}){const m=u(),v={tier:g.tier===void 0?m.tier:g.tier|0,paint:g.paint===void 0?m.paint:g.paint|0};return Ao(o,JSON.stringify(v)),v}function f(){const g=u();return{secret:c(),playerId:r(),name:l(),seat:String(s??""),look:g,tier:g.tier,paint:g.paint}}function p(){i=null,a=null,Ao(e,w0()),Uo.delete(n);try{globalThis.localStorage?.removeItem(n)}catch{}return f()}return{seat:String(s??""),getSecret:c,getPlayerId:r,getName:l,setName:h,getLook:u,setLook:d,identity:f,reset:p}}const eo=mm(pm()),gm=()=>eo.getSecret(),vm=()=>eo.getPlayerId(),wm=()=>eo.getName(),bm=()=>eo.identity(),qc=()=>eo.seat;function _0(s,t){const e=new URL(t);return s==null||s===""?e.searchParams.delete("seat"):e.searchParams.set("seat",String(s)),e.href}function xm(s=qc()){const t=parseInt(String(s||"1"),10);return String((Number.isFinite(t)?t:1)+1)}function ym(s,t={}){if(!s||typeof s.appendChild!="function")return null;const e=t.doc??globalThis.document,n=t.href??globalThis.location?.href??"http://localhost:5173/",o=t.seat??qc();if(!e)return null;const i=(p,g,m)=>{const v=e.createElement(p);return g!=null&&(v.textContent=g),m&&Object.assign(v.style,m),v},a=i("div");a.id="invite",Object.assign(a.style,{marginTop:"1rem"});const c=i("h3","Drive together"),r=i("small",o?`you are seat ${o}`:"two windows on one computer are two drivers");c.appendChild(r),a.appendChild(c);const l=i("p","Every window on this computer shares one driver, so a second one would be your own car — and you are never in your own mirror. Give the new window a seat and it becomes someone else.",{opacity:"0.72",fontSize:"0.82rem",lineHeight:"1.45",margin:"0.2rem 0 0.5rem"});a.appendChild(l);const h=xm(o),u=_0(h,n),d=_0(null,n);a.appendChild(T0(e,i,`Second window here (seat ${h})`,u,t)),a.appendChild(T0(e,i,"Someone on another computer",d,t,"their machine has its own driver, so no seat"));const f=i("p","One world, one map. You will see each other once you are within a few kilometres of the same place.",{opacity:"0.6",fontSize:"0.78rem",margin:"0.5rem 0 0"});return a.appendChild(f),s.appendChild(a),a}function T0(s,t,e,n,o,i){const a=t("div",null,{margin:"0.35rem 0"}),c=t("div",i?`${e} — ${i}`:e,{fontSize:"0.8rem",opacity:"0.85",marginBottom:"0.2rem"});a.appendChild(c);const r=t("div",null,{display:"flex",gap:"0.4rem",alignItems:"center",flexWrap:"wrap"}),l=t("span",n,{flex:"1 1 12rem",minWidth:"0",fontSize:"0.74rem",opacity:"0.75",wordBreak:"break-all",userSelect:"all"});r.appendChild(l);const h=t("button","Copy");h.setAttribute("type","button"),h.addEventListener?.("click",async()=>{let d=!1;try{const f=o.clipboard??globalThis.navigator?.clipboard;f?.writeText&&(await f.writeText(n),d=!0)}catch{}d||_m(s,l),h.textContent=d?"Copied":"Select and copy",setTimeout(()=>{h.textContent="Copy"},2200)}),r.appendChild(h);const u=t("button","Open");return u.setAttribute("type","button"),u.addEventListener?.("click",()=>{const d=o.open??globalThis.open;try{d?.(n,"_blank","noopener")}catch{}}),r.appendChild(u),a.appendChild(r),a}function _m(s,t){try{const e=s.createRange();e.selectNodeContents(t);const n=globalThis.getSelection?.();n?.removeAllRanges(),n?.addRange(e)}catch{}}const Tm=["Escape","KeyM"];class Am{constructor(t){this.hooks=t,this.open=!1,this.current={car:"coupe",feel:"road",terrain:"rolling"};const e=this.root=document.createElement("div");e.id="menu",e.hidden=!0,e.innerHTML=`
      <div class="sheet">
        <h2>Garage</h2>
        <p class="hint">Escape or M to close · everything here is also a URL parameter</p>

        <h3>Car <small>each one drives differently — unlocked by your best streak</small></h3>
        <div class="row" data-group="car"></div>

        <h3>Land <small>reloads the world</small></h3>
        <div class="row" data-group="terrain"></div>

        <div class="foot">
          <button data-act="auto">Auto-drive</button>
          <button data-act="cheat">Unlock all</button>
          <button data-act="camera">Camera: —</button>
          <button data-act="reset">Put me back on the road (R)</button>
          <a class="btn" href="./previews/">All previews</a>
          <button data-act="close">Drive</button>
        </div>
      </div>`,document.body.appendChild(e);const n=e.querySelector(".sheet"),o=ym(n);o&&n.insertBefore(o,n.querySelector(".foot")),this._fillCars(),this._fill("terrain",Object.keys(zs).map(i=>[i,zs[i].label])),e.addEventListener("click",i=>this._onClick(i)),addEventListener("keydown",i=>{Tm.includes(i.code)&&(i.preventDefault(),this.toggle())})}_fillCars(){const t=this.hooks.bestStreak?this.hooks.bestStreak():0,e=this.root.querySelector('[data-group="car"]');e.innerHTML=es.map(n=>{const o=to(n,t);return`<button data-group="car" data-key="${n.id}" title="${n.blurb}"${o?"":` class="locked" data-unlock="${Ic(n.unlockAt)}"`}>${n.label}</button>`}).join("")}_fill(t,e){const n=this.root.querySelector(`[data-group="${t}"]`);n.innerHTML=e.map(([o,i])=>`<button data-group="${t}" data-key="${o}">${i}</button>`).join("")}_mark(){for(const o of this.root.querySelectorAll("button[data-key]"))o.classList.toggle("on",this.current[o.dataset.group]===o.dataset.key);const t=this.root.querySelector('[data-act="camera"]');t&&this.hooks.camera&&(t.textContent=`Camera: ${this.hooks.camera()}`);const e=this.root.querySelector('[data-act="cheat"]');e&&(e.textContent=qn()?"Unlocks: all open":"Unlock all (testing)",e.classList.toggle("on",qn()));const n=this.root.querySelector('[data-act="auto"]');if(n&&this.hooks.isAuto){const o=this.hooks.isAuto();n.textContent=o?"Auto-drive: on (G)":"Auto-drive (G)",n.classList.toggle("on",o)}}async _onClick(t){const e=t.target.closest("button");if(!e)return;const{group:n,key:o,act:i}=e.dataset;if(i==="close")return this.hide();if(i==="reset")return this.hooks.onReset?.(),this.hide();if(i==="camera")return this.hooks.cycleCam?.(),this._mark();if(i==="cheat"){this.hooks.onCheat?.(!qn()),this._fillCars(),this._mark();return}if(i==="auto")return this.hooks.onAuto?.(),this._mark(),this.hide();if(n==="car"){const a=Qn[o],c=this.hooks.bestStreak?this.hooks.bestStreak():0;if(a&&!to(a,c))return;this.current.car=o,this._mark(),e.disabled=!0,await this.hooks.onCar?.(o),e.disabled=!1,this.hide()}else if(n==="feel")this.current.feel=o,this._mark(),this.hooks.onFeel?.(o),this.hide();else if(n==="terrain"){const a=new URLSearchParams(location.search);a.set("terrain",o),a.set("feel",this.current.feel),a.set("car",this.current.car),location.search=a.toString()}}setCurrent(t){Object.assign(this.current,t),this._mark()}show(){this._fillCars(),this.open=!0,this.root.hidden=!1,this._mark()}hide(){this.open=!1,this.root.hidden=!0}toggle(){this.open?this.hide():this.show()}}const Mm="modulepreload",Sm=function(s,t){return new URL(s,t).href},A0={},km=function(t,e,n){let o=Promise.resolve();if(e&&e.length>0){let a=function(h){return Promise.all(h.map(u=>Promise.resolve(u).then(d=>({status:"fulfilled",value:d}),d=>({status:"rejected",reason:d}))))};const c=document.getElementsByTagName("link"),r=document.querySelector("meta[property=csp-nonce]"),l=r?.nonce||r?.getAttribute("nonce");o=a(e.map(h=>{if(h=Sm(h,n),h in A0)return;A0[h]=!0;const u=h.endsWith(".css"),d=u?'[rel="stylesheet"]':"";if(!!n)for(let g=c.length-1;g>=0;g--){const m=c[g];if(m.href===h&&(!u||m.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${h}"]${d}`))return;const p=document.createElement("link");if(p.rel=u?"stylesheet":Mm,u||(p.as="script"),p.crossOrigin="",p.href=h,l&&p.setAttribute("nonce",l),document.head.appendChild(p),u)return new Promise((g,m)=>{p.addEventListener("load",g),p.addEventListener("error",()=>m(new Error(`Unable to preload CSS for ${h}`)))})}))}function i(a){const c=new Event("vite:preloadError",{cancelable:!0});if(c.payload=a,window.dispatchEvent(c),!c.defaultPrevented)throw a}return o.then(a=>{for(const c of a||[])c.status==="rejected"&&i(c.reason);return t().catch(i)})},M0=8192,jc=6e3,Em=5;function Rm({backend:s="auto",base44AppId:t=null,phpBase:e="./api/",identity:n=null}={}){const o=e.endsWith("/")?e:`${e}/`,i=n??{getSecret:gm,getName:wm,getPlayerId:vm},a={base44:t?Cm(t):null,php:zm(o),local:Lm(i)},c=s==="auto"?["base44","php","local"].filter(m=>a[m]):[s,"local"].filter((m,v,x)=>a[m]&&x.indexOf(m)===v),r={pinned:null,fails:0,lastMs:0,sent:0,errors:0,lastError:null};let l=null;const h=new Promise(m=>{l=m});function u(m){r.pinned=m,r.fails=0,l(m)}function d(m){const v=JSON.stringify({v:1,secret:i.getSecret(),name:i.getName(),t:Date.now(),...m});if(v.length>M0)throw new Error(`[net] payload ${v.length} B exceeds the ${M0} B cap`);return v}async function f(m,v){const x=Date.now(),b=await a[m].send(v);if(r.lastMs=Date.now()-x,!b||typeof b!="object")throw new Error(`[net] ${m} returned a non-object`);return b}async function p(m){const v=d(m);if(r.pinned)try{const b=await f(r.pinned,v);return r.fails=0,r.sent++,b}catch(b){if(r.fails++,r.errors++,r.lastError=String(b&&b.message?b.message:b),r.fails<Em)throw b;console.error(`[net] ${r.pinned} failed ${r.fails}x, re-probing`,r.lastError),r.pinned=null,r.fails=0}let x=null;for(const b of c)try{const y=await f(b,v);return u(b),r.sent++,y}catch(y){x=y,r.lastError=String(y&&y.message?y.message:y),b!=="local"&&console.info(`[net] ${b} not available here, trying the next backend`)}throw r.errors++,x??new Error("[net] no transport available")}function g(){return h}return{send:p,ready:g,get backend(){return r.pinned??(c[0]||"local")},info(){return{backend:r.pinned??"unresolved",chain:c.slice(),phpBase:o,appId:t,lastMs:r.lastMs,sent:r.sent,errors:r.errors,lastError:r.lastError}},close(){for(const m of Object.keys(a))a[m]?.close?.()}}}function zm(s){const t=`${s}drive.php`;return{async send(e){const n=new AbortController,o=setTimeout(()=>n.abort(),jc);try{const i=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json"},body:e,signal:n.signal,credentials:"omit",cache:"no-store"});if(!i.ok){const a=new Error(`HTTP ${i.status}`);throw a.status=i.status,a}return await i.json()}finally{clearTimeout(o)}}}}function Cm(s){let t=null;function e(){return t||(t=km(()=>import("./index-C5QPFtM6.js"),[],import.meta.url).then(n=>n.createClient({appId:s}))),t}return{async send(n){const o=await e(),i=new AbortController,a=setTimeout(()=>i.abort(),jc);try{const c=await o.functions.fetch("/drive",{method:"POST",headers:{"Content-Type":"application/json"},body:n,signal:i.signal});if(!c.ok){const r=new Error(`HTTP ${c.status}`);throw r.status=c.status,r}return await c.json()}finally{clearTimeout(a)}},close(){t?.then(n=>n.cleanup?.()).catch(()=>{}),t=null}}}function Lm(s){const t=new Map;return{async send(e){const n=JSON.parse(e),o=Date.now(),i=s.getPlayerId(),a={now:o,you:{playerId:i},peers:[],rate:.25};if(n.op==="save"&&Array.isArray(n.ops)){const c=t.get(i)??{seed:null,visited:[],ops:[]};for(const r of n.ops)Fm(c,r);t.set(i,c)}else n.op==="load"&&(a.save=t.get(i)??null);return a}}}function Fm(s,t){if(!(!t||typeof t!="object"))if(t.k==="seed")s.seed=t.v|0;else if(t.k==="visited"){const e=s.visited.findIndex(n=>n.b===t.b);e<0?s.visited.push({b:t.b,d:t.d}):s.visited[e]={b:t.b,d:Dm(s.visited[e].d,t.d)}}else s.ops.push(t),s.ops.length>4e3&&s.ops.splice(0,s.ops.length-4e3)}function Dm(s,t){const e=atob(s),n=atob(t),o=Math.max(e.length,n.length);let i="";for(let a=0;a<o;a++)i+=String.fromCharCode((e.charCodeAt(a)||0)|(n.charCodeAt(a)||0));return btoa(i)}const S0=250,Im=1.2,Pm=12,Om=11e3,Nm=24;class Bm{constructor({scene:t,buildGhostCar:e}){if(typeof e!="function")throw new Error("[remotes] buildGhostCar is required");this.scene=t,this.buildGhostCar=e,this.group=new qe,this.group.name="ghosts",this.group.frustumCulled=!1,t?.add(this.group),this.peers=new Map,this._offset=null}get count(){return this.peers.size}ingest(t,e){if(Number.isFinite(e)){const o=e-Date.now();this._offset===null||Math.abs(o-this._offset)>1500?this._offset=o:this._offset+=(o-this._offset)*.15}if(!Array.isArray(t))return;const n=Number.isFinite(e)?e:Date.now()+(this._offset??0);for(const o of t){if(!o||typeof o.id!="string")continue;let i=this.peers.get(o.id);if(!i&&(i=this._spawn(o),!i))continue;i.lastSeen=n,i.name=typeof o.name=="string"?o.name:i.name;const a=Number.isFinite(o.t)?o.t:n,c=i.buf;if(c.length&&a<=c[c.length-1].t)continue;i.placed&&(i.jumpT=Date.now()+(this._offset??0)-S0,i.preJump=Fi(i.buf,i.jumpT));const r=c.length?c[c.length-1]:null,l=Oe(o.yaw),h=r?r.yaw+ks(r.yaw,l):l,u=Oe(o.y),d=r?X((u-r.y)/((a-r.t)/1e3),-12,12):0;c.push({t:a,x:Oe(o.x),y:u,z:Oe(o.z),yaw:h,vx:Oe(o.vx),vy:d,vz:Oe(o.vz),yawRate:Oe(o.yawRate),steer:Oe(o.steer),throttle:Oe(o.throttle),brake:Oe(o.brake),flags:o.flags|0}),c.length>Nm&&c.shift(),i.corrected=!0,o.tier!==void 0&&(i.tier=o.tier|0),o.paint!==void 0&&(i.paint=o.paint|0)}}update(t,e=Date.now()){const n=e+(this._offset??0),o=n-S0;for(const[i,a]of this.peers){if(n-a.lastSeen>Om){this._despawn(i,a);continue}const c=Fi(a.buf,o);if(!c)continue;const r=a.obj;if(!a.placed)a.placed=!0,r.visible=!0,a.ex=a.ey=a.ez=a.eyaw=0;else if(a.corrected&&a.preJump){const h=Fi(a.buf,a.jumpT);h&&(a.ex=a.preJump.x+a.ex-h.x,a.ey=a.preJump.y+a.ey-h.y,a.ez=a.preJump.z+a.ez-h.z,a.eyaw=ks(h.yaw,a.preJump.yaw+a.eyaw)),Math.hypot(a.ex,a.ey,a.ez)>Pm&&(a.ex=a.ey=a.ez=a.eyaw=0),a.preJump=null}a.corrected=!1;const l=Math.exp(-9*t);a.ex*=l,a.ey*=l,a.ez*=l,a.eyaw*=l,r.position.set(c.x+a.ex,c.y+a.ey,c.z+a.ez),r.rotation.y=c.yaw+a.eyaw,a.pose=c,a.api?.update?.(c,t)}}list(){const t=pt.uCamPos.value,e=[];for(const[n,o]of this.peers){const i=o.pose,a=i?Math.hypot(i.x-t.x,i.y-t.y,i.z-t.z):1/0;e.push({id:n,name:o.name,dist:a})}return e.sort((n,o)=>n.dist-o.dist),e}nearestDistance(){const t=pt.uCamPos.value;let e=1/0;for(const n of this.peers.values()){const o=n.pose;if(!o)continue;const i=Math.hypot(o.x-t.x,o.y-t.y,o.z-t.z);i<e&&(e=i)}return e}dispose(){for(const[t,e]of this.peers)this._despawn(t,e);this.peers.clear(),this.group.parent?.remove(this.group)}_spawn(t){let e;try{e=this.buildGhostCar({id:t.id,name:typeof t.name=="string"?t.name:"",tier:t.tier|0,paint:t.paint|0})}catch(i){return console.error("[remotes] buildGhostCar threw for",t.id,i),null}const n=e?.isObject3D?e:e?.root??e?.group??e?.object;if(!n?.isObject3D)return console.error("[remotes] buildGhostCar returned no Object3D for",t.id),null;n.visible=!1,n.matrixAutoUpdate=!0,this.group.add(n);const o={id:t.id,name:typeof t.name=="string"?t.name:"",tier:t.tier|0,paint:t.paint|0,obj:n,api:e?.isObject3D?null:e,buf:[],pose:null,placed:!1,corrected:!1,preJump:null,jumpT:0,ex:0,ey:0,ez:0,eyaw:0,lastSeen:0};return this.peers.set(t.id,o),o}_despawn(t,e){this.group.remove(e.obj),e.api?.dispose?e.api.dispose():Gm(e.obj),this.peers.delete(t)}}function Oe(s){return Number.isFinite(s)?s:0}function Fi(s,t){const e=s.length;if(e===0)return null;if(e===1||t<=s[0].t)return k0(s[0],(t-s[0].t)/1e3);const n=s[e-1];if(t>=n.t)return k0(n,(t-n.t)/1e3);let o=e-2;for(;o>0&&s[o].t>t;)o--;const i=s[o],a=s[o+1],c=a.t-i.t,r=X((t-i.t)/c,0,1),l=c/1e3,h=o>0?s[o-1]:null,u=o+2<e?s[o+2]:null,d=a.y-i.y,f=h?.5*(a.y-h.y)*(c/(a.t-h.t)):d,p=u?.5*(u.y-i.y)*(c/(u.t-i.t)):d;return{x:oo(i.x,i.vx*l,a.x,a.vx*l,r),y:oo(i.y,f,a.y,p,r),z:oo(i.z,i.vz*l,a.z,a.vz*l,r),yaw:oo(i.yaw,i.yawRate*l,a.yaw,a.yawRate*l,r),steer:i.steer+(a.steer-i.steer)*r,throttle:i.throttle+(a.throttle-i.throttle)*r,brake:i.brake+(a.brake-i.brake)*r,vx:i.vx+(a.vx-i.vx)*r,vz:i.vz+(a.vz-i.vz)*r,flags:r<.5?i.flags:a.flags}}function k0(s,t){const e=X(t,0,Im);return{x:s.x+s.vx*e,y:s.y+s.vy*e,z:s.z+s.vz*e,yaw:s.yaw+s.yawRate*e,steer:s.steer,throttle:s.throttle,brake:s.brake,vx:s.vx,vz:s.vz,flags:s.flags}}function Gm(s){s.traverse(t=>{t.geometry?.dispose?.();const e=t.material;Array.isArray(e)?e.forEach(n=>n.dispose?.()):e?.dispose?.()})}const Mo=4096,zt=16,E0=zt*zt/8,Um=2e4,R0=5800,z0=4e3,Hm="wanderoad",Vs="save";class Wm{constructor({seed:t,transport:e}){this.seed=t>>>0,this.transport=e,this.visited=new Map,this.dirtyBlocks=new Set,this.pending=[],this.ops=[],this._seq=0,this._timer=null,this._inflight=null,this._db=null,this._stats={uploads:0,uploadErrors:0,lastUpload:0,lastLocal:0},this.pending.push({k:"seed",v:this.seed})}markVisited(t,e){const n=Math.floor(t/Mo),o=Math.floor(e/Mo),i=Math.floor(n/zt),a=Math.floor(o/zt),c=`${i},${a}`;let r=this.visited.get(c);r||(r=new Uint8Array(E0),this.visited.set(c,r));const l=(n%zt+zt)%zt,u=(o%zt+zt)%zt*zt+l,d=1<<(u&7),f=u>>3;return r[f]&d?!1:(r[f]|=d,this.dirtyBlocks.add(c),this._touch(),!0)}isVisited(t,e){const n=Math.floor(t/Mo),o=Math.floor(e/Mo),i=this.visited.get(`${Math.floor(n/zt)},${Math.floor(o/zt)}`);if(!i)return!1;const a=(n%zt+zt)%zt,r=(o%zt+zt)%zt*zt+a;return(i[r>>3]&1<<(r&7))!==0}note(t){if(!t||typeof t!="object")throw new Error("[save] note() needs an object");const e={...t,n:++this._seq,t:Date.now()};return this.ops.push(e),this.pending.push(e),this.ops.length>z0&&this.ops.splice(0,this.ops.length-z0),this._touch(),e}_touch(){this._writeLocal(),this._timer===null&&typeof setTimeout=="function"&&(this._timer=setTimeout(()=>{this._timer=null,this.flush().catch(()=>{})},Um))}flush(){return this._inflight?this._inflight:(this._inflight=this._flushOnce().finally(()=>{this._inflight=null}),this._inflight)}async _flushOnce(){if(!this.transport)return{sent:0,more:!1};let t=0;for(let e=0;e<6;e++){const n=this._takeBatch();if(n.ops.length===0)break;try{await this.transport.send({op:"save",seed:this.seed,ops:n.ops})}catch(o){throw this._stats.uploadErrors++,console.error("[save] upload failed, keeping the local copy",o?.message??o),o}this._stats.uploads++,this._stats.lastUpload=Date.now();for(const o of n.blocks)this.dirtyBlocks.delete(o);this.pending.splice(0,n.opCount),t+=n.ops.length}return{sent:t,more:this.pending.length+this.dirtyBlocks.size>0}}_takeBatch(){const t=[],e=[];let n=0;for(const i of this.dirtyBlocks){const a={k:"visited",b:i,d:C0(this.visited.get(i))},c=JSON.stringify(a).length+1;if(n+c>R0)break;t.push(a),e.push(i),n+=c}let o=0;for(const i of this.pending){const a=JSON.stringify(i).length+1;if(n+a>R0)break;t.push(i),n+=a,o++}return{ops:t,blocks:e,opCount:o}}async load(){const t=await this._readLocal();if(t&&this._absorb(t),this.transport)try{const e=await this.transport.send({op:"load",seed:this.seed});e?.save&&this._absorb(e.save)}catch(e){console.error("[save] remote load failed, using the local copy",e?.message??e)}return{seed:this.seed,visited:this.visited.size,ops:this.ops.length}}_absorb(t){if(!t||typeof t!="object")return;if(Number.isFinite(t.seed)&&t.seed>>>0!==this.seed){console.error(`[save] ignoring a save for seed ${t.seed>>>0}, this world is ${this.seed}`);return}for(const n of t.visited??[]){const o=Km(n.d);if(!o)continue;const i=this.visited.get(n.b);if(!i)this.visited.set(n.b,o);else for(let a=0;a<i.length&&a<o.length;a++)i[a]|=o[a]}const e=new Set(this.ops.map(n=>n.n));for(const n of t.ops??[])!n||e.has(n.n)||(this.ops.push(n),e.add(n.n),n.n>this._seq&&(this._seq=n.n));this.ops.sort((n,o)=>(n.n??0)-(o.n??0))}stats(){let t=0;for(const e of this.visited.values())for(let n=0;n<e.length;n++)t+=$m(e[n]);return{seed:this.seed,regions:t,blocks:this.visited.size,ops:this.ops.length,pending:this.pending.length+this.dirtyBlocks.size,bytes:this.visited.size*E0+JSON.stringify(this.ops).length,uploads:this._stats.uploads,uploadErrors:this._stats.uploadErrors,lastUpload:this._stats.lastUpload,lastLocal:this._stats.lastLocal}}dispose(){this._timer!==null&&(clearTimeout(this._timer),this._timer=null)}_openDb(){if(this._db)return this._db;const t=globalThis.indexedDB;return t?(this._db=new Promise(e=>{let n;try{n=t.open(Hm,1)}catch{e(null);return}n.onupgradeneeded=()=>{n.result.objectStoreNames.contains(Vs)||n.result.createObjectStore(Vs)},n.onsuccess=()=>e(n.result),n.onerror=()=>e(null),n.onblocked=()=>e(null)}),this._db):(this._db=Promise.resolve(null),this._db)}async _writeLocal(){const t=await this._openDb();if(!t)return;const e=this._serialise();try{const n=t.transaction(Vs,"readwrite");n.objectStore(Vs).put(e,`seed:${this.seed}`),n.oncomplete=()=>{this._stats.lastLocal=Date.now()},n.onerror=()=>console.error("[save] IndexedDB write failed")}catch(n){console.error("[save] IndexedDB transaction failed",n?.message??n)}}async _readLocal(){const t=await this._openDb();return t?new Promise(e=>{try{const o=t.transaction(Vs,"readonly").objectStore(Vs).get(`seed:${this.seed}`);o.onsuccess=()=>e(o.result??null),o.onerror=()=>e(null)}catch{e(null)}}):null}_serialise(){const t=[];for(const[e,n]of this.visited)t.push({b:e,d:C0(n)});return{seed:this.seed,visited:t,ops:this.ops}}}function $m(s){return s=s-(s>>1&85),s=(s&51)+(s>>2&51),s+(s>>4)&15}function C0(s){let t="";for(let e=0;e<s.length;e++)t+=String.fromCharCode(s[e]);return btoa(t)}function Km(s){if(typeof s!="string")return null;let t;try{t=atob(s)}catch{return null}const e=new Uint8Array(t.length);for(let n=0;n<t.length;n++)e[n]=t.charCodeAt(n);return e}const qm={open:[0,2,4,7,9],still:[0,3,5,7,10]},L0={open:[0,3,4,2],still:[0,4,2,3]},Ys=[{id:"off",label:"Radio off",scale:null},{id:"valley",label:"Valley",scale:"open",root:55,chordSecs:22,bellRate:.16,drone:.5},{id:"longway",label:"The Long Way",scale:"still",root:51.9,chordSecs:26,bellRate:.1,drone:.7}],Di=(s,t)=>s*Math.pow(2,t/12);class jm{constructor(t,e,{volume:n=.5}={}){this.ctx=t,this.station=0,this._t=0,this._chordT=1e9,this._bellT=0,this._chord=0,this.out=t.createGain(),this.out.gain.value=0,this.tone=t.createBiquadFilter(),this.tone.type="lowpass",this.tone.frequency.value=1600,this.tone.Q.value=.4,this.out.connect(this.tone).connect(e);const o=Math.floor(t.sampleRate*2.6),i=t.createBuffer(2,o,t.sampleRate);for(let a=0;a<2;a++){const c=i.getChannelData(a);for(let r=0;r<o;r++)c[r]=(Math.random()*2-1)*Math.pow(1-r/o,3.2)}this.verb=t.createConvolver(),this.verb.buffer=i,this.verbGain=t.createGain(),this.verbGain.gain.value=.55,this.verb.connect(this.verbGain).connect(this.tone),this.volume=n}get label(){return Ys[this.station].label}get on(){return Ys[this.station].scale!==null}next(){this.station=(this.station+1)%Ys.length;const t=Ys[this.station].scale!==null;return this.out.gain.setTargetAtTime(t?this.volume*.16:0,this.ctx.currentTime,.5),this._chordT=1e9,this.label}setVolume(t){this.volume=N(t),Ys[this.station].scale&&this.out.gain.setTargetAtTime(this.volume*.16,this.ctx.currentTime,.3)}_voice(t,e,n,o,i="triangle",a=0){const c=this.ctx,r=c.createOscillator();r.type=i,r.frequency.value=t,r.detune.value=a;const l=c.createGain();l.gain.setValueAtTime(0,e),l.gain.linearRampToValueAtTime(o,e+n*.34),l.gain.exponentialRampToValueAtTime(1e-4,e+n),r.connect(l),l.connect(this.out),l.connect(this.verb),r.start(e),r.stop(e+n+.05)}update(t,e=1){const n=Ys[this.station];if(!n.scale)return;const o=this.ctx;if(!o||o.state!=="running")return;this._t+=t,this._chordT+=t,this._bellT+=t;const i=qm[n.scale],a=L0[n.scale];if(this._chordT>=n.chordSecs){this._chordT=0,this._chord=(this._chord+1)%a.length;const r=a[this._chord],l=o.currentTime+.05,h=n.chordSecs*1.25;for(const[u,d,f]of[[r,0,.16],[(r+2)%i.length,0,.11],[(r+4)%i.length,1,.08]]){const p=Di(n.root,i[u]+12*d);this._voice(p,l,h,f,"triangle",-5),this._voice(p,l,h,f*.8,"triangle",6)}this._voice(Di(n.root,i[r]-12),l,h,.09*n.drone,"sine")}const c=n.bellRate*O(.25,1,N(e));if(this._bellT>1/Math.max(c,.01)){this._bellT=0;const r=L0[n.scale][this._chord],l=i[(r+(Math.random()*i.length|0))%i.length],h=12*(1+(Math.random()*2|0));this._voice(Di(n.root,l+h),o.currentTime+.02,3.4,.055,"sine")}}}const Zs=12,Js=[25,55,100,165,250,360,500],se=1+Zs*Js.length,Vm=240,F0=8,D0=600,I0=150,P0=70;class Ym{constructor(t){this.seed=t>>>0,this._px=new Float64Array(se),this._pz=new Float64Array(se),this._wet=new Uint8Array(se),this._fb=new Float32Array(se),this._trees=new Float32Array(se),this._live=new Uint8Array(se),this._ox=new Float32Array(se),this._oz=new Float32Array(se),this._inner=new Int16Array(se);let e=1;for(let n=0;n<Js.length;n++){const o=Js[n];for(let i=0;i<Zs;i++){const a=(i+n%2*.5)/Zs*Math.PI*2;this._ox[e]=Math.sin(a)*o,this._oz[e]=Math.cos(a)*o,e++}}this._inner[0]=0;for(let n=1;n<se;n++){const o=(n-1)/Zs|0;if(o===0){this._inner[n]=0;continue}const i=this._ox[n]/Js[o],a=this._oz[n]/Js[o];let c=0,r=-2;for(let l=0;l<Zs;l++){const h=1+(o-1)*Zs+l,u=(this._ox[h]*i+this._oz[h]*a)/Js[o-1];u>r&&(r=u,c=h)}this._inner[n]=c}this._cursor=0,this._acc=0,this._w=new Float32Array(_t),this.seaDist=1/0,this.seaExtent=0,this.seaRight=0,this.trees=0,this.treeRight=0}_probe(t,e,n){const o=e+this._ox[t],i=n+this._oz[t],a=fa(o,i,this.seed,this._w),c=Ls(a.w,-1/0),r=Xn(o,i,this.seed),l=c===null?1e9:r-c,h=l<0;this._px[t]=o,this._pz[t]=i,this._fb[t]=l,this._wet[t]=h?1:0,this._trees[t]=h?0:Oo(o,i,this.seed)*ic(a.w,$o,"trees"),this._live[t]=1}prime(t,e){for(let n=0;n<se;n++)this._probe(n,t,e);this._cursor=0,this._acc=0}update(t,e,n,o){this._acc+=t*Vm;let i=Math.min(this._acc|0,F0);for(this._acc-=i,this._acc>F0&&(this._acc=0);i-- >0;)this._probe(this._cursor,e,n),this._cursor=(this._cursor+1)%se;this.read(e,n,o)}read(t,e,n){const o=Math.sin(n),i=Math.cos(n);let a=1/0,c=0,r=0,l=0,h=0,u=0,d=0,f=0,p=0,g=0,m=0;for(let b=0;b<se;b++){if(!this._live[b])continue;const y=this._px[b]-t,A=this._pz[b]-e,_=Math.sqrt(y*y+A*A),S=1/(1+_/D0*(_/D0));if(c+=S,this._wet[b]){r+=S;let k=_;const R=this._inner[b],P=this._fb[R];if(R!==b&&this._live[R]&&P>0){const U=N(P/(P-this._fb[b])),W=this._px[R]+(this._px[b]-this._px[R])*U-t,I=this._pz[R]+(this._pz[b]-this._pz[R])*U-e;k=Math.sqrt(W*W+I*I)}k<a&&(a=k);const z=1/(1+_/I0*(_/I0)),L=_>.001?z/_:0;l+=y*L,h+=A*L,u+=z}const T=this._trees[b],M=1/(1+_/P0*(_/P0));if(d+=T*M,f+=M,T>0&&_>.001){const k=T*M/_;p+=y*k,g+=A*k,m+=T*M}}this.seaDist=a,this.seaExtent=c>0?r/c:0,this.trees=f>0?d/f:0;const v=Math.sqrt(l*l+h*h);this.seaRight=v>1e-6?X((h*o-l*i)/v,-1,1)*N(v/(u||1)):0;const x=Math.sqrt(p*p+g*g);this.treeRight=x>1e-6?X((g*o-p*i)/x,-1,1)*N(x/(m||1)):0}}const Ii=540,Xm=95,Zm=1.35,Jm=.075;function Qm(s,t=1){if(!(s<Ii))return 0;const e=1/(1+Math.pow(s/Xm,Zm)),n=mt(Ii,Ii*.82,s),o=O(.5,1,mt(.02,.22,t));return Jm*e*n*o}const t2=.055,e2=.5;function s2(s){return t2*mt(.8,24,s)}function n2(s){return e2*Math.pow(N(s/45),.75)}function O0(s,t,e,n){return O(1,t,mt(11,40,Math.abs(s)))*(e?n:1)}const o2=.5,i2=.2,a2=.78,r2=.7,N0=[[1,1.28,.09,0,.26],[2,1.22,.07,.075,.2],[3,1,.055,.055,.16],[2,.72,.12,.1,.3],[4,1.06,.045,.05,.14]],B0=4;class c2{constructor(t,e,n,o){this.ctx=t,this.field=new Ym(o),this._sea=0,this._birdG=0,this._birdRate=0,this._birdPhase=0,this._nextThresh=.7,this._voice=0,this._primed=!1,this.out=t.createGain(),this.out.gain.value=1,this.out.connect(e);const i=t.createBufferSource();i.buffer=n,i.loop=!0,i.start(),this.noise=i,this.seaHP=t.createBiquadFilter(),this.seaHP.type="highpass",this.seaHP.frequency.value=150,this.seaHP.Q.value=.707,this.seaLow=t.createBiquadFilter(),this.seaLow.type="lowpass",this.seaLow.frequency.value=420,this.seaLow.Q.value=.707,this.seaHiss=t.createBiquadFilter(),this.seaHiss.type="bandpass",this.seaHiss.frequency.value=1500,this.seaHiss.Q.value=.65,this.hissGain=t.createGain(),this.hissGain.gain.value=0,this.swell=t.createGain(),this.swell.gain.value=.68,this.lfoDepth=[];for(const[a,c]of[[.0833,.22],[.0521,.13]]){const r=t.createOscillator();r.type="sine",r.frequency.value=a;const l=t.createGain();l.gain.value=c,r.connect(l).connect(this.swell.gain),r.start(),this.lfoDepth.push({g:l,depth:c})}this.seaGainNode=t.createGain(),this.seaGainNode.gain.value=0,this.seaPan=t.createStereoPanner?t.createStereoPanner():null,i.connect(this.seaHP),this.seaHP.connect(this.seaLow).connect(this.swell),this.seaHP.connect(this.seaHiss).connect(this.hissGain).connect(this.swell),this.swell.connect(this.seaGainNode),this.seaPan?this.seaGainNode.connect(this.seaPan).connect(this.out):this.seaGainNode.connect(this.out),this.birdBus=t.createGain(),this.birdBus.gain.value=1,this.birdBus.connect(this.out),this.voices=[];for(let a=0;a<B0;a++){const c=t.createOscillator();c.type="sine",c.frequency.value=3e3;const r=t.createGain();r.gain.value=0;const l=t.createStereoPanner?t.createStereoPanner():null;l?c.connect(r).connect(l).connect(this.birdBus):c.connect(r).connect(this.birdBus),c.start(),this.voices.push({o:c,g:r,p:l})}}update(t,e,n){const o=this.ctx;if(!o||o.state!=="running")return;this._primed||(this.field.prime(e.x,e.z),this._primed=!0);const i=this.field;i.update(t,e.x,e.z,e.yaw);const a=o.currentTime,c=.35,r=Qm(i.seaDist,i.seaExtent)*O0(e.speed,o2,n,a2);this._sea=kt(this._sea,r,1.6,t),this.seaGainNode.gain.setTargetAtTime(this._sea,a,c);const l=N(1-i.seaDist/220),h=mt(.04,.3,i.seaExtent);this.seaLow.frequency.setTargetAtTime(420+l*1700,a,c),this.hissGain.gain.setTargetAtTime(.8*l*l*h,a,c);for(let d=0;d<this.lfoDepth.length;d++){const f=this.lfoDepth[d];f.g.gain.setTargetAtTime(f.depth*O(.3,1,h),a,c)}this.seaPan&&this.seaPan.pan.setTargetAtTime(i.seaRight*.8*(1-.5*i.seaExtent),a,.25);const u=O0(e.speed,i2,n,r2);this._birdG=kt(this._birdG,s2(i.trees)*u,1.2,t),this._birdRate=kt(this._birdRate,n2(i.trees),1.2,t),this._birdPhase+=t*this._birdRate,this._birdPhase>=this._nextThresh&&(this._birdPhase=0,this._nextThresh=.35+Math.random()*1.3,this._birdG>.0015&&this._call(i.treeRight))}_call(t){const e=this.ctx,n=this.voices[this._voice];this._voice=(this._voice+1)%B0;const o=N0[Math.random()*N0.length|0],i=o[0],a=o[1],c=o[2],r=o[3],l=o[4],h=2100+Math.random()*1800,u=this._birdG*(.7+Math.random()*.5),d=e.currentTime+.02;n.o.frequency.cancelScheduledValues(d),n.g.gain.cancelScheduledValues(d),n.g.gain.setValueAtTime(0,d),n.p&&n.p.pan.setValueAtTime(X(t*.85+(Math.random()-.5)*.5,-1,1),d);let f=d;for(let p=0;p<i;p++){const g=h*(1+(Math.random()-.5)*.06);n.o.frequency.setValueAtTime(g,f),n.o.frequency.exponentialRampToValueAtTime(g*a,f+c),n.g.gain.setValueAtTime(0,f),n.g.gain.linearRampToValueAtTime(u,f+.012),n.g.gain.exponentialRampToValueAtTime(1e-5,f+c+l),f+=c+l*.45+r}}setVolume(t){this.out&&this.out.gain.setTargetAtTime(N(t),this.ctx.currentTime,.2)}}class l2{constructor({volume:t=.38,seed:e=null}={}){this.ctx=null,this.volume=t,this.seed=e,this.enabled=!0,this._started=!1,this._limitSmooth=0;const n=()=>this.start();for(const o of["pointerdown","keydown","touchstart"])addEventListener(o,n,{once:!0,passive:!0})}start(){if(this._started||!this.enabled)return;const t=window.AudioContext||window.webkitAudioContext;if(!t)return;this._started=!0;const e=this.ctx=new t,n=this.master=e.createGain();n.gain.value=this.volume,n.connect(e.destination),this.engGain=e.createGain(),this.engGain.gain.value=0;const o=e.createBiquadFilter();o.type="lowpass",o.frequency.value=420,o.Q.value=.8,this.engFilter=o,this.engGain.connect(o).connect(n),this.oscs=[];for(const[h,u,d]of[["sawtooth",.5,.5],["sawtooth",1,.34],["triangle",2,.06],["sine",.25,.42]]){const f=e.createOscillator();f.type=h;const p=e.createGain();p.gain.value=d,f.connect(p).connect(this.engGain),f.start(),this.oscs.push({o:f,mul:u})}const i=e.createBufferSource(),a=e.sampleRate*2,c=e.createBuffer(1,a,e.sampleRate),r=c.getChannelData(0);let l=0;for(let h=0;h<a;h++){const u=Math.random()*2-1;l=.99*l+.01*u,r[h]=l*3.5+u*.25}i.buffer=c,i.loop=!0,i.start(),this.noise=i,this._noiseBuf=c,this.windFilter=e.createBiquadFilter(),this.windFilter.type="bandpass",this.windFilter.frequency.value=700,this.windFilter.Q.value=.5,this.windGain=e.createGain(),this.windGain.gain.value=0,i.connect(this.windFilter).connect(this.windGain).connect(n),this.roadFilter=e.createBiquadFilter(),this.roadFilter.type="bandpass",this.roadFilter.frequency.value=180,this.roadFilter.Q.value=1.6,this.roadGain=e.createGain(),this.roadGain.gain.value=0,i.connect(this.roadFilter).connect(this.roadGain).connect(n),this.scrubFilter=e.createBiquadFilter(),this.scrubFilter.type="bandpass",this.scrubFilter.frequency.value=1100,this.scrubFilter.Q.value=2.6,this.scrubGain=e.createGain(),this.scrubGain.gain.value=0,i.connect(this.scrubFilter).connect(this.scrubGain).connect(n),this.radio=new jm(e,n)}_ensureAmbience(t){if(this.ambience||!this._noiseBuf)return;const e=this.seed??t?.terrain?.seed;e!=null&&(this.ambience=new c2(this.ctx,this.master,this._noiseBuf,e),this._ambienceBuilds=(this._ambienceBuilds||0)+1)}update(t,e){const n=this.ctx;if(!n||n.state==="suspended")return;const o=n.currentTime,i=.06,a=Math.abs(e.speed),c=N((e.rpm-900)/(e.spec.redline-900)),r=26+c*48;for(const{o:f,mul:p}of this.oscs)f.frequency.setTargetAtTime(r*p,o,i);const l=N(e.throttle*.85+c*.3);this.engGain.gain.setTargetAtTime(.032+l*.1,o,i),this.engFilter.frequency.setTargetAtTime(260+l*640+c*240,o,i);const h=Math.pow(N((a-15)/60),1.4);this.windGain.gain.setTargetAtTime(h*.085,o,i),this.windFilter.frequency.setTargetAtTime(330+a*4.5,o,i);const u=e.surfaceKind==="tarmac"?.35:1;this.roadGain.gain.setTargetAtTime(N(a/26)*.062*(.6+u),o,i),this.roadFilter.frequency.setTargetAtTime(78+a*3.2,o,i),this.roadFilter.Q.setTargetAtTime(O(2.4,.9,u),o,i),this._limitSmooth=O(this._limitSmooth,e.limit,Math.min(1,t*12));const d=N((this._limitSmooth-.72)/.28);if(this.scrubGain.gain.setTargetAtTime(d*d*.1*N(a/8),o,.03),this.scrubFilter.frequency.setTargetAtTime(900+d*620,o,i),this.radio){const f=N(1-Math.max(e.limit,Math.abs(e.slip)/.5)*1.2);this.radio.update(t,f)}this._ensureAmbience(e),this.ambience&&this.ambience.update(t,e,this.radio?this.radio.on:!1)}nextStation(){return this.start(),this.radio?this.radio.next():"no audio"}horn(){const t=this.ctx;if(!t)return;const e=t.currentTime;for(const[n,o]of[[392,0],[523.25,.11]]){const i=t.createOscillator();i.type="triangle",i.frequency.value=n;const a=t.createGain();a.gain.setValueAtTime(0,e+o),a.gain.linearRampToValueAtTime(.16,e+o+.02),a.gain.exponentialRampToValueAtTime(1e-4,e+o+.42),i.connect(a).connect(this.master),i.start(e+o),i.stop(e+o+.5)}}thump(t=.5){const e=this.ctx;if(!e)return;const n=e.currentTime,o=e.createOscillator();o.type="sine",o.frequency.setValueAtTime(140+90*t,n),o.frequency.exponentialRampToValueAtTime(48,n+.24);const i=e.createGain();i.gain.setValueAtTime(X(t,.05,1)*.4,n),i.gain.exponentialRampToValueAtTime(1e-4,n+.3),o.connect(i).connect(this.master),o.start(n),o.stop(n+.34)}chime(){const t=this.ctx;if(!t)return;const e=t.currentTime;[[659.25,0],[987.77,.14]].forEach(([n,o])=>{const i=t.createOscillator();i.type="sine",i.frequency.value=n;const a=t.createGain();a.gain.setValueAtTime(0,e+o),a.gain.linearRampToValueAtTime(.09,e+o+.03),a.gain.exponentialRampToValueAtTime(1e-4,e+o+.9),i.connect(a).connect(this.master),i.start(e+o),i.stop(e+o+1)})}setVolume(t){this.volume=N(t),this.master&&(this.master.gain.value=this.volume)}dispose(){this.ctx&&this.ctx.close().catch(()=>{}),this.ctx=null}}const nn=s=>document.querySelector(s),as=(s,t)=>{const e=nn("#stat");e&&(e.textContent=s),t!==void 0&&nn("#barIn")&&(nn("#barIn").style.width=`${t*100|0}%`)},Qo=new URLSearchParams(location.search),Ft=(parseInt(Qo.get("seed")??"",10)||20260726)>>>0,h2=Qo.has("debug"),u2=Qo.has("offline"),ls=Fp();ls.cheat&&Fc(!0);const Lo=np(),G0=Dc(Lo),d2=Cp(ls.terrain);Ph(Lp(ls.terrain));async function f2(){as("warming the engine…",.04);const s=document.createElement("canvas");nn("#app").appendChild(s);const t=Qo.has("probe"),e=new Fl({canvas:s,antialias:!1,powerPreference:"high-performance",stencil:!1,preserveDrawingBuffer:t});if(!e.capabilities.isWebGL2){as("this browser has no WebGL2 — try Chrome, Edge or Firefox");return}const n=Math.min(devicePixelRatio||1,1.75);e.setPixelRatio(n),e.setSize(innerWidth,innerHeight,!1),e.outputColorSpace=an,e.toneMapping=0;const o=new Ho,i=new Z0(64,innerWidth/innerHeight,.28,16e3),a=new lh(e,{width:innerWidth,height:innerHeight,pixelRatio:n});o.add($l()),as("drawing the map…",.14);const c=Vl(),r=new yh({seed:Ft,scene:o}),l=new Cd({seed:Ft,scene:o}),h=new Wp,u=new ff({seed:Ft,material:c,viewDistance:6800,terrain:ls.terrain,onChunk:Y=>{if(Y.water&&r.add(Y),Y.level<=Zn){const j=yc({cx:Y.cx,cz:Y.cz,level:Y.level,seed:Ft});l.add(Y,j),Y.level===0&&h.addChunk(`${Y.cx},${Y.cz}`,$p(j))}},onRelease:Y=>{r.remove(Y),l.remove(Y),Y.level===0&&h.removeChunk(`${Y.cx},${Y.cz}`)}});o.add(u.group);const d=new Lh({renderer:e,scene:o,seed:Ft}),f=new $d({seed:Ft,scene:o}),p=new rd(e,{seed:Ft}),g=new hf({seed:Ft,scene:o,wind:p});as("finding a road…",.34);const m=lr(Ft);u.forceChunk(m.x,m.z);let v=new Re(Ft,m.x-420,m.z-420,m.x+420,m.z+420),x=m.x,b=m.z;const y=(Y,j)=>((Math.abs(Y-x)>240||Math.abs(j-b)>240)&&(v=new Re(Ft,Y-420,j-420,Y+420,j+420),x=Y,b=j),v);as("unloading the car…",.52);const A=bm(),_=new dp({tier:Lo.tier,terrain:v,preset:G0.assist});_.placeAt(m.x,m.z,m.heading);const S=Lo.id;let T;try{T=await Yr({car:S,paint:A.look?.paint??0,base:new URL("./models/cars/",location.href).href})}catch(Y){console.error("[car] model failed to load, using the built-in body",Y?.message??Y),T=gf({tier:Lo.tier,paint:A.look?.paint??0})}o.add(T.group);const M=new pp(i,{mode:"sport"}),k=new fp(window);k.attachTouch(s);const R=new bp,P=new Ep;let z=null;const L=new Y1;z=new Ap({scene:o});const U=new l2({seed:Ft}),W=new tm({camera:i,seed:Ft,spawn:m,terrain:v,chase:M,groundAt:(Y,j)=>_.terrain.height(Y,j),hud:L,onEnd:()=>M.reset()}),I=new L1({seed:Ft,scene:o,solids:h}),H=new W1({findStation:(Y,j)=>I.nearestStation(Y,j),say:(Y,j)=>L.say(Y,j)}),V=new K1(L.root);let D=S;async function $(Y){if(!Bo[Y]||Y===D)return;const j=Qn[Y];if(j&&!to(j,Math.max(sn(),P.state.best))){L.say(`${j.label} unlocks at ${(j.unlockAt/1e3).toFixed(1)} km`,3);return}try{const Nt=await Yr({car:Y,paint:A.look?.paint??0,base:new URL("./models/cars/",location.href).href});if(o.remove(T.group),T.dispose?.(),T=Nt,o.add(T.group),D=Y,window.WANDEROAD.model=T,j){const Ps=Dc(j);_.setTier(j.tier),_.setPreset(Ps.assist)}z.reset(_),L.say(`${Bo[Y].label} — ${j?j.blurb:""}`,3.2)}catch(Nt){console.error("[car] swap failed",Nt?.message??Nt),L.say("that one would not load",2.5)}}const q=new Am({onAuto:()=>R.toggle(_),isAuto:()=>R.on,onCar:$,bestStreak:()=>Math.max(sn(),P.state.best),onCheat:Y=>{Fc(Y),L.say(Y?"every car unlocked":"unlocks restored",2.4)},onReset:()=>ot(),camera:()=>M.mode,cycleCam:()=>M.cycle()});q.setCurrent({car:D,feel:ls.feel,terrain:ls.terrain});const Q=document.createElement("div");Q.id="openMenu",Q.textContent="ESC — garage",L.root.appendChild(Q);function ot(){const j=(_.terrain||v).roads.query(_.x,_.z);if(isFinite(j.d)&&Tu(j.qx,j.qz,Ft))_.placeAt(j.qx,j.qz,Math.atan2(j.tx,j.tz));else{const Nt=lr(Ft,_.x,_.z);_.placeAt(Nt.x,Nt.z,Nt.heading)}M.reset(),z.reset(_),L.say("back on the road",2)}const ht=new Qp({recover:ot,say:(Y,j)=>L.say(Y,j)});as("looking for company…",.7);const rt=Rm({backend:u2?"none":"auto",phpBase:new URL("./api/",location.href).href}),Tt=new Bm({scene:o,buildGhostCar:vf}),Pt=new Wm({seed:Ft,transport:rt});await Pt.load().catch(()=>{});const Wt=()=>`c${Math.round(_.x/2048)}_${Math.round(_.z/2048)}`;addEventListener("resize",()=>{e.setSize(innerWidth,innerHeight,!1),a.setSize(innerWidth,innerHeight),i.aspect=innerWidth/innerHeight,i.updateProjectionMatrix()}),addEventListener("pagehide",()=>{P.flush(),Pt.flush(),rt.send({op:"bye",cell:Wt(),car:le()}).catch(()=>{})}),document.addEventListener("visibilitychange",()=>{document.hidden&&(P.flush(),Pt.flush())});let Ot=null;h2&&(Ot=document.createElement("div"),Ot.id="debug",document.body.appendChild(Ot));const le=()=>({x:_.x,y:_.y,z:_.z,yaw:_.yaw,vx:_.vx,vy:_.vy,vz:_.vz,yawRate:_.yawRate,steer:_.steer,throttle:_.throttle,brake:_.brake,gear:_.gear,tier:_.tier,paint:A.look?.paint??0,flags:(_.onGround?0:1)|(_.handbrake>.5?2:0)});let ze="offline",gt=0;async function Fs(Y){if(!(Y<gt)){gt=Y+4e3;try{const j=await rt.send({op:"tick",cell:Wt(),car:le()});if(!j){ze="offline";return}ze=rt.backend==="local"?"solo":"online",j.peers&&Tt.ingest(j.peers,j.now),gt=performance.now()+1e3/Math.max(.05,Math.min(j.rate||.25,10))}catch{ze="offline",gt=performance.now()+8e3}}}let Ds=performance.now(),un=0,dn=Ds,Is=0,so=!1;const no=new lt;function Lt(Y){requestAnimationFrame(Lt);const j=Math.min((Y-Ds)/1e3,.1);Ds=Y;const Nt=k.poll();if(k.tapped("camera")&&L.say(`camera: ${M.cycle()}`,1.6),k.tapped("reverse")&&(_.reverse=!_.reverse),k.tapped("nextCar")){const he=Math.max(sn(),P.state.best),xe=es.filter(Ve=>to(Ve,he)).map(Ve=>Ve.id);if(xe.length<2)L.say("one car so far — drive further to unlock more",2.6);else{const Ve=xe.indexOf(D),pn=xe[(Ve+1)%xe.length];q.setCurrent({car:pn}),$(pn)}}k.tapped("horn")&&U.horn(),k.tapped("radio")&&L.say(U.nextStation(),2.4),k.tapped("autodrive")&&L.say(R.toggle(_)?"auto-drive on — sit back":"auto-drive off",2.4),k.tapped("reset")&&ot();for(const[he,xe]of[["Digit1","cruise"],["Digit2","sport"],["Digit3","off"],["Digit4","hardcore"]])k.pressed.has(he)&&(_.setPreset(xe),L.say(`assists: ${xe}`,2));_.terrain=y(_.x,_.z);const Ps=R.on,ti=R.update(_,Nt,j)||Nt;Ps&&!R.on&&L.say(R.lastReason||"auto-drive off",2.2),q.open||H.update(j,_),q.open||_.update(j,H.gate(ti));const Ce=h.resolve(_,1.05,j);Ce&&Ce.severity>.35&&Ce.speed>9&&(U.thump(Math.min(1,Ce.severity*Ce.speed/40)),P.update(2,_,{onRoad:0}),L.say("ouch",1.4));const ss=_.terrain.surface(_.x,_.z);q.open||ht.update(j,_,ss),P.update(j,_,ss),z.update(j,_,P.state),T.group.position.set(_.x,_.y-.36,_.z),T.group.rotation.set(0,_.yaw,0),T.setBodyRoll(_.roll,_.pitch),T.setSteer(_.steerAngle||0),T.setWheelSpin(_.wheelSpin),T.setBrakeGlow(_.brake);let fn=0;if(W.active&&((k.pressed.size||Nt.throttle>.05||Nt.brake>.05||Math.abs(Nt.steer)>.05)&&W.skip(),W.update(j,_)),W.active||(fn=M.update(_,j,(he,xe)=>_.terrain.height(he,xe),{drift:R.on})),pt.uTime.value=Y/1e3,pt.uCamPos.value.copy(i.position),i.getWorldDirection(no),pt.uCull.value.set(no.x,no.z,Math.cos(1.15),0),u.update(_.x,_.z),f.update(_.x,_.z),p.update(j,i.position),g.update(_.x,_.z,_.y,j),d.update(j,i.position),r.update(j,i.position),l.update(j,i.position),I.update(j,_.x,_.z),Pt.markVisited(_.x,_.z),Tt.update(j,Y),Fs(Y),U.update(j,_),a.speed=fn,a.limit=_.limit,L.update(j,{car:_,streak:P,surface:ss,remotes:Tt,netState:ze}),V.update(j,H,_),a.render(o,i),k.endFrame(),un++,Y-dn>500&&(Is=un*1e3/(Y-dn),un=0,dn=Y,Ot)){const he=u.stats;Ot.textContent=`fps ${Is.toFixed(0)}  live ${he.live}  queue ${he.queued}  built ${he.built}  wk ${he.workers}
pos ${_.x.toFixed(0)}, ${_.z.toFixed(0)}  ${_.kph.toFixed(0)} km/h  g${_.gear}  slip ${(_.slip*180/Math.PI).toFixed(0)}°  limit ${_.limit.toFixed(2)}
road ${ss.onRoad.toFixed(2)}  grip ${ss.grip.toFixed(2)}  ${Wi[ss.dominant]}  solids ${h.count}
calls ${e.info.render.calls}  tris ${e.info.render.triangles/1e3|0}k  net ${ze}  peers ${Tt.count}`}!so&&u.stats.live>14&&(so=!0,as("go anywhere.",1),setTimeout(()=>{nn("#veil").classList.add("gone"),nn("#hud").hidden=!1,W.begin(),(ls.feel!=="road"||ls.terrain!=="rolling")&&L.say(`${G0.label} · ${d2.label}`,4.5)},500))}requestAnimationFrame(Lt),window.THREE=Dl,window.WANDEROAD={renderer:e,scene:o,camera:i,streamer:u,car:_,model:T,chase:M,cine:W,streak:P,auto:R,trail:z,fleet:es,solids:h,flora:l,remotes:Tt,post:a,props:I,fuel:H,SEED:Ft,stats:()=>u.stats,fps:()=>Is,drive:Y=>Object.assign(window.WANDEROAD._auto||(window.WANDEROAD._auto={}),Y)}}f2().catch(s=>{console.error(s),as(`boot failed: ${s.message}`)});
