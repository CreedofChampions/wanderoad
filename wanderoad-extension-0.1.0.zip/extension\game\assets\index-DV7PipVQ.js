import{C as oe,V as Y,M as Oe,a as ct,b as Os,R as pt,B as ba,c as bt,d as ya,F as On,N as nn,L as Ft,H as Mn,U as Tn,e as Qt,f as G,S as ie,g as Bn,h as Vs,W as ps,i as Ut,j as Mt,k as ms,O as ge,D as Jt,l as Gn,A as Bs,m as wi,Z as xi,n as bi,o as yi,p as _i,I as pe,q as _s,r as Mi,s as Ti,Q as Un,t as _a,u as Ma,v as Ta,G as ne,T as Sa,w as Sn,x as Si,y as Aa,z as ds,E as Ai,J as te,K as Be,P as ka,X as Ra,Y as Ea,_ as Ca,$ as za,a0 as La,a1 as Da,a2 as Fa,a3 as Ia,a4 as ki,a5 as An,a6 as Pa,a7 as Na,a8 as on,a9 as Oa,aa as Ri,ab as os,ac as Ba,ad as Ga,ae as Ua,af as Ha,ag as Wa,ah as Ka,ai as Ei,aj as $a,ak as qa,al as ja,am as Va,an as Ya,ao as Xa,ap as Ci,aq as Za,ar as io,as as ao,at as ro,au as co,av as lo,aw as Ja,ax as Is,ay as Qa,az as tr}from"./three-0hhNWlqB.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))s(n);new MutationObserver(n=>{for(const i of n)if(i.type==="childList")for(const o of i.addedNodes)o.tagName==="LINK"&&o.rel==="modulepreload"&&s(o)}).observe(document,{childList:!0,subtree:!0});function e(n){const i={};return n.integrity&&(i.integrity=n.integrity),n.referrerPolicy&&(i.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?i.credentials="include":n.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function s(n){if(n.ep)return;n.ep=!0;const i=e(n);fetch(n.href,i)}})();const ft={skyZenith:"#4E80B4",skyUpper:"#7BA9CE",skyMid:"#A8CAE0",skyHorizon:"#E4DAC2",skyHorizonSun:"#FBE2AE",sunGlow:"#FFF1CE",sunDisc:"#FFFAEA",skyAnti:"#C8D4D6",haze:"#A9BCC7",mist:"#D6DDD4",cloudTop:"#FFF8EC",cloudBody:"#F6E7D2",cloudTerm:"#E8CFB4",cloudUnder:"#B7ACC3",cloudCore:"#9791B0",cloudRim:"#FFEFBE",cirrus:"#F3E6D6",gTip:"#C6D46B",gUpper:"#93B84E",gMid:"#6C9A47",gLow:"#436E4F",gBase:"#2B564F",gTrans:"#E9EE7C",gSheen:"#EDF0C8",gDry:"#D9C079",gPatchA:"#87AC4B",gPatchB:"#6C9A56",gPatchC:"#9DBC5E",gPatchD:"#5F8A5A",tLit:"#93B159",tMid:"#6A924F",tShade:"#456A54",tHollow:"#33564F",ridgeNear:"#8FA9A2",ridgeMid:"#9CB0B4",ridgeFar:"#AEBCC9",ridgeFurthest:"#BFC8D4",pathLit:"#C9AD80",pathShade:"#7A664D",rockLit:"#B4A794",rockShade:"#5F5C58",bounce:"#AA9C64",wShallow:"#A5CBBE",wMid:"#5F9CA0",wDeep:"#2F5F6C",wDeepShade:"#274E5C",wSpark:"#FFFCEC",wFoam:"#EEF5EF",wetStone:"#6E7E75",sA:"#CBB99E",sB:"#BDA98C",sC:"#D6C6AA",sD:"#B2A490",sShade:"#6C6355",sDeep:"#585A62",mortar:"#AB9C85",moss:"#6F8C4E",lichen:"#B3BE96",cLit:"#84A94C",cMid:"#5A8148",cShade:"#2F5546",cDeep:"#254A44",cTrans:"#BED063",cVarA:"#98AC43",cVarB:"#6E9440",cVarC:"#A9B65C",trunkLit:"#8E7659",trunkShade:"#4C3F34",roofA:"#B96A4C",roofB:"#A05C46",roofSlate:"#6E7583",thatch:"#BC9E66",wallA:"#EFE4D0",wallB:"#E4D5BA",timber:"#7C5D46",windowGlow:"#FFD98C",tarmacLit:"#8E8B86",tarmacShade:"#4A4C52",tarmacWet:"#5E6670",lineWhite:"#F2EADA",lineYellow:"#E7C87A",gravelLit:"#C3AE8B",gravelShade:"#78684F",kerb:"#CFC5B2",postWood:"#8A7357",postPaint:"#EFE4D0",paintA:"#C8503F",paintB:"#E0B14E",paintC:"#3F6E8C",paintD:"#EFE7D6",paintE:"#4E7F79",paintF:"#2E3440",chrome:"#D7DCE0",glass:"#7FA2B8",tyre:"#2A2A2E",tail:"#E4573F",head:"#FFF3D0",sun:"#FFD79C",ambSky:"#9EC6E6",ambGround:"#AA9C64",shadowTint:"#5C6E9E"},Te={};for(const a in ft)Te[a]=new oe(ft[a]).convertSRGBToLinear();const er=a=>`vec3(${a.r.toFixed(5)},${a.g.toFixed(5)},${a.b.toFixed(5)})`,C={};for(const a in Te)C[a]=er(Te[a]);const Gs={};for(const a in Te)Gs[a]=[Te[a].r,Te[a].g,Te[a].b];function sr(){return`
const vec3 K_SUN        = ${C.sun};
const vec3 K_AMB_SKY    = ${C.ambSky};
const vec3 K_AMB_GND    = ${C.ambGround};
const vec3 K_SHADOW     = ${C.shadowTint};
const vec3 K_HAZE       = ${C.haze};
const vec3 K_MIST       = ${C.mist};
const vec3 K_SKY_ZEN    = ${C.skyZenith};
const vec3 K_SKY_UP     = ${C.skyUpper};
const vec3 K_SKY_MID    = ${C.skyMid};
const vec3 K_SKY_HOR    = ${C.skyHorizon};
const vec3 K_SKY_HORSUN = ${C.skyHorizonSun};
const vec3 K_SKY_ANTI   = ${C.skyAnti};
const vec3 K_SUN_GLOW   = ${C.sunGlow};
const vec3 K_SUN_DISC   = ${C.sunDisc};
const vec3 K_C_TOP      = ${C.cloudTop};
const vec3 K_C_BODY     = ${C.cloudBody};
const vec3 K_C_TERM     = ${C.cloudTerm};
const vec3 K_C_UNDER    = ${C.cloudUnder};
const vec3 K_C_CORE     = ${C.cloudCore};
const vec3 K_C_RIM      = ${C.cloudRim};
const vec3 K_T_LIT      = ${C.tLit};
const vec3 K_T_MID      = ${C.tMid};
const vec3 K_T_SHADE    = ${C.tShade};
const vec3 K_T_HOLLOW   = ${C.tHollow};
const vec3 K_ROCK_LIT   = ${C.rockLit};
const vec3 K_ROCK_SHADE = ${C.rockShade};
const vec3 K_PATH_LIT   = ${C.pathLit};
const vec3 K_PATH_SHADE = ${C.pathShade};
const vec3 K_TAR_LIT    = ${C.tarmacLit};
const vec3 K_TAR_SHADE  = ${C.tarmacShade};
const vec3 K_LINE_W     = ${C.lineWhite};
const vec3 K_LINE_Y     = ${C.lineYellow};
const vec3 K_GRAVEL_LIT = ${C.gravelLit};
const vec3 K_GRAVEL_SHD = ${C.gravelShade};
const vec3 K_W_SHALLOW  = ${C.wShallow};
const vec3 K_W_MID      = ${C.wMid};
const vec3 K_W_DEEP     = ${C.wDeep};
const vec3 K_BOUNCE     = ${C.bounce};
const float SUN_I = 1.38;
`}const me=[{ground:[1,1,1],rock:[1,1,1],foliage:[1,1,1],haze:ft.haze,hazeMul:1,dryness:0,snow:0,wet:.12},{ground:[1.24,1.1,.72],rock:[1.12,1.05,.92],foliage:[1.14,1.02,.66],haze:"#D6C79E",hazeMul:1.35,dryness:.85,snow:0,wet:.02},{ground:[.82,.9,.98],rock:[.9,.95,1.06],foliage:[.72,.86,.86],haze:"#9FB6CE",hazeMul:.72,dryness:.1,snow:1,wet:.2},{ground:[1.42,1.06,.78],rock:[1.3,1.02,.86],foliage:[1.05,.9,.62],haze:"#E6C7AC",hazeMul:1.6,dryness:1,snow:0,wet:0},{ground:[.88,.96,.9],rock:[.86,.9,.9],foliage:[.84,.96,.86],haze:"#CBD6D2",hazeMul:1.9,dryness:0,snow:0,wet:1}];function zi(){const a=me.length,t=new Float32Array(a*3),e=new Float32Array(a*3),s=new Float32Array(a*3),n=new Float32Array(a*3),i=new Float32Array(a*4);return me.forEach((o,r)=>{t.set(o.ground,r*3),e.set(o.rock,r*3),s.set(o.foliage,r*3);const c=new oe(o.haze).convertSRGBToLinear();n.set([c.r,c.g,c.b],r*3),i.set([o.hazeMul,o.dryness,o.snow,o.wet],r*4)}),{ground:t,rock:e,foliage:s,haze:n,scal:i,count:a}}const nr=`precision highp float;
precision highp int;
uniform mat4 modelMatrix;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform mat4 viewMatrix;
uniform mat3 normalMatrix;
uniform vec3 cameraPosition;
in vec3 position;
`,or=`
vec3  SAFE3(vec3 c){ return clamp(mix(vec3(0.0), c, equal(c, c)), vec3(0.0), vec3(64.0)); }
float SAFE1(float x){ return (x == x) ? clamp(x, 0.0, 64.0) : 0.0; }
`,Li=`precision highp float;
precision highp int;
${or}`,mt=`
float hash11(float p){ p=fract(p*0.1031); p*=p+33.33; p*=p+p; return fract(p); }
float hash12(vec2 p){ vec3 p3=fract(vec3(p.xyx)*0.1031); p3+=dot(p3,p3.yzx+33.33);
  return fract((p3.x+p3.y)*p3.z); }
vec2 hash22(vec2 p){ vec3 p3=fract(vec3(p.xyx)*vec3(0.1031,0.1030,0.0973));
  p3+=dot(p3,p3.yzx+33.33); return fract((p3.xx+p3.yz)*p3.zy); }
vec3 hash32(vec2 p){ vec3 p3=fract(vec3(p.xyx)*vec3(0.1031,0.1030,0.0973));
  p3+=dot(p3,p3.yxz+33.33); return fract((p3.xxy+p3.yzz)*p3.zyx); }
float hash13(vec3 p){ p=fract(p*0.1031); p+=dot(p,p.zyx+31.32); return fract((p.x+p.y)*p.z); }
vec3 hash33(vec3 p){ p=fract(p*vec3(0.1031,0.1030,0.0973)); p+=dot(p,p.yxz+33.33);
  return fract((p.xxy+p.yxx)*p.zyx); }
`,vt=`
float vn2(vec2 p){ vec2 i=floor(p), f=fract(p); vec2 u=f*f*f*(f*(f*6.0-15.0)+10.0);
  return mix(mix(hash12(i),hash12(i+vec2(1,0)),u.x),
             mix(hash12(i+vec2(0,1)),hash12(i+vec2(1,1)),u.x),u.y); }
float vn3(vec3 p){ vec3 i=floor(p), f=fract(p); vec3 u=f*f*f*(f*(f*6.0-15.0)+10.0);
  float a=hash13(i+vec3(0,0,0)), b=hash13(i+vec3(1,0,0));
  float c=hash13(i+vec3(0,1,0)), d=hash13(i+vec3(1,1,0));
  float e=hash13(i+vec3(0,0,1)), g=hash13(i+vec3(1,0,1));
  float h=hash13(i+vec3(0,1,1)), k=hash13(i+vec3(1,1,1));
  return mix(mix(mix(a,b,u.x),mix(c,d,u.x),u.y), mix(mix(e,g,u.x),mix(h,k,u.x),u.y), u.z); }
vec2 grad2(vec2 i){ float a=hash12(i)*6.2831853; return vec2(cos(a),sin(a)); }
float pn2(vec2 p){ vec2 i=floor(p), f=fract(p); vec2 u=f*f*f*(f*(f*6.0-15.0)+10.0);
  float a=dot(grad2(i),f), b=dot(grad2(i+vec2(1,0)),f-vec2(1,0));
  float c=dot(grad2(i+vec2(0,1)),f-vec2(0,1)), d=dot(grad2(i+vec2(1,1)),f-vec2(1,1));
  return mix(mix(a,b,u.x),mix(c,d,u.x),u.y)*1.42; }
vec3 grad3(vec3 i){ return normalize(hash33(i)*2.0-1.0); }
float pn3(vec3 p){ vec3 i=floor(p), f=fract(p); vec3 u=f*f*f*(f*(f*6.0-15.0)+10.0);
  float n000=dot(grad3(i+vec3(0,0,0)),f-vec3(0,0,0));
  float n100=dot(grad3(i+vec3(1,0,0)),f-vec3(1,0,0));
  float n010=dot(grad3(i+vec3(0,1,0)),f-vec3(0,1,0));
  float n110=dot(grad3(i+vec3(1,1,0)),f-vec3(1,1,0));
  float n001=dot(grad3(i+vec3(0,0,1)),f-vec3(0,0,1));
  float n101=dot(grad3(i+vec3(1,0,1)),f-vec3(1,0,1));
  float n011=dot(grad3(i+vec3(0,1,1)),f-vec3(0,1,1));
  float n111=dot(grad3(i+vec3(1,1,1)),f-vec3(1,1,1));
  return mix(mix(mix(n000,n100,u.x),mix(n010,n110,u.x),u.y),
             mix(mix(n001,n101,u.x),mix(n011,n111,u.x),u.y),u.z)*1.35; }
float fbm2(vec2 p, int oct){ float a=0.5,s=0.0,n=0.0;
  for(int i=0;i<8;i++){ if(i>=oct)break; s+=a*pn2(p); n+=a; p*=2.02; p+=vec2(3.1,1.7); a*=0.5; }
  return s/n; }
float fbm3(vec3 p, int oct){ float a=0.5,s=0.0,n=0.0;
  for(int i=0;i<6;i++){ if(i>=oct)break; s+=a*pn3(p); n+=a; p*=2.03; p+=vec3(2.7,1.3,4.1); a*=0.5; }
  return s/n; }
`,Hn=`
uniform float uTime;
uniform vec3  uSunDir;        // world -> sun, normalised
uniform vec3  uCamPos;
uniform vec2  uWindOrigin;    // centre of the wind render target, world xz
uniform vec2  uCloudDrift;
uniform sampler2D uWindTex;
// The pen's uHeight / uSplat / uMeadow samplers are gone: they were bakes of one fixed
// valley into fixed-size textures, which is exactly the assumption an infinite world
// cannot make. Height, splat and tussock hue now arrive as per-vertex attributes from the
// chunk mesher instead, so they stream with the terrain and cost no texture units.
uniform sampler2D uShadowMap;
uniform sampler2D uCloudSh;   // baked cloud-shadow coverage
uniform vec2  uCloudShOrigin;
uniform vec2  uShadowC;      // centre of the sun shadow map, world xz
uniform vec4  uCull;         // xy = view direction on the ground, z = cos(half angle)
uniform vec2  uWindLag;      // mean wind direction x the response-lag distance
uniform mat4  uLightMat;
uniform float uShadowTexel;
uniform float uCloudAmount;
uniform float uFogMul;
uniform float uFogNear;      // metres before aerial perspective starts
uniform float uFogFar;       // metres to full haze
// There is deliberately no uChunkOrigin. Chunk vertices are local to their node and the
// node's world position rides in three's own modelMatrix, so one material with one uniform
// set draws every chunk in the world. Global precision is handled by rebasing the whole
// scene graph (see render/origin.js), not by a per-draw offset uniform.
`,Ys=`
vec3 skyDome(vec3 d, out float sunMask){
  float y  = d.y;
  float yy = max(y, -0.18);
  // four-stop vertical wash
  vec3 col = mix(K_SKY_HOR, K_SKY_MID, smoothstep(-0.02, 0.13, yy));
  col = mix(col, K_SKY_UP,  smoothstep(0.10, 0.36, yy));
  col = mix(col, K_SKY_ZEN, smoothstep(0.32, 0.86, yy));

  // azimuthal asymmetry: warm toward the sun, cool away from it
  vec2 dh = normalize(d.xz + vec2(1e-5));
  vec2 sh = normalize(uSunDir.xz + vec2(1e-5));
  float az = dot(dh, sh) * 0.5 + 0.5;
  float horiz = pow(1.0 - clamp(yy, 0.0, 1.0), 3.4);
  col = mix(col, K_SKY_ANTI,    horiz * (1.0-az) * 0.62);
  col = mix(col, K_SKY_HORSUN,  horiz * pow(az, 2.1) * 0.92);

  // Mie forward-scatter halo
  float ang = dot(d, uSunDir);
  float halo = pow(max(ang, 0.0), 7.0);
  float wide = pow(max(ang, 0.0), 1.9);
  col = mix(col, K_SUN_GLOW, clamp(halo*0.72 + wide*0.16, 0.0, 0.9));

  // sun disc (painted 3x oversize, never blown out)
  sunMask = smoothstep(0.99977, 0.99992, ang);
  col = mix(col, K_SUN_DISC*1.9, sunMask);

  // thin cirrus streaks, sheared by the upper wind
  float cd = smoothstep(0.035, 0.30, yy);
  if(cd > 0.001){
    vec2 sp = d.xz / max(y, 0.05) * 0.0016;
    sp += uCloudDrift * 0.00022;
    vec2 w = vec2(fbm2(sp*2.1+vec2(7.3,2.1),3), fbm2(sp*2.1+vec2(1.9,9.4),3));
    float ci = fbm2(vec2(sp.x*0.55, sp.y*3.4) + w*0.6, 4);
    ci = smoothstep(0.10, 0.44, ci) * cd * (0.30 + 0.5*pow(max(ang,0.0),1.4));
    col = mix(col, ${C.cirrus}*(0.92+0.55*pow(max(ang,0.0),3.0)), ci*0.55*uCloudAmount);
  }
  return col;
}
vec3 skyDome(vec3 d){ float s; return skyDome(d, s); }

// The same wash without the sun disc and without the warped cirrus fbm.  A
// reflection in moving water resolves none of that detail — it just costs ten
// octaves of noise per pixel of river and comes back as sparkle.
vec3 skyDomeLite(vec3 d){
  float yy = max(d.y, -0.18);
  vec3 col = mix(K_SKY_HOR, K_SKY_MID, smoothstep(-0.02, 0.13, yy));
  col = mix(col, K_SKY_UP,  smoothstep(0.10, 0.36, yy));
  col = mix(col, K_SKY_ZEN, smoothstep(0.32, 0.86, yy));
  vec2 dh = normalize(d.xz + vec2(1e-5));
  vec2 sh = normalize(uSunDir.xz + vec2(1e-5));
  float az = dot(dh, sh)*0.5 + 0.5;
  float horiz = pow(1.0 - clamp(yy, 0.0, 1.0), 3.4);
  col = mix(col, K_SKY_ANTI,   horiz*(1.0-az)*0.62);
  col = mix(col, K_SKY_HORSUN, horiz*pow(az, 2.1)*0.92);
  float ang = max(dot(d, uSunDir), 0.0);
  col = mix(col, K_SUN_GLOW, clamp(pow(ang,7.0)*0.72 + pow(ang,1.9)*0.16, 0.0, 0.9));
  return col;
}
`;function ke({cshSpan:a=4600,cloudDeck:t=980}={}){return`
// The analytic coverage field.  Thirteen octaves of warped fbm — beautiful,
// and far too expensive to evaluate once per fragment of a full screen.  It is
// therefore evaluated ONCE PER FRAME into a 512² map (see CLOUDSH_FS) that is
// centred on where the cloud deck projects along the sun vector; every surface
// in the valley then reads its cloud shadow with a single texture fetch.  The
// field's finest feature is ~95 m across and the map is 9 m/texel, so the baked
// version is indistinguishable from the live one.
float cloudField(vec2 q){
  vec2 p = (q - uCloudDrift) * 0.00071;
  vec2 w = vec2(fbm2(p*1.55+vec2(11.3,4.7),3), fbm2(p*1.55+vec2(37.1,19.2),3));
  float f = fbm2(p + w*0.62, 4);
  float g = fbm2(p*3.7 + w*1.1, 3);
  f = f*0.78 + g*0.22;
  return clamp(smoothstep(-0.035, 0.30, f) * uCloudAmount, 0.0, 1.0);
}
const float CSH_SPAN = ${a.toFixed(1)};
vec2 cloudShadowUV(vec3 wp){
  float t = (${t.toFixed(1)} - wp.y) / max(uSunDir.y, 0.06);
  vec2 q = wp.xz + uSunDir.xz * t;
  return (q - uCloudShOrigin) / CSH_SPAN + 0.5;
}
float cloudShadow(vec3 wp){
  vec2 uv = cloudShadowUV(wp);
  float c = texture(uCloudSh, clamp(uv, vec2(0.0015), vec2(0.9985))).r;
  return 1.0 - 0.64 * c;
}
`}const We=`
// four taps, no painterly wobble — for surfaces too small to show the edge
float sunShadowFast(vec3 wp, float ndl){
  vec4 lp = uLightMat * vec4(wp, 1.0);
  vec3 pc = lp.xyz / lp.w * 0.5 + 0.5;
  if(pc.z > 0.9995) return 1.0;
  vec2 e = abs(pc.xy - 0.5);
  float fade = 1.0 - smoothstep(0.40, 0.497, max(e.x, e.y));
  if(fade <= 0.001) return 1.0;
  float bias = mix(0.0026, 0.0006, clamp(ndl,0.0,1.0));
  float s = 0.0;
  s += step(pc.z-bias, texture(uShadowMap, pc.xy + vec2( 1.0, 1.0)*uShadowTexel).r);
  s += step(pc.z-bias, texture(uShadowMap, pc.xy + vec2(-1.0, 1.0)*uShadowTexel).r);
  s += step(pc.z-bias, texture(uShadowMap, pc.xy + vec2( 1.0,-1.0)*uShadowTexel).r);
  s += step(pc.z-bias, texture(uShadowMap, pc.xy + vec2(-1.0,-1.0)*uShadowTexel).r);
  return mix(1.0, s*0.25, fade);
}
float sunShadow(vec3 wp, float ndl){
  vec4 lp = uLightMat * vec4(wp, 1.0);
  vec3 pc = lp.xyz / lp.w;
  pc = pc * 0.5 + 0.5;
  if(pc.z > 0.9995) return 1.0;
  vec2 e = abs(pc.xy - 0.5);
  float fade = 1.0 - smoothstep(0.40, 0.497, max(e.x, e.y));
  if(fade <= 0.001) return 1.0;
  float bias = mix(0.0022, 0.00045, clamp(ndl,0.0,1.0));
  // Painterly wobble: the shadow edge is DRAWN, not filtered — the noise offset
  // is what gives the edge its brush character, and it is specified in metres
  // so it stays the same shape whatever the map's span or resolution.  Because
  // the wobble dominates the silhouette, five taps in a cross read the same as
  // the old nine in a box, on every lit fragment in the valley.
  float j0 = vn2(wp.xz*2.7) - 0.5;
  float j1 = vn2(wp.zx*8.3 + 9.7) - 0.5;
  vec2 jo = vec2(j0*2.0 + j1*0.9, j1*1.6 - j0*0.7) * 0.00070833;
  float r = uShadowTexel*1.7;
  float s = step(pc.z - bias, texture(uShadowMap, pc.xy + jo).r);
  s += step(pc.z - bias, texture(uShadowMap, pc.xy + jo + vec2( r, r)).r);
  s += step(pc.z - bias, texture(uShadowMap, pc.xy + jo + vec2(-r, r)).r);
  s += step(pc.z - bias, texture(uShadowMap, pc.xy + jo + vec2( r,-r)).r);
  s += step(pc.z - bias, texture(uShadowMap, pc.xy + jo + vec2(-r,-r)).r);
  return mix(1.0, s*0.2, fade);
}
`,Re=`
// three-colour hue-path ramp; transitions are soft but visibly banded
vec3 ramp3(float t, vec3 shade, vec3 mid, vec3 lit, float soft, float jit){
  float a = smoothstep(0.17 - soft + jit, 0.17 + soft + jit, t);
  float b = smoothstep(0.58 - soft + jit, 0.58 + soft + jit, t);
  return mix(mix(shade, mid, a), lit, b);
}
struct Surf {
  vec3 N; vec3 V; vec3 P;     // normal, surface->eye, world pos
  vec3 shade; vec3 mid; vec3 lit;
  float soft;                 // band softness
  float jit;                  // painterly wobble of the band edges
  float shadow;               // 0 shadowed .. 1 lit
  float trans;                // translucency thickness 0..1
  vec3  transCol;
  float rim; float ao; float ambient;
};
vec3 paint(Surf s){
  float ndl  = dot(s.N, uSunDir);
  // Half-lambert. A 13.5° sun grazes flat ground at ndl≈0.23; plain Lambert
  // would drop the whole valley floor into the shade band and golden hour
  // would read as dusk.
  float wrap = clamp(ndl*0.62 + 0.46, 0.0, 1.0);
  float jit  = s.jit;
  float t    = wrap * mix(0.34, 1.0, s.shadow);
  vec3  col  = ramp3(t, s.shade, s.mid, s.lit, s.soft, jit);

  float litAmt = smoothstep(0.34, 0.86, t);
  col *= mix(vec3(0.94), K_SUN * 1.32, litAmt * 0.62);

  // shadows change hue, they do not go black
  col = mix(col*0.80 + K_SHADOW*0.040, col, s.shadow*0.82 + 0.18);

  // Hemispheric ambient TINTS rather than washes: normalised to unit luminance
  // so it can rotate hue (cool from the sky, warm from the ground bounce)
  // without ever bleaching the palette.
  vec3 hemi = mix(K_AMB_GND, K_AMB_SKY, s.N.y*0.5 + 0.5);
  vec3 hueOnly = hemi / max(dot(hemi, vec3(0.2126,0.7152,0.0722)), 1e-3);
  col *= mix(vec3(1.0), hueOnly, 0.22 * s.ambient * (1.0 - litAmt*0.55));
  col += hemi * 0.052 * s.ambient * s.ao * (1.0 - litAmt*0.85);

  // backlight rim — the connective tissue of the whole image
  float back = smoothstep(0.05, 0.85, dot(s.V, -uSunDir));
  float fres = pow(1.0 - clamp(dot(s.N, s.V), 0.0, 1.0), 4.2);
  col += K_SUN * (fres * back * s.rim * 1.15 * s.shadow);

  // subsurface transmission (grass, leaves, smoke)
  if(s.trans > 0.001){
    // light coming THROUGH the blade, not bouncing off it: only the part of
    // the surface that is nearly edge-on to the sun actually transmits
    float tr = pow(clamp(dot(s.V, -uSunDir), 0.0, 1.0), 3.2);
    float thin = pow(clamp(1.0 - abs(dot(s.N, uSunDir)), 0.0, 1.0), 2.2);
    col += s.transCol * tr * thin * s.trans * s.shadow * 0.52;
  }
  col *= s.ao;
  return col;
}

// ── aerial perspective ──────────────────────────────────────────────────────
float gFogAmt = 0.0;   // written by aerial(), read back as the alpha channel so
                       // the post chain knows how far away each pixel is
// uFogNear / uFogFar replace the pen's baked CFG.fogNear=70 / CFG.fogFar=1700. That valley
// was 2 km across and 1700 m of visibility was generous; a car doing 90 m/s down a steppe
// arterial needs to see the next ridge, so the game drives these from the camera's far
// plane and softens them per biome (dunes haze up, highlands clear).
vec3 aerial(vec3 col, float dist, vec3 V, float worldY){
  dist = (dist == dist) ? min(dist, 1.0e6) : 1.0e6;   // a NaN depth must not
  float d  = max(dist - uFogNear, 0.0);   // poison the colour
  float hf = mix(1.0, exp(-max(worldY - 6.0, 0.0)/260.0), 0.72);
  float f  = 1.0 - exp(-pow(d / uFogFar, 1.28) * 3.1 * hf * uFogMul);
  float mie = pow(clamp(dot(-V, uSunDir), 0.0, 1.0), 3.4);
  vec3 fc = mix(K_HAZE, K_SKY_HORSUN, mie*0.88);
  fc = mix(fc, K_SKY_ANTI, clamp(dot(-V,uSunDir),-1.0,0.0)*-0.32);
  // mist pooling in the valley floor
  float pool = smoothstep(46.0, 8.0, worldY) * smoothstep(120.0, 420.0, dist);
  fc = mix(fc, K_MIST, pool*0.45);
  f  = clamp(f + pool*0.16, 0.0, 1.0);
  gFogAmt = f;
  return mix(col, fc, f);
}
`,Wn=`
precision mediump float;
out vec4 o;
void main(){ o = vec4(1.0); }`;function It(...a){return Li+Hn+sr()+a.join("")}function xt(...a){return nr+Hn+a.join("")}const ir=13.5,ar=118;function rr(a=ir,t=ar){const e=a*Math.PI/180,s=t*Math.PI/180;return new Y(Math.sin(s)*Math.cos(e),Math.sin(e),Math.cos(s)*Math.cos(e)).normalize()}const J={uTime:{value:0},uSunDir:{value:rr()},uCamPos:{value:new Y},uWindOrigin:{value:new ct},uCloudDrift:{value:new ct},uWindTex:{value:null},uShadowMap:{value:null},uCloudSh:{value:null},uCloudShOrigin:{value:new ct},uShadowC:{value:new ct},uCull:{value:new Os(0,0,-1,0)},uWindLag:{value:new ct},uLightMat:{value:new Oe},uShadowTexel:{value:1/2048},uCloudAmount:{value:.62},uFogMul:{value:1},uFogNear:{value:140},uFogFar:{value:4200}};function St(a={}){const t={};for(const e in J)t[e]=J[e];for(const e in a)t[e]=a[e];return t}const cr=`
out vec3 vDir;
void main(){
  vDir = position;
  // Translation only: the sky must rotate with the camera but never move relative to it,
  // and the w-trick pins it to the far plane so it can never poke through terrain.
  mat4 v = viewMatrix;
  v[3].xyz = vec3(0.0);
  vec4 p = projectionMatrix * v * vec4(position, 1.0);
  gl_Position = p.xyww;
}
`,lr=`
in vec3 vDir;
out vec4 fragColor;
void main(){
  vec3 d = normalize(vDir);
  float sunMask;
  vec3 col = skyDome(d, sunMask);
  // Alpha carries "how far away" for the post chain; the sky is as far as it gets.
  fragColor = vec4(SAFE3(col), 1.0);
}
`;function hr(){const a=new pt({glslVersion:"300 es",uniforms:St(),vertexShader:xt(cr),fragmentShader:It(mt,vt,Ys,lr),side:ba,depthWrite:!1,depthTest:!1}),t=new bt(new ya(2,2,2),a);return t.frustumCulled=!1,t.renderOrder=-1e3,t.name="sky",t}const Ce=zi();function ur(){const a=(e,s,n)=>{const i=[];for(let o=0;o<s;o++){const r=[];for(let c=0;c<n;c++)r.push(e[o*n+c].toFixed(4));i.push(`vec${n}(${r.join(",")})`)}return i.join(`,
  `)},t=Ce.count;return`
const int NBIOME = ${t};
const vec3 B_GROUND[${t}] = vec3[${t}](
  ${a(Ce.ground,t,3)}
);
const vec3 B_ROCK[${t}] = vec3[${t}](
  ${a(Ce.rock,t,3)}
);
const vec3 B_FOLIAGE[${t}] = vec3[${t}](
  ${a(Ce.foliage,t,3)}
);
const vec3 B_HAZE[${t}] = vec3[${t}](
  ${a(Ce.haze,t,3)}
);
// x hazeMul, y dryness, z snow, w wet
const vec4 B_SCAL[${t}] = vec4[${t}](
  ${a(Ce.scal,t,4)}
);
`}const dr=`
in vec3 normal;
in vec4 aBiome;   // weights 0..3, the fifth is 1 - sum
in vec2 aRoad;    // x = carve mask, y = carriageway

out vec3 vWorld;
out vec3 vNormal;
out vec4 vBiome;
out vec2 vRoad;
out float vDist;

void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld  = wp.xyz;
  vNormal = normalize(mat3(modelMatrix) * normal);
  vBiome  = aBiome;
  vRoad   = aRoad;
  vDist   = length(wp.xyz - uCamPos);
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`,fr=`
in vec3 vWorld;
in vec3 vNormal;
in vec4 vBiome;
in vec2 vRoad;
in float vDist;
out vec4 fragColor;

// The five weights, renormalised. The mesher stores four and lets the fifth fall out of
// the sum, which saves a byte per vertex and guarantees they add to one after
// interpolation — a genuine partition, so no fragment is ever "no biome".
void weights(out float w[NBIOME]){
  float a = vBiome.x, b = vBiome.y, c = vBiome.z, d = vBiome.w;
  float e = max(1.0 - (a+b+c+d), 0.0);
  float s = max(a+b+c+d+e, 1e-4);
  w[0]=a/s; w[1]=b/s; w[2]=c/s; w[3]=d/s; w[4]=e/s;
}

void main(){
  float w[NBIOME];
  weights(w);

  vec3 tintG = vec3(0.0), tintR = vec3(0.0), haze = vec3(0.0);
  vec4 scal = vec4(0.0);
  for(int i=0;i<NBIOME;i++){
    tintG += B_GROUND[i]  * w[i];
    tintR += B_ROCK[i]    * w[i];
    haze  += B_HAZE[i]    * w[i];
    scal  += B_SCAL[i]    * w[i];
  }

  vec3 N = normalize(vNormal);
  vec3 V = normalize(uCamPos - vWorld);
  float slope = 1.0 - clamp(N.y, 0.0, 1.0);

  // ── ground colour ─────────────────────────────────────────────────────────
  // Two large-scale noise fields break the flatness: one picks between the four ground
  // stops, the other is a fine grain that survives to the horizon and stops distant
  // hillsides reading as vinyl.
  float blot = fbm2(vWorld.xz * 0.0042, 4) * 0.5 + 0.5;
  float grain = pn2(vWorld.xz * 0.16) * 0.5 + 0.5;

  vec3 lit   = mix(K_T_LIT,   K_T_MID,    blot * 0.55);
  vec3 mid   = mix(K_T_MID,   K_T_SHADE,  blot * 0.40);
  vec3 shade = mix(K_T_SHADE, K_T_HOLLOW, blot * 0.62);

  // Dryness bleaches the greens towards straw. It is a hue rotation, not a desaturation:
  // dead grass is yellow, not grey.
  vec3 dry = vec3(0.86, 0.76, 0.42);
  lit   = mix(lit,   lit   * dry * 1.45, scal.y);
  mid   = mix(mid,   mid   * dry * 1.32, scal.y);
  shade = mix(shade, shade * dry * 1.18, scal.y);

  lit *= tintG; mid *= tintG; shade *= tintG;

  // ── rock on the steep parts ───────────────────────────────────────────────
  float rockAmt = smoothstep(0.36, 0.66, slope) * (0.55 + 0.45*grain);
  vec3 rLit = K_ROCK_LIT * tintR, rShd = K_ROCK_SHADE * tintR;
  lit   = mix(lit,   rLit,          rockAmt);
  mid   = mix(mid,   mix(rLit,rShd,0.5), rockAmt);
  shade = mix(shade, rShd,          rockAmt);

  // ── snow above the line, only on ground the snow could sit on ─────────────
  float snowLine = smoothstep(120.0, 240.0, vWorld.y) * scal.z;
  float snowHold = smoothstep(0.55, 0.16, slope);
  float snow = clamp(snowLine * snowHold * (0.6 + 0.5*grain), 0.0, 1.0);
  lit   = mix(lit,   vec3(0.95,0.96,0.99), snow);
  mid   = mix(mid,   vec3(0.80,0.85,0.94), snow);
  shade = mix(shade, vec3(0.58,0.66,0.82), snow);

  // ── the road ──────────────────────────────────────────────────────────────
  float onRoad = vRoad.y;
  if(onRoad > 0.003){
    // Surface kind comes from the biome mix: tarmac in the green world, gravel in the
    // steppe, sand in the dunes. Blended, so a road entering a desert visibly silts up.
    float sandy   = w[3];
    float gravely = w[1];
    vec3 tLit = K_TAR_LIT,  tShd = K_TAR_SHADE;
    tLit = mix(tLit, K_GRAVEL_LIT, gravely*0.85);
    tShd = mix(tShd, K_GRAVEL_SHD, gravely*0.85);
    tLit = mix(tLit, K_T_LIT*1.35*dry, sandy*0.9);
    tShd = mix(tShd, K_T_MID*1.05*dry, sandy*0.9);

    // Wear: two long streaks where the wheels run, and a rough grain everywhere.
    float wear = pn2(vWorld.xz * vec2(0.9, 0.11)) * 0.5 + 0.5;
    float chip = vn2(vWorld.xz * 3.1);
    vec3 rl = mix(tLit, tLit*1.10, wear) * mix(0.94, 1.06, chip);
    vec3 rs = mix(tShd, tShd*0.92, wear);

    lit   = mix(lit,   rl,               onRoad);
    mid   = mix(mid,   mix(rl,rs,0.55),  onRoad);
    shade = mix(shade, rs,               onRoad);
  }

  // ── shading ───────────────────────────────────────────────────────────────
  float ndl = dot(N, uSunDir);
  float sh  = sunShadow(vWorld, ndl) * cloudShadow(vWorld);

  Surf s;
  s.N = N; s.V = V; s.P = vWorld;
  s.shade = shade; s.mid = mid; s.lit = lit;
  s.soft  = mix(0.16, 0.34, clamp(vDist/900.0, 0.0, 1.0));
  s.jit   = (vn2(vWorld.xz * 0.55) - 0.5) * 0.09;
  s.shadow = sh;
  s.trans = 0.0; s.transCol = vec3(0.0);
  s.rim   = mix(0.30, 0.10, onRoad);
  s.ao    = 1.0;
  s.ambient = 1.0;

  vec3 col = paint(s);

  // Standing water in the wetland: a dark wet sheen under the fog, not a mirror. The real
  // water surface is a separate mesh; this is the mud it sits on.
  col = mix(col, col*0.62 + K_W_DEEP*0.10, scal.w * smoothstep(6.0, 0.5, vWorld.y) * 0.7);

  // Biome haze colour feeds the shared aerial term.
  col = aerial(col, vDist, V, vWorld.y);
  col = mix(col, mix(col, haze, 0.55), clamp(scal.x - 1.0, 0.0, 1.2) * gFogAmt * 0.6);

  fragColor = vec4(SAFE3(col), gFogAmt);
}
`;function pr(){const a=ke({cshSpan:9200,cloudDeck:980});return new pt({glslVersion:"300 es",uniforms:St(),vertexShader:xt(dr),fragmentShader:It(mt,vt,ur(),Ys,a,We,Re,fr),side:On})}const mr=5,vr=1.02,gr=.75,ho=.62,wr=1.4,uo=.85,xr=.38,br=.36,yr=.44,fo=.1,_r=.14,Mr=.06,Tr=`
in vec2 uv;
out vec2 vUv;
void main(){
  // One oversized triangle, not two triangles: no diagonal seam for the FXAA pass to find
  // and one less vertex-shader invocation per full-screen pass.
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}
`,Sr=`
uniform sampler2D uSrc; uniform float uThresh; uniform float uSoft;
in vec2 vUv; out vec4 outColor;
void main(){
  // the NaN firewall lives here too: one bad texel entering the bloom pyramid gets
  // smeared over a whole neighbourhood by the downsample chain
  vec3 c = SAFE3(texture(uSrc, vUv).rgb);
  float l = dot(c, vec3(0.2126,0.7152,0.0722));
  float k = smoothstep(uThresh, uThresh+uSoft, l);
  outColor = vec4(c*k, 1.0);
}`,po=`
uniform sampler2D uSrc; uniform vec2 uTexel;
in vec2 vUv; out vec4 outColor;
void main(){
  vec2 t=uTexel;
  vec3 a=texture(uSrc,vUv+t*vec2(-2,-2)).rgb, b=texture(uSrc,vUv+t*vec2(0,-2)).rgb, c=texture(uSrc,vUv+t*vec2(2,-2)).rgb;
  vec3 d=texture(uSrc,vUv+t*vec2(-2, 0)).rgb, e=texture(uSrc,vUv).rgb,               f=texture(uSrc,vUv+t*vec2(2, 0)).rgb;
  vec3 g=texture(uSrc,vUv+t*vec2(-2, 2)).rgb, h=texture(uSrc,vUv+t*vec2(0, 2)).rgb, i=texture(uSrc,vUv+t*vec2(2, 2)).rgb;
  vec3 j=texture(uSrc,vUv+t*vec2(-1,-1)).rgb, k=texture(uSrc,vUv+t*vec2(1,-1)).rgb;
  vec3 l=texture(uSrc,vUv+t*vec2(-1, 1)).rgb, m=texture(uSrc,vUv+t*vec2(1, 1)).rgb;
  vec3 o = e*0.125 + (a+c+g+i)*0.03125 + (b+d+f+h)*0.0625 + (j+k+l+m)*0.125;
  outColor = vec4(o,1.0);
}`,Ar=`
uniform sampler2D uSrc; uniform sampler2D uPrev; uniform vec2 uTexel; uniform float uRadius;
in vec2 vUv; out vec4 outColor;
void main(){
  vec2 t=uTexel*uRadius;
  vec3 s = texture(uSrc,vUv+t*vec2(-1,-1)).rgb*1.0 + texture(uSrc,vUv+t*vec2(0,-1)).rgb*2.0
         + texture(uSrc,vUv+t*vec2( 1,-1)).rgb*1.0 + texture(uSrc,vUv+t*vec2(-1,0)).rgb*2.0
         + texture(uSrc,vUv).rgb*4.0                + texture(uSrc,vUv+t*vec2( 1,0)).rgb*2.0
         + texture(uSrc,vUv+t*vec2(-1, 1)).rgb*1.0 + texture(uSrc,vUv+t*vec2(0, 1)).rgb*2.0
         + texture(uSrc,vUv+t*vec2( 1, 1)).rgb*1.0;
  outColor = vec4(texture(uPrev,vUv).rgb + s/16.0, 1.0);
}`,kr=`
uniform sampler2D uSrc; uniform vec2 uTexel; uniform vec2 uDir;
in vec2 vUv; out vec4 outColor;
void main(){
  vec2 d = uTexel*uDir;
  vec3 c = texture(uSrc,vUv).rgb*0.227;
  c += (texture(uSrc,vUv+d*1.3846).rgb + texture(uSrc,vUv-d*1.3846).rgb)*0.316;
  c += (texture(uSrc,vUv+d*3.2308).rgb + texture(uSrc,vUv-d*3.2308).rgb)*0.070;
  outColor = vec4(c,1.0);
}`,Rr=`
uniform sampler2D uScene, uBloom, uSoft;
uniform vec2  uRes;
uniform float uExposure, uBloomAmt, uPaint, uCA, uVignette, uGrain;
uniform float uRadial, uVigSpeed, uCALimit;
in vec2 vUv; out vec4 outColor;

/*  Luma FXAA.  A million-blade meadow is the worst possible case for spatial
    aliasing, which is why the scene used to be brute-force supersampled at
    1.3x.  Resolving the edges here instead buys back 1.45x of the entire
    fragment budget — every shaded pixel in the frame — for five extra taps in
    one full-screen pass.  Blades are already floored to ~1 px wide by the grass
    shader, so there is nothing thinner than a pixel for it to smear.         */
// The buffer is linear HDR, where a sunlit blade can sit at 1.5 and a shaded
// one at 0.03.  Thresholding raw linear luma makes FXAA fire almost nowhere in
// the light and everywhere in the dark; folding it through the same Reinhard
// shape the eye will see puts every threshold back in the range the algorithm
// was designed for, which is the difference between it working on grass and not.
float fxLuma(vec3 c){ c = c/(c + vec3(1.0)); return dot(c, vec3(0.2126,0.7152,0.0722)); }
vec3 fxaa(sampler2D tex, vec2 uv, vec2 rcp, vec3 mC){
  float lNW = fxLuma(texture(tex, uv + vec2(-1.0,-1.0)*rcp).rgb);
  float lNE = fxLuma(texture(tex, uv + vec2( 1.0,-1.0)*rcp).rgb);
  float lSW = fxLuma(texture(tex, uv + vec2(-1.0, 1.0)*rcp).rgb);
  float lSE = fxLuma(texture(tex, uv + vec2( 1.0, 1.0)*rcp).rgb);
  float lM  = fxLuma(mC);
  float lMin = min(lM, min(min(lNW,lNE), min(lSW,lSE)));
  float lMax = max(lM, max(max(lNW,lNE), max(lSW,lSE)));
  if(lMax - lMin < max(0.016, lMax*0.055)) return mC;   // flat: leave it alone
  vec2 dir = vec2(-((lNW + lNE) - (lSW + lSE)), ((lNW + lSW) - (lNE + lSE)));
  float red = max((lNW+lNE+lSW+lSE)*0.0156, 0.0039);
  float rcpDir = 1.0 / (min(abs(dir.x), abs(dir.y)) + red);
  dir = clamp(dir*rcpDir, vec2(-6.0), vec2(6.0)) * rcp;
  vec3 a = 0.5*(texture(tex, uv + dir*(1.0/3.0 - 0.5)).rgb
              + texture(tex, uv + dir*(2.0/3.0 - 0.5)).rgb);
  vec3 b = a*0.5 + 0.25*(texture(tex, uv - dir*0.5).rgb + texture(tex, uv + dir*0.5).rgb);
  float lB = fxLuma(b);
  return (lB < lMin || lB > lMax) ? a : b;
}

vec3 tonemap(vec3 x){
  x = max(x, vec3(0.0));
  vec3 a = x*(x*0.36 + 0.42);
  vec3 b = x*(x*0.34 + 0.66) + 0.11;
  return clamp(a/b, 0.0, 1.0);
}
float luma(vec3 c){ return dot(c, vec3(0.2126,0.7152,0.0722)); }
vec3 toSRGB(vec3 c){
  return mix(c*12.92, 1.055*pow(max(c,vec3(1e-5)), vec3(1.0/2.4))-0.055, step(0.0031308, c));
}

// Speed streak. Six taps between the pixel and the vanishing point, spanning 3.5% of the
// radius vector — ~38 px at the corner of a 1080p frame, ~0 in the middle of it.
const int   RB_TAPS = 6;
const float RB_SPAN = 0.035;

void main(){
  vec2 uv = vUv;
  vec2 d  = uv - 0.5;
  float r2 = dot(d,d);

  // ── edge resolve, then a whisper of chromatic aberration at the rim ────
  // the centre texel was being fetched four separate times — by FXAA, twice by
  // the aberration and once for the fog weight.  One fetch, passed around.
  vec4 src = texture(uScene, uv);
  vec2 rcp = 1.0/uRes;
  vec3 c = SAFE3(fxaa(uScene, uv, rcp, src.rgb));
  // uCALimit is 0.06*limit^2 from the CPU. It rides an r2*r2 falloff, not the pen's r2, so
  // the grip fringe is confined to the outer corners: at the limit it reaches 0.015 (~14 px
  // of split at 1080p, at the very corner) and is already under 2 px by mid-frame. On the
  // pen's own r2 falloff a term that size would tear a rainbow across the whole image.
  float ca = uCA * (0.0016 + r2*0.0060) + uCALimit*r2*r2;
  c.r += texture(uScene, uv + d*ca).r - src.r;
  c.b += texture(uScene, uv - d*ca).b - src.b;
  c = SAFE3(c);
  float fogW = src.a;

  // ── speed streak ───────────────────────────────────────────────────────
  // uRadial is the blend weight of the streaked copy, not the tap span: the frame never
  // loses its edges, it gains a ghost of them trailing outward. The vanishing point is
  // held sharp — smearing it too reads as a tunnel, not as velocity.
  if(uRadial > 0.0){
    vec2 st = d * (RB_SPAN / float(RB_TAPS));
    vec3 acc = vec3(0.0);
    for(int i=1;i<=RB_TAPS;i++) acc += texture(uScene, uv - st*float(i)).rgb;
    c = mix(c, SAFE3(acc/float(RB_TAPS)), uRadial * smoothstep(0.02, 0.20, r2));
  }

  // ── watercolour softening with distance (wet-in-wet, not bokeh) ────────
  // fogW is gFogAmt, written into the alpha channel by aerial() in every world shader.
  vec3 soft = texture(uSoft, uv).rgb;
  float wet = clamp(fogW*0.85, 0.0, 1.0);
  c = mix(c, soft, wet * 0.42 * uPaint);

  // ── chroma bleed: paint runs, pixels do not ────────────────────────────
  // this used to be a flat 20% everywhere, which quietly smeared the colour of
  // near detail too; it belongs to distance, like the softening it accompanies
  {
    float lc = luma(c);
    vec3 chroma = soft - vec3(luma(soft));
    c = mix(c, vec3(lc) + chroma, (0.09 + 0.17*wet)*uPaint);
  }

  // ── bloom ──────────────────────────────────────────────────────────────
  vec3 bl = texture(uBloom, uv).rgb;
  c += bl * uBloomAmt * mix(vec3(1.0), K_SUN, 0.55);

  // ── the print ──────────────────────────────────────────────────────────
  // last chance: the soft/bloom chains are sampled here and a single bad texel
  // anywhere upstream would otherwise survive the tonemap as a solid block
  c = SAFE3(c) * uExposure;
  c = tonemap(c);

  // shadows to violet, highlights to cream — the single biggest lever
  float l = luma(c);
  vec3 shadowPush = mix(vec3(0.90,0.95,1.16), vec3(1.0), smoothstep(0.0, 0.34, l));
  vec3 highPush   = mix(vec3(1.0), vec3(1.055,1.012,0.925), smoothstep(0.44, 0.98, l));
  c *= mix(vec3(1.0), shadowPush, 0.85*uPaint) * mix(vec3(1.0), highPush, 0.9*uPaint);
  // lift: nothing in a Ghibli frame is ever pure black
  vec3 lift = vec3(0.017, 0.021, 0.036)*uPaint;
  c = c*(1.0 - lift) + lift;
  // gentle S and a nudge of saturation in the midtones
  c = mix(c, c*c*(3.0-2.0*c), 0.16*uPaint);
  l = luma(c);
  float satBoost = 1.0 + 0.16*uPaint*smoothstep(0.10,0.42,l)*(1.0-smoothstep(0.62,0.96,l));
  c = mix(vec3(l), c, satBoost);

  // ── paper tooth ────────────────────────────────────────────────────────
  // two gradient-noise evaluations, not four: this is a +/-3% multiplier on the
  // final colour, and it runs on every pixel of the frame
  vec2 gp = uv*uRes/2.4;
  float grain = pn2(gp*0.5)*0.62 + pn2(gp*0.13 + 11.0)*0.38;
  float fibre = pn2(vec2(uv.x*uRes.x*0.06, uv.y*uRes.y*0.9));
  c *= 1.0 + grain*0.030*uGrain + fibre*0.010*uGrain;

  // ── vignette, warm-dark ────────────────────────────────────────────────
  float vig = pow(clamp(1.0 - r2*1.15, 0.0, 1.0), 1.55);
  c *= mix(vec3(1.0), mix(vec3(0.62,0.60,0.66), vec3(1.0), vig), uVignette);
  // ...and the speed vignette on top of it: tighter (r2*2.1 vs 1.15) and cooler, so it
  // closes in from the corners as the car winds up instead of just re-darkening the frame.
  float vigS = pow(clamp(1.0 - r2*2.10, 0.0, 1.0), 1.10);
  c *= mix(vec3(1.0), mix(vec3(0.55,0.55,0.60), vec3(1.0), vigS), uVigSpeed);

  c = toSRGB(clamp(c, 0.0, 1.0));

  // ── ordered dither: the sky must never band ────────────────────────────
  float dth = fract(dot(gl_FragCoord.xy, vec2(0.7548776662, 0.5698402909)));
  c += (dth - 0.5)/255.0;
  outColor = vec4(c, 1.0);
}`;function ze(a,t,e=[]){return new pt({glslVersion:"300 es",uniforms:St(t),vertexShader:xt(Tr),fragmentShader:It(...e,a),depthTest:!1,depthWrite:!1})}class Er{constructor(t,{width:e,height:s,pixelRatio:n=1,renderScale:i=1,bloomLevels:o=mr}={}){this.renderer=t,this.pixelRatio=n,this.renderScale=i,this.bloomLevels=Math.max(1,o|0),this.speed=0,this.limit=0,this.exposure=1,this.bloom=1,this.paint=1,this._quality=1,t.toneMapping=nn,t.outputColorSpace=Ft;const r=t.getContext(),c=!!(r.getExtension("EXT_color_buffer_half_float")||r.getExtension("EXT_color_buffer_float"));this._type=c?Mn:Tn,c||console.error("[post] no renderable half-float target; HDR bloom disabled (threshold 1.02 is unreachable on an 8-bit buffer)"),this._quadGeo=new Qt,this._quadGeo.setAttribute("position",new G(new Float32Array([-1,-1,0,3,-1,0,-1,3,0]),3)),this._quadGeo.setAttribute("uv",new G(new Float32Array([0,0,2,0,0,2]),2)),this._quadGeo.boundingSphere=new ie(new Y,10),this._quadCam=new Bn,this._quadScene=new Vs,this._quadMesh=new bt(this._quadGeo,null),this._quadMesh.frustumCulled=!1,this._quadScene.add(this._quadMesh),this._bright=ze(Sr,{uSrc:{value:null},uThresh:{value:vr},uSoft:{value:gr}}),this._downMats=[],this._upMats=[];for(let l=1;l<this.bloomLevels;l++)this._downMats.push(ze(po,{uSrc:{value:null},uTexel:{value:new ct(1,1)}})),this._upMats.push(ze(Ar,{uSrc:{value:null},uPrev:{value:null},uTexel:{value:new ct(1,1)},uRadius:{value:wr}}));this._softDown=ze(po,{uSrc:{value:null},uTexel:{value:new ct(1,1)}}),this._blurMats=[0,1].map(l=>ze(kr,{uSrc:{value:null},uTexel:{value:new ct(1,1)},uDir:{value:new ct(l?0:1,l?1:0)}})),this._composite=ze(Rr,{uScene:{value:null},uBloom:{value:null},uSoft:{value:null},uRes:{value:new ct(1,1)},uExposure:{value:1},uBloomAmt:{value:ho},uPaint:{value:1},uCA:{value:1},uVignette:{value:uo},uGrain:{value:1},uRadial:{value:0},uVigSpeed:{value:fo},uCALimit:{value:0}},[mt,vt]),this._sceneRT=null,this._bloomRTs=[],this._upRTs=[],this._softRTs=[],this.setSize(e,s)}get quality(){return this._quality}set quality(t){const e=Math.min(1,Math.max(.5,t));e!==this._quality&&(this._quality=e,this._buildBloom())}get target(){return this._sceneRT}get bufferWidth(){return this._w}get bufferHeight(){return this._h}setSize(t,e){const s=this.pixelRatio*this.renderScale,n=Math.max(16,Math.floor(t*s)),i=Math.max(16,Math.floor(e*s));this._sceneRT&&n===this._w&&i===this._h||(this._w=n,this._h=i,this._sceneRT&&this._sceneRT.dispose(),this._sceneRT=new ps(n,i,{type:this._type,format:ms,minFilter:Mt,magFilter:Mt,wrapS:Ut,wrapT:Ut,depthBuffer:!0,stencilBuffer:!1,samples:0}),this._composite.uniforms.uRes.value.set(n,i),this._softRTs.forEach(o=>o.dispose()),this._softRTs=[0,1].map(()=>this._mkRT(Math.max(2,n>>3),Math.max(2,i>>3))),this._blurMats.forEach(o=>o.uniforms.uTexel.value.set(1/this._softRTs[0].width,1/this._softRTs[0].height)),this._buildBloom())}_mkRT(t,e){return new ps(t,e,{type:this._type,format:ms,minFilter:Mt,magFilter:Mt,wrapS:Ut,wrapT:Ut,depthBuffer:!1,stencilBuffer:!1})}_buildBloom(){this._bloomRTs.forEach(s=>s.dispose()),this._upRTs.forEach(s=>s.dispose()),this._bloomRTs=[],this._upRTs=[];let t=Math.max(2,Math.floor(this._w*this._quality)>>1),e=Math.max(2,Math.floor(this._h*this._quality)>>1);for(let s=0;s<this.bloomLevels;s++)this._bloomRTs.push(this._mkRT(t,e)),this._upRTs.push(this._mkRT(t,e)),t=Math.max(2,t>>1),e=Math.max(2,e>>1)}_blit(t,e){this._quadMesh.material=t,this.renderer.setRenderTarget(e||null),this.renderer.render(this._quadScene,this._quadCam)}render(t,e){const s=this.renderer;s.toneMapping!==nn&&(s.toneMapping=nn),s.outputColorSpace!==Ft&&(s.outputColorSpace=Ft),s.setRenderTarget(this._sceneRT),s.render(t,e),this._bright.uniforms.uSrc.value=this._sceneRT.texture,this._blit(this._bright,this._bloomRTs[0]);const n=this._bloomRTs.length;for(let c=1;c<n;c++){const l=this._downMats[c-1];l.uniforms.uSrc.value=this._bloomRTs[c-1].texture,l.uniforms.uTexel.value.set(1/this._bloomRTs[c-1].width,1/this._bloomRTs[c-1].height),this._blit(l,this._bloomRTs[c])}for(let c=0;c<n-1;c++){const l=n-2-c,h=this._upMats[c];h.uniforms.uSrc.value=c===0?this._bloomRTs[n-1].texture:this._upRTs[l+1].texture,h.uniforms.uPrev.value=this._bloomRTs[l].texture,h.uniforms.uTexel.value.set(1/this._upRTs[l].width,1/this._upRTs[l].height),this._blit(h,this._upRTs[l])}this._softDown.uniforms.uSrc.value=this._sceneRT.texture,this._softDown.uniforms.uTexel.value.set(1/this._softRTs[0].width,1/this._softRTs[0].height),this._blit(this._softDown,this._softRTs[0]),this._blurMats[0].uniforms.uSrc.value=this._softRTs[0].texture,this._blit(this._blurMats[0],this._softRTs[1]),this._blurMats[1].uniforms.uSrc.value=this._softRTs[1].texture,this._blit(this._blurMats[1],this._softRTs[0]);const i=Math.min(1,Math.max(0,this.speed)),o=Math.min(1,Math.max(0,this.limit)),r=this._composite.uniforms;r.uScene.value=this._sceneRT.texture,r.uBloom.value=(n>1?this._upRTs[0]:this._bloomRTs[0]).texture,r.uSoft.value=this._softRTs[0].texture,r.uExposure.value=this.exposure,r.uBloomAmt.value=ho*this.bloom,r.uPaint.value=this.paint,r.uCA.value=this.paint,r.uVignette.value=uo,r.uGrain.value=this.paint,r.uRadial.value=xr*i*i*Cr(br,yr,i),r.uVigSpeed.value=fo+_r*i,r.uCALimit.value=Mr*o*o,this._blit(this._composite,null)}dispose(){this._sceneRT&&this._sceneRT.dispose(),this._bloomRTs.forEach(t=>t.dispose()),this._upRTs.forEach(t=>t.dispose()),this._softRTs.forEach(t=>t.dispose()),this._sceneRT=null,this._bloomRTs=[],this._upRTs=[],this._softRTs=[],[this._bright,this._softDown,this._composite,...this._downMats,...this._upMats,...this._blurMats].forEach(t=>t.dispose()),this._quadGeo.dispose(),this._quadScene.remove(this._quadMesh),this._quadMesh.material=null}}function Cr(a,t,e){const s=Math.min(1,Math.max(0,(e-a)/(t-a)));return s*s*(3-2*s)}const Z=Math.PI*2,De=Math.PI/180,K=(a,t,e)=>a<t?t:a>e?e:a,D=a=>a<0?0:a>1?1:a,I=(a,t,e)=>a+(t-a)*e,At=(a,t,e)=>{const s=D((e-a)/(t-a));return s*s*(3-2*s)};function Us(a,t){let e=(t-a)%Z;return e>Math.PI&&(e-=Z),e<=-Math.PI&&(e+=Z),e}function Ct(a,t,e,s){return I(a,t,1-Math.exp(-e*s))}function zr(a,t,e,s){return a+Us(a,t)*(1-Math.exp(-e*s))}function Tt(a,t,e=0){let s=Math.imul(a|0,2376512323)^Math.imul(t|0,3625334849)^Math.imul(e|0,3407524639);return s=Math.imul(s^s>>>15,739982445),s=Math.imul(s^s>>>12,695872825),(s^s>>>15)>>>0}function Di(a,t,e,s=0){let n=Math.imul(a|0,2376512323)^Math.imul(t|0,3625334849)^Math.imul(e|0,3407524639)^Math.imul(s|0,374761393);return n=Math.imul(n^n>>>13,1540483477),(n^n>>>15)>>>0}function Ke(a){let t=a>>>0;return()=>{t=t+1831565813|0;let e=Math.imul(t^t>>>15,1|t);return e=e+Math.imul(e^e>>>7,61|e)^e,((e^e>>>14)>>>0)/4294967296}}function Lr(a,t){return Math.sqrt(a*a+t*t)}function kn(a,t,e,s,n,i){const o=n-e,r=i-s,c=o*o+r*r;let l=c>0?((a-e)*o+(t-s)*r)/c:0;l=D(l);const h=e+o*l,u=s+r*l;return{d:Lr(a-h,t-u),t:l,x:h,z:u}}function Ms(a,t,e,s,n){const i=n*n,o=i*n;return(2*o-3*i+1)*a+(o-2*i+n)*t+(-2*o+3*i)*e+(o-i)*s}const Dr=9200,Fr=980,Ir=4,Pr=.1,Nr=`
in vec4 wdat;      // x depth in metres, yz bed-downhill direction, w flow speed
out vec3 vW;
out vec4 vD;
out float vDist;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vW = wp.xyz;
  vD = wdat;
  vDist = length(wp.xyz - uCamPos);
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`,Or=a=>`
in vec3 vW;
in vec4 vD;
in float vDist;
out vec4 fragColor;

// The pen read its gusts out of a 256² wind render target that every system in the valley
// shared. Wanderoad has no wind pass yet (uWindTex is unbound), and sampling an unbound
// sampler is a black texture, not a calm day — so the cat's-paw field is analytic here.
// Two octaves at ~130 m per cell, advected slowly across the world: gust cells that are big
// enough to darken a whole bay and slow enough that you watch one arrive.
float gustAt(vec2 p){
  vec2 q = p * 0.0078 - vec2(uTime * 0.052, uTime * 0.019);
  float g = fbm2(q, 3) * 0.5 + 0.5;
  // Ceiling of 1.25 rather than the pen's 1.6: an fbm hits its ceiling far more often than
  // the pen's simulated wind field did, and at 1.6 the surface is permanently at full chop.
  return clamp(smoothstep(0.44, 0.90, g) * 1.25, 0.0, 1.25);
}

// ── band limiting ───────────────────────────────────────────────────────────
// The pen never had to solve this: its water was a 12-to-30 m ribbon that left the screen
// after a few hundred metres. A flooded wetland is a sheet running to the horizon, seen
// almost edge-on, so a pixel two kilometres out covers tens of metres of surface — and every
// noise band finer than that pixel turns into moire chevrons instead of ripples.
//
// fw is the pixel footprint per flow-space axis, straight off the hardware derivatives, and
// f is a band's frequency along each of those axes. Their dot product is how many cycles of
// that band fit inside one pixel; past about a half the band carries no information, so it
// is faded out rather than point-sampled. Same idea as a mip chain, done analytically
// because these bands are functions rather than textures.
//
// It has to be the dot product and not max(fw)*max(f). Both the footprint and the ripple
// bands are strongly anisotropic, and at grazing incidence they are anisotropic in the SAME
// direction: the pixel is long down the view, the ripples are long down the flow. Collapsing
// either to a single number is the isotropic-mip mistake, and it blurs the whole surface to
// a flat sheet the moment the camera drops towards eye level — which, in a driving game, is
// where the camera lives.
float bandLimit(vec2 fw, vec2 f){ return 1.0 - smoothstep(0.28, 0.72, dot(fw, abs(f))); }

// Anisotropic chop: four bands, all far longer down the ripple axis than across it, which is
// the single thing that makes water look like it is going somewhere. The pen's frequencies
// and weights, each gated at its own Nyquist limit, and each advected by the local current as
// a domain offset in metres rather than as a term buried inside the frequency scaling.
float ripple(vec2 q, vec2 drift, float t, float gust, vec2 fw){
  vec2 d1 = q - drift*1.122;   // 0.055/0.049 — the pen's own downstream rate, in metres
  vec2 d2 = q - drift*0.950;   // 0.115/0.121
  vec2 d3 = q - drift*0.810;   // 0.255/0.315
  // The capillary chop is wind-driven, not current-driven, so it keeps the pen's fixed
  // advection instead of following the bed.
  vec2 d4 = q - vec2(t*2.087, -t*0.667);
  float n1 = pn2(vec2(d1.x*0.049, d1.y*0.40))        * bandLimit(fw, vec2(0.049, 0.40));
  float n2 = pn2(vec2(d2.x*0.121, d2.y*0.92) + 7.0)  * bandLimit(fw, vec2(0.121, 0.92));
  float n3 = pn2(vec2(d3.x*0.315, d3.y*2.30) + 19.0) * bandLimit(fw, vec2(0.315, 2.30));
  float n4 = pn2(vec2(d4.x*1.15, d4.y*1.05) + 31.0)  * bandLimit(fw, vec2(1.15, 1.05)) * gust;
  return n1*0.52 + n2*0.30 + n3*0.17 + n4*0.30;
}

// ── the ripple frame ────────────────────────────────────────────────────────
// A rigid, world-anchored rotation of world space, gently domain-warped, seeded per world.
//
// It CANNOT be the pen's per-fragment flow frame (q = dot(P.xz, flow)). Out here a world
// position is thousands of metres long, so a two-degree wobble in an interpolated flow
// direction moves the noise domain by a hundred metres — and the downhill field of any lake
// converges on a line down its middle, where that direction sweeps through 180 degrees inside
// a single quad. The result is a fan of zebra stripes radiating from every deep channel, at a
// frequency no amount of band limiting can reach, because in the domain the stripes really
// are there.
//
// So the frame is global and linear in position: continuous everywhere, no chunk seams, and
// stable no matter how far from the origin the player has driven. The local current still
// does the work you can see — it enters as the advection velocity below, where it multiplies
// TIME instead of position and therefore cannot blow up.
const vec2 RIP_AXIS = vec2(${a.x.toFixed(6)}, ${a.z.toFixed(6)});
vec2 rippleFrame(vec2 p){
  // A ~270 m domain warp so the streaks meander instead of ruling the whole world in parallel
  // lines. Amplitude times frequency stays well under one, so the map keeps a bounded
  // derivative and the frame stays as well-behaved as the plain rotation underneath it.
  vec2 w = vec2(pn2(p*0.0037 + 11.3), pn2(p*0.0037 + 41.7)) * 46.0;
  vec2 s = p + w;
  return vec2(dot(s, RIP_AXIS), dot(s, vec2(-RIP_AXIS.y, RIP_AXIS.x)));
}

void main(){
  // Dry bed. The terrain already occludes the plane wherever the ground rises through it, so
  // this only matters at LOD cracks and along the shoreline, where a metre of tolerance stops
  // the plane's own 2 m-sampled waterline from cutting inside the mesh's 1 m-sampled one.
  if(!(vD.x > -0.5)) discard;

  vec3 P = vW;
  vec3 V = normalize(uCamPos - P);
  float depth = max(vD.x, 0.0);
  float sp = vD.w;

  vec2 q = rippleFrame(P.xz);
  vec2 fw = max(fwidth(q), vec2(1e-4));

  // The local current, expressed in the ripple frame. Interpolation is safe here: where two
  // vertices flow at each other the vector simply shortens towards zero, which is slack water
  // and reads as slack water, instead of spinning through every heading inside one quad.
  vec2 fl = vD.yz;
  fl *= min(1.0, inversesqrt(max(dot(fl, fl), 1e-8)));
  vec2 adv = vec2(dot(fl, RIP_AXIS), dot(fl, vec2(-RIP_AXIS.y, RIP_AXIS.x)));
  vec2 drift = adv * (uTime * sp);

  // Gust cells are ~32 m across at their finest, so they too stop carrying information once
  // the pixel is wider than that — and their surface darkening is the most visible aliasing
  // of the lot, because it is a contrast term rather than a colour one.
  float gust = gustAt(P.xz) * bandLimit(fw, vec2(0.031));

  // The finite differences that build the normal are sampled at the pixel footprint of their
  // OWN axis rather than at the pen's fixed 0.42 m, so each degrades into a box filter of
  // exactly the right width instead of into noise — and a grazing pixel does not drag the
  // across-axis difference out with it.
  vec2 e = max(fw, vec2(0.42));
  float h0 = ripple(q, drift, uTime, gust, fw);
  float hx = ripple(q + vec2(e.x, 0.0), drift, uTime, gust, fw);
  float hy = ripple(q + vec2(0.0, e.y), drift, uTime, gust, fw);
  float amp = mix(0.055, 0.20, clamp(sp*0.22, 0.0, 1.0)) * (0.55 + 0.9*gust);
  // Shallow water is choppier: the bed shortens the wave.
  amp *= mix(1.35, 1.0, smoothstep(0.3, 2.6, depth));
  vec2 dh = (vec2(hx, hy) - h0)/e * amp * 14.0;
  // Back out of the ripple frame into world xz. The warp is ignored in this rotation: it is a
  // few degrees of shear, and the normal only has to look right, not integrate.
  vec2 axC = vec2(-RIP_AXIS.y, RIP_AXIS.x);
  vec3 N = normalize(vec3(-(dh.x*RIP_AXIS.x + dh.y*axC.x), 1.0, -(dh.x*RIP_AXIS.y + dh.y*axC.y)));
  // Flatten with distance so a lake two kilometres away is a plate of colour and not a
  // boiling field of highlights. Barely stronger than the pen's 0.75 over 120-520 m: with
  // the bands gated above, this is now a look control rather than an anti-aliasing measure.
  N = normalize(mix(N, vec3(0.0,1.0,0.0), smoothstep(110.0, 560.0, vDist)*0.82));

  float ndl = dot(N, uSunDir);
  float sh = sunShadow(P, ndl) * cloudShadow(P);

  // ── depth-graded body colour, in bands ─────────────────────────────────────
  // Painted water is not a smooth gradient; it is a few flat plates of colour whose
  // boundaries you can point at. The pen keyed those plates off distance-across-the-channel;
  // here they key off real depth, so a shelving bay draws its own contour lines.
  float bedDepth = smoothstep(0.12, 4.4, depth);
  float plateJ = pn2(vec2(q.x*0.045, q.y*0.42) + 3.0)*0.070*bandLimit(fw, vec2(0.045, 0.42));
  float b1 = smoothstep(0.16 + plateJ, 0.30 + plateJ, bedDepth);
  float b2 = smoothstep(0.50 + plateJ, 0.68 + plateJ, bedDepth);
  vec3 body = mix(K_W_SHALLOW, K_W_MID, b1);
  body = mix(body, K_W_DEEP, b2);
  // the gravel bed showing through the shallows (cool wet stone, not sand)
  float bedN = pn2(P.xz*0.55)*0.5 + 0.5;
  vec3 wetBed = mix(${C.wetStone}, K_W_SHALLOW, 0.45) * mix(0.80, 1.06, mix(0.5, bedN, bandLimit(fw, vec2(0.55))));
  body = mix(wetBed, body, smoothstep(0.02, 0.22, bedDepth));
  // caustic light rocking over the shallow bed
  vec2 dc = q - drift*0.471;   // 0.8/1.7
  float caus = pn2(vec2(dc.x*1.7, dc.y*2.9 + uTime*0.5));
  caus = pow(clamp(caus*0.5 + 0.5, 0.0, 1.0), 3.0);
  body += ${C.wSpark}*caus*0.20*(1.0 - smoothstep(0.05, 0.40, bedDepth))*sh*bandLimit(fw, vec2(1.7, 2.9));

  // ── reflection ─────────────────────────────────────────────────────────────
  // Sky only. The pen also had a planar mirror pass for its one valley; a streaming world
  // would need one render target per water body per frame, and stylised water keeps its own
  // colour at grazing angles anyway — which is why the Fresnel term is clamped so low.
  vec3 R = reflect(-V, N);
  vec3 refl = skyDomeLite(normalize(vec3(R.x, max(R.y, 0.012), R.z)));
  float fres = 0.035 + 0.70*pow(1.0 - clamp(dot(N,V), 0.0, 1.0), 4.0);
  fres = clamp(fres, 0.0, 0.46);

  vec3 col = mix(body, refl, fres*0.86);
  col = mix(col*0.74 + K_SHADOW*0.10, col, sh*0.82 + 0.18);

  // ── flow ribbons ───────────────────────────────────────────────────────────
  // Long creases travelling downstream: they show which way the water is going with no motion
  // at all, which is what carries the read on a distant reach only twelve pixels wide.
  {
    vec2 e1 = q - drift*1.333;   // 0.10/0.075
    vec2 e2 = q - drift*1.097;   // 0.17/0.155
    float r1 = pn2(vec2(e1.x*0.075, e1.y*0.55) + 5.0);
    float r2 = pn2(vec2(e2.x*0.155, e2.y*1.05) + 41.0);
    float rib = smoothstep(0.28, 0.62, abs(r1)*0.75 + abs(r2)*0.45);
    float bright = smoothstep(0.0, 0.5, r1 + r2);
    col = mix(col, mix(${C.wDeepShade}, ${C.wSpark}, bright),
              rib*0.16*(0.4 + 0.6*sh)*bandLimit(fw, vec2(0.155, 1.05)));
  }

  // ── quantised sun glitter ──────────────────────────────────────────────────
  // Hard-stepped into discrete winking glints rather than left as a specular lobe: a
  // specular lobe on stylised water reads as plastic.
  float f = dot(normalize(R), uSunDir);
  float broad = pow(max(f, 0.0), 22.0);
  vec2 dg = q - drift*0.579 - vec2(0.0, uTime*0.097);   // 1.1/1.9 and 0.35/3.6
  float glintN = pn2(dg*vec2(1.9, 3.6))*0.5 + 0.5;
  float twinkle = step(0.42, glintN) * (0.55 + 0.75*pn2((q - vec2(uTime*0.286))*7.0));
  // A winking glint is a sub-pixel event by construction, so once a pixel is wider than the
  // glint field it hands its energy to the broad lobe rather than strobing.
  float glint = smoothstep(0.9975, 0.99925, f) * twinkle * bandLimit(fw, vec2(1.9, 3.6));
  float glitterPath = smoothstep(0.55, 1.0, dot(normalize(vec2(V.x,V.z)), -normalize(uSunDir.xz)));
  col += ${C.wSpark} * (glint*2.6 + broad*0.42) * sh * (0.35 + 0.75*glitterPath);

  // ── shore foam ─────────────────────────────────────────────────────────────
  // Keyed off the measured depth, so the foam band is a genuine contour of the bed and
  // widens by itself wherever the shore shelves gently.
  float edge = 1.0 - smoothstep(0.0, 1.25, depth);
  vec2 ds = q - drift*0.824;   // 0.7/0.85
  float scallop = mix(0.5, pn2(vec2(ds.x*0.85, ds.y*2.2))*0.5 + 0.5, bandLimit(fw, vec2(0.85, 2.2)));
  float foam = clamp(smoothstep(0.42, 0.96, edge*(0.50 + 0.95*scallop)), 0.0, 1.0);
  col = mix(col, ${C.wFoam}*mix(0.80, 1.10, scallop), foam*0.55);

  // cat's paws darken the surface where a gust touches down
  col *= mix(1.0, 0.86, smoothstep(0.75, 1.6, gust));

  col += K_SUN * pow(clamp(dot(V,-uSunDir), 0.0, 1.0), 5.0) * 0.16 * sh;
  col = aerial(col, vDist, V, P.y);
  fragColor = vec4(SAFE3(col), gFogAmt);
}
`;function Br(a){const t=Tt(11433,4574,a)/4294967296*Z,e={x:Math.cos(t),z:Math.sin(t)},s=ke({cshSpan:Dr,cloudDeck:Fr});return new pt({glslVersion:"300 es",uniforms:St(),vertexShader:xt(Nr),fragmentShader:It(mt,vt,Ys,s,We,Re,Or(e)),transparent:!1,side:Jt})}const mo=new Map;function Gr(a){let t=mo.get(a);if(t)return t;t=new Uint16Array((a-1)*(a-1)*6);let e=0;for(let s=0;s<a-1;s++)for(let n=0;n<a-1;n++){const i=s*a+n,o=i+1,r=i+a,c=r+1;t[e++]=i,t[e++]=r,t[e++]=o,t[e++]=o,t[e++]=r,t[e++]=c}return mo.set(a,t),t}const vo=a=>`${a.level}:${a.cx},${a.cz}`;class Ur{constructor({seed:t,scene:e}){this.seed=t>>>0,this.scene=e,this.material=Br(this.seed),this.group=new ge,this.group.name="water",this.group.matrixAutoUpdate=!1,e.add(this.group),this.planes=new Map,this.stats={live:0,visible:0},this._cullT=0,this._cam=new Y}add(t){if(!t||!t.water||t.level>Ir)return;const e=vo(t);if(this.planes.has(e))return;const s=this._buildPlane(t);if(!s)return;const n=new bt(s,this.material);n.position.set(t.ox,t.water.level,t.oz),n.matrixAutoUpdate=!1,n.updateMatrix(),n.frustumCulled=!0,n.renderOrder=1,n.userData.level=t.level,this.group.add(n),this.planes.set(e,n),this.stats.live=this.planes.size}remove(t){if(!t)return;const e=vo(t),s=this.planes.get(e);s&&(this.group.remove(s),s.geometry.dispose(),this.planes.delete(e),this.stats.live=this.planes.size)}update(t,e){if(e&&this._cam.set(e.x,e.y,e.z),this._cullT-=t,this._cullT>0)return;this._cullT=Pr;const s=J.uFogFar.value*1.25;let n=0;for(const i of this.planes.values()){const o=i.geometry.boundingSphere,r=i.position.x+o.center.x-this._cam.x,c=i.position.z+o.center.z-this._cam.z,l=s+o.radius,h=r*r+c*c<l*l;i.visible=h,h&&n++}this.stats.visible=n}dispose(){for(const t of this.planes.values())this.group.remove(t),t.geometry.dispose();this.planes.clear(),this.scene.remove(this.group),this.material.dispose(),this.stats.live=0,this.stats.visible=0}_buildPlane(t){const e=t.grid|0;if(e<3)return null;const s=this._bedReader(t,e);if(!s)return null;const n=e+1>>1,i=(e-1)/(n-1),o=t.water.level,r=t.size/(n-1),c=i*2,l=Tt(t.cx,t.cz,this.seed^31358)/4294967296*Z,h=Math.cos(l),u=Math.sin(l),d=new Float32Array(n*n*3),f=new Float32Array(n*n*4);for(let m=0;m<n;m++){const v=m*i;for(let g=0;g<n;g++){const w=g*i,x=m*n+g;d[x*3]=g*r,d[x*3+1]=0,d[x*3+2]=m*r;const y=w-c<0?0:w-c,T=w+c>e-1?e-1:w+c,b=v-c<0?0:v-c,M=v+c>e-1?e-1:v+c,_=(s(T,v)-s(y,v))/((T-y)*t.step)||0,S=(s(w,M)-s(w,b))/((M-b)*t.step)||0;let A=-_,L=-S;const E=Math.sqrt(A*A+L*L);E>.001?(A/=E,L/=E):(A=h,L=u);const k=o-s(w,v);f[x*4]=k,f[x*4+1]=A,f[x*4+2]=L;const R=1-.72*D((k-1.2)/7);f[x*4+3]=(.35+2*D(E*8))*R}}const p=new Qt;return p.setAttribute("position",new G(d,3)),p.setAttribute("wdat",new G(f,4)),p.setIndex(new G(Gr(n),1)),p.boundingSphere=new ie(new Y(t.size*.5,0,t.size*.5),t.size*.7072),p}_bedReader(t,e){const s=t.heights;if(s&&s.length>=e*e)return(o,r)=>s[r*e+o];const n=t.mesh&&t.mesh.geometry&&t.mesh.geometry.getAttribute("position");if(!n||n.count<e*e)return null;const i=n.array;return(o,r)=>i[(r*e+o)*3+1]}}const is=9,as=3050,Fe=is*as,Hr=9200,go=980,Wr=10500,Rn=12800,wo=1500,Kr=.35,xo=2.3,$r=`
in vec2 vUv;
out vec4 fragColor;
void main(){
  vec2 tile = floor(vUv*2.0);
  float seed = (tile.x + tile.y*2.0)*37.13 + 5.0;
  vec2 c = fract(vUv*2.0)*2.0 - 1.0;
  float r = length(c);
  float ang = atan(c.y, c.x);
  vec2 ring = vec2(cos(ang), sin(ang));
  float lob = fbm2(ring*2.35 + seed*13.7, 3) + fbm2(ring*5.1 + seed*29.1, 2)*0.45;
  float R = 0.80 + lob*0.20;
  float a = smoothstep(R, R-0.34, r);
  float den = fbm2(c*2.6 + seed*31.3, 3)*0.5 + 0.5;
  float edge = smoothstep(R-0.36, R-0.02, r);
  float aSoft = smoothstep(R, R-0.42, r);
  fragColor = vec4(a, den, edge, aSoft);
}
`,qr=`
in vec2 vUv;
out vec4 fragColor;
void main(){
  vec2 q = uCloudShOrigin + (vUv - 0.5)*CSH_SPAN;
  float c = smoothstep(0.06, 0.60, cloudField(q));
  fragColor = vec4(c, c, c, 1.0);
}
`,bo=`
in vec2 uv;
out vec2 vUv;
void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }
`,jr=`
in vec2 corner;
in vec3 pdata;   // radius, per-puff seed, height fraction within its formation
in vec2 fcen;    // the formation's lattice centre, xz
out vec2 vC;
out float vSeed;
out float vHF;
out vec3 vW;
out float vOp;
out vec3 vRight;
out vec3 vUp;
out vec3 vFwd;

const float DECK_PERIOD = ${Fe.toFixed(1)};

void main(){
  // Wrap by whole lattice periods into the window around the camera. The offset is computed
  // from the FORMATION centre, not the puff, so a formation always wraps as one cloud
  // instead of tearing in half.
  vec2 fhome = fcen + uCloudDrift;
  vec2 wrapOff = floor((uCamPos.xz - fhome)/DECK_PERIOD + 0.5) * DECK_PERIOD;
  vec2 fw = fhome + wrapOff;
  vec3 wc = position + vec3(uCloudDrift.x + wrapOff.x, 0.0, uCloudDrift.y + wrapOff.y);

  // The same field that draws the shadow decides whether this puff exists. cloudField()
  // subtracts uCloudDrift again, so a cloud's existence is pinned to its wrapped home in the
  // world while the puff itself rides the wind — a cloud that moves rather than one that
  // blinks.
  float op = smoothstep(0.16, 0.52, cloudField(fw));
  // Fade well inside DECK_PERIOD*0.5 so the wrap always happens to an invisible puff.
  op *= 1.0 - smoothstep(${Wr.toFixed(1)}, ${Rn.toFixed(1)}, length(uCamPos - wc));
  vOp = op;
  if(op < 0.012){ gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }

  vRight = normalize(vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]));
  vUp    = normalize(vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]));
  vFwd   = normalize(vec3(viewMatrix[0][2], viewMatrix[1][2], viewMatrix[2][2]));

  float rad = pdata.x * mix(0.80, 1.06, op);
  float ra = pdata.y*2.399963;                    // golden-angle spin per puff
  float cr = cos(ra), sr = sin(ra);
  vec2 rc = vec2(corner.x*cr - corner.y*sr, corner.x*sr + corner.y*cr);
  vec3 wp = wc + vRight*(rc.x*rad) + vUp*(rc.y*rad*0.86);
  vC = rc; vSeed = pdata.y; vHF = pdata.z; vW = wp;
  gl_Position = projectionMatrix * viewMatrix * vec4(wp, 1.0);
}
`,Vr=`
uniform sampler2D uPuff;
in vec2 vC;
in float vSeed;
in float vHF;
in vec3 vW;
in float vOp;
in vec3 vRight;
in vec3 vUp;
in vec3 vFwd;
out vec4 fragColor;
void main(){
  float r = length(vC);
  if(!(r <= 1.02)) discard;
  vec2 tile = vec2(mod(floor(vSeed*4.0), 2.0), mod(floor(vSeed*2.0), 2.0));
  vec4 prof = texture(uPuff, (clamp(vC,-1.0,1.0)*0.5 + 0.5)*0.5 + tile*0.5);
  // An analytic radial falloff multiplies the baked profile: it softens the silhouette, and
  // it makes a hard-edged opaque quad structurally impossible even if the atlas is missing.
  float a = prof.r * smoothstep(1.02, 0.60, r);
  if(!(a > 0.004)) discard;
  float den = prof.g;
  a *= mix(0.62, 1.0, den);
  a *= vOp;

  // Fake volumetric normal off the billboard disc, biased upward: cumulus tops face the sky,
  // bellies face the ground.
  float zz = sqrt(max(0.0, 1.0 - min(r,1.0)*min(r,1.0)));
  vec3 N = normalize(vRight*vC.x + vUp*vC.y + vFwd*zz*0.85 + vec3(0.0, 0.62, 0.0));
  vec3 V = normalize(uCamPos - vW);

  float ndl = dot(N, uSunDir);
  float t = clamp(ndl*0.5 + 0.5, 0.0, 1.0);
  // Height fraction as its own term rather than a nudge to the lambert: it is what separates
  // a stack of towers into readable storeys instead of one grey mass, because a cumulus is
  // lit as much by the sky dome above it as by the sun on its shoulder.
  t = mix(t, clamp(t + vHF*0.36 - 0.10, 0.0, 1.0), 0.78);
  t *= mix(0.68, 1.10, den);
  float term = smoothstep(0.30, 0.54, t);       // the terminator, as a line

  vec3 col = ramp3(t, K_C_UNDER, K_C_TERM, K_C_TOP, 0.085, (den-0.5)*0.06);
  // the belly goes violet fast, and it does not pass through grey to get there
  col = mix(mix(K_C_CORE, K_C_UNDER, 0.30), col, smoothstep(0.0, 0.28, t));
  col = mix(col, K_C_BODY, 0.13);
  col *= mix(vec3(1.0), K_SUN*1.28, term*0.44);

  // silver lining: the rim of a backlit cumulus blazes
  float back = clamp(dot(V, -uSunDir), 0.0, 1.0);
  float edge = prof.b;
  float sunEdge = clamp(dot(normalize(vRight*vC.x + vUp*vC.y), uSunDir)*0.5+0.5, 0.0, 1.0);
  float rimLine = smoothstep(0.30, 0.84, edge);
  float silver = rimLine * pow(sunEdge, 1.9) * (0.34 + 1.7*pow(back, 1.3));
  col = mix(col, K_C_RIM*1.45, clamp(silver, 0.0, 0.94));
  // ...and a thin cool line down the shaded side, which is the thing that actually reads as
  // "drawn" rather than "rendered"
  col = mix(col, mix(K_C_CORE, K_SHADOW, 0.42), rimLine*(1.0-sunEdge)*(1.0-term)*0.36);
  col += K_SUN * pow(back, 6.0) * 0.62 * (1.0-edge*0.4);

  // Clouds are far enough that full aerial perspective would erase them; the pen carries
  // them at 55% of their true distance so they haze without dissolving.
  col = aerial(col, length(uCamPos - vW)*0.55, V, vW.y);
  fragColor = vec4(SAFE3(col), clamp(a, 0.0, 1.0));
}
`,Fi=new Vs,Yr=new Bn,Xr=(()=>{const a=new Qt;a.setAttribute("position",new G(new Float32Array([-1,-1,0,3,-1,0,-1,3,0]),3)),a.setAttribute("uv",new G(new Float32Array([0,0,2,0,0,2]),2)),a.boundingSphere=new ie(new Y,10);const t=new bt(a,null);return t.frustumCulled=!1,Fi.add(t),t})();function yo(a,t,e){Xr.material=t,a.setRenderTarget(e),a.render(Fi,Yr),a.setRenderTarget(null)}function Zr(a){const t=Ke(Tt(23568,53445,a>>>0)),e=[];for(let h=0;h<is;h++)for(let u=0;u<is;u++){const d=(u-(is-1)/2)*as+(t()-.5)*as*.75,f=(h-(is-1)/2)*as+(t()-.5)*as*.75,p=620+t()*820,m=.72+t()*.85,v=2+(t()*3|0),g=(300+t()*230)*m;let w=0;const x=[],y=7+(t()*7|0);for(let T=0;T<y;T++){const b=t()*Z,M=Math.sqrt(t())*g,_=Math.cos(b)*M,S=Math.sin(b)*M*.72,A=t()*.1*g;x.push({x:_,y:A,z:S,rad:(.44+t()*.32)*g,seed:t()*100}),A>w&&(w=A)}for(let T=0;T<v;T++){const b=t()*Z,M=Math.sqrt(t())*g*.55,_=Math.cos(b)*M,S=Math.sin(b)*M*.7,A=(.85+t()*1.15)*g,L=4+(t()*4|0);for(let E=0;E<L;E++){const k=E/(L-1),R=k*A,P=(.52-.22*k*k+t()*.13)*g*(1-.25*k),W=(t()-.5)*g*.3*(.4+k),U=(t()-.5)*g*.3*(.4+k);if(x.push({x:_+W,y:R,z:S+U,rad:P,seed:t()*100}),R>w&&(w=R),E>0&&t()<.7){const q=t()*Z,st=P*(.55+t()*.5);x.push({x:_+W+Math.cos(q)*st,y:R+(t()-.3)*P*.5,z:S+U+Math.sin(q)*st,rad:P*(.42+t()*.3),seed:t()*100})}}}for(const T of x)e.push({cx:d+T.x,cy:p+T.y,cz:f+T.z,rad:T.rad,seed:T.seed,hf:w>1?K(T.y/w,0,1):.5,fx:d,fz:f})}const s=e.length,n=new Float32Array(s*4*3),i=new Float32Array(s*4*2),o=new Float32Array(s*4*3),r=new Float32Array(s*4*2);for(let h=0;h<s;h++){const u=e[h];for(let d=0;d<4;d++){const f=h*4+d;n[f*3]=u.cx,n[f*3+1]=u.cy,n[f*3+2]=u.cz,i[f*2]=d===1||d===3?1:-1,i[f*2+1]=d>=2?1:-1,o[f*3]=u.rad,o[f*3+1]=u.seed,o[f*3+2]=u.hf,r[f*2]=u.fx,r[f*2+1]=u.fz}}const c=new Qt;c.setAttribute("position",new G(n,3)),c.setAttribute("corner",new G(i,2)),c.setAttribute("pdata",new G(o,3)),c.setAttribute("fcen",new G(r,2));const l=new Uint32Array(s*6);return c.setIndex(new G(l,1)),c.boundingSphere=new ie(new Y(0,900,0),Fe),{geom:c,puffs:e,index:l,count:s}}class Jr{constructor({renderer:t,scene:e,seed:s}){this.renderer=t,this.scene=e,this.seed=s>>>0;const n=ke({cshSpan:Hr,cloudDeck:go});this.puffRT=new ps(1024,1024,{format:ms,type:Tn,minFilter:Gn,magFilter:Mt,generateMipmaps:!0,depthBuffer:!1});const i=new pt({glslVersion:"300 es",uniforms:St(),vertexShader:xt(bo),fragmentShader:It(mt,vt,$r),depthTest:!1,depthWrite:!1});yo(t,i,this.puffRT),i.dispose(),this.shadowRT=new ps(512,512,{format:ms,type:Tn,minFilter:Mt,magFilter:Mt,wrapS:Ut,wrapT:Ut,generateMipmaps:!1,depthBuffer:!1}),this.shadowMat=new pt({glslVersion:"300 es",uniforms:St({uCloudSh:{value:null}}),vertexShader:xt(bo),fragmentShader:It(mt,vt,n,qr),depthTest:!1,depthWrite:!1}),J.uCloudSh.value=this.shadowRT.texture,this.deck=Zr(this.seed),this.material=new pt({glslVersion:"300 es",uniforms:St({uPuff:{value:this.puffRT.texture}}),vertexShader:xt(mt,vt,n,jr),fragmentShader:It(Re,Vr),side:Jt,transparent:!0,depthTest:!0,depthWrite:!1,blending:_i,blendSrc:yi,blendDst:bi,blendEquation:Bs,blendSrcAlpha:xi,blendDstAlpha:wi,blendEquationAlpha:Bs}),this.mesh=new bt(this.deck.geom,this.material),this.mesh.name="clouds",this.mesh.frustumCulled=!1,this.mesh.matrixAutoUpdate=!1,this.mesh.renderOrder=40,e.add(this.mesh);const o=Tt(7482,49421,this.seed)/4294967296*Z;this._driftX=Math.cos(o)*xo,this._driftZ=Math.sin(o)*xo,this._sortT=0,this._dist=new Float32Array(this.deck.count),this._order=new Int32Array(this.deck.count);for(let r=0;r<this.deck.count;r++)this._order[r]=r;this.stats={puffs:this.deck.count,drawn:0},this.update(0,{x:0,y:0,z:0})}update(t,e){const s=e?e.x:0,n=e?e.y:0,i=e?e.z:0,o=J.uTime.value;J.uCloudDrift.value.set(this._driftX*o,this._driftZ*o),this._sortT-=t,this._sortT<=0&&(this._sortT=Kr,this._sort(s,n,i));const r=J.uSunDir.value,c=(go-n)/Math.max(r.y,.06);J.uCloudShOrigin.value.set(s+r.x*c,i+r.z*c),yo(this.renderer,this.shadowMat,this.shadowRT)}_sort(t,e,s){const n=this.deck.puffs,i=this.deck.index,o=n.length,r=this._dist,c=this._order,l=J.uCloudDrift.value.x,h=J.uCloudDrift.value.y;for(let m=0;m<o;m++){const v=n[m],g=Math.round((t-(v.fx+l))/Fe)*Fe,w=Math.round((s-(v.fz+h))/Fe)*Fe,x=v.cx+l+g-t,y=v.cy-e,T=v.cz+h+w-s;r[m]=x*x+y*y+T*T}for(let m=1;m<o;m++){const v=c[m],g=r[v];let w=m-1;for(;w>=0&&r[c[w]]<g;)c[w+1]=c[w],w--;c[w+1]=v}const u=Rn*Rn;let d=0;for(let m=0;m<o;m++)r[c[m]]<=u&&d++;let f=d>wo?d-wo:0,p=0;for(let m=0;m<o;m++){const v=c[m];if(r[v]>u)continue;if(f>0){f--;continue}const g=v*4;i[p++]=g,i[p++]=g+1,i[p++]=g+2,i[p++]=g,i[p++]=g+2,i[p++]=g+3}this.deck.geom.index.needsUpdate=!0,this.deck.geom.setDrawRange(0,p),this.stats.drawn=p/6}dispose(){this.scene.remove(this.mesh),this.deck.geom.dispose(),this.material.dispose(),this.shadowMat.dispose(),J.uCloudSh.value===this.shadowRT.texture&&(J.uCloudSh.value=null),this.shadowRT.dispose(),this.puffRT.dispose(),this.stats.drawn=0}}const vs=64,rs=new Float32Array(vs),cs=new Float32Array(vs);for(let a=0;a<vs;a++){const t=a/vs*6.283185307179586;rs[a]=Math.cos(t),cs[a]=Math.sin(t)}const Ts=vs-1;function Xt(a,t,e=0){const s=Math.floor(a),n=Math.floor(t),i=a-s,o=t-n,r=i*i*i*(i*(i*6-15)+10),c=o*o*o*(o*(o*6-15)+10),l=Tt(s,n,e)>>>20&Ts,h=Tt(s+1,n,e)>>>20&Ts,u=Tt(s,n+1,e)>>>20&Ts,d=Tt(s+1,n+1,e)>>>20&Ts,f=rs[l]*i+cs[l]*o,p=rs[h]*(i-1)+cs[h]*o,m=rs[u]*i+cs[u]*(o-1),v=rs[d]*(i-1)+cs[d]*(o-1);return I(I(f,p,r),I(m,v,r),c)*1.42}function Zt(a,t,e=5,s=0,n=2.03,i=.5){let o=.5,r=1,c=0,l=0;for(let h=0;h<e;h++)c+=o*Xt(a*r,t*r,s+h*1013),l+=o,o*=i,r*=n;return c/l}function En(a,t,e=5,s=0,n=2.07,i=.5){let o=.5,r=1,c=0,l=0,h=1;for(let u=0;u<e;u++){let d=1-Math.abs(Xt(a*r,t*r,s+u*7919));d*=d,d*=h,h=d*1.6,h>1?h=1:h<0&&(h=0),c+=o*d,l+=o,o*=i,r*=n}return c/l*2-1}function Qr(a,t,e=4,s=0,n=2,i=.5){let o=.5,r=1,c=0,l=0;for(let h=0;h<e;h++)c+=o*Math.abs(Xt(a*r,t*r,s+h*3733)),l+=o,o*=i,r*=n;return c/l*2-1}function Ii(a,t,e,s,n=1){const i=Zt(a+5.2,t+1.3,3,s+101),o=Zt(a+9.7,t+4.1,3,s+227);return Zt(a+n*i,t+n*o,e,s)}const de={MEADOW:0,STEPPE:1,HIGHLAND:2,DUNES:3,WETLAND:4},lt=5,Cn=["Meadow","Steppe","Highlands","Dunes","Wetland"],Ss=1/7200,_o=1/15500,Mo=1/9800,To=1/2600;function tc(a,t,e){const s=Ii(a*Ss,t*Ss,5,e^6699,.8),n=En(a*Ss*1.7,t*Ss*1.7,4,e^23613);let i=D(.5+s*.62+Math.max(0,n)*.34-.06);const o=Zt(a*_o+41.3,t*_o-17.9,3,e^30635);let r=D(.5+o*.85-At(.52,.95,i)*.62);const c=Zt(a*Mo-88.1,t*Mo+12.7,4,e^13297),l=At(.44,.16,i);let h=D(.5+c*.9+l*.3-At(.55,.9,i)*.25);const u=Xt(a*To,t*To,e^40503)*.045;return i=D(i+u),r=D(r+u*1.4),h=D(h-u*1.1),{e:i,t:r,m:h}}const So=a=>D(.5+(a-.5)*1.92);function Pi(a,t,e){const s=tc(a,t,e),n=So(s.e),i=So(s.t),o=D(.5+(s.t-s.m)*1.45);return{ue:n,ut:i,ua:o,e:s.e,t:s.t,m:s.m}}const ec=[[.5,.45,.52,1.9,2.3,1.3,1],[.48,.72,.64,1.6,2.6,1.6,1.32],[.88,.45,.26,3,1.1,2,1.35],[.42,.95,.8,1.5,3.1,1.7,1.55],[.13,.12,.52,2.6,2.6,1,1.5]],Ni=new Float32Array(lt),Oi=new Float32Array([1,1,1,1,1]);function sc(a){for(let t=0;t<lt;t++)Oi[t]=a&&a[t]>0?a[t]:1}function Bi(a,t,e,s=Ni){const n=Pi(a,t,e);return zn(n,s)}function zn(a,t=Ni){let e=0,s=0,n=-1;for(let o=0;o<lt;o++){const r=ec[o],c=(a.ue-r[0])*r[3],l=(a.ua-r[1])*r[4],h=(a.ut-r[2])*r[5],u=r[6]*Oi[o]*Math.exp(-(c*c+l*l+h*h));t[o]=u,e+=u,u>n&&(n=u,s=o)}const i=1/(e||1);for(let o=0;o<lt;o++)t[o]*=i;return{w:t,dominant:s,e:a.e,t:a.t,m:a.m,ue:a.ue,ua:a.ua,ut:a.ut}}const Yt=[{amp:30,base:6,rough:.18,wave:460,drive:1,water:1.2},{amp:18,base:3,rough:.1,wave:900,drive:1,water:0},{amp:178,base:14,rough:.86,wave:1600,drive:1,water:.6},{amp:26,base:2,rough:.02,wave:430,drive:1,water:0},{amp:7,base:-2,rough:.05,wave:700,drive:1,water:2.5}];function nc(a,t,e,s){const n=Yt[s],i=1/n.wave;switch(s){case de.MEADOW:{const o=Ii(a*i,t*i,5,e^2577,.55),r=En(a*i*.6,t*i*.6,3,e^2578,2,.4);return n.base+(o*.82+r*.18)*n.amp}case de.STEPPE:{const o=Zt(a*i,t*i,4,e^2849,2,.42),r=Xt(a*i*.35,t*i*.35,e^2850);return n.base+(o*.55+r*.45)*n.amp}case de.HIGHLAND:{const o=En(a*i,t*i,6,e^3121,2,.4),r=Zt(a*i*2.1,t*i*2.1,4,e^3122,2,.4),c=D(o*.5+.5),l=Math.pow(c,1.55)*1.62-.36;return n.base+(l*.88+r*.12)*n.amp}case de.DUNES:{const o=Qr(a*i,t*i,4,e^3393,2,.42),r=Math.sin((a*.0121+t*.0047)*6.283+Zt(a*i*.5,t*i*.5,3,e^3394)*4.2);return n.base+(o*.55+r*.45)*n.amp}case de.WETLAND:{const o=Zt(a*i,t*i,4,e^3665,2,.42),r=At(.15,-.35,o);return n.base+o*n.amp-r*4.5}default:return 0}}function Kn(a,t){let e=0,s=0;for(let i=0;i<lt;i++){const o=a[i];o<.02||(e+=Yt[i].water*o,s+=o)}if(s<=0)return null;const n=e/s;return t<n?n:null}const xs=[{trees:26,rocks:5,bushes:16,reeds:0,posts:.6,grass:1,kinds:["broadleaf","broadleaf","poplar"]},{trees:4,rocks:8,bushes:9,reeds:0,posts:.9,grass:.72,kinds:["acacia","scrub"]},{trees:18,rocks:26,bushes:6,reeds:0,posts:.4,grass:.34,kinds:["pine","pine","deadpine"]},{trees:.5,rocks:10,bushes:2,reeds:0,posts:.25,grass:.06,kinds:["palm","scrub"]},{trees:11,rocks:2,bushes:12,reeds:34,posts:1.2,grass:.8,kinds:["willow","willow","broadleaf"]}],an=[{surface:"tarmac",grip:1,rough:.06,width:8,lines:1},{surface:"gravel",grip:.78,rough:.3,width:9,lines:.15},{surface:"tarmac",grip:.92,rough:.14,width:6.8,lines:.8},{surface:"sand",grip:.62,rough:.42,width:10.5,lines:0},{surface:"tarmac",grip:.86,rough:.1,width:7.2,lines:.6}];function oc(a,t,e){let s=0;for(let n=0;n<lt;n++)s+=a[n]*t[n][e];return s}const Ge=[{cell:1800,jitter:.34,connect:.86,width:8.6,verge:5,curve:.44,samples:14},{cell:620,jitter:.42,connect:.5,width:6.2,verge:3,curve:.62,samples:10}],Ln=1/4294967296;function Me(a,t,e,s,n){const i=Ge[e],o=Tt(a,t,s^(e===0?20858:11165)),r=((o&65535)*Ln*65536-.5)*2*i.jitter,c=((o>>>16&65535)*Ln*65536-.5)*2*i.jitter;return n[0]=(a+.5+r)*i.cell,n[1]=(t+.5+c)*i.cell,n}function ls(a,t,e,s,n){const i=Ge[s];return Tt(a*2+e,t,n^(s===0?40001:20343))*Ln<i.connect}const se=[0,0],Lt=[0,0];function Ao(a,t,e,s,n){const i=Ge[e];Me(a,t,e,s,se);let o=0,r=0;ls(a,t,0,e,s)&&(Me(a+1,t,e,s,Lt),o+=Lt[0]-se[0],r+=Lt[1]-se[1]),ls(a-1,t,0,e,s)&&(Me(a-1,t,e,s,Lt),o+=se[0]-Lt[0],r+=se[1]-Lt[1]),ls(a,t,1,e,s)&&(Me(a,t+1,e,s,Lt),o+=Lt[0]-se[0],r+=Lt[1]-se[1]),ls(a,t-1,1,e,s)&&(Me(a,t-1,e,s,Lt),o+=se[0]-Lt[0],r+=se[1]-Lt[1]);const c=Math.hypot(o,r);if(c<1e-5)n[0]=i.cell,n[1]=0;else{const l=i.cell*i.curve*2/c;n[0]=o*l,n[1]=r*l}return n}const rn=[0,0],cn=[0,0];function ic(a,t,e,s,n,i,o,r,c,l){const h=c*c,u=h*c,d=2*u-3*h+1,f=u-2*h+c,p=-2*u+3*h,m=u-h;return l[0]=d*a+f*e+p*n+m*o,l[1]=d*t+f*s+p*i+m*r,l}function ac(a,t,e,s,n){const i=Ge[s],o=e===0?a+1:a,r=e===0?t:t+1,c=Me(a,t,s,n,[0,0]),l=Me(o,r,s,n,[0,0]);Ao(a,t,s,n,rn),Ao(o,r,s,n,cn);const h=i.samples,u=new Float32Array((h+1)*2),d=[0,0];for(let m=0;m<=h;m++)ic(c[0],c[1],rn[0],rn[1],l[0],l[1],cn[0],cn[1],m/h,d),u[m*2]=d[0],u[m*2+1]=d[1];const p=1+((Tt(a*3+e,t*7,n^30657)&255)/255-.5)*.22;return{tier:s,pts:u,y:new Float32Array(h+1),width:i.width*p,verge:i.verge,key:`${s}:${a},${t},${e}`,minX:0,maxX:0,minZ:0,maxZ:0}}function rc(a){let t=1/0,e=-1/0,s=1/0,n=-1/0;for(let i=0;i<a.pts.length;i+=2){const o=a.pts[i],r=a.pts[i+1];o<t&&(t=o),o>e&&(e=o),r<s&&(s=r),r>n&&(n=r)}a.minX=t,a.maxX=e,a.minZ=s,a.maxZ=n}function Gi(a,t,e,s,n,i=40){const o=[];for(let r=0;r<Ge.length;r++){const c=Ge[r],l=c.cell*(.5+c.curve)+i,h=Math.floor((a-l)/c.cell),u=Math.floor((e+l)/c.cell),d=Math.floor((t-l)/c.cell),f=Math.floor((s+l)/c.cell);for(let p=d;p<=f;p++)for(let m=h;m<=u;m++)for(let v=0;v<2;v++){if(!ls(m,p,v,r,n))continue;const g=ac(m,p,v,r,n);rc(g);const w=g.width*.5+g.verge+i;g.maxX<a-w||g.minX>e+w||g.maxZ<t-w||g.minZ>s+w||o.push(g)}}return o}const hs=18;function Ui(a,t,e=null){const s=a.y.length,n=new Float32Array(s);for(let r=0;r<s;r++)n[r]=t(a.pts[r*2],a.pts[r*2+1]);a.y.set(n);const i=a.tier===0?6:3,o=new Float32Array(s);for(let r=0;r<i;r++){for(let c=0;c<s;c++){const l=a.y[Math.max(0,c-1)],h=a.y[c],u=a.y[Math.min(s-1,c+1)];o[c]=l*.25+h*.5+u*.25}a.y.set(o)}for(let r=0;r<s;r++){const c=a.y[r]-n[r];if(c>hs?a.y[r]=n[r]+hs:c<-hs&&(a.y[r]=n[r]-hs),e){const l=e(a.pts[r*2],a.pts[r*2+1]);l!==null&&a.y[r]<l+1.1&&(a.y[r]=l+1.1)}}for(let r=1;r<s-1;r++)o[r]=a.y[r-1]*.2+a.y[r]*.6+a.y[r+1]*.2;if(o[0]=a.y[0],o[s-1]=a.y[s-1],a.y.set(o),e){for(let r=0;r<s;r++){const c=e(a.pts[r*2],a.pts[r*2+1]);c!==null&&a.y[r]<c+1.1&&(a.y[r]=c+1.1)}for(let r=1;r<s-1;r++){const c=a.y[r-1]*.25+a.y[r]*.5+a.y[r+1]*.25,l=e(a.pts[r*2],a.pts[r*2+1]);o[r]=l!==null?Math.max(c,l+1.1):c}o[0]=a.y[0],o[s-1]=a.y[s-1],a.y.set(o)}return a}class cc{constructor(t,e,s,n,i,o,r=60,c=null){this.edges=Gi(t,e,s,n,i,r),this.seed=i,this._land=o;for(const l of this.edges)Ui(l,o,c);if(lc(this.edges),c)for(const l of this.edges)for(let h=0;h<l.y.length;h++){const u=c(l.pts[h*2],l.pts[h*2+1]);u!==null&&l.y[h]<u+1.1&&(l.y[h]=u+1.1)}}query(t,e){let s=1/0,n=0,i=0,o=0,r=1,c=0,l=0,h=0,u=null;for(const d of this.edges){const f=d.width*.5+d.verge+30;if(t<d.minX-f||t>d.maxX+f||e<d.minZ-f||e>d.maxZ+f)continue;const p=d.pts,m=p.length/2-1;for(let v=0;v<m;v++){const g=p[v*2],w=p[v*2+1],x=p[v*2+2],y=p[v*2+3],T=kn(t,e,g,w,x,y);if(T.d<s){s=T.d,n=I(d.y[v],d.y[v+1],T.t),i=d.width,o=d.tier;const b=x-g,M=y-w,_=Math.hypot(b,M)||1;r=b/_,c=M/_,l=T.x,h=T.z,u=d}}}return{d:s,y:n,width:i,tier:o,tx:r,tz:c,qx:l,qz:h,edge:u}}carve(t,e,s={mask:0,y:0,edge:0,d:1/0,tier:0,tx:1,tz:0,width:0}){let n=0,i=0,o=0,r=0,c=1/0,l=0,h=0,u=1,d=0;for(const f of this.edges){const p=f.width*.5,m=p+f.verge*2.6+60;if(t<f.minX-m||t>f.maxX+m||e<f.minZ-m||e>f.maxZ+m)continue;const v=f.pts,g=v.length/2-1;let w=1/0,x=0,y=1,T=0;for(let S=0;S<g;S++){const A=v[S*2],L=v[S*2+1],E=v[S*2+2],k=v[S*2+3],R=kn(t,e,A,L,E,k);if(R.d<w){w=R.d,x=I(f.y[S],f.y[S+1],R.t);const P=E-A,W=k-L,U=Math.hypot(P,W)||1;y=P/U,T=W/U}}if(w>m)continue;const b=Math.abs(x-this._land(t,e)),M=p+3+Math.min(b,hs+4)*1.6,_=1-At(p,M,w);_<=5e-4||(n+=_,i+=_*x,o=Math.max(o,_),w<c&&(c=w,l=f.width,h=f.tier,u=y,d=T,r=1-At(p-.4,p+.35,w)))}return s.d=c,s.tier=h,s.tx=u,s.tz=d,s.width=l,s.mask=o,s.edge=r,s.y=n>1e-6?i/n:0,s}}function lc(a){const t=[...a].sort((n,i)=>n.key<i.key?-1:n.key>i.key?1:0),e=t.filter(n=>n.tier===0),s=t.filter(n=>n.tier!==0);if(s.length){ko(s,e);for(let n=1;n<s.length;n++)ko([s[n]],s.slice(0,n))}}function ko(a,t){if(t.length)for(const e of a){const s=e.y.length,n=new Float32Array(s),i=new Float32Array(s);for(let c=0;c<s;c++){const l=e.pts[c*2],h=e.pts[c*2+1];let u=1/0,d=0;for(const f of t){const p=f.width*.5+14;if(l<f.minX-p||l>f.maxX+p||h<f.minZ-p||h>f.maxZ+p)continue;const m=f.pts.length/2-1;for(let v=0;v<m;v++){const g=kn(l,h,f.pts[v*2],f.pts[v*2+1],f.pts[v*2+2],f.pts[v*2+3]);g.d<u&&(u=g.d,d=I(f.y[v],f.y[v+1],g.t))}}if(u<18){const f=1-At(4,18,u);n[c]=d-e.y[c],i[c]=f}}const o=new Float32Array(s);for(let c=0;c<s;c++)o[c]=n[c]*i[c];const r=new Float32Array(s);for(let c=0;c<3;c++){for(let l=0;l<s;l++){const h=o[Math.max(0,l-1)],u=o[l],d=o[Math.min(s-1,l+1)];r[l]=i[l]>.75?u:h*.3+u*.4+d*.3}o.set(r)}for(let c=0;c<s;c++)e.y[c]+=o[c]}}const hc=new Float32Array(lt),uc=.02;function Hs(a,t,e,s){let n=0;for(let i=0;i<lt;i++){const o=s[i];o<uc||(n+=o*nc(a,t,e,i))}return n+Zt(a*.055,t*.055,3,e^7949,2,.4)*.55}function Hi(a,t,e){const{w:s}=Bi(a,t,e,hc);return Hs(a,t,e,s)}const Wi=a=>(t,e)=>Hi(t,e,a),Ki=a=>(t,e)=>{const{w:s}=Bi(t,e,a,dc);return Kn(s,Hs(t,e,a,s))},dc=new Float32Array(lt),Kt=48;class fc{constructor(t,e,s,n,i,o=128){this.seed=t,this.x0=Math.floor((e-o)/Kt)*Kt,this.z0=Math.floor((s-o)/Kt)*Kt,this.nx=Math.ceil((n+o-this.x0)/Kt)+2,this.nz=Math.ceil((i+o-this.z0)/Kt)+2;const r=this.nx*this.nz;this.ue=new Float32Array(r),this.ua=new Float32Array(r),this.ut=new Float32Array(r);for(let c=0;c<this.nz;c++)for(let l=0;l<this.nx;l++){const h=Pi(this.x0+l*Kt,this.z0+c*Kt,t),u=c*this.nx+l;this.ue[u]=h.ue,this.ua[u]=h.ua,this.ut[u]=h.ut}this._out={ue:0,ua:0,ut:0,e:0,t:0,m:0}}sample(t,e){const s=(t-this.x0)/Kt,n=(e-this.z0)/Kt;let i=Math.floor(s),o=Math.floor(n);i<0?i=0:i>this.nx-2&&(i=this.nx-2),o<0?o=0:o>this.nz-2&&(o=this.nz-2);const r=D(s-i),c=D(n-o),l=o*this.nx+i,h=l+1,u=l+this.nx,d=u+1,f=m=>I(I(m[l],m[h],r),I(m[u],m[d],r),c),p=this._out;return p.ue=f(this.ue),p.ua=f(this.ua),p.ut=f(this.ut),p}}class Ue{constructor(t,e,s,n,i,o=80){this.seed=t,this.climate=new fc(t,e,s,n,i,o+64),this.roads=new cc(e,s,n,i,t,Wi(t),o,Ki(t)),this._carve={mask:0,y:0,edge:0,d:1/0,tier:0,tx:1,tz:0,width:0},this._wl=new Float32Array(lt)}weights(t,e,s=this._wl){return zn(this.climate.sample(t,e),s)}land(t,e){const{w:s}=this.weights(t,e);return Hs(t,e,this.seed,s)}height(t,e){const{w:s}=this.weights(t,e),n=Hs(t,e,this.seed,s),i=this.roads.carve(t,e,this._carve);if(i.mask<=.001)return n;let o=0;for(let f=0;f<lt;f++)o+=s[f]*Yt[f].drive;const r=i.y,c=Math.abs(n-r),l=i.width*.5,h=l+3+c*1.5,u=(1-At(l,h,i.d))*D(o);let d=I(n,r,u);if(i.edge>.001){const f=D(i.d/l||0);d-=i.edge*f*f*.18}return d}normal(t,e,s=.6,n=[0,1,0]){const i=this.height(t-s,e),o=this.height(t+s,e),r=this.height(t,e-s),c=this.height(t,e+s),l=i-o,h=r-c,u=2*s,d=Math.hypot(l,u,h)||1;return n[0]=l/d,n[1]=u/d,n[2]=h/d,n}surface(t,e,s=null){const n=s||(this._surf||={y:0,nx:0,ny:1,nz:0,w:new Float32Array(lt),dominant:0,onRoad:0,roadDist:1/0,roadTier:0,roadTx:1,roadTz:0,grip:1,rough:0,surfaceKind:"grass"}),i=zn(this.climate.sample(t,e),n.w);n.dominant=i.dominant,n.y=this.height(t,e);const o=this.normal(t,e);n.nx=o[0],n.ny=o[1],n.nz=o[2];const r=this.roads.carve(t,e,this._carve);n.onRoad=r.edge,n.roadDist=r.d,n.roadTier=r.tier,n.roadTx=r.tx,n.roadTz=r.tz;let c=0,l=0;for(let d=0;d<lt;d++)c+=n.w[d]*an[d].grip,l+=n.w[d]*an[d].rough;const h=I(.52,.72,n.w[0]+n.w[4]),u=I(.85,.45,n.w[0]);return n.grip=I(h,c,n.onRoad),n.rough=I(u,l,n.onRoad),n.surfaceKind=n.onRoad>.5?an[i.dominant].surface:"ground",n}quickHeight(t,e){return this.height(t,e)}}function Ro(a,t=0,e=0){const n=new Ue(a,t-3e3,e-3e3,t+3e3,e+3e3,120);let i=null;for(const o of n.roads.edges){if(o.tier!==0)continue;const r=o.pts.length/2;for(let c=1;c<r-1;c++){const l=o.pts[c*2],h=o.pts[c*2+1],u=Math.abs(o.y[c+1]-o.y[c-1]),d=Math.hypot(l-t,h-e),f=u*40+d*.01;if(!i||f<i.score){const p=o.pts[c*2+2]-o.pts[c*2-2],m=o.pts[c*2+3]-o.pts[c*2-1];i={x:l,z:h,y:n.height(l,h),heading:Math.atan2(p,m),score:f}}}}return i||{x:t,z:e,y:n.height(t,e),heading:0,score:0}}const us=64,pc=8,mc=30,vc=a=>a<=2?65:33,gc=65,He=a=>us*(1<<a);function wc(a){const{cx:t,cz:e,level:s,seed:n}=a,i=He(s),o=vc(s),r=t*i,c=e*i,l=i/(o-1),h=new Ue(n,r,c,r+i,c+i,Math.max(80,l*3)),u=o*o,d=(o-1)*4,f=u+d,p=new Float32Array(f*3),m=new Float32Array(f*3),v=new Uint8Array(f*4),g=new Uint8Array(f*2),w=new Float32Array(u);let x=1/0,y=-1/0,T=1/0,b=-1/0,M=!1;const _=new Float32Array(lt),S={mask:0,y:0,edge:0,d:1/0,tier:0,tx:1,tz:0,width:0};for(let z=0;z<o;z++){const O=c+z*l;for(let j=0;j<o;j++){const it=r+j*l,tt=z*o+j,nt=h.height(it,O);w[tt]=nt,nt<x&&(x=nt),nt>y&&(y=nt),p[tt*3]=j*l,p[tt*3+1]=nt,p[tt*3+2]=z*l,h.weights(it,O,_),v[tt*4]=_[0]*255|0,v[tt*4+1]=_[1]*255|0,v[tt*4+2]=_[2]*255|0,v[tt*4+3]=_[3]*255|0,h.roads.carve(it,O,S),g[tt*2]=D(S.mask)*255|0,g[tt*2+1]=D(S.edge)*255|0;const gt=Kn(_,nt);gt!==null&&(M=!0,gt<T&&(T=gt),gt>b&&(b=gt))}}for(let z=0;z<o;z++)for(let O=0;O<o;O++){const j=z*o+O,it=w[z*o+Math.max(0,O-1)],tt=w[z*o+Math.min(o-1,O+1)],nt=w[Math.max(0,z-1)*o+O],gt=w[Math.min(o-1,z+1)*o+O],ht=O===0||O===o-1?l:l*2,Pt=z===0||z===o-1?l:l*2;let Q=(it-tt)/ht,Nt=(nt-gt)/Pt;const Ht=Math.hypot(Q,1,Nt);m[j*3]=Q/Ht,m[j*3+1]=1/Ht,m[j*3+2]=Nt/Ht}const L=(o-1)*(o-1)*6+d*6,E=f>65535?Uint32Array:Uint16Array,k=new E(L);let R=0;for(let z=0;z<o-1;z++)for(let O=0;O<o-1;O++){const j=z*o+O,it=j+1,tt=j+o,nt=tt+1;((O^z)&1)===0?(k[R++]=j,k[R++]=tt,k[R++]=it,k[R++]=it,k[R++]=tt,k[R++]=nt):(k[R++]=j,k[R++]=tt,k[R++]=nt,k[R++]=j,k[R++]=nt,k[R++]=it)}let P=u;const W=z=>{const O=z*3;return p[P*3]=p[O],p[P*3+1]=p[O+1]-mc,p[P*3+2]=p[O+2],m[P*3]=m[O],m[P*3+1]=m[O+1],m[P*3+2]=m[O+2],v[P*4]=v[z*4],v[P*4+1]=v[z*4+1],v[P*4+2]=v[z*4+2],v[P*4+3]=v[z*4+3],g[P*2]=g[z*2],g[P*2+1]=g[z*2+1],P++},U=[];for(let z=0;z<o-1;z++)U.push(z);for(let z=0;z<o-1;z++)U.push(z*o+(o-1));for(let z=o-1;z>0;z--)U.push((o-1)*o+z);for(let z=o-1;z>0;z--)U.push(z*o);const q=U.map(W);for(let z=0;z<U.length;z++){const O=U[z],j=U[(z+1)%U.length],it=q[z],tt=q[(z+1)%U.length];k[R++]=O,k[R++]=it,k[R++]=j,k[R++]=j,k[R++]=it,k[R++]=tt}let st=null;return M&&(st={level:(T+b)*.5,minY:x,maxY:y}),{cx:t,cz:e,level:s,size:i,ox:r,oz:c,step:l,grid:o,minY:x,maxY:y,vertCount:f,position:p,normal:m,biome:v,road:g,index:k,heights:s===0?w:null,water:st}}const gs=2,$i=["trees","rocks","bushes","reeds","posts"],xc={trees:1414677829,rocks:1380926283,bushes:1112888136,reeds:1380271428,posts:1347375956},bc=.7,yc=34,_c=6,Ps={},qi={},ji={};for(const a of $i){let t=0;for(let e=0;e<lt;e++)t=Math.max(t,xs[e][a]);Ps[a]=a==="posts"?yc:Math.sqrt(1e4*bc/t),qi[a]=Ps[a]*Ps[a],ji[a]=a==="posts"?_c:1}const Mc={trees:Math.cos(34*De),rocks:Math.cos(58*De),bushes:Math.cos(42*De),reeds:Math.cos(12*De),posts:Math.cos(24*De)},As=.15,Vi=26,Tc=1.6,ks=2,Sc={trees:(a,t,e)=>a<=As&&t>=e*.5+2.5,bushes:(a,t,e)=>a<=As&&t>=e*.5+1.4,rocks:(a,t,e)=>a<=As&&t>=e*.5+1.2,reeds:a=>a<=As,posts:(a,t)=>a<=.05&&t<=Vi},Ac={trees:(a,t)=>t===null||a>=t+.9,bushes:(a,t)=>t===null||a>=t+.5,rocks:(a,t)=>t===null||a>=t-.6,posts:(a,t)=>t===null||a>=t+.3,reeds:(a,t)=>t!==null&&t-a<=Tc&&t-a>=-.35};function kc(a,t){let e=0;for(let s=0;s<lt;s++)if(e+=a[s],t<e)return s;return lt-1}function Xe(a,t,e,s,n,i,o,r,c){const l=Ps[a],h=qi[a],u=ji[a],d=xc[a],f=Mc[a],p=Sc[a],m=Ac[a],v=Math.floor(s/l),g=Math.floor((s+i-1e-6)/l),w=Math.floor(n/l),x=Math.floor((n+i-1e-6)/l);for(let y=w;y<=x;y++)for(let T=v;T<=g;T++){const b=Ke(Di(T,y,d,e)),M=(T+b())*l,_=(y+b())*l;if(M<s||M>=s+i||_<n||_>=n+i)continue;const S=t.weights(M,_);o.set(S.w);const A=S.dominant,L=oc(o,xs,a);if(b()>=L*h*u/1e4)continue;const E=t.roads.carve(M,_);if(!p(E.edge,E.d,E.width))continue;const k=t.height(M,_),R=Kn(o,-1/0);if(!m(k,R))continue;const P=(k-t.height(M+ks,_))/ks,W=(k-t.height(M,_+ks))/ks,U=1/Math.hypot(P,1,W);U<f||(r.x=M,r.z=_,r.y=k,r.ny=U,r.dominant=A,r.wy=R,r.onRoad=E.edge,r.roadD=E.d,r.roadW=E.width,r.roadTx=E.tx,r.roadTz=E.tz,c(r,b))}}function Yi({cx:a,cz:t,level:e,seed:s}){const n={trees:[],rocks:[],bushes:[],reeds:[],posts:[]};if(!(e>=0)||e>gs)return n;const i=He(e),o=a*i,r=t*i,c=new Ue(s,o,r,o+i,r+i,Math.max(Vi+16,i*.25)),l=new Float32Array(lt),h={x:0,z:0,y:0,ny:1,wy:null,dominant:0,onRoad:0,roadD:1/0,roadW:0,roadTx:1,roadTz:0};return Xe("trees",c,s,o,r,i,l,h,(u,d)=>{const f=xs[kc(l,d())].kinds;n.trees.push({x:u.x,y:u.y,z:u.z,yaw:d()*Z,scale:.72+d()*.66,kind:f[d()*f.length|0],hue:d(),biome:u.dominant})}),Xe("bushes",c,s,o,r,i,l,h,(u,d)=>{n.bushes.push({x:u.x,y:u.y,z:u.z,yaw:d()*Z,scale:.62+d()*.7,kind:"scrub",hue:d(),biome:u.dominant})}),Xe("rocks",c,s,o,r,i,l,h,(u,d)=>{const f=d();n.rocks.push({x:u.x,y:u.y,z:u.z,yaw:d()*Z,scale:.34+Math.pow(d(),2.4)*3.1,kind:f<.58?"boulder":f<.86?"slab":"shard",tilt:(d()-.5)*(f<.58?.5:f<.86?.9:.3),hue:d(),biome:u.dominant})}),Xe("reeds",c,s,o,r,i,l,h,(u,d)=>{n.reeds.push({x:u.x,y:u.y,z:u.z,yaw:d()*Z,scale:.6+d()*.7,kind:"reed",hue:d(),depth:u.wy-u.y,biome:u.dominant})}),Xe("posts",c,s,o,r,i,l,h,(u,d)=>{const f=u.roadD<u.roadW*.5+3.5;n.posts.push({x:u.x,y:u.y,z:u.z,yaw:f?Math.atan2(u.roadTx,u.roadTz)+Math.PI*.5:d()*Z,scale:f?.85+d()*.3:.7+d()*.5,kind:f?d()<.12?"milestone":"marker":"fence",lean:(d()-.5)*.16,hue:d(),biome:u.dominant})}),n}function Rc(a){if(!(a>=0)||a>gs)return 0;const t=He(a)*He(a);let e=0;for(const s of $i){let n=0;for(let i=0;i<lt;i++)n=Math.max(n,xs[i][s]);e+=n}return Math.ceil(e*t/1e4)}J.uMeanWind||(J.uMeanWind={value:new ct(3,1)});J.uWindSpan||(J.uWindSpan={value:0});const Ec=9200,Cc=()=>({pos:[],nrm:[],clm:[],flx:[],hue:[],idx:[],n:0});function Xi(a,t,e,s,n,i,o,r,c,l,h,u){return a.pos.push(t,e,s),a.nrm.push(n,i,o),a.clm.push(r,c,l),a.flx.push(h),a.hue.push(u),a.n++}function zc(a){const t=new Mi;t.setAttribute("position",new G(new Float32Array(a.pos),3)),t.setAttribute("nrm",new G(new Float32Array(a.nrm),3)),t.setAttribute("clm",new G(new Float32Array(a.clm),3)),t.setAttribute("flx",new G(new Float32Array(a.flx),1)),t.setAttribute("hue",new G(new Float32Array(a.hue),1));const e=a.n>65535?Uint32Array:Uint16Array;return t.setIndex(new G(new e(a.idx),1)),t}function Ot(a,t,e,s,n){const i=[];for(let o=0;o<t.length;o++){const r=t[o];let c;o===0?c=[t[1][0]-r[0],t[1][1]-r[1],t[1][2]-r[2]]:o===t.length-1?c=[r[0]-t[o-1][0],r[1]-t[o-1][1],r[2]-t[o-1][2]]:c=[t[o+1][0]-t[o-1][0],t[o+1][1]-t[o-1][1],t[o+1][2]-t[o-1][2]];const l=Math.hypot(c[0],c[1],c[2])||1;c=[c[0]/l,c[1]/l,c[2]/l];let h=[0,1,0];Math.abs(c[1])>.94&&(h=[1,0,0]);let u=[c[1]*h[2]-c[2]*h[1],c[2]*h[0]-c[0]*h[2],c[0]*h[1]-c[1]*h[0]];const d=Math.hypot(u[0],u[1],u[2])||1;u=[u[0]/d,u[1]/d,u[2]/d];const f=[c[1]*u[2]-c[2]*u[1],c[2]*u[0]-c[0]*u[2],c[0]*u[1]-c[1]*u[0]],p=[],m=Math.pow(K(o/(t.length-1),0,1),1.6)*.55;for(let v=0;v<s;v++){const g=v/s*Z,w=Math.cos(g),x=Math.sin(g),y=1+Math.sin(g*3+o)*.09+Math.cos(g*5-o*.7)*.05,T=e[o]*y,b=u[0]*w+f[0]*x,M=u[1]*w+f[1]*x,_=u[2]*w+f[2]*x;p.push(Xi(a,r[0]+b*T,r[1]+M*T,r[2]+_*T,b,M,_,r[0],r[1],r[2],m,n))}i.push(p)}for(let o=0;o<i.length-1;o++)for(let r=0;r<s;r++){const c=i[o][r],l=i[o][(r+1)%s],h=i[o+1][r],u=i[o+1][(r+1)%s];a.idx.push(c,h,l,l,h,u)}}const ln=(()=>{const a=(1+Math.sqrt(5))/2,t=[[-1,a,0],[1,a,0],[-1,-a,0],[1,-a,0],[0,-1,a],[0,1,a],[0,-1,-a],[0,1,-a],[a,0,-1],[a,0,1],[-a,0,-1],[-a,0,1]].map(o=>{const r=Math.hypot(o[0],o[1],o[2]);return[o[0]/r,o[1]/r,o[2]/r]}),e=[[0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],[1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],[3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],[4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1]],s=(o,r)=>{const c=[],l={},h=(u,d)=>{const f=u<d?`${u}_${d}`:`${d}_${u}`;if(l[f]!==void 0)return l[f];const p=[(o[u][0]+o[d][0])/2,(o[u][1]+o[d][1])/2,(o[u][2]+o[d][2])/2],m=Math.hypot(p[0],p[1],p[2]);return o.push([p[0]/m,p[1]/m,p[2]/m]),l[f]=o.length-1,l[f]};for(const u of r){const d=h(u[0],u[1]),f=h(u[1],u[2]),p=h(u[2],u[0]);c.push([u[0],d,p],[u[1],f,d],[u[2],p,f],[d,f,p])}return c},n={v:t.map(o=>o.slice()),f:e.map(o=>o.slice())};n.f=s(n.v,n.f);const i={v:n.v.map(o=>o.slice()),f:n.f.map(o=>o.slice())};return i.f=s(i.v,i.f),{L0:{v:t,f:e},L1:n,L2:i}})();function $t(a,t,e,s,n,i,o,r,c,l){const h=l>=2?ln.L2:l>=1?ln.L1:ln.L0,u=a.n,d=Ke(r*7919|0),f=[d()*10,d()*10,d()*10];for(const p of h.v){const m=1+.2*Math.sin(p[0]*4.1+f[0])*Math.sin(p[1]*3.7+f[1])+.14*Math.sin(p[2]*6.3+f[2])*Math.cos(p[0]*5.1+f[1])+.09*Xt(p[0]*3.4+f[0],p[2]*3.4+f[2]);Xi(a,t+p[0]*n*m,e+p[1]*i*m,s+p[2]*o*m,p[0],p[1],p[2],t,e,s,1,c)}for(const p of h.f)a.idx.push(u+p[0],u+p[1],u+p[2])}const Xs={broadleaf:{h:11.5,flex:1},poplar:{h:15,flex:.8},pine:{h:14.5,flex:.52},deadpine:{h:13,flex:.26},acacia:{h:9.5,flex:.9},scrub:{h:2.5,flex:1.25},palm:{h:12.5,flex:1.6},willow:{h:9.5,flex:1.75}},Lc=Object.keys(Xs);function Dc(a,t,e){const s=Cc(),n=Ke(e),i=a==="poplar"?13+n()*5:a==="pine"?12+n()*6:a==="deadpine"?11+n()*5:a==="acacia"?8+n()*3.5:a==="palm"?10+n()*5:a==="scrub"?1.9+n()*1.3:a==="willow"?8+n()*3:10+n()*4,o=t>=2?8:t>=1?6:4,r=Math.max(0,t-1);if(a==="pine"){const c=[],l=[];for(let u=0;u<=6;u++){const d=u/6;c.push([Math.sin(d*2.1)*.35*d*i*.06,d*i,Math.cos(d*1.7)*.3*d*i*.06]),l.push(I(i*.035,i*.006,d))}Ot(s,c,l,o,0);const h=t>=1?6:4;for(let u=0;u<h;u++){const d=.3+.68*(u/(h-1)),f=(1-d)*i*.3+i*.05;$t(s,0,d*i+i*.04,0,f,f*.36,f,e+u*13,.15+n()*.7,r)}}else if(a==="poplar"){const c=[],l=[];for(let u=0;u<=7;u++){const d=u/7;c.push([Math.sin(d*3)*.5,d*i,Math.cos(d*2.2)*.45]),l.push(I(i*.028,i*.005,d))}Ot(s,c,l,o,0);const h=t>=1?9:5;for(let u=0;u<h;u++){const d=.2+.78*(u/(h-1)),f=i*(.17-.08*Math.abs(d-.55)*1.4);$t(s,Math.sin(d*7)*.5,d*i,Math.cos(d*6)*.45,f*.9,f*1.35,f*.9,e+u*29,.2+n()*.7,r)}}else if(a==="willow"){const c=[],l=[];for(let u=0;u<=5;u++){const d=u/5;c.push([d*d*1.7,d*i*.72,Math.sin(d*2)*.6]),l.push(I(i*.05,i*.012,d))}Ot(s,c,l,o,0);const h=t>=1?12:6;for(let u=0;u<h;u++){const d=n()*Z,f=Math.sqrt(n())*i*.42,p=Math.cos(d)*f+1.5,m=Math.sin(d)*f,v=i*.62+(n()-.3)*i*.22,g=i*(.13+n()*.09);$t(s,p,v,m,g*1.15,g*.8,g*1.15,e+u*37,.5+n()*.5,r),t>=1&&$t(s,p*1.05,v-g*1.5,m*1.05,g*.55,g*1.5,g*.55,e+u*41,.6+n()*.4,r)}}else if(a==="deadpine"){const c=[],l=[],h=(n()-.5)*.9;for(let d=0;d<=6;d++){const f=d/6;c.push([h*f*f*i*.1,f*i,Math.sin(f*2.7)*.4]),l.push(I(i*.032,i*.012,Math.pow(f,.75)))}Ot(s,c,l,o,0);const u=t>=2?7:t>=1?5:3;for(let d=0;d<u;d++){const f=.34+.58*(d/Math.max(1,u-1)),p=d*2.399+n()*.6,m=i*(.3-.16*f)*(.7+n()*.6),v=[],g=[];for(let w=0;w<=2;w++){const x=w/2;v.push([Math.cos(p)*m*x,f*i+x*m*.42-x*x*m*.5,Math.sin(p)*m*x]),g.push(I(i*.012,i*.003,x))}Ot(s,v,g,Math.max(3,o-3),0)}if(t>=1)for(let d=0;d<2;d++){const f=n()*Z,p=i*(.09+n()*.05);$t(s,Math.cos(f)*i*.1,i*(.68+d*.16),Math.sin(f)*i*.1,p,p*.22,p,e+d*61,n()*.25,r)}}else if(a==="acacia"){const c=[],l=[],h=(n()-.5)*.4;for(let p=0;p<=5;p++){const m=p/5;c.push([h*m*m*i*.2,m*i*.6,Math.cos(m*2.1)*.3]),l.push(I(i*.055,i*.02,m))}Ot(s,c,l,o,0);const u=t>=1?5:3,d=i*.52;for(let p=0;p<u;p++){const m=p/u*Z+n()*.8,v=d*(.72+n()*.3),g=[],w=[];for(let x=0;x<=3;x++){const y=x/3;g.push([Math.cos(m)*v*y,i*.58+Math.pow(y,.55)*i*.3,Math.sin(m)*v*y]),w.push(I(i*.02,i*.005,y))}Ot(s,g,w,Math.max(3,o-2),0)}const f=t>=2?16:t>=1?10:5;for(let p=0;p<f;p++){const m=n()*Z,v=Math.pow(n(),.42)*d,g=d*(.2+n()*.16)*(1-v/d*.35);$t(s,Math.cos(m)*v,i*.9-v*.1+(n()-.5)*i*.05,Math.sin(m)*v,g*1.25,g*.34,g*1.25,e+p*71,n(),r)}}else if(a==="scrub"){const c=t>=1?3:2;for(let h=0;h<c;h++){const u=h/c*Z+n()*1.1,d=[],f=[];for(let p=0;p<=3;p++){const m=p/3;d.push([Math.cos(u)*m*i*.22,m*i*.55,Math.sin(u)*m*i*.22]),f.push(I(i*.05,i*.018,m))}Ot(s,d,f,Math.max(3,o-2),0)}const l=t>=2?9:t>=1?6:3;for(let h=0;h<l;h++){const u=n()*Z,d=Math.pow(n(),.6)*i*.42,f=i*(.24+n()*.16);$t(s,Math.cos(u)*d,i*.52+(n()-.35)*i*.24,Math.sin(u)*d,f*1.1,f*.78,f*1.1,e+h*83,n(),r)}}else if(a==="palm"){const c=[],l=[],h=.9+n()*1.4,u=n()*Z;for(let v=0;v<=7;v++){const g=v/7,w=h*g*g;c.push([Math.cos(u)*w,g*i,Math.sin(u)*w]),l.push(I(i*.026,i*.016,g))}Ot(s,c,l,o,0);const d=Math.cos(u)*h,f=Math.sin(u)*h,p=t>=2?9:t>=1?7:5,m=i*.44;for(let v=0;v<p;v++){const g=v/p*Z+n()*.35,w=.8+n()*.6;for(let x=1;x<=3;x++){const y=x/3,T=m*y,b=m*(.19-.075*y);$t(s,d+Math.cos(g)*T,i+m*(.26*y-.62*y*y*w),f+Math.sin(g)*T,b*1.15,b*.3,b*1.15,e+v*97+x*7,.25+n()*.6,r)}}$t(s,d,i+m*.06,f,m*.22,m*.2,m*.22,e+991,.3+n()*.3,r)}else{const c=[],l=[],h=(n()-.5)*.5;for(let p=0;p<=6;p++){const m=p/6;c.push([h*m*m*i*.14+Math.sin(m*3.4)*.35,m*i*.52,Math.cos(m*2.6)*.35]),l.push(I(i*.062,i*.026,m))}Ot(s,c,l,o,0);const u=t>=2?5:t>=1?4:0;for(let p=0;p<u;p++){const m=p/u*Z+n()*.9,v=i*(.26+n()*.16),g=[],w=[];for(let x=0;x<=3;x++){const y=x/3;g.push([Math.cos(m)*v*y*.9,i*.5+y*v*.72-y*y*v*.12,Math.sin(m)*v*y*.9]),w.push(I(i*.02,i*.006,y))}Ot(s,g,w,Math.max(3,o-2),0)}const d=t>=2?22:t>=1?12:7,f=i*.4;for(let p=0;p<d;p++){let m,v,g,w;if(p===0)m=0,v=i*.78,g=0,w=f*.72;else{const x=n()*Z,y=Math.pow(n(),.55)*f*1.02;m=Math.cos(x)*y,g=Math.sin(x)*y*.92,v=i*.74+(n()-.44)*f*.95-y*.2,w=f*(.26+n()*.26)}$t(s,m,v,g,w*1.12,w*.86,w*1.12,e+p*53,n(),r)}}return s}const Zi=`
uniform vec2  uMeanWind;
uniform float uWindSpan;   // metres covered by uWindTex; 0 = no target, analytic only
float windBandAnalytic(vec2 p){
  vec2 q = p - uMeanWind * (uTime * 1.22);
  float a = fbm2(q * 0.0052, 3);
  float b = pn2(q * 0.0168 + 13.0);
  float c = pn2(q * 0.055  + 41.0);
  return clamp(a*1.30 + b*0.55 + c*0.22, -1.2, 1.4);
}
vec4 windAnalytic(vec2 p){
  float band = windBandAnalytic(p);
  float gust = clamp(0.80 + band*0.95, 0.05, 2.3);
  return vec4(uMeanWind*gust, gust, clamp(band, 0.0, 1.0)*0.85);
}
// Single exit on purpose. The obvious early-return version makes the HLSL backend emit
// "use of potentially uninitialized variable", and a driver that acts on that warning turns
// a tree into a black billboard. Both fast paths survive: inside the render target the
// simulated field IS the answer and the twenty-odd hashes of the analytic fallback are pure
// waste, outside it there is no texture to fetch. Every vertex of a tree samples the same
// iPos.xz, so the branch is perfectly coherent across a warp.
vec4 windSample(vec2 p){
  vec4 res;
  vec2 uv = (p - uWindOrigin) / max(uWindSpan, 1.0) + 0.5;
  float edge = (uWindSpan > 0.0)
    ? 1.0 - smoothstep(0.40, 0.498, max(abs(uv.x-0.5), abs(uv.y-0.5)))
    : 0.0;
  if(edge <= 0.001){
    res = windAnalytic(p);
  } else if(edge >= 0.999){
    res = texture(uWindTex, clamp(uv, vec2(0.003), vec2(0.997)));
  } else {
    res = mix(windAnalytic(p), texture(uWindTex, clamp(uv, vec2(0.003), vec2(0.997))), edge);
  }
  return res;
}
// logarithmic boundary layer, normalised to the 10 m reference height
float windProfile(float z){ return log((max(z,0.015) + 0.06) / 0.06) * 0.19523; }
`;function Ji(){const a=zi(),t=[];for(let e=0;e<a.count;e++)t.push(`vec3(${a.foliage[e*3].toFixed(4)},${a.foliage[e*3+1].toFixed(4)},${a.foliage[e*3+2].toFixed(4)})`);return`
const int NFOL = ${a.count};
const vec3 B_FOLIAGE[${a.count}] = vec3[${a.count}](${t.join(",")});
`}const Qi=`
uniform float uTreeH;      // nominal archetype height
uniform float uFlex;       // archetype stiffness multiplier (willow >> snag)
uniform float uCullR;      // >0 : reject instances beyond this radius of the shadow centre
in vec3 nrm; in vec3 clm; in float flx; in float hue;
in vec4 iPos;              // xyz = root, w = scale
in vec4 iVar;              // rot, hueShift, phase, biome
out vec3 vW; out vec3 vN; out float vHue; out float vLeaf; out float vDist;
out float vY; out float vAO; out vec3 vTint;
void main(){
  // The sun shadow map covers a bounded square around the car, so a tree two kilometres
  // away cannot cast into it — yet without this every instance in the world would still be
  // transformed, swayed and rasterised into it. The depth material sets uCullR; the beauty
  // material leaves it 0.
  if(uCullR > 0.0 && distance(iPos.xz, uShadowC) > uCullR){
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return;
  }
  float sc = iPos.w;
  float rot = iVar.x, ph = iVar.z;
  float c = cos(rot), s = sin(rot);
  vec3 lp  = position * sc;
  vec3 ln  = nrm;
  vec3 lc  = clm * sc;
  vec3 rp  = vec3(lp.x*c - lp.z*s, lp.y, lp.x*s + lp.z*c);
  vec3 rn  = vec3(ln.x*c - ln.z*s, ln.y, ln.x*s + ln.z*c);
  vec3 rc  = vec3(lc.x*c - lc.z*s, lc.y, lc.x*s + lc.z*c);
  float H  = uTreeH * sc;

  vec4 W = windSample(iPos.xz);
  float prof = windProfile(max(H*0.62, 0.6));
  vec2 wv = W.rg * prof;
  float gust = W.b, exc = W.a;
  float spd = length(wv);

  vec2 bd = normalize(wv + vec2(1e-5));
  float yn = clamp(rp.y / max(H, 0.5), 0.0, 1.4);

  // trunk: static bend + a resonant mode near 0.5 Hz, mass-lagged behind the grass
  float f0  = 0.40 + 0.26*fract(ph*0.31831);
  float osc = sin(uTime*6.2831853*f0 + ph);
  float bend = (spd*0.052 + (exc*0.30 + max(gust-1.0,0.0)*0.55)*0.16*osc) * uFlex;
  bend = clamp(bend, -0.55, 0.75);
  vec3 p = rp;
  p.xz += bd * (bend * yn*yn * H * 0.42);
  p.y  -= bend*bend * yn*yn * H * 0.22;   // a bent mast is a shorter mast

  // clumps: a faster secondary sway, each with its own phase
  float cph = dot(rc.xz, vec2(0.61, 0.43)) + ph*2.7;
  float f1  = 0.70 + 0.42*fract(sin(cph)*137.51);
  float csw = sin(uTime*6.2831853*f1 + cph);
  vec3  cOff = vec3(bd.x, 0.15*csw, bd.y) * csw * (0.06 + 0.34*gust) * 0.34 * flx * sc;
  p += cOff;

  // leaves flutter around their clump centre
  vec3 rel = rp - rc;
  float rl = length(rel) + 1e-4;
  float flut = sin(uTime*5.1 + dot(rel, vec3(3.3,4.9,2.7)) + cph*1.7);
  p += (rel/rl) * flut * 0.045 * flx * sc * (0.35 + 0.8*gust);

  vec3 wp = iPos.xyz + p;
  vW = wp; vN = normalize(rn); vHue = fract(hue + iVar.y);
  vLeaf = step(0.9, flx); vY = clamp(rp.y/max(H,0.5), 0.0, 1.0);
  // Cheap vertical AO: the inside of a canopy and the foot of a trunk never see the sky.
  vAO = mix(0.62, 1.0, smoothstep(0.0, 0.55, vY));
  vTint = B_FOLIAGE[clamp(int(iVar.w + 0.5), 0, NFOL-1)];
  vec4 mv = viewMatrix * vec4(wp, 1.0);
  vDist = -mv.z;
  gl_Position = projectionMatrix * mv;
}`,Fc=`
in vec3 vW; in vec3 vN; in float vHue; in float vLeaf; in float vDist;
in float vY; in float vAO; in vec3 vTint;
out vec4 outColor;
void main(){
  vec3 N = normalize(vN);
  vec3 V = normalize(uCamPos - vW);
  vec3 lit, mid, shd; float trans, rim;

  if(vLeaf > 0.5){
    // four-green canopy mosaic
    vec3 base = vHue<0.26 ? ${C.cVarA} : (vHue<0.52 ? ${C.cLit} :
                (vHue<0.76 ? ${C.cVarB} : ${C.cVarC}));
    float grain = pn2(vW.xz*0.85 + vW.y*0.6)*0.5+0.5;
    lit = mix(base, ${C.cLit}, 0.42) * (1.02 + 0.24*grain);
    mid = mix(${C.cMid}, base*0.72, 0.45);
    shd = mix(${C.cShade}, ${C.cDeep}, grain*0.45);
    // Biome foliage tint: the same table the ground blends, so a highland pine and the
    // hillside it stands on go cold together.
    lit *= vTint; mid *= vTint; shd *= vTint;
    trans = 1.05; rim = 0.52;
  } else {
    float bark = pn2(vec2(atan(N.z,N.x)*3.4, vW.y*3.1))*0.5+0.5;
    vec3 wood = mix(vec3(1.0), vTint, 0.55);
    lit = ${C.trunkLit} * (0.82 + 0.34*bark) * wood;
    mid = mix(${C.trunkLit}, ${C.trunkShade}, 0.55) * wood;
    shd = ${C.trunkShade} * (0.85 + 0.3*bark) * wood;
    trans = 0.0; rim = 0.28;
  }
  // moss on the shaded north side of trunks and the underside of clumps
  float moss = smoothstep(0.15, -0.5, N.y) * (pn2(vW.xz*1.6 + vW.y)*0.5+0.5);
  shd = mix(shd, ${C.moss}*0.55, moss*0.35*(1.0-vLeaf));

  float ndl = dot(N, uSunDir);
  float sh = sunShadow(vW, ndl) * cloudShadow(vW);
  Surf s;
  s.N=N; s.V=V; s.P=vW; s.shade=shd; s.mid=mid; s.lit=lit;
  s.soft = mix(0.09, 0.20, clamp(vDist*0.004,0.0,1.0));
  s.jit = (vn2(vW.xz*3.9 + vW.y*1.7) - 0.5)*0.055;
  s.shadow = sh; s.trans = trans; s.transCol = ${C.cTrans};
  s.rim = rim; s.ao = vAO; s.ambient = 1.0;
  vec3 col = paint(s);
  col = aerial(col, vDist, V, vW.y);
  outColor = vec4(SAFE3(col), gFogAmt);
}`;function Ic(a){const t=Xs[a];return new pt({glslVersion:"300 es",uniforms:St({uTreeH:{value:t.h},uFlex:{value:t.flex},uCullR:{value:0}}),vertexShader:xt(mt,vt,Zi,Ji(),Qi),fragmentShader:It(mt,vt,ke({cshSpan:Ec}),We,Re,Fc),side:Jt})}function Pc(a,t){const e=Xs[a];return new pt({glslVersion:"300 es",uniforms:St({uTreeH:{value:e.h},uFlex:{value:e.flex},uCullR:{value:t}}),vertexShader:xt(mt,vt,Zi,Ji(),Qi),fragmentShader:Wn,side:Jt})}const Nc=1400,Oc=.92,Bc=420,Eo=2.6,Co=512;class Gc{constructor({seed:t,scene:e,quality:s=1,cullDistance:n=Nc,bushes:i=!0}){this.seed=t>>>0,this.scene=e,this.quality=K(s,.4,2),this.cull=n*K(this.quality,.7,1.35),this.renderBushes=i,this.group=new ge,this.group.name="flora",this.group.matrixAutoUpdate=!1,this.batches=new Map,this.chunks=new Map,this.pending=[],this.stats={chunks:0,instances:0,batches:0,attached:0,buildMs:0,backlog:0},this._cam=new Y,this._hasCam=!1,e.add(this.group)}_detailFor(t){return K(2-t-(this.quality<.75?1:0),0,2)}add(t){if(t.level>gs)return;const e=`${t.level}:${t.cx},${t.cz}`;if(this.chunks.has(e))return;const s={key:e,level:t.level,cx:t.cx,cz:t.cz,mx:t.ox+t.size*.5,mz:t.oz+t.size*.5,groups:null,blocks:null,dead:!1};this.chunks.set(e,s),this.pending.push(s),this.stats.chunks=this.chunks.size}remove(t){const e=`${t.level}:${t.cx},${t.cz}`,s=this.chunks.get(e);s&&(s.dead=!0,s.blocks&&this._detach(s),this.chunks.delete(e),this.stats.chunks=this.chunks.size)}update(t,e){e&&(this._cam.copy(e),this._hasCam=!0),this._drain(t),this._cullPass(),this._flush()}_drain(t){const e=performance.now(),s=t>1/45?Eo*.45:Eo;let n=0;for(;this.pending.length;){const i=this.pending[0];if(i.dead){this.pending.shift();continue}if(n>0&&performance.now()-e>s)break;this.pending.shift(),this._scatter(i),n++}this.stats.buildMs=performance.now()-e,this.stats.backlog=this.pending.length}_scatter(t){const e=Yi({cx:t.cx,cz:t.cz,level:t.level,seed:this.seed}),s=this._detailFor(t.level),n=new Map,i=(o,r,c)=>{for(let l=0;l<o.length;l++){const h=o[l],u=Xs[h.kind];if(!u){console.error("[flora] no archetype for species",h.kind,"— check BIOME_SCATTER kinds");continue}const d=`${h.kind}:${r}`;let f=n.get(d);f||(f={kind:h.kind,detail:r,pos:[],vari:[],minX:1e9,maxX:-1e9,minZ:1e9,maxZ:-1e9,minY:1e9,maxY:-1e9},n.set(d,f));const p=Tt(Math.round(h.x*4),Math.round(h.z*4),this.seed)/4294967296*10,m=h.y-c*h.scale;f.pos.push(h.x,m,h.z,h.scale),f.vari.push(h.yaw,h.hue,p,h.biome);const v=u.h*h.scale*1.25,g=v*.45;h.x-g<f.minX&&(f.minX=h.x-g),h.x+g>f.maxX&&(f.maxX=h.x+g),h.z-g<f.minZ&&(f.minZ=h.z-g),h.z+g>f.maxZ&&(f.maxZ=h.z+g),m<f.minY&&(f.minY=m),m+v>f.maxY&&(f.maxY=m+v)}};i(e.trees,s,.35),this.renderBushes&&t.level<=1&&i(e.bushes,Math.min(s,t.level===0?1:0),.18),t.groups=n,(!this._hasCam||this._distance(t)<=this.cull)&&this._attach(t)}_distance(t){return Math.hypot(t.mx-this._cam.x,t.mz-this._cam.z)}_batch(t,e){const s=`${t}:${e}`;let n=this.batches.get(s);if(n)return n;const i=Tt(Lc.indexOf(t)+1,e+1,1592598191),o=zc(Dc(t,e,i)),r=Math.max(64,Rc(Math.min(gs,2-e))),c=new Float32Array(r*4),l=new Float32Array(r*4),h=new pe(c,4),u=new pe(l,4);h.setUsage(_s),u.setUsage(_s),o.setAttribute("iPos",h),o.setAttribute("iVar",u),o.instanceCount=0,o.boundingSphere=new ie(new Y,0);const d=new bt(o,Ic(t));return d.frustumCulled=!0,d.matrixAutoUpdate=!1,d.updateMatrix(),d.renderOrder=2,d.visible=!1,d.userData.depth=Pc(t,Bc),this.group.add(d),n={key:s,kind:t,detail:e,geom:o,mesh:d,iPos:c,iVar:l,aPos:h,aVar:u,cap:r,count:0,blocks:[],dirty:!1},this.batches.set(s,n),this.stats.batches=this.batches.size,n}_reserve(t,e){if(e<=t.cap)return;let s=t.cap;for(;s<e;)s*=2;const n=new Float32Array(s*4),i=new Float32Array(s*4);n.set(t.iPos.subarray(0,t.count*4)),i.set(t.iVar.subarray(0,t.count*4)),t.aPos=new pe(n,4),t.aVar=new pe(i,4),t.aPos.setUsage(_s),t.aVar.setUsage(_s),t.geom.setAttribute("iPos",t.aPos),t.geom.setAttribute("iVar",t.aVar),t.iPos=n,t.iVar=i,t.cap=s}_attach(t){if(t.blocks||!t.groups)return;const e=[];for(const s of t.groups.values()){const n=s.pos.length/4;if(!n)continue;const i=this._batch(s.kind,s.detail);this._reserve(i,i.count+n),i.iPos.set(s.pos,i.count*4),i.iVar.set(s.vari,i.count*4);const o={batch:i,start:i.count,len:n,g:s};i.blocks.push(o),i.count+=n,i.dirty=!0,e.push(o)}t.blocks=e}_detach(t){if(t.blocks){for(const e of t.blocks){const s=e.batch,n=s.blocks.indexOf(e);if(n<0)continue;if(s.count-(e.start+e.len)>0){s.iPos.copyWithin(e.start*4,(e.start+e.len)*4,s.count*4),s.iVar.copyWithin(e.start*4,(e.start+e.len)*4,s.count*4);for(let o=n+1;o<s.blocks.length;o++)s.blocks[o].start-=e.len}s.blocks.splice(n,1),s.count-=e.len,s.dirty=!0}t.blocks=null}}_cullPass(){if(!this._hasCam)return;const t=this.cull,e=this.cull*Oc;let s=0;for(const n of this.chunks.values()){if(!n.groups)continue;const i=this._distance(n);n.blocks?i>t?this._detach(n):s++:i<=e&&(this._attach(n),s++)}this.stats.attached=s,this.chunks.size>Co&&this._evict()}_evict(){const t=[];for(const s of this.chunks.values())!s.blocks&&s.groups&&t.push(s);t.sort((s,n)=>this._distance(n)-this._distance(s));const e=Math.min(t.length,this.chunks.size-Co);for(let s=0;s<e;s++)this.chunks.delete(t[s].key);this.stats.chunks=this.chunks.size}_flush(){let t=0;for(const e of this.batches.values()){if(t+=e.count,!e.dirty||(e.dirty=!1,e.geom.instanceCount=e.count,e.mesh.visible=e.count>0,e.aPos.needsUpdate=!0,e.aVar.needsUpdate=!0,!e.count))continue;let s=1e9,n=-1e9,i=1e9,o=-1e9,r=1e9,c=-1e9;for(const h of e.blocks){const u=h.g;u.minX<s&&(s=u.minX),u.maxX>n&&(n=u.maxX),u.minZ<i&&(i=u.minZ),u.maxZ>o&&(o=u.maxZ),u.minY<r&&(r=u.minY),u.maxY>c&&(c=u.maxY)}const l=e.geom.boundingSphere;l.center.set((s+n)*.5,(r+c)*.5,(i+o)*.5),l.radius=Math.hypot(n-s,c-r,o-i)*.5}this.stats.instances=t}dispose(){for(const t of this.batches.values())this.group.remove(t.mesh),t.geom.dispose(),t.mesh.material.dispose(),t.mesh.userData.depth.dispose();this.batches.clear(),this.chunks.clear(),this.pending.length=0,this.group.parent&&this.group.parent.remove(this.group)}}const N={MATTE:0,METAL:1,EMIT:2,GLASS:3,LAMP_A:4,LAMP_B:5,LAMP_C:6},X=a=>Gs[a],Se=(a,t)=>[a[0]*t,a[1]*t,a[2]*t],Ws=(a,t,e)=>[I(a[0],t[0],e),I(a[1],t[1],e),I(a[2],t[2],e)];function Ks(){return{pos:[],nrm:[],col:[],mat:[],idx:[],n:0}}function Et(a,t,e,s,n,i,o,r,c){return a.pos.push(t,e,s),a.nrm.push(n,i,o),a.col.push(r[0],r[1],r[2]),a.mat.push(c||0),a.n++}function $n(a,t,e,s,n){a.idx.push(t,e,s,t,s,n)}function zo(a,t,e,s){a.idx.push(t,e,s)}function Lo(a,t,e,s){return[a*e-t*s,a*s+t*e]}function ot(a,t,e,s,n,i,o,r,c,l){const h=Math.cos(r),u=Math.sin(r),d=(m,v,g)=>{const[w,x]=Lo(m*n,g*o,h,u);return[t+w,e+v*i,s+x]},f=(m,v)=>{const[g,w]=Lo(m,v,h,u);return[g,0,w]},p=[{q:[[1,-1,-1],[1,-1,1],[1,1,1],[1,1,-1]],n:f(1,0)},{q:[[-1,-1,1],[-1,-1,-1],[-1,1,-1],[-1,1,1]],n:f(-1,0)},{q:[[-1,1,-1],[1,1,-1],[1,1,1],[-1,1,1]],n:[0,1,0]},{q:[[-1,-1,1],[1,-1,1],[1,-1,-1],[-1,-1,-1]],n:[0,-1,0]},{q:[[-1,-1,1],[-1,1,1],[1,1,1],[1,-1,1]],n:f(0,1)},{q:[[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,-1]],n:f(0,-1)}];for(const m of p){const v=m.q.map(g=>{const w=d(g[0],g[1],g[2]);return Et(a,w[0],w[1],w[2],m.n[0],m.n[1],m.n[2],c,l)});$n(a,v[0],v[1],v[2],v[3])}}function Gt(a,t,e,s,n,i,o,r,c,l){let h=[e[0]-t[0],e[1]-t[1],e[2]-t[2]];const u=Math.hypot(h[0],h[1],h[2])||1;h=[h[0]/u,h[1]/u,h[2]/u];let d=[0,1,0];Math.abs(h[1])>.94&&(d=[1,0,0]);let f=[h[1]*d[2]-h[2]*d[1],h[2]*d[0]-h[0]*d[2],h[0]*d[1]-h[1]*d[0]];const p=Math.hypot(f[0],f[1],f[2])||1;f=[f[0]/p,f[1]/p,f[2]/p];const m=[h[1]*f[2]-h[2]*f[1],h[2]*f[0]-h[0]*f[2],h[0]*f[1]-h[1]*f[0]],v=[],g=[];for(let w=0;w<i;w++){const x=w/i*Z,y=Math.cos(x),T=Math.sin(x),b=f[0]*y+m[0]*T,M=f[1]*y+m[1]*T,_=f[2]*y+m[2]*T;v.push(Et(a,t[0]+b*s,t[1]+M*s,t[2]+_*s,b,M,_,o,r)),g.push(Et(a,e[0]+b*n,e[1]+M*n,e[2]+_*n,b,M,_,o,r))}for(let w=0;w<i;w++){const x=(w+1)%i;$n(a,v[w],g[w],g[x],v[x])}if(l){const w=Et(a,e[0],e[1],e[2],h[0],h[1],h[2],o,r);for(let x=0;x<i;x++){const y=(x+1)%i,T=Et(a,a.pos[g[x]*3],a.pos[g[x]*3+1],a.pos[g[x]*3+2],h[0],h[1],h[2],o,r),b=Et(a,a.pos[g[y]*3],a.pos[g[y]*3+1],a.pos[g[y]*3+2],h[0],h[1],h[2],o,r);zo(a,w,T,b)}}if(c){const w=Et(a,t[0],t[1],t[2],-h[0],-h[1],-h[2],o,r);for(let x=0;x<i;x++){const y=(x+1)%i,T=Et(a,a.pos[v[x]*3],a.pos[v[x]*3+1],a.pos[v[x]*3+2],-h[0],-h[1],-h[2],o,r),b=Et(a,a.pos[v[y]*3],a.pos[v[y]*3+1],a.pos[v[y]*3+2],-h[0],-h[1],-h[2],o,r);zo(a,w,b,T)}}}function Uc(a,t,e){const s=t[0]-a[0],n=t[1]-a[1],i=t[2]-a[2],o=e[0]-a[0],r=e[1]-a[1],c=e[2]-a[2],l=n*c-i*r,h=i*o-s*c,u=s*r-n*o,d=Math.hypot(l,h,u);return d>1e-9?[l/d,h/d,u/d]:[0,1,0]}function _e(a,t,e,s,n,i,o,r){let c=e,l=n,h=Uc(t,e,n);r&&h[0]*r[0]+h[1]*r[1]+h[2]*r[2]<0&&(c=n,l=e,h=[-h[0],-h[1],-h[2]]);const u=Et(a,t[0],t[1],t[2],h[0],h[1],h[2],i,o),d=Et(a,c[0],c[1],c[2],h[0],h[1],h[2],i,o),f=Et(a,s[0],s[1],s[2],h[0],h[1],h[2],i,o),p=Et(a,l[0],l[1],l[2],h[0],h[1],h[2],i,o);$n(a,u,d,f,p)}function $s(a){const t=new Qt;return t.setAttribute("position",new G(new Float32Array(a.pos),3)),t.setAttribute("nrm",new G(new Float32Array(a.nrm),3)),t.setAttribute("vcol",new G(new Float32Array(a.col),3)),t.setAttribute("vmat",new G(new Float32Array(a.mat),1)),t.setIndex(a.idx),t.computeBoundingSphere(),t}const ta=`
in vec3 nrm; in vec3 vcol; in float vmat;
out vec3 vW; out vec3 vN; out vec3 vC; out vec3 vL; out float vM; out float vDist;
void main(){
  vec4 wp = modelMatrix*vec4(position,1.0);
  vW = wp.xyz; vN = normalize(mat3(modelMatrix)*nrm); vC = vcol; vM = vmat;
  vL = position;
  vec4 mv = viewMatrix*wp; vDist = -mv.z;
  gl_Position = projectionMatrix*mv;
}`;function Hc(a){const t=a?"uGhostAlpha":"gFogAmt";return`
uniform vec3 uLamp;   // x,y,z = the three switchable emissive channels, 0..1
${a?"uniform float uGhostAlpha;":""}
in vec3 vW; in vec3 vN; in vec3 vC; in vec3 vL; in float vM; in float vDist;
out vec4 outColor;
void main(){
  vec3 N=normalize(vN), V=normalize(uCamPos-vW);
  vec3 base = vC;
  // Grain in OBJECT space, not the pen's world space. The pen's painted objects were
  // bolted to the valley floor, so the two were the same thing; a car doing 90 m/s
  // through a world-space noise field crawls with paint-coloured static.
  float g  = pn2(vL.xz*4.3 + vL.y*3.7)*0.5+0.5;
  float g2 = pn2(vL.xz*17.0 - vL.y*9.0)*0.5+0.5;
  base *= 0.90 + 0.20*g + 0.06*g2;

  // lit / mid / shade travel along a hue path, never a brightness ramp
  vec3 lit = base*1.12;
  vec3 mid = mix(base*0.76, K_AMB_SKY*0.22, 0.16);
  vec3 shd = mix(base*0.40, K_SHADOW*0.60, 0.44);
  float rim = 0.30, ao = 1.0;

  if(vM > 3.5){                             // switchable lamp, channels A/B/C
    float ch = vM < 4.5 ? uLamp.x : (vM < 5.5 ? uLamp.y : uLamp.z);
    vec3 dead = mix(base*0.50, K_SKY_MID*0.30, 0.35);
    vec3 hot  = base*2.6 + K_SUN*0.22;
    vec3 c = mix(dead, hot, ch);
    // An unlit lens is an object and hazes with everything else; a lamp that is ON is a
    // light source and must stay legible through the haze, so the fog is faded out with
    // the channel rather than applied flat.
    c = mix(aerial(c, vDist, V, vW.y), c, ch);
    outColor = vec4(SAFE3(c), ${t});
    return;
  }
  if(vM > 1.5 && vM < 2.5){                 // lit window
    float flick = 0.94 + 0.06*sin(uTime*2.1 + vW.x*3.1 + vW.z*1.7);
    outColor = vec4(SAFE3(base*2.4*flick + K_SUN*0.25), ${a?"uGhostAlpha":"0.0"});
    return;
  }
  if(vM > 0.5 && vM < 1.5){                 // painted metal: crisper bands
    lit = base*1.25; mid = base*0.62;
    shd = mix(base*0.30, K_SHADOW*0.7, 0.5);
    rim = 0.62;
  }
  if(vM > 2.5){                             // glass / dark opening
    lit = mix(base, K_SKY_MID, 0.55); mid = base*0.7; shd = base*0.42; rim = 0.75;
  }

  float ndl = dot(N,uSunDir);
  float sh = sunShadow(vW,ndl)*cloudShadow(vW);
  Surf s; s.N=N; s.V=V; s.P=vW; s.shade=shd; s.mid=mid; s.lit=lit;
  s.soft = mix(0.075, 0.19, clamp(vDist*0.004,0.0,1.0));
  s.jit = (vn2(vL.xz*3.9 + vL.y*1.7) - 0.5)*0.055;
  s.shadow=sh; s.trans=0.0; s.transCol=vec3(0.0);
  s.rim=${a?"rim*2.1":"rim"}; s.ao=ao; s.ambient=1.0;
  vec3 col=paint(s);
  ${a?`
  // A ghost is a rumour of a car: keep the silhouette and the sun-side rim, let the
  // middle of every panel drift towards the sky it is standing in front of.
  float fres = pow(1.0 - clamp(dot(N,V),0.0,1.0), 2.6);
  col = mix(col*0.72 + K_SKY_MID*0.16, col + K_SUN*0.35, fres);
  `:""}
  col = aerial(col,vDist,V,vW.y);
  outColor = vec4(SAFE3(col), ${t});
}`}const Wc=ke({cshSpan:9200,cloudDeck:980});function qn({side:a=Jt,ghost:t=!1,opacity:e=.85,uniforms:s={}}={}){const n={uLamp:{value:new Y(0,0,0)}};t&&(n.uGhostAlpha={value:e});const i=new pt({glslVersion:"300 es",uniforms:St(Object.assign(n,s)),vertexShader:xt(ta),fragmentShader:It(mt,vt,Wc,We,Re,Hc(t)),side:a});return t&&(i.transparent=!0,i.depthWrite=!0,i.blending=_i,i.blendSrc=yi,i.blendDst=bi,i.blendEquation=Bs,i.blendSrcAlpha=xi,i.blendDstAlpha=wi,i.blendEquationAlpha=Bs),i}function Kc(){return new pt({glslVersion:"300 es",uniforms:St(),vertexShader:xt(ta),fragmentShader:Wn,side:Jt,colorWrite:!1})}const $c=1900,qc=.07,ce=6,jc=28,Vc=`
in vec3 normal;
in vec2 aCross;   // x = -1..1 across the carriageway, y = metres travelled along it
out vec3 vWorld;
out vec3 vNormal;
out vec2 vCross;
out float vDist;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vWorld = wp.xyz;
  vNormal = normalize(mat3(modelMatrix) * normal);
  vCross = aCross;
  vDist = length(wp.xyz - uCamPos);
  gl_Position = projectionMatrix * viewMatrix * wp;
}
`,Yc=`
in vec3 vWorld;
in vec3 vNormal;
in vec2 vCross;
in float vDist;
out vec4 fragColor;

uniform float uLineMix;   // 0 = unmarked track, 1 = fully marked road
uniform vec3  uSurfLit;
uniform vec3  uSurfShade;

void main(){
  float across = vCross.x;          // -1 .. 1
  float along  = vCross.y;          // metres
  float a = abs(across);

  // Surface: two large wear streaks where the wheels run, plus a fine chip grain. The
  // streaks are what make a road read as USED, and used is what makes it read as a road.
  float wear  = smoothstep(0.62, 0.30, abs(a - 0.46));
  float chip  = vn2(vWorld.xz * 3.4) * 0.5 + vn2(vWorld.xz * 11.0) * 0.5;
  vec3 lit   = uSurfLit   * mix(1.0, 1.09, wear) * mix(0.95, 1.05, chip);
  vec3 shade = uSurfShade * mix(1.0, 0.93, wear);
  vec3 mid   = mix(lit, shade, 0.5);

  // ── markings ────────────────────────────────────────────────────────────
  // Generated from the ribbon's own coordinates, never from a texture: a texture would need
  // a UV atlas, a mip chain and an alignment pass, and would still shimmer at 250 km/h.
  float px = fwidth(across) * 1.6 + 1e-5;

  // continuous edge lines just inside the shoulder
  float edge = smoothstep(0.90 + px, 0.90 - px, a) * smoothstep(0.80 - px, 0.80 + px, a);
  // dashed centre line: 3 m of paint, 6 m of gap, which is close enough to real road
  // marking that it reads correctly at a glance
  float dash = step(fract(along / 9.0), 0.34);
  float centre = smoothstep(0.055 + px, 0.055 - px, a) * dash;

  // 'mark', not 'paint': paint() is the shared lighting function and a float of the same
  // name shadows it, which fails to compile with a message that points somewhere else.
  float mark = clamp(edge + centre, 0.0, 1.0) * uLineMix;
  vec3 markCol = mix(K_LINE_W, K_LINE_W * 0.86, wear * 0.7);
  lit   = mix(lit,   markCol,        mark);
  mid   = mix(mid,   markCol * 0.9,  mark);
  shade = mix(shade, markCol * 0.62, mark);

  vec3 N = normalize(vNormal);
  vec3 V = normalize(uCamPos - vWorld);
  float ndl = dot(N, uSunDir);
  float sh = sunShadow(vWorld, ndl) * cloudShadow(vWorld);

  Surf s;
  s.N = N; s.V = V; s.P = vWorld;
  s.shade = shade; s.mid = mid; s.lit = lit;
  s.soft = 0.20; s.jit = (vn2(vWorld.xz * 0.7) - 0.5) * 0.05;
  s.shadow = sh; s.trans = 0.0; s.transCol = vec3(0.0);
  s.rim = 0.08; s.ao = 1.0; s.ambient = 1.0;

  vec3 col = paint(s);
  col = aerial(col, vDist, V, vWorld.y);
  fragColor = vec4(SAFE3(col), gFogAmt);
}
`;function Xc(){return new pt({glslVersion:"300 es",uniforms:St({uLineMix:{value:1},uSurfLit:{value:new Y(...Gs.tarmacLit)},uSurfShade:{value:new Y(...Gs.tarmacShade)}}),vertexShader:xt(Vc),fragmentShader:It(mt,vt,Ys,ke({cshSpan:9200,cloudDeck:980}),We,Re,Yc),side:On})}function Zc(a){const t=a.pts.length/2,e=[];for(let p=0;p<t-1;p++){const m=a.pts[p*2],v=a.pts[p*2+1],g=a.pts[p*2+2],w=a.pts[p*2+3],x=Math.hypot(g-m,w-v),y=Math.max(1,Math.round(x/6));for(let T=0;T<y;T++){const b=T/y;e.push({x:I(m,g,b),z:I(v,w,b),y:I(a.y[p],a.y[p+1],b)})}}const s=t-1;e.push({x:a.pts[s*2],z:a.pts[s*2+1],y:a.y[s]});const n=e.length,i=n*ce,o=new Float32Array(i*3),r=new Float32Array(i*3),c=new Float32Array(i*2),l=new Uint32Array((n-1)*(ce-1)*6),h=a.width*.5;let u=0;for(let p=0;p<n;p++){const m=e[p],v=e[Math.min(p+1,n-1)],g=e[Math.max(p-1,0)];let w=v.x-g.x,x=v.z-g.z;const y=Math.hypot(w,x)||1;w/=y,x/=y;const T=x,b=-w;p>0&&(u+=Math.hypot(m.x-e[p-1].x,m.z-e[p-1].z));for(let M=0;M<ce;M++){const _=M/(ce-1)*2-1,S=m.x+T*_*h,A=m.z+b*_*h,L=-Math.abs(_)*Math.abs(_)*.18,E=p*ce+M;o[E*3]=S,o[E*3+1]=m.y+L+qc,o[E*3+2]=A,r[E*3]=0,r[E*3+1]=1,r[E*3+2]=0,c[E*2]=_,c[E*2+1]=u}}let d=0;for(let p=0;p<n-1;p++)for(let m=0;m<ce-1;m++){const v=p*ce+m,g=v+1,w=v+ce,x=w+1;l[d++]=v,l[d++]=w,l[d++]=g,l[d++]=g,l[d++]=w,l[d++]=x}const f=new Qt;return f.setAttribute("position",new G(o,3)),f.setAttribute("normal",new G(r,3)),f.setAttribute("aCross",new G(c,2)),f.setIndex(new G(l,1)),f.computeBoundingSphere(),{geometry:f,ring:e,half:h}}function Jc(a,t,e,s){const n=[];let i=0;for(let o=1;o<t.length;o++){const r=t[o],c=t[o-1];i+=Math.hypot(r.x-c.x,r.z-c.z);let l=r.x-c.x,h=r.z-c.z;const u=Math.hypot(l,h)||1;l/=u,h/=u;const d=h,f=-l;let p=0;const m=Math.min(o+3,t.length-1);if(m>o){let v=t[m].x-r.x,g=t[m].z-r.z;const w=Math.hypot(v,g)||1;v/=w,g/=w,p=l*g-h*v}if(i>=jc){i=0;const v=(o&1)===0?1:-1;n.push({kind:"post",x:r.x+d*v*(e+1.5),z:r.z+f*v*(e+1.5),y:r.y,yaw:Math.atan2(l,h)})}if(Math.abs(p)>.22&&o%4===0){const v=p>0?-1:1;n.push({kind:"chevron",x:r.x+d*v*(e+2.4),z:r.z+f*v*(e+2.4),y:r.y,yaw:Math.atan2(-d*v,-f*v),flip:p>0?1:-1})}}return n}function Qc(){const a=Ks();Gt(a,[0,0,0],[0,1.05,0],.075,.065,6,[.94,.9,.82],N.MATTE,!0,!0),ot(a,0,.92,.042,.055,.11,.01,0,[.92,.32,.22],N.MATTE);const t=Ks();return Gt(t,[0,0,0],[0,1.35,0],.055,.05,6,[.42,.38,.33],N.MATTE,!0,!0),ot(t,0,1.45,0,.6,.34,.035,0,[.95,.93,.86],N.MATTE),ot(t,-.13,1.45,.04,.16,.24,.01,.5,[.18,.2,.24],N.MATTE),ot(t,.17,1.45,.04,.16,.24,.01,.5,[.18,.2,.24],N.MATTE),{post:$s(a),chevron:$s(t)}}class tl{constructor({seed:t,scene:e,range:s=$c}){this.seed=t>>>0,this.range=s,this.group=new ge,this.group.name="roads",e.add(this.group),this.material=Xc(),this.paintedMaterial=qn(),this.furniture=Qc(),this.live=new Map,this._lastX=1/0,this._lastZ=1/0,this._height=Wi(this.seed),this._water=Ki(this.seed),this.stats={edges:0,tris:0}}update(t,e){if(Math.hypot(t-this._lastX,e-this._lastZ)<180)return;this._lastX=t,this._lastZ=e;const s=this.range,n=Gi(t-s,e-s,t+s,e+s,this.seed,40),i=new Set;for(const o of n){if(i.add(o.key),this.live.has(o.key))continue;Ui(o,this._height,this._water);const{geometry:r,ring:c,half:l}=Zc(o),h=new bt(r,this.material);h.frustumCulled=!0,h.matrixAutoUpdate=!1,h.renderOrder=1,this.group.add(h);const u=Jc(o,c,l,this.seed),d=u.filter(m=>m.kind==="post"),f=u.filter(m=>m.kind==="chevron"),p={mesh:h,instanced:[]};for(const[m,v]of[[this.furniture.post,d],[this.furniture.chevron,f]]){if(!v.length)continue;const g=new Ti(m,this.paintedMaterial,v.length),w=new Oe,x=new Un,y=new Y,T=new Y(1,1,1);v.forEach((b,M)=>{y.set(b.x,b.y,b.z),x.setFromAxisAngle(new Y(0,1,0),b.yaw),w.compose(y,x,T),g.setMatrixAt(M,w)}),g.instanceMatrix.needsUpdate=!0,g.frustumCulled=!1,this.group.add(g),p.instanced.push(g)}this.live.set(o.key,p)}for(const[o,r]of this.live)if(!i.has(o)){this.group.remove(r.mesh),r.mesh.geometry.dispose();for(const c of r.instanced)this.group.remove(c),c.dispose();this.live.delete(o)}this.stats.edges=this.live.size}dispose(){for(const[t,e]of this.live){e.mesh.geometry.dispose();for(const s of e.instanced)s.dispose();this.live.delete(t)}this.material.dispose()}}const ea=900,Do=2.6,wt=32,Ze=1200,el=24,Dn={uMeanWind:{value:new ct(3,1)}};function sl(){return Dn}const Fo=`
uniform vec2 uMeanWind;   // supplied by windUniforms(), not by the shared U block
const float WIND_SPAN = ${ea.toFixed(1)};
// Beyond the render target we still want visible gust bands rolling over the far hills,
// so the fallback is an analytic version of the same travelling wave.
float windBandAnalytic(vec2 p){
  vec2 q = p - uMeanWind * (uTime * 1.22);
  float a = fbm2(q * 0.0052, 3);
  float b = pn2(q * 0.0168 + 13.0);
  float c = pn2(q * 0.055  + 41.0);
  return clamp(a*1.30 + b*0.55 + c*0.22, -1.2, 1.4);
}
vec4 windSample(vec2 p){
  vec2 uv = (p - uWindOrigin) / WIND_SPAN + 0.5;
  vec2 c = clamp(uv, vec2(0.003), vec2(0.997));
  vec4 w = texture(uWindTex, c);
  float edge = 1.0 - smoothstep(0.40, 0.498, max(abs(uv.x-0.5), abs(uv.y-0.5)));
  // Inside the render target the simulated field IS the answer. The analytic fallback
  // costs ~20 hash evaluations and is pure waste there — and since a blade's vertices all
  // sample the same point, this branch is perfectly coherent across a warp. It is the
  // single largest saving in the grass vertex shader.
  if(edge >= 0.999) return w;
  float band = windBandAnalytic(p);
  float gust = clamp(0.80 + band*0.95, 0.05, 2.3);
  vec4 fb = vec4(uMeanWind*gust, gust, clamp(band, 0.0, 1.0)*0.85);
  return mix(fb, w, edge);
}
// logarithmic boundary layer, normalised to the 10 m reference height
float windProfile(float z){
  return log((max(z,0.015) + 0.06) / 0.06) * 0.19523;
}
`,nl=`precision highp float;
in vec3 position;
in vec2 uv;
out vec2 vUv;
void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`,ol=`${Li}${Hn}
uniform vec2  uMeanWind;
uniform vec4  uCellA[6];      // xy: head station + cross offset, z: length, w: width
uniform vec4  uCellB[6];      // x: amplitude, y: veer, z: age, w: -
uniform vec2  uFwd;
uniform vec2  uSide;
uniform float uGustiness;
uniform float uTurbI;
uniform sampler2D uWindTerr;  // coarse ground height, metres
uniform vec3  uWindTerrO;     // xy: proxy centre in world xz, z: 1 / proxy span
${mt}${vt}
in vec2 vUv;
out vec4 outColor;

float terrH(vec2 p){
  vec2 uv = (p - uWindTerrO.xy) * uWindTerrO.z + 0.5;
  return texture(uWindTerr, clamp(uv, vec2(0.008), vec2(0.992))).r;
}
vec3 terrN(vec2 p, float e){
  float l = terrH(p - vec2(e,0.0)), r = terrH(p + vec2(e,0.0));
  float d = terrH(p - vec2(0.0,e)), u = terrH(p + vec2(0.0,e));
  return normalize(vec3(l-r, 2.0*e, d-u));
}

/* divergence-free turbulence with an inertial-subrange amplitude spectrum: eddy velocity
   at wavenumber k scales as k^(-1/3), and each octave decorrelates on its own turnover
   time tau ~ k^(-2/3). */
vec2 turbulence(vec2 p, float t, out float mag){
  vec2 v = vec2(0.0);
  float k = 0.0118, amp = 1.0, e = 0.021;
  mag = 0.0;
  for(int i=0;i<4;i++){
    vec2 q = (p - uMeanWind*t) * k;
    float tt = t * (0.055 * pow(2.0, float(i)*0.667));
    float n0 = pn3(vec3(q,                tt));
    float nx = pn3(vec3(q + vec2(e,0.0),  tt));
    float ny = pn3(vec3(q + vec2(0.0,e),  tt));
    vec2 curl = vec2(ny - n0, -(nx - n0)) / e;
    v   += amp * curl;
    mag += amp * length(curl);
    k *= 2.0; amp *= 0.7937;               // 2^(-1/3)
  }
  return v;
}

void main(){
  vec2 p = uWindOrigin + (vUv - 0.5) * ${ea.toFixed(1)};
  float t = uTime;

  vec2 flow = uMeanWind;
  float meanSpd = max(length(uMeanWind), 0.05);

  // ── coherent gust cells ──────────────────────────────────────────────────
  // 'crossS' rather than 'cross': shadowing the built-in compiles, but the grass shader
  // shares these chunks and does call cross().
  float along = dot(p, uFwd), crossS = dot(p, uSide);
  float gust = 0.0, veer = 0.0, front = 0.0;
  for(int i=0;i<6;i++){
    float u = (along - uCellA[i].x) / uCellA[i].z;
    if(u > 0.18 || u < -6.5) continue;
    float head = smoothstep(0.15, 0.0, u);
    float body = exp(u*2.05);
    float cw   = exp(-pow(abs(crossS - uCellA[i].y)/(uCellA[i].w*0.5), 2.3));
    float g = uCellB[i].x * head * body * cw;
    gust  += g;
    veer  += g * uCellB[i].y;
    front += uCellB[i].x * exp(-abs(u)*9.0) * cw;   // the sharp leading edge
  }
  gust *= uGustiness; front *= uGustiness;

  // ── inertial-subrange turbulence, advected with the flow ─────────────────
  float tmag;
  vec2 turb = turbulence(p, t, tmag) * meanSpd * uTurbI;
  flow += turb;

  // ── terrain coupling ─────────────────────────────────────────────────────
  // The probe offsets are the pen's (58 m for the crest, 48 m upwind for the shelter).
  // They are wider than one proxy texel, which is why a 37.5 m proxy is enough.
  float h  = terrH(p);
  float hs = 0.25*(terrH(p+vec2(58.0,0.0)) + terrH(p-vec2(58.0,0.0))
                 + terrH(p+vec2(0.0,58.0)) + terrH(p-vec2(0.0,58.0)));
  float crest = (h - hs) / 24.0;
  float speedup = 1.0 + 0.92*clamp(crest, 0.0, 1.1);
  float hUp = terrH(p - uFwd*48.0);
  float shelter = exp(-max(hUp - h, 0.0)/23.0);
  speedup *= mix(0.42, 1.0, shelter);

  vec3 n = terrN(p, 40.0);
  vec2 grad = -n.xz;
  float slope = length(grad);
  vec2 contour = normalize(vec2(-grad.y, grad.x) + vec2(1e-6));
  if(dot(contour, uFwd) < 0.0) contour = -contour;
  vec2 fdir = normalize(flow + vec2(1e-6));
  fdir = normalize(mix(fdir, contour, clamp(slope*2.1, 0.0, 0.58)));

  float spd = length(flow) * speedup * (1.0 + gust*1.35);
  // the gust front veers the direction as it passes over
  float a = veer * 0.85;
  vec2 dir = vec2(fdir.x*cos(a) - fdir.y*sin(a), fdir.x*sin(a) + fdir.y*cos(a));

  vec2 vel = dir * spd;
  float gustNorm = spd / max(meanSpd, 0.4);
  float excite = clamp(front*1.35 + tmag*0.22, 0.0, 3.0);

  outColor = vec4(vel, gustNorm, excite);
}`;class il{constructor(t,e={}){this.renderer=t;const s=K(e.quality??1,.4,2),n=Math.max(128,Math.round((e.res??320)*Math.sqrt(s))&-2);this.everyNthFrame=Math.max(1,e.everyNthFrame??3),this._frame=0,this.rt=new ps(n,n,{type:Mn,format:ms,minFilter:Mt,magFilter:Mt,wrapS:Ut,wrapT:Ut,depthBuffer:!1,stencilBuffer:!1}),J.uWindTex.value=this.rt.texture;const i=Ke((e.seed??4242)>>>0);this._r=i,this.time=0,this.baseSpeed=4.2,this.baseDir=292*De,this.meanSpeed=this.baseSpeed,this.meanDir=this.baseDir,this.tgtSpeed=this.baseSpeed,this.tgtDir=this.baseDir,this.gustiness=1,this.vec=new ct,this.fwd=[0,1],this.side=[-1,0],this.cloudDrift=new ct,this.cloudWind=new ct;const o=Math.sin(this.meanDir+Math.PI),r=Math.cos(this.meanDir+Math.PI);this.fwd=[o,r],this.side=[-r,o],this.vec.set(o*this.meanSpeed,r*this.meanSpeed),this.cells=[];for(let u=0;u<6;u++)this.cells.push({s:-1400+u*430+i()*260,c:(i()-.5)*900,len:26+i()*34,wid:70+i()*130,amp:.85+i()*1.35,veer:(i()-.5)*.42,life:0});this._pxData=new Uint16Array(wt*wt),this._pxNext=new Float32Array(wt*wt),this._pxCursor=wt*wt,this._pxNextOX=0,this._pxNextOZ=0,this.proxy=new _a(this._pxData,wt,wt,Ma,Mn),this.proxy.minFilter=Mt,this.proxy.magFilter=Mt,this.proxy.wrapS=Ut,this.proxy.wrapT=Ut,this.proxy.needsUpdate=!0,this._seed=(e.seed??4242)>>>0,this.worldSeed=(e.worldSeed??20260726)>>>0;const c=new Qt;c.setAttribute("position",new G(new Float32Array([-1,-1,0,3,-1,0,-1,3,0]),3)),c.setAttribute("uv",new G(new Float32Array([0,0,2,0,0,2]),2)),c.boundingSphere=new ie(new Y,10),this._quadGeo=c,this._quadScene=new Vs,this._quadCam=new Bn;const l=[],h=[];for(let u=0;u<6;u++)l.push(new Os),h.push(new Os);this._uni={uTime:J.uTime,uWindOrigin:J.uWindOrigin,uMeanWind:Dn.uMeanWind,uCellA:{value:l},uCellB:{value:h},uFwd:{value:new ct(o,r)},uSide:{value:new ct(-r,o)},uGustiness:{value:1},uTurbI:{value:.26},uWindTerr:{value:this.proxy},uWindTerrO:{value:new Y(0,0,1/Ze)}},this.material=new pt({glslVersion:"300 es",vertexShader:nl,fragmentShader:ol,uniforms:this._uni,depthTest:!1,depthWrite:!1}),this._quad=new bt(c,this.material),this._quad.frustumCulled=!1,this._quadScene.add(this._quad)}setSeed(t){return this.worldSeed=t>>>0,this._pxCursor=wt*wt,this}update(t,e){const s=this._r;this.time+=t;const n=1-Math.exp(-t/25),i=1-Math.exp(-t/40);this.tgtSpeed=K(this.tgtSpeed+(s()-.5)*t*2.4,this.baseSpeed*.62,this.baseSpeed*1.45),this.tgtDir=K(this.tgtDir+(s()-.5)*t*.16,this.baseDir-.34,this.baseDir+.34),this.meanSpeed+=(this.tgtSpeed-this.meanSpeed)*n,this.meanDir+=(this.tgtDir-this.meanDir)*i;const o=Math.sin(this.meanDir+Math.PI),r=Math.cos(this.meanDir+Math.PI);this.vec.set(o*this.meanSpeed,r*this.meanSpeed),this.fwd[0]=o,this.fwd[1]=r,this.side[0]=-r,this.side[1]=o;const c=this.meanSpeed*1.25*t;for(const u of this.cells)u.s+=c,u.life+=t,u.s-(e.x*o+e.z*r)>620&&(u.s-=1560+s()*280,u.c=(s()-.5)*940,u.len=26+s()*34,u.wid=70+s()*130,u.amp=.8+s()*1.4,u.veer=(s()-.5)*.44,u.life=0);const l=this.meanDir+Math.PI+.19;this.cloudWind.set(Math.sin(l)*this.meanSpeed*2.35,Math.cos(l)*this.meanSpeed*2.35),this.cloudDrift.x+=this.cloudWind.x*t,this.cloudDrift.y+=this.cloudWind.y*t,Dn.uMeanWind.value.copy(this.vec);const h=Math.hypot(this.vec.x,this.vec.y)||1;J.uWindLag.value.set(this.vec.x/h*Do,this.vec.y/h*Do),this._stepProxy(e),this._frame%this.everyNthFrame===0&&this._pass(e),this._frame++}_stepProxy(t){const e=wt*wt;this._pxCursor>=e&&(this._pxNextOX=t.x,this._pxNextOZ=t.z,this._pxCursor=0);const s=Ze/(wt-1),n=this._pxNextOX-Ze*.5,i=this._pxNextOZ-Ze*.5,o=Math.min(e,this._pxCursor+el);for(let r=this._pxCursor;r<o;r++){const c=r%wt,l=r/wt|0;this._pxNext[r]=Hi(n+c*s,i+l*s,this.worldSeed)}if(this._pxCursor=o,o>=e){for(let r=0;r<e;r++)this._pxData[r]=Ta.toHalfFloat(this._pxNext[r]);this.proxy.needsUpdate=!0,this._uni.uWindTerrO.value.set(this._pxNextOX,this._pxNextOZ,1/Ze)}}_pass(t){const e=this._uni;J.uWindOrigin.value.set(t.x,t.z),e.uFwd.value.set(this.fwd[0],this.fwd[1]),e.uSide.value.set(this.side[0],this.side[1]),e.uGustiness.value=this.gustiness;for(let i=0;i<6;i++){const o=this.cells[i];e.uCellA.value[i].set(o.s,o.c,o.len,o.wid),e.uCellB.value[i].set(o.amp,o.veer,o.life,0)}const s=this.renderer,n=s.getRenderTarget();s.setRenderTarget(this.rt),s.render(this._quadScene,this._quadCam),s.setRenderTarget(n)}sample(t,e,s){const n=this.fwd[0],i=this.fwd[1],o=this.side[0],r=this.side[1];let c=this.vec.x,l=this.vec.y;const h=t*n+e*i,u=t*o+e*r;let d=0,f=0;for(const k of this.cells){const R=(h-k.s)/k.len;if(R>.16||R<-6)continue;const P=At(.14,0,R),W=Math.exp(R*2.05),U=Math.exp(-Math.pow(Math.abs(u-k.c)/(k.wid*.5),2.3)),q=k.amp*P*W*U*this.gustiness;d+=q,f+=q*k.veer}const p=this.time,m=(t-this.vec.x*p)*.0125,v=(e-this.vec.y*p)*.0125,g=Xt(m,v,this._seed),w=Xt(m+3.7,v-1.9,this._seed),x=m*2.6,y=v*2.6,T=Xt(x+11,y+5,this._seed),b=Xt(x-7,y+13,this._seed);c+=(g*1+T*.79)*this.meanSpeed*.19,l+=(w*1+b*.79)*this.meanSpeed*.19;const M=1+d*.85,_=Math.cos(f),S=Math.sin(f),A=(c*_-l*S)*M,L=(c*S+l*_)*M,E=s===void 0?1:Math.log((Math.max(s,.015)+.06)/.06)*.19523;return{x:A*E,z:L*E,gust:d,speed:Math.hypot(A,L)*E}}dispose(){this.rt.dispose(),this.proxy.dispose(),this.material.dispose(),this._quadGeo.dispose(),J.uWindTex.value===this.rt.texture&&(J.uWindTex.value=null)}}const al=4400,Fn=1.5,rl=[{cs:12,near:0,far:26,dn:7,grid:7,lat:8,segs:3,wpx:1.7,hs:1,prepass:!0},{cs:28,near:22,far:88,dn:22,grid:9,lat:10,segs:2,wpx:2,hs:1.08,prepass:!0},{cs:80,near:80,far:300,dn:80,grid:9,lat:14,segs:1,wpx:3.8,hs:1.36,prepass:!1},{cs:160,near:270,far:560,dn:270,grid:9,lat:14,segs:1,wpx:6,hs:1.95,prepass:!1}],cl=.004,Io=2;function ll(a){if(a<=0)return 0;if(a>=1)return 1;const t=Math.ceil(Math.log2(a)*Io);return Math.min(1,Math.pow(2,t/Io))}const hl=.74,ul=.85,Rs=930,Po=100,dl=2.5,No=1/65535,fl=1/4294967296,pl=xs.map(a=>a.grass),ml=me.map(a=>a.dryness),vl=me.map(a=>a.snow),gl=me.map(a=>a.wet),hn=a=>`vec3(${a[0].toFixed(4)},${a[1].toFixed(4)},${a[2].toFixed(4)})`,wl=`
const vec3 F_DRY  = ${hn(me[de.STEPPE].foliage)};
const vec3 F_COLD = ${hn(me[de.HIGHLAND].foliage)};
const vec3 F_WET  = ${hn(me[de.WETLAND].foliage)};
`;function xl(a){const t=Math.max(1,a),e=2*t+1,s=new Float32Array(e*3);let n=0;for(let c=0;c<t;c++){const l=c/t;s[n++]=0,s[n++]=l,s[n++]=0,s[n++]=1,s[n++]=l,s[n++]=0}s[n++]=.5,s[n++]=1,s[n++]=0;const i=new Uint16Array((t-1)*6+3);let o=0;for(let c=0;c<t-1;c++){const l=c*2;i[o++]=l,i[o++]=l+2,i[o++]=l+1,i[o++]=l+1,i[o++]=l+2,i[o++]=l+3}const r=(t-1)*2;return i[o++]=r,i[o++]=2*t,i[o++]=r+1,{position:new G(s,3),index:new G(i,1)}}function bl(a,t){const e=Ke(t),s=new Uint16Array(a*2),n=Math.ceil(Math.sqrt(a)),i=1/n;let o=0;for(let r=0;r<a;r++){const c=r%n,l=r/n|0;s[o++]=Math.min(65535,(c+e())*i*65535)|0,s[o++]=Math.min(65535,(l+e())*i*65535)|0}for(let r=a-1;r>0;r--){const c=e()*(r+1)|0,l=s[r*2],h=s[r*2+1];s[r*2]=s[c*2],s[r*2+1]=s[c*2+1],s[c*2]=l,s[c*2+1]=h}return s}const Oo=a=>`
uniform float uChunkSize;
uniform vec4  uLod;            // near, nearWidth, far, farWidth
uniform vec3  uLodB;           // widthBoost(angular), heightScale, ringDistance
uniform float uWindGain;
uniform float uPlayerPush;
in vec2  iPos;
in float iGrd;
in vec4  iTint;                // dryness, snow, wetness, lushness
${a?"":`
out vec3  vW;
out vec3  vN;
out float vT;        // height along the blade 0..1
out float vBend;     // how far the blade is laid over 0..1
out vec3  vTint;     // swale, tussock, dryness
out vec2  vBio;      // snow, wetness
out float vSide;     // -1..1 across the blade
out float vOccl;     // shaded by taller neighbours
out float vVar;      // per-blade value/hue jitter, seed head packed in
`}
void degenerate(){ gl_Position = vec4(2.0, 2.0, 2.0, 1.0); }

void main(){
  vec2 vtx = position.xy;              // x = across the blade, y = along it
  // The chunk origin comes straight out of the model matrix (three keeps that up to date
  // per object for free), so all of a ring's chunks share ONE material with ZERO per-draw
  // uniform traffic. Riding along with it: the density fraction the CPU drew in the X
  // scale and the chunk's ground-height range in the Y scale, both constant per chunk and
  // both otherwise a uniform upload per draw.
  vec2 cCen = vec2(modelMatrix[3][0], modelMatrix[3][2]);
  vec2 wxz  = (cCen - vec2(uChunkSize*0.5)) + iPos*uChunkSize;
  vec2 toB  = wxz - uCamPos.xz;
  float d2  = dot(toB, toB);
  float invD = inversesqrt(max(d2, 1e-4));
  float dist = d2*invD;

  /*  Lateral view-cone rejection, per blade, as the very first thing the shader does —
      five instructions, no memory access, no hashing. Culling happens per CHUNK on the
      CPU, and a chunk is a coarse unit: the one the car is standing in is always kept, yet
      more than half of its blades are behind you. uCull.xy is the view direction flattened
      onto the ground and uCull.z the cosine of the widest frustum corner, with a pad for
      blade width and wind lean. Blades within about five metres are exempt, since at that
      range a blade's own width subtends more than the pad. */
  if(d2 > 30.0 && dot(toB, uCull.xy)*invD < uCull.z){ degenerate(); return; }

  // ── overlapping LOD fades: blades grow in and shrink out, never pop ─────
  float fadeIn  = uLod.x <= 0.01 ? 1.0 : smoothstep(uLod.x - uLod.y, uLod.x + uLod.y, dist);
  float fadeOut = uLod.z <= 0.0  ? 1.0 : 1.0 - smoothstep(uLod.z - uLod.w, uLod.z, dist);
  float fade = fadeIn * fadeOut;
  if(fade < 0.006){ degenerate(); return; }

  // ── the density law, resolved per blade ────────────────────────────────
  // The CPU already thinned this chunk to the density its NEAREST corner deserves (it
  // deliberately over-draws), so all that is left here is to reject the surplus against
  // this blade's own true distance. The result is a perfectly smooth radial density
  // gradient with no chunk banding at all — which is what lets the far ring use 160 m
  // chunks and a few dozen draw calls.
  float rQ = hash12(wxz*1.317 + 7.71);
  float dn = uLodB.z;
  float chunkKeep = modelMatrix[0][0];
  // the exponent is 1.5 exactly so this is x·x·inversesqrt(x): three cheap instructions
  float xr = min(dn/max(dist, dn), 1.0);
  float bladeKeep = xr*xr*inversesqrt(max(xr, 1e-6));
  float need = rQ*chunkKeep;
  if(need > bladeKeep){ degenerate(); return; }   // conservative early gate

  /*  The pen issued three vertex texture fetches here — height, meadow, wind — carefully
      arranged so their addresses did not depend on each other. Two of the three are gone:
      the ground and everything the meadow texture used to carry now arrive as instance
      attributes, which cost no latency at all. What is left is the wind, sampled a little
      UPWIND of the blade: a spatial stand-in for the blade's own response lag, so a gust
      front visibly SWEEPS across the field instead of switching on. */
  float ground = modelMatrix[3][1] + iGrd * modelMatrix[1][1];
  vec4  Wsam   = windSample(wxz - uWindLag);

  float dryv  = iTint.x;
  float snowv = iTint.y;
  float lush  = iTint.w;
  // No grass mask gate: the CPU deleted every blade with no business existing — on the
  // carriageway, on a cliff, in the sand. What survives from the pen is the growth ramp,
  // because a hard accept/reject makes a blade POP into existence as you drive at it, and
  // a field full of popping blades shimmers.
  float thr  = bladeKeep*(0.78 + 0.22*lush);
  float grow = clamp((thr - need) / max(thr*0.22, 1e-5), 0.0, 1.0);
  if(grow <= 0.004){ degenerate(); return; }
  fade *= grow;

  // per-blade randomness hashed from WORLD position: the template is shared by every chunk
  // of this ring, yet nothing visibly tiles
  vec3 h3 = hash32(wxz*0.9173 + 11.0);
  float rH = h3.x, rO = h3.y, rS = h3.z;
  float rP = hash12(wxz*2.713 + 31.4);
  // Grass is negatively gravitropic — the stem grows toward vertical whatever the slope
  // does. Being correct here also removes four heightmap taps per vertex.
  vec3 up = vec3(0.0, 1.0, 0.0);

  // ── tussocks: height, hue and lean cluster at metre and decametre scales
  // The pen baked these two bands into its meadow texture because it could not afford
  // gradient noise on twelve million vertices. At a fifth of that count, two value-noise
  // taps are cheaper than the texture fetch they replace — and they stream for free.
  float clumpA = vn2(wxz * 0.0147);          // ~68 m tussock band
  float clumpB = vn2(wxz * 0.00342 + 17.3);  // ~292 m swales

  // a wild hay meadow, not a lawn
  float hgt = (0.30 + rH*0.30);
  hgt *= 0.68 + 0.74*clumpB;
  hgt *= 0.84 + 0.38*clumpA;
  hgt *= mix(1.24, 0.82, dryv);          // dry biomes carry a shorter sward
  hgt *= mix(0.55, 1.0, lush);
  // snow packs a sward flat long before it buries it
  hgt *= mix(1.0, 0.42, snowv * smoothstep(120.0, 240.0, ground));
  hgt *= uLodB.y;
  hgt  = max(hgt, 0.08);

  float wid = (0.0082 + rS*0.0070) * (0.84 + 0.40*clumpA);
  // angular floor: a blade is never allowed to fall below ~1 screen pixel wide
  wid = max(wid, dist * uLodB.x);

  float stiff = 0.52 + rS*0.46 + clumpB*0.10;

  // ── frame ──────────────────────────────────────────────────────────────
  float orient = rO*6.2831853 + clumpA*2.4;
  vec3 axis = vec3(cos(orient), 0.0, sin(orient));
  // at distance, swing the blade to present its face to the eye so it can never disappear
  // edge-on
  vec3 toCam = normalize(vec3(uCamPos.x - wxz.x, 0.0, uCamPos.z - wxz.y) + vec3(1e-5));
  float faceCam = smoothstep(16.0, 80.0, dist);
  axis = normalize(mix(axis, normalize(cross(vec3(0.0,1.0,0.0), toCam)), faceCam*0.88));

  vec3 sideV = normalize(cross(up, axis) + vec3(1e-6));
  vec3 front = normalize(cross(sideV, up));

  vec3 p0  = vec3(wxz.x, ground - 0.035, wxz.y);
  vec3 iv2 = p0 + up*hgt*0.965 + front*hgt*(0.20 + rH*0.34);

  // ── forces ─────────────────────────────────────────────────────────────
  vec2 wv = Wsam.rg; float gustN = Wsam.b, excite = Wsam.a;
  float prof = windProfile(hgt*0.70);
  vec3 wind3 = vec3(wv.x, 0.0, wv.y) * prof;

  vec3 gE = vec3(0.0,-1.0,0.0) * (1.6 + 1.4*rH);
  vec3 gF = 0.25 * length(gE) * front;
  vec3 gv = (gE + gF) * 0.048;

  vec3 dir0 = normalize(iv2 - p0);
  float fd = 1.0 - abs(dot(normalize(wind3 + vec3(1e-5)), dir0));   // alignment
  float fr = clamp(dot(iv2 - p0, up)/hgt, 0.0, 1.0);                // straightness
  vec3 wf = wind3 * (0.30 + 0.95*fd) * fr * uWindGain * (0.55 + 0.75*hgt);

  // quasi-static equilibrium of recovery + gravity + wind (Hooke)
  vec3 v2 = iv2 + (gv + wf) / max(stiff, 0.18);

  // ── ringing: a gust front leaves the blade quivering at its own frequency
  float fB = 1.85 + rS*1.55;
  float ph = rQ*6.2831853;
  float osc = sin(uTime*6.2831853*fB + ph);
  float amp = (excite*0.50 + max(gustN-0.85,0.0)*0.42) * (0.040 + 0.075*(1.0-stiff));
  vec2  wdirn = normalize(wv + vec2(1e-5));
  v2 += vec3(wdirn.x, 0.0, wdirn.y) * osc * amp * hgt;
  // never frozen: a low flutter always present
  v2 += sideV * sin(uTime*7.4*(0.65+rS) + ph*2.3) * hgt * 0.020 * (0.35 + gustN*0.65);

  // ── whatever is standing in the sward parts it ─────────────────────────
  // The pen pushed the grass aside around a walker. Here it is the camera: in a bumper or
  // bonnet view it is a metre off the ground and the sward opens around it; in a chase view
  // the vertical test switches it off, which is correct — the car is five metres ahead.
  if(uPlayerPush > 0.0){
    vec2 dp = wxz - uCamPos.xz;
    float pd = length(dp);
    if(pd < 2.4){
      float vert = 1.0 - smoothstep(1.3, 2.8, abs(uCamPos.y - ground));
      float push = smoothstep(1.85, 0.15, pd) * vert * uPlayerPush;
      v2 += vec3(dp.x, -0.55, dp.y)/max(pd, 0.02) * push * hgt * 0.85;
    }
  }

  // ── state corrections (Jahrmann §5.2) ──────────────────────────────────
  v2 -= up * min(dot(up, v2 - p0), 0.0);
  vec3 d20 = v2 - p0;
  float lproj = length(d20 - up*dot(d20, up));
  vec3 v1 = p0 + hgt*up*max(1.0 - lproj/hgt, 0.05*max(lproj/hgt, 1.0));
  float L0 = length(v2 - p0);
  float L1 = length(v1 - p0) + length(v2 - v1);
  float L  = (2.0*L0 + L1)/3.0;
  float rr = hgt / max(L, 1e-4);
  v1 = p0 + rr*(v1 - p0);
  v2 = v1 + rr*(v2 - v1);

  // ── evaluate the Bézier ────────────────────────────────────────────────
  float head = step(0.895, rP);     // one blade in ten carries a seed head
  float t = vtx.y;
  vec3 a = mix(p0, v1, t);
  vec3 b = mix(v1, v2, t);
  vec3 c = mix(a, b, t);
  vec3 tang = normalize(b - a + vec3(0.0,1e-5,0.0));

  // sqrt rather than pow(x, 0.40): the profile differs by a couple of percent over the
  // length of a blade and it is one transcendental fewer per vertex
  float wprof = sqrt(1.0 - t) * (0.60 + 0.42*smoothstep(0.0, 0.16, t));
  wprof = mix(wprof, wprof*1.9, head*smoothstep(0.80, 0.99, t));
  float u = (vtx.x - 0.5);
  vec3 sideW = normalize(sideV - tang*dot(sideV, tang) + vec3(1e-6));
  vec3 pos = c + sideW * (u * wid * wprof * 2.0 * fade);
  // shrink the whole blade as it fades, so LOD changes are invisible
  pos = mix(p0 + vec3(0.0, 0.02, 0.0), pos, 0.30 + 0.70*fade);

  // ── curved cross-section: two triangles wide, shades like a rolled leaf
  vec3 faceN = normalize(cross(sideW, tang));
  vec3 N = normalize(faceN + sideW*(u*2.0)*0.66);

${a?"":`
  vBend = clamp(1.0 - dot(normalize(v2-p0), up), 0.0, 1.0);
  vT    = t;
  vSide = u*2.0;
  vW    = pos;
  vN    = N;
  // a blade shorter than its neighbours sits in their shade: this is what gives a dense
  // sward its internal depth instead of one flat wall of green
  vOccl = smoothstep(0.18, 1.05, hgt / (0.42 + 0.72*clumpB));
  // the seed-head flag rides in the integer part of vVar
  vVar  = rS*0.6 + rH*0.4 + head*2.0;

  // per-blade hue: the meadow is a mosaic, never one green. The dryness gets a per-blade
  // wobble so a biome border reads as grass drying out patch by patch, not as a gradient.
  vTint = vec3(clumpB, clumpA, clamp(dryv + (rH-0.5)*0.22, 0.0, 1.0));
  vBio  = vec2(snowv, iTint.z);
`}
  gl_Position = projectionMatrix * viewMatrix * vec4(pos, 1.0);
}`,yl=a=>`
in vec3 vW; in vec3 vN; in float vT; in float vBend;
in vec3 vTint; in vec2 vBio; in float vSide; in float vOccl; in float vVar;
out vec4 outColor;

void main(){
  vec3 N = normalize(vN);
  vec3 toEye = uCamPos - vW;
  float vDist = length(toEye);
  vec3 V = toEye / max(vDist, 1e-4);
  if(!gl_FrontFacing) N = -N;
  float vHead = step(1.5, vVar);
  float vVarF = vVar - vHead*2.0;
  float vAO   = mix(0.34, 1.0, pow(vT, 0.55));

  // ── vertical hue path: teal at the root, yellow-green at the tip ───────
  float t = vT;
  vec3 lit = mix(${C.gLow}, ${C.gMid}, smoothstep(0.00, 0.26, t));
  lit = mix(lit, ${C.gUpper}, smoothstep(0.20, 0.66, t));
  lit = mix(lit, ${C.gTip},   smoothstep(0.80, 1.00, t));
  vec3 mid = mix(${C.gBase}, ${C.gMid}, smoothstep(0.05, 0.80, t));
  vec3 shd = mix(${C.gBase}*0.82, ${C.gLow}, smoothstep(0.15, 0.95, t));

  // meadow mosaic
  lit = mix(lit, ${C.gPatchC}, smoothstep(0.35,0.85,vTint.x)*0.45);
  lit = mix(lit, ${C.gPatchA}, smoothstep(0.65,0.15,vTint.x)*0.35);
  mid = mix(mid, ${C.gPatchB}, smoothstep(0.3,0.8,vTint.y)*0.40);
  shd = mix(shd, ${C.tHollow}, smoothstep(0.4,0.9,vTint.y)*0.35);

  // ── the biome, as three scalars rather than five branches ──────────────
  // Dryness bleeds the greens toward straw from the tip down, because that is the order a
  // blade actually cures in. It is a hue rotation and not a desaturation: dead grass is
  // yellow, not grey.
  float dryB = vTint.z;
  float dry = smoothstep(0.10, 0.95, dryB) * smoothstep(0.30, 0.98, t);
  lit = mix(lit, ${C.gDry},      dry*0.72);
  mid = mix(mid, ${C.gDry}*0.72, dry*0.48);
  shd = mix(shd, ${C.gDry}*0.36, dry*0.30);

  // BIOME_TINT's foliage multipliers, along the three axes the instance carries.
  float snowB = vBio.x, wetB = vBio.y;
  vec3 fol = mix(vec3(1.0), F_DRY,  dryB);
  fol *= mix(vec3(1.0), F_COLD, snowB);
  fol *= mix(vec3(1.0), F_WET,  wetB);
  lit *= fol; mid *= fol; shd *= fol;

  // Snow above the line, on the same curve the terrain material uses so a snowfield and
  // the grass poking through it agree about where the line is.
  float snowC = snowB * smoothstep(120.0, 240.0, vW.y);
  lit = mix(lit, vec3(0.95,0.96,0.99), snowC*0.86);
  mid = mix(mid, vec3(0.80,0.85,0.94), snowC*0.86);
  shd = mix(shd, vec3(0.58,0.66,0.82), snowC*0.86);

  // no two blades in a meadow are the same green
  float vj = 0.84 + 0.34*vVarF;
  lit *= vj; mid *= vj*0.98; shd *= 0.92 + 0.20*vVarF;
  lit = mix(lit, ${C.gPatchB}, smoothstep(0.72, 1.0, vVarF)*0.30);

  float ndl = dot(N, uSunDir);
${a<=1?"  float sh = sunShadow(vW, ndl) * cloudShadow(vW);":a===2?"  float sh = sunShadowFast(vW, ndl) * cloudShadow(vW);":"  float sh = cloudShadow(vW);"}
  float selfShadow = mix(0.62, 1.0, pow(t, 0.75));

  // Everything that varies ACROSS the width of a blade — the fanned normal, the rim, the
  // wind flash, the midrib — is sub-pixel detail once a blade is only two or three pixels
  // wide, and sub-pixel detail does not resolve, it sparkles. nearK retires those terms
  // with distance and leaves the ones that vary ALONG the blade, which stay several pixels
  // tall much further out.
  float nearK = 1.0 - smoothstep(55.0, 240.0, vDist);
  N = normalize(mix(vec3(0.0,1.0,0.0), N, 0.34 + 0.66*nearK));

  Surf s;
  s.N=N; s.V=V; s.P=vW;
  s.shade=shd; s.mid=mid; s.lit=lit;
  s.soft = ${a<=1?"mix(0.11, 0.24, clamp(vDist*0.008,0.0,1.0))":"0.20"};
  s.jit  = ${a<=1?"(vn2(vW.xz*3.9 + vW.y*1.7) - 0.5)*0.055":"(vVarF-0.5)*0.05"};
  s.shadow = sh*selfShadow*mix(0.52, 1.0, vOccl);
  s.trans  = 1.00*smoothstep(0.12,0.68,t);
  s.transCol = ${C.gTrans};
  s.rim = 0.34*(0.25 + 0.75*nearK); s.ao = vAO; s.ambient = 1.0;
  vec3 col = paint(s);

  // ── the wind flash ─────────────────────────────────────────────────────
  // a blade laid over by a gust turns its broad face up and catches the light: this is what
  // makes a gust visible as a pale band racing across the field
  float geom = pow(clamp(1.0 - abs(dot(N,V)), 0.0, 1.0), 1.9)*0.45
             + pow(clamp(dot(N, normalize(uSunDir + V)), 0.0, 1.0), 3.2)*0.55;
  float flash = smoothstep(0.34, 0.86, vBend) * smoothstep(0.14, 0.78, t);
  col = mix(col, ${C.gSheen}, geom*flash*0.55*(0.30 + 0.70*sh)*(0.32 + 0.68*nearK));

  // seed head: a warm bronze plume on one blade in ten
  if(vHead > 0.5){
    float hd = smoothstep(0.78, 0.94, t);
    col = mix(col, mix(${C.gDry}, vec3(0.32,0.22,0.14), 0.42)*1.25, hd*0.82);
  }
  // a hint of the midrib, and the deep interior of the sward
  col *= 1.0 - abs(vSide)*0.13*nearK;
  col *= mix(0.46, 1.0, vOccl*0.55 + 0.45);

  // Out past a hundred metres a blade is only two or three pixels wide, and full contrast
  // against the ground behind it is what makes distant grass crawl and sparkle as the
  // camera moves. Converging it toward the sward mean keeps every bit of the texture and
  // takes the edge energy out of it — which is, not coincidentally, exactly what a painter
  // does at that depth.
  col = mix(col, mix(col, ${C.tMid}, 0.62), smoothstep(90.0, 430.0, vDist)*0.42);

  col = aerial(col, vDist, V, vW.y);
  outColor = vec4(SAFE3(col), gFogAmt);
}`;class _l{constructor(t,e){this.cap=e,this.count=0,this.cx=0,this.cz=0,this.wx=0,this.wy=0,this.wz=0,this.frac=1,this.wantFrac=1,this.dirty=!0,this.stamp=-1,this.built=0,this.minY=0,this.ySpan=1,this.lat=new Float32Array((t.R.lat+1)*(t.R.lat+1)*5),this.iPos=new Uint16Array(e*2),this.iGrd=new Uint16Array(e),this.iTint=new Uint8Array(e*4);const s=new Mi;s.setAttribute("position",t.blade.position),s.setIndex(t.blade.index),this.aPos=new pe(this.iPos,2,!0),this.aGrd=new pe(this.iGrd,1,!0),this.aTint=new pe(this.iTint,4,!0),s.setAttribute("iPos",this.aPos),s.setAttribute("iGrd",this.aGrd),s.setAttribute("iTint",this.aTint),s.boundingSphere=new ie(new Y,1e6),s.instanceCount=0,this.geom=s;const n=new bt(s,t.mat);if(n.frustumCulled=!1,n.renderOrder=4+t.index,n.visible=!1,this.mesh=n,t.preMat){const i=new bt(s,t.preMat);i.frustumCulled=!1,i.renderOrder=-20+t.index,this.pre=i,n.add(i)}else this.pre=null}dispose(){this.geom.dispose()}}class Ml{constructor({seed:t,scene:e,quality:s=1,wind:n=null}={}){this.seed=t>>>0,this.quality=K(s,.25,2),this.wind=n,this.budgetMs=dl,this.angPerPx=1.012/1080,this._group=new ge,this._group.matrixAutoUpdate=!1,this._group.name="grass",e&&e.add(this._group),this._terrain=null,this._regionX=1/0,this._regionZ=1/0,this.stats={chunks:0,dirty:0,drawn:0,built:0,extended:0,buildMs:0,bytes:0},this._rings=rl.map((i,o)=>this._buildRing(i,o))}get group(){return this._group}setAngular(t){this.angPerPx=t;for(const e of this._rings)e.uni.uLodB.value.x=t*e.R.wpx;return this}_buildRing(t,e){const s=xl(t.segs),n=Math.max(64,Math.round(al/Math.pow(t.dn,Fn)*t.cs*t.cs*this.quality)),i=bl(n,7e3+e*131+this.seed),o=St(Object.assign({uChunkSize:{value:t.cs},uLod:{value:new Os(t.near,Math.max(7,t.near*.26),t.far,t.far*.26)},uLodB:{value:new Y(this.angPerPx*t.wpx,t.hs,t.dn)},uWindGain:{value:.235},uPlayerPush:{value:e===0?1:0}},sl())),r=ke({cshSpan:9200,cloudDeck:980}),c=new pt({glslVersion:"300 es",uniforms:o,vertexShader:xt(mt,vt,Fo,Oo(!1)),fragmentShader:It(mt,vt,wl,r,We,Re,yl(e)),side:Jt}),l=t.prepass?new pt({glslVersion:"300 es",uniforms:o,vertexShader:xt(mt,vt,Fo,Oo(!0)),fragmentShader:Wn,side:Jt,colorWrite:!1}):null,h=t.grid,u=(h-1)/2,d=new Int32Array(h*h),f=new Float32Array(h*h),p=[];for(let v=-u;v<=u;v++)for(let g=-u;g<=u;g++){const w=(v+u)*h+(g+u),x=Tl(t,g,v),y=x<cl?0:ll(x);f[w]=y,d[w]=y<=0?0:Math.max(48,Math.round(n*y)),d[w]>0&&p.push(w)}return p.sort((v,g)=>{const w=v%h-u,x=(v/h|0)-u,y=g%h-u,T=(g/h|0)-u;return Math.max(Math.abs(w),Math.abs(x))-Math.max(Math.abs(y),Math.abs(T))}),{R:t,index:e,blade:s,tpl:i,full:n,uni:o,mat:c,preMat:l,grid:h,half:u,cap:d,capFrac:f,order:p,slots:new Array(h*h).fill(null),scratch:new Array(h*h).fill(null),pool:[],ox:0,oz:0,stamp:0,ready:!1}}update(t,e,s,n){this.wind&&this.wind.update(n,{x:t,y:s,z:e});const i=performance.now();this._ensureRegion(t,e);for(const r of this._rings)this._recentre(r,t,e);const o=this._drainQueue(i);this.stats.buildMs=performance.now()-i,this.stats.built+=o,this._draw(t,e,s)}_ensureRegion(t,e){this._terrain&&Math.abs(t-this._regionX)<Po&&Math.abs(e-this._regionZ)<Po||(this._terrain=new Ue(this.seed,t-Rs,e-Rs,t+Rs,e+Rs,90),this._regionX=t,this._regionZ=e)}_recentre(t,e,s){const n=t.R.cs,i=Math.floor(e/n),o=Math.floor(s/n);if(t.ready&&i===t.ox&&o===t.oz)return;const r=t.grid,c=t.half;if(t.ready){const l=i-t.ox,h=o-t.oz,u=t.slots,d=t.scratch,f=++t.stamp;d.fill(null);for(let p=-c;p<=c;p++){const m=p+h;if(!(m<-c||m>c))for(let v=-c;v<=c;v++){const g=v+l;if(g<-c||g>c)continue;const w=u[(m+c)*r+(g+c)];w&&(w.stamp=f,d[(p+c)*r+(v+c)]=w)}}for(let p=0;p<u.length;p++){const m=u[p];m&&m.stamp!==f&&this._release(t,m)}t.slots=d,t.scratch=u}t.ox=i,t.oz=o,t.ready=!0;for(let l=0;l<t.order.length;l++){const h=t.order[l],u=t.cap[h],d=t.slots[h];if(d&&d.cap>=u)continue;const f=h%r-c,p=(h/r|0)-c,m=this._acquire(t,u);d?(this._carryOver(d,m),this._release(t,d),this.stats.extended++):(m.cx=i+f,m.cz=o+p),m.wantFrac=t.capFrac[h],t.slots[h]=m}}_carryOver(t,e){e.iPos.set(t.iPos.subarray(0,t.count*2)),e.iGrd.set(t.iGrd.subarray(0,t.count)),e.iTint.set(t.iTint.subarray(0,t.count*4)),e.lat.set(t.lat),e.count=t.count,e.built=t.built,e.cx=t.cx,e.cz=t.cz,e.wx=t.wx,e.wy=t.wy,e.wz=t.wz,e.minY=t.minY,e.ySpan=t.ySpan,e.frac=t.frac,e.mesh.position.copy(t.mesh.position),e.mesh.scale.y=t.ySpan,e.aPos.needsUpdate=!0,e.aGrd.needsUpdate=!0,e.aTint.needsUpdate=!0,e.dirty=!0}_acquire(t,e){let s=-1;for(let i=0;i<t.pool.length;i++){const o=t.pool[i];o.cap<e||(s<0||o.cap<t.pool[s].cap)&&(s=i)}if(s>=0){const i=t.pool.splice(s,1)[0];return i.count=0,i.built=0,i.dirty=!0,i}const n=new _l(t,e);return this._group.add(n.mesh),this.stats.chunks++,this.stats.bytes+=e*10,n}_release(t,e){e.mesh.visible=!1,e.dirty=!0,t.pool.push(e);const s=t.grid+2;for(;t.pool.length>s;){let n=0;for(let o=1;o<t.pool.length;o++)t.pool[o].cap>t.pool[n].cap&&(n=o);const i=t.pool.splice(n,1)[0];this._group.remove(i.mesh),i.dispose(),this.stats.chunks--,this.stats.bytes-=i.cap*10}}_drainQueue(t){let e=0,s=0;for(const n of this._rings)for(let i=0;i<n.order.length;i++){const o=n.slots[n.order[i]];!o||!o.dirty||(s++,!(performance.now()-t>=this.budgetMs)&&(this._buildChunk(n,o),e++))}return this.stats.dirty=s,e}_buildChunk(t,e){const s=t.R,n=s.cs,i=s.lat,o=i+1,r=e.lat,c=e.cx*n,l=e.cz*n;if(e.built===0){const T=this._terrain,b=n/i;let M=1/0,_=-1/0;for(let S=0;S<o;S++){const A=l+S*b;for(let L=0;L<o;L++){const E=c+L*b,k=T.height(E,A),R=T.weights(E,A).w;let P=0,W=0,U=0,q=0;for(let O=0;O<lt;O++){const j=R[O];j<.002||(P+=j*pl[O],W+=j*ml[O],U+=j*vl[O],q+=j*gl[O])}const st=T.roads.carve(E,A).edge,z=(S*o+L)*5;r[z]=k,r[z+1]=P*(1-D(st)),r[z+2]=W,r[z+3]=U,r[z+4]=q,k<M&&(M=k),k>_&&(_=k)}}for(let S=0;S<o;S++){const A=S>0?S-1:S,L=S<o-1?S+1:S,E=(L-A)*b;for(let k=0;k<o;k++){const R=k>0?k-1:k,P=k<o-1?k+1:k,W=(P-R)*b,U=(r[(S*o+R)*5]-r[(S*o+P)*5])/W,q=(r[(A*o+k)*5]-r[(L*o+k)*5])/E,st=1/Math.sqrt(U*U+q*q+1);r[(S*o+k)*5+1]*=At(hl,ul,st)}}e.minY=M,e.ySpan=Math.max(_-M,.5),e.wx=c+n*.5,e.wz=l+n*.5,e.wy=M+e.ySpan*.5,e.count=0}const h=e.minY,u=1/e.ySpan,d=t.tpl,f=e.cap,p=e.iPos,m=e.iGrd,v=e.iTint,g=this.seed,w=e.cx,x=e.cz;let y=e.count;for(let T=e.built;T<f;T++){const b=d[T*2],M=d[T*2+1],_=b*No*i,S=M*No*i;let A=_|0;A>i-1&&(A=i-1);let L=S|0;L>i-1&&(L=i-1);const E=_-A,k=S-L,R=(L*o+A)*5,P=R+5,W=R+o*5,U=W+5,q=(1-E)*(1-k),st=E*(1-k),z=(1-E)*k,O=E*k,j=r[R+1]*q+r[P+1]*st+r[W+1]*z+r[U+1]*O;if(j<=.004||Di(w,x,T,g)*fl>j)continue;const it=r[R]*q+r[P]*st+r[W]*z+r[U]*O,tt=r[R+2]*q+r[P+2]*st+r[W+2]*z+r[U+2]*O,nt=r[R+3]*q+r[P+3]*st+r[W+3]*z+r[U+3]*O,gt=r[R+4]*q+r[P+4]*st+r[W+4]*z+r[U+4]*O;p[y*2]=b,p[y*2+1]=M,m[y]=(it-h)*u*65535|0;const ht=y*4;v[ht]=D(tt)*255|0,v[ht+1]=D(nt)*255|0,v[ht+2]=D(gt)*255|0,v[ht+3]=D(j)*255|0,y++}e.count=y,e.built=f,e.aPos.needsUpdate=!0,e.aGrd.needsUpdate=!0,e.aTint.needsUpdate=!0,e.mesh.position.set(e.wx,e.minY,e.wz),e.mesh.scale.y=e.ySpan,e.frac=e.wantFrac,e.dirty=!1}_draw(t,e,s){const n=J.uCull.value;let i=0;for(const o of this._rings){const r=o.R,c=r.cs,l=Math.max(7,r.near*.26),h=r.far*.26,u=o.slots;for(let d=0;d<u.length;d++){const f=u[d];if(!f)continue;const p=f.mesh;if(f.count===0){p.visible=!1;continue}const m=f.wx-t,v=f.wy-s,g=f.wz-e,w=Math.sqrt(m*m+v*v+g*g);if(w-c*.75>r.far){p.visible=!1;continue}if(w+c*.75<r.near-l){p.visible=!1;continue}if(w>c*1.6){const L=1/Math.sqrt(m*m+g*g||1),E=c*.75/w;if((m*n.x+g*n.y)*L<n.z-E){p.visible=!1;continue}}const x=Math.max(Math.abs(m)-c*.5,0),y=Math.max(Math.abs(g)-c*.5,0),T=Math.max(Math.sqrt(x*x+y*y+v*v),r.dn),b=Math.min(1,Math.pow(r.dn/T,Fn));let M=1;r.near>.01&&(M*=At(r.near-l-c*.6,r.near+l,w)),M*=1-At(r.far-h,r.far+c*.6,w);const _=f.frac,S=Math.min(b,_),A=Math.round(f.count*(S/_)*D(M));if(A<=0){p.visible=!1;continue}p.visible=!0,p.scale.x=S,f.geom.instanceCount=A,i+=A}}this.stats.drawn=i}dispose(){for(const t of this._rings){for(const e of t.slots)e&&e.dispose();for(const e of t.pool)e.dispose();t.slots.fill(null),t.pool.length=0,t.mat.dispose(),t.preMat&&t.preMat.dispose()}this._group.clear(),this._group.parent&&this._group.parent.remove(this._group),this._rings.length=0,this.stats.chunks=0,this.stats.bytes=0}}function Tl(a,t,e){const s=Math.max(7,a.near*.26),n=a.far*.26,i=Math.hypot(Math.max(Math.abs(t)-1,0)*a.cs,Math.max(Math.abs(e)-1,0)*a.cs);if(i>a.far)return 0;const o=Math.hypot((Math.abs(t)+1)*a.cs,(Math.abs(e)+1)*a.cs);let r=0;const c=24;for(let l=0;l<=c;l++){const h=i+(o-i)*l/c,u=Math.min(1,Math.pow(a.dn/Math.max(h,a.dn),Fn)),d=a.near<=.01?1:At(a.near-s,a.near+s,h),f=1-At(a.far-n,a.far,h),p=u*d*f;p>r&&(r=p)}return r}const Sl=1.7,Bo=520;class Al{constructor({seed:t,material:e,depthMaterial:s=null,workers:n=0,viewDistance:i=7e3,onChunk:o=null,onRelease:r=null,terrain:c="rolling"}){this.seed=t>>>0,this.material=e,this.depthMaterial=s,this.viewDistance=i,this.onChunk=o,this.onRelease=r,this.terrainPreset=c,this.group=new ge,this.group.name="terrain",this.group.matrixAutoUpdate=!1,this.live=new Map,this.pending=new Map,this.queue=[],this.stats={built:0,queued:0,live:0,workers:0,lastMs:0};const l=n||Math.max(2,Math.min(6,(navigator.hardwareConcurrency||4)-2));this.workers=[],this.busy=[];for(let h=0;h<l;h++){const u=new Worker(new URL(""+new URL("chunkWorker-o_WmJx4Z.js",import.meta.url).href,import.meta.url),{type:"module"});u.onmessage=d=>this._onWorkerMessage(h,d.data),u.onerror=d=>console.error("[streamer] worker error",d.message),this.workers.push(u),this.busy.push(null)}this.stats.workers=l,this._jobId=1,this._camera=new Y,this._maxLevel=Math.min(pc-1,Math.max(0,Math.ceil(Math.log2(i/us))))}_select(t,e){const s=new Map,n=this._maxLevel,i=He(n),o=Math.ceil(this.viewDistance/i)+1,r=Math.floor(t/i),c=Math.floor(e/i),l=[];for(let h=c-o;h<=c+o;h++)for(let u=r-o;u<=r+o;u++)l.push([u,h,n]);for(;l.length;){const[h,u,d]=l.pop(),f=He(d),p=(h+.5)*f,m=(u+.5)*f,v=Math.max(Math.abs(t-p)-f*.5,0),g=Math.max(Math.abs(e-m)-f*.5,0),w=Math.hypot(v,g);if(!(w>this.viewDistance))if(d>0&&w<f*Sl){const x=d-1;l.push([h*2,u*2,x]),l.push([h*2+1,u*2,x]),l.push([h*2,u*2+1,x]),l.push([h*2+1,u*2+1,x])}else s.set(`${d}:${h},${u}`,{cx:h,cz:u,level:d,d:w})}return s}update(t,e){const s=performance.now(),n=this._select(t,e);this.queue.length=0;for(const[i,o]of n)this.live.has(i)||this.pending.has(i)||this.queue.push({key:i,...o});this.queue.sort((i,o)=>i.d-o.d);for(const[i,o]of this.live)n.has(i)||this._release(i,o);if(this.live.size>Bo){const i=[...this.live.entries()].sort((o,r)=>{const c=Math.hypot(o[1].ox+o[1].size*.5-t,o[1].oz+o[1].size*.5-e);return Math.hypot(r[1].ox+r[1].size*.5-t,r[1].oz+r[1].size*.5-e)-c});for(let o=0;o<i.length-Bo;o++)this._release(i[o][0],i[o][1])}this._pump(),this.stats.queued=this.queue.length,this.stats.live=this.live.size,this.stats.lastMs=performance.now()-s}_pump(){for(let t=0;t<this.workers.length&&this.queue.length;t++){if(this.busy[t])continue;const e=this.queue.shift();if(this.live.has(e.key)||this.pending.has(e.key)){t--;continue}const s=this._jobId++;this.busy[t]=e.key,this.pending.set(e.key,s),this.workers[t].postMessage({jobId:s,cx:e.cx,cz:e.cz,level:e.level,seed:this.seed,terrain:this.terrainPreset})}}_onWorkerMessage(t,e){const s=this.busy[t];if(this.busy[t]=null,e.type==="error"){console.error("[streamer] chunk build failed",e.message),s&&this.pending.delete(s),this._pump();return}if(e.type!=="chunk")return;const n=`${e.level}:${e.cx},${e.cz}`;this.pending.delete(n),this.live.has(n)||this._adopt(n,e),this._pump()}_adopt(t,e){const s=new Qt;s.setAttribute("position",new G(e.position,3)),s.setAttribute("normal",new G(e.normal,3)),s.setAttribute("aBiome",new G(e.biome,4,!0)),s.setAttribute("aRoad",new G(e.road,2,!0)),s.setIndex(new G(e.index,1));const n=Math.hypot(e.size,e.maxY-e.minY)*.72;s.boundingSphere=new ie(new Y(e.size*.5,(e.minY+e.maxY)*.5,e.size*.5),n);const i=new bt(s,this.material);i.position.set(e.ox,0,e.oz),i.frustumCulled=!0,i.matrixAutoUpdate=!1,i.updateMatrix(),i.userData.level=e.level,i.renderOrder=-e.level,this.group.add(i);const o={mesh:i,level:e.level,cx:e.cx,cz:e.cz,size:e.size,ox:e.ox,oz:e.oz,step:e.step,grid:e.grid,minY:e.minY,maxY:e.maxY,heights:e.heights||null,water:e.water||null};this.live.set(t,o),this.stats.built++,this.onChunk&&this.onChunk(o,e)}_release(t,e){this.onRelease&&this.onRelease(e),this.group.remove(e.mesh),e.mesh.geometry.dispose(),this.live.delete(t)}sampleHeight(t,e){const s=us,n=`0:${Math.floor(t/s)},${Math.floor(e/s)}`,i=this.live.get(n);if(!i||!i.heights)return null;const o=(t-i.ox)/i.step,r=(e-i.oz)/i.step;let c=Math.floor(o),l=Math.floor(r);const h=i.grid||gc;if(c<0||l<0||c>h-2||l>h-2)return null;const u=o-c,d=r-l,f=i.heights,p=f[l*h+c],m=f[l*h+c+1],v=f[(l+1)*h+c],g=f[(l+1)*h+c+1];return(p*(1-u)+m*u)*(1-d)+(v*(1-u)+g*u)*d}isReady(t,e){return this.sampleHeight(t,e)!==null}forceChunk(t,e){const s=Math.floor(t/us),n=Math.floor(e/us),i=`0:${s},${n}`;if(this.live.has(i))return;const o=wc({cx:s,cz:n,level:0,seed:this.seed});this.pending.delete(i),this._adopt(i,o)}dispose(){for(const t of this.workers)t.terminate();for(const[t,e]of this.live)this._release(t,e)}}const Go=["gt","sports","hyper"],Uo=[{name:"Persimmon",body:X("paintA"),accent:X("paintD")},{name:"Barley",body:X("paintB"),accent:X("paintF")},{name:"Cobalt",body:X("paintC"),accent:X("paintD")},{name:"Chalk",body:X("paintD"),accent:X("paintF")},{name:"Verdigris",body:X("paintE"),accent:X("paintD")},{name:"Ink",body:X("paintF"),accent:X("paintB")},{name:"Rust",body:Ws(X("paintA"),X("paintF"),.42),accent:X("paintB")},{name:"Seafoam",body:Ws(X("paintE"),X("paintD"),.45),accent:X("paintC")}],kl={gt:{hull:[{z:2.35,yb:.34,yt:.74,wb:.56,wt:.62},{z:1.98,yb:.26,yt:.8,wb:.78,wt:.82},{z:1.39,yb:.22,yt:.86,wb:.86,wt:.92},{z:.6,yb:.22,yt:.9,wb:.88,wt:.92},{z:-.1,yb:.22,yt:.94,wb:.88,wt:.92},{z:-.95,yb:.24,yt:.96,wb:.88,wt:.9},{z:-1.39,yb:.26,yt:.94,wb:.86,wt:.88},{z:-2.35,yb:.44,yt:.82,wb:.62,wt:.66}],cabin:[{z:.58,yb:.86,yt:.99,wb:.84,wt:.66},{z:-.14,yb:.9,yt:1.36,wb:.82,wt:.62},{z:-.86,yb:.92,yt:1.36,wb:.82,wt:.62},{z:-2.06,yb:.84,yt:.98,wb:.74,wt:.5}],axle:[1.39,-1.39],track:[.8,.8],wheel:{rf:.34,rr:.35,wf:.145,wr:.155},lamps:"round",tail:"blocks",wing:"none",intakes:!1},sports:{hull:[{z:2.15,yb:.26,yt:.6,wb:.54,wt:.64},{z:1.72,yb:.2,yt:.7,wb:.8,wt:.88},{z:1.28,yb:.18,yt:.76,wb:.86,wt:.94},{z:.45,yb:.18,yt:.84,wb:.88,wt:.94},{z:-.35,yb:.2,yt:.96,wb:.9,wt:.96},{z:-1.05,yb:.22,yt:1.02,wb:.9,wt:.96},{z:-1.28,yb:.24,yt:1.02,wb:.88,wt:.94},{z:-2.15,yb:.46,yt:.88,wb:.7,wt:.74}],cabin:[{z:.42,yb:.8,yt:.88,wb:.8,wt:.58},{z:-.18,yb:.86,yt:1.24,wb:.78,wt:.56},{z:-.66,yb:.9,yt:1.24,wb:.76,wt:.54},{z:-1.02,yb:.92,yt:1.02,wb:.72,wt:.46}],axle:[1.28,-1.28],track:[.8,.82],wheel:{rf:.33,rr:.35,wf:.15,wr:.175},lamps:"slim",tail:"blocks",wing:"lip",intakes:!0},hyper:{hull:[{z:2.3,yb:.16,yt:.48,wb:.64,wt:.76},{z:1.85,yb:.14,yt:.58,wb:.92,wt:1},{z:1.35,yb:.13,yt:.66,wb:.96,wt:1.03},{z:.5,yb:.13,yt:.74,wb:.96,wt:1.02},{z:-.3,yb:.14,yt:.88,wb:.98,wt:1.03},{z:-1.05,yb:.16,yt:.96,wb:.98,wt:1.03},{z:-1.35,yb:.18,yt:.96,wb:.96,wt:1},{z:-2.3,yb:.36,yt:.84,wb:.78,wt:.84}],cabin:[{z:.46,yb:.7,yt:.8,wb:.82,wt:.54},{z:-.14,yb:.8,yt:1.16,wb:.8,wt:.5},{z:-.62,yb:.84,yt:1.16,wb:.78,wt:.48},{z:-1.06,yb:.86,yt:.98,wb:.72,wt:.42}],axle:[1.35,-1.35],track:[.84,.85],wheel:{rf:.34,rr:.36,wf:.165,wr:.2},lamps:"slim",tail:"bar",wing:"high",intakes:!0}},Ho=a=>[[a.wb,a.yb,a.z],[-a.wb,a.yb,a.z],[-a.wt,a.yt,a.z],[a.wt,a.yt,a.z]];function Wo(a,t,e,s,n=!0,i=!0){let o=Ho(t[0]);n&&_e(a,o[0],o[1],o[2],o[3],e,s,[0,0,1]);for(let r=1;r<t.length;r++){const c=Ho(t[r]);_e(a,o[0],o[3],c[3],c[0],e,s,[1,0,0]),_e(a,o[1],o[2],c[2],c[1],e,s,[-1,0,0]),_e(a,o[3],o[2],c[2],c[3],e,s,[0,1,0]),_e(a,o[0],o[1],c[1],c[0],e,s,[0,-1,0]),o=c}i&&_e(a,o[0],o[1],o[2],o[3],e,s,[0,0,-1])}function un(a,t){if(t>=a[0].z)return a[0];for(let e=1;e<a.length;e++)if(t>=a[e].z){const s=a[e-1],n=a[e],i=(s.z-t)/(s.z-n.z);return{z:t,yb:I(s.yb,n.yb,i),yt:I(s.yt,n.yt,i),wb:I(s.wb,n.wb,i),wt:I(s.wt,n.wt,i)}}return a[a.length-1]}function Es(a,t,e,s,n,i,o,r){for(let c=0;c<n;c++){const l=c/n*Z,h=(c+1)/n*Z,u=Math.cos(l),d=Math.sin(l),f=Math.cos(h),p=Math.sin(h);_e(a,[t,e*u,e*d],[t,e*f,e*p],[t,s*f,s*p],[t,s*u,s*d],i,o,[r,0,0])}}function Ko(a,t){const e=Ks(),s=X("tyre"),n=Ws(X("chrome"),X("paintF"),.34),i=Se(X("chrome"),.72),o=Ws(X("tyre"),X("tail"),.34);Gt(e,[-t,0,0],[t,0,0],a,a,14,s,N.MATTE,!1,!1),Es(e,t,a,a*.68,14,Se(s,1.18),N.MATTE,1),Es(e,-t,a,a*.68,14,Se(s,1.18),N.MATTE,-1),Gt(e,[-t*.92,0,0],[t*.92,0,0],a*.68,a*.68,8,Se(n,.7),N.METAL,!1,!1),Es(e,t*.92,a*.68,a*.52,12,n,N.METAL,1),Es(e,-t*.92,a*.68,a*.52,12,n,N.METAL,-1);for(let r=0;r<5;r++){const c=r/5*Z,l=Math.cos(c),h=Math.sin(c);for(const u of[-1,1]){const d=u*t*.9;Gt(e,[d,a*.18*l,a*.18*h],[d,a*.56*l,a*.56*h],a*.07,a*.06,4,n,N.METAL,!1,!1)}}return Gt(e,[-t*.96,0,0],[t*.96,0,0],a*.19,a*.19,8,i,N.METAL,!0,!0),Gt(e,[-t*.42,0,0],[t*.42,0,0],a*.6,a*.6,12,o,N.LAMP_C,!0,!0),$s(e)}function Rl(a,t,e){const s=Ks(),n=t.body,i=t.accent,o=X("paintF"),r=X("chrome"),c=X("glass"),l=X("head"),h=X("tail"),u=a.hull[0].z,d=a.hull[a.hull.length-1].z,f=a.hull[0],p=a.hull[a.hull.length-1];Wo(s,a.hull,n,N.METAL),Wo(s,a.cabin,c,N.GLASS);const m=a.cabin[1],v=a.cabin[2];ot(s,0,m.yt+.012,(m.z+v.z)*.5,m.wt*.94,.02,Math.abs(m.z-v.z)*.5+.05,0,n,N.METAL);const g=(a.axle[0]+a.axle[1])*.5,w=un(a.hull,g);for(const M of[-1,1])ot(s,M*(w.wb+.01),w.yb+.07,g,.035,.07,(a.axle[0]-a.axle[1])*.5-.34,0,o,N.MATTE);ot(s,0,f.yb+.015,u-.14,f.wb*1.02,.025,.18,0,o,N.MATTE),ot(s,0,I(f.yb,f.yt,.28),u-.03,f.wb*.72,.09,.06,0,o,N.GLASS);const x=I(f.yt,f.yb,.26);for(const M of[-1,1]){const _=M*(f.wt*.62);a.lamps==="round"?(Gt(s,[_,x,u-.12],[_,x,u+.03],.115,.105,8,l,N.LAMP_A,!1,!0),Gt(s,[_,x,u-.14],[_,x,u-.11],.125,.125,8,r,N.METAL,!1,!0)):(ot(s,_,x,u-.02,.2,.045,.08,0,l,N.LAMP_A),ot(s,_,x-.055,u-.03,.2,.02,.07,0,o,N.MATTE))}ot(s,0,p.yb+.17,d+.015,p.wb*.94,.06,.04,0,o,N.MATTE);const y=I(p.yt,p.yb,.34);if(a.tail==="bar")ot(s,0,y,d+.02,p.wt*.82,.035,.05,0,h,N.LAMP_B);else for(const M of[-1,1])ot(s,M*p.wt*.55,y,d+.02,.22,.05,.05,0,h,N.LAMP_B);if(a.wing==="lip")ot(s,0,p.yt+.04,d+.16,p.wt*.9,.035,.14,0,n,N.METAL);else if(a.wing==="high"){const M=d+.24,_=p.yt+.3;ot(s,0,_,M,p.wt*.92,.025,.16,0,n,N.METAL);for(const S of[-1,1])ot(s,S*p.wt*.92,_-.02,M,.02,.1,.2,0,i,N.METAL),ot(s,S*.3,_-.16,M-.02,.03,.16,.05,0,o,N.METAL)}if(a.intakes){const M=a.axle[1]+.62,_=un(a.hull,M);for(const S of[-1,1])ot(s,S*(I(_.wb,_.wt,.55)+.005),I(_.yb,_.yt,.58),M,.03,.1,.26,0,o,N.GLASS),ot(s,S*(I(_.wb,_.wt,.55)+.02),I(_.yb,_.yt,.58),M+.28,.02,.11,.05,0,i,N.METAL)}const T=a.cabin[0].z+.06,b=un(a.hull,T);for(const M of[-1,1]){const _=M*(b.wt+.02);Gt(s,[_,b.yt+.02,T],[_+M*.09,b.yt+.09,T-.02],.018,.018,4,o,N.MATTE,!1,!1),ot(s,_+M*.11,b.yt+.1,T-.03,.035,.045,.075,0,n,N.METAL)}if(!e){const M=a.cabin[1];for(const _ of[-1,1])ot(s,_*.32,M.yt-.22,M.z-.16,.13,.11,.05,0,o,N.MATTE),ot(s,_*.32,M.yt-.4,M.z-.02,.17,.1,.2,0,Se(o,1.5),N.MATTE);ot(s,0,M.yb+.06,a.cabin[0].z-.1,M.wb*.8,.05,.12,0,Se(o,1.2),N.MATTE);for(let _=-1;_<=1;_++)ot(s,_*p.wb*.42,p.yb+.06,d+.18,.025,.06,.18,0,o,N.MATTE);for(const _ of[-1,1])Gt(s,[_*.22,p.yb+.06,d+.12],[_*.22,p.yb+.06,d-.03],.042,.047,6,Se(r,.72),N.METAL,!1,!0)}return $s(s)}function sa(a,t,e){const s=typeof a=="number"?Go[a]||"sports":Go.indexOf(a)>=0?a:"sports",n=kl[s],i=Uo.length,o=Uo[((t|0)%i+i)%i],r=qn(e?{ghost:!0,opacity:.85}:{}),c=Kc(),l=[],h=Rl(n,o,e),u=Ko(n.wheel.rf,n.wheel.wf),d=Ko(n.wheel.rr,n.wheel.wr);l.push(h,u,d);const f=new ne;f.name=`car:${s}`;const p=new ne;p.name="chassis",f.add(p);const m=new bt(h,r);m.userData.depth=c,p.add(m);const v=[],g=[],w=(S,A)=>{const L=S?u:d,E=S?n.axle[0]:n.axle[1],k=A*n.track[S?0:1],R=S?n.wheel.rf:n.wheel.rr,P=new bt(L,r);if(P.userData.depth=c,S){const W=new ne;W.position.set(k,R,E),f.add(W),W.add(P),v.push(W)}else P.position.set(k,R,E),f.add(P);g.push(P)};w(!0,1),w(!0,-1),w(!1,1),w(!1,-1);const x=r.uniforms.uLamp.value;let y=!1,T=0;const b=()=>{x.x=y?1:0,x.y=Math.max(y?.28:0,T),x.z=T},M=S=>S.getIndex().count/3|0,_=M(h)+2*M(u)+2*M(d);return{group:f,wheels:g,setSteer(S){v[0].rotation.y=S,v[1].rotation.y=S},setWheelSpin(S){for(const A of g)A.rotation.x=S},setBrakeGlow(S){T=D(S),b()},setLights(S){y=!!S,b()},setBodyRoll(S,A){p.rotation.z=S,p.rotation.x=A},triangles:_,dispose(){for(const S of l)S.dispose();r.dispose(),c.dispose(),f.parent&&f.parent.remove(f)}}}function El({tier:a="sports",paint:t=0}={}){return sa(a,t,!1)}function Cl({tier:a="sports",paint:t=0}={}){return sa(a,t,!0)}function $o(a,t){if(t===Sa)return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."),a;if(t===Sn||t===Si){let e=a.getIndex();if(e===null){const o=[],r=a.getAttribute("position");if(r!==void 0){for(let c=0;c<r.count;c++)o.push(c);a.setIndex(o),e=a.getIndex()}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."),a}const s=e.count-2,n=[];if(t===Sn)for(let o=1;o<=s;o++)n.push(e.getX(0)),n.push(e.getX(o)),n.push(e.getX(o+1));else for(let o=0;o<s;o++)o%2===0?(n.push(e.getX(o)),n.push(e.getX(o+1)),n.push(e.getX(o+2))):(n.push(e.getX(o+2)),n.push(e.getX(o+1)),n.push(e.getX(o)));n.length/3!==s&&console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");const i=a.clone();return i.setIndex(n),i.clearGroups(),i}else return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:",t),a}class zl extends Aa{constructor(t){super(t),this.dracoLoader=null,this.ktx2Loader=null,this.meshoptDecoder=null,this.pluginCallbacks=[],this.register(function(e){return new Pl(e)}),this.register(function(e){return new Nl(e)}),this.register(function(e){return new ql(e)}),this.register(function(e){return new jl(e)}),this.register(function(e){return new Vl(e)}),this.register(function(e){return new Bl(e)}),this.register(function(e){return new Gl(e)}),this.register(function(e){return new Ul(e)}),this.register(function(e){return new Hl(e)}),this.register(function(e){return new Il(e)}),this.register(function(e){return new Wl(e)}),this.register(function(e){return new Ol(e)}),this.register(function(e){return new $l(e)}),this.register(function(e){return new Kl(e)}),this.register(function(e){return new Dl(e)}),this.register(function(e){return new Yl(e)}),this.register(function(e){return new Xl(e)})}load(t,e,s,n){const i=this;let o;if(this.resourcePath!=="")o=this.resourcePath;else if(this.path!==""){const l=ds.extractUrlBase(t);o=ds.resolveURL(l,this.path)}else o=ds.extractUrlBase(t);this.manager.itemStart(t);const r=function(l){n?n(l):console.error(l),i.manager.itemError(t),i.manager.itemEnd(t)},c=new Ai(this.manager);c.setPath(this.path),c.setResponseType("arraybuffer"),c.setRequestHeader(this.requestHeader),c.setWithCredentials(this.withCredentials),c.load(t,function(l){try{i.parse(l,o,function(h){e(h),i.manager.itemEnd(t)},r)}catch(h){r(h)}},s,r)}setDRACOLoader(t){return this.dracoLoader=t,this}setKTX2Loader(t){return this.ktx2Loader=t,this}setMeshoptDecoder(t){return this.meshoptDecoder=t,this}register(t){return this.pluginCallbacks.indexOf(t)===-1&&this.pluginCallbacks.push(t),this}unregister(t){return this.pluginCallbacks.indexOf(t)!==-1&&this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(t),1),this}parse(t,e,s,n){let i;const o={},r={},c=new TextDecoder;if(typeof t=="string")i=JSON.parse(t);else if(t instanceof ArrayBuffer)if(c.decode(new Uint8Array(t,0,4))===na){try{o[$.KHR_BINARY_GLTF]=new Zl(t)}catch(u){n&&n(u);return}i=JSON.parse(o[$.KHR_BINARY_GLTF].content)}else i=JSON.parse(c.decode(t));else i=t;if(i.asset===void 0||i.asset.version[0]<2){n&&n(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));return}const l=new hh(i,{path:e||this.resourcePath||"",crossOrigin:this.crossOrigin,requestHeader:this.requestHeader,manager:this.manager,ktx2Loader:this.ktx2Loader,meshoptDecoder:this.meshoptDecoder});l.fileLoader.setRequestHeader(this.requestHeader);for(let h=0;h<this.pluginCallbacks.length;h++){const u=this.pluginCallbacks[h](l);u.name||console.error("THREE.GLTFLoader: Invalid plugin found: missing name"),r[u.name]=u,o[u.name]=!0}if(i.extensionsUsed)for(let h=0;h<i.extensionsUsed.length;++h){const u=i.extensionsUsed[h],d=i.extensionsRequired||[];switch(u){case $.KHR_MATERIALS_UNLIT:o[u]=new Fl;break;case $.KHR_DRACO_MESH_COMPRESSION:o[u]=new Jl(i,this.dracoLoader);break;case $.KHR_TEXTURE_TRANSFORM:o[u]=new Ql;break;case $.KHR_MESH_QUANTIZATION:o[u]=new th;break;default:d.indexOf(u)>=0&&r[u]===void 0&&console.warn('THREE.GLTFLoader: Unknown extension "'+u+'".')}}l.setExtensions(o),l.setPlugins(r),l.parse(s,n)}parseAsync(t,e){const s=this;return new Promise(function(n,i){s.parse(t,e,n,i)})}}function Ll(){let a={};return{get:function(t){return a[t]},add:function(t,e){a[t]=e},remove:function(t){delete a[t]},removeAll:function(){a={}}}}const $={KHR_BINARY_GLTF:"KHR_binary_glTF",KHR_DRACO_MESH_COMPRESSION:"KHR_draco_mesh_compression",KHR_LIGHTS_PUNCTUAL:"KHR_lights_punctual",KHR_MATERIALS_CLEARCOAT:"KHR_materials_clearcoat",KHR_MATERIALS_DISPERSION:"KHR_materials_dispersion",KHR_MATERIALS_IOR:"KHR_materials_ior",KHR_MATERIALS_SHEEN:"KHR_materials_sheen",KHR_MATERIALS_SPECULAR:"KHR_materials_specular",KHR_MATERIALS_TRANSMISSION:"KHR_materials_transmission",KHR_MATERIALS_IRIDESCENCE:"KHR_materials_iridescence",KHR_MATERIALS_ANISOTROPY:"KHR_materials_anisotropy",KHR_MATERIALS_UNLIT:"KHR_materials_unlit",KHR_MATERIALS_VOLUME:"KHR_materials_volume",KHR_TEXTURE_BASISU:"KHR_texture_basisu",KHR_TEXTURE_TRANSFORM:"KHR_texture_transform",KHR_MESH_QUANTIZATION:"KHR_mesh_quantization",KHR_MATERIALS_EMISSIVE_STRENGTH:"KHR_materials_emissive_strength",EXT_MATERIALS_BUMP:"EXT_materials_bump",EXT_TEXTURE_WEBP:"EXT_texture_webp",EXT_TEXTURE_AVIF:"EXT_texture_avif",EXT_MESHOPT_COMPRESSION:"EXT_meshopt_compression",EXT_MESH_GPU_INSTANCING:"EXT_mesh_gpu_instancing"};class Dl{constructor(t){this.parser=t,this.name=$.KHR_LIGHTS_PUNCTUAL,this.cache={refs:{},uses:{}}}_markDefs(){const t=this.parser,e=this.parser.json.nodes||[];for(let s=0,n=e.length;s<n;s++){const i=e[s];i.extensions&&i.extensions[this.name]&&i.extensions[this.name].light!==void 0&&t._addNodeRef(this.cache,i.extensions[this.name].light)}}_loadLight(t){const e=this.parser,s="light:"+t;let n=e.cache.get(s);if(n)return n;const i=e.json,c=((i.extensions&&i.extensions[this.name]||{}).lights||[])[t];let l;const h=new oe(16777215);c.color!==void 0&&h.setRGB(c.color[0],c.color[1],c.color[2],Ft);const u=c.range!==void 0?c.range:0;switch(c.type){case"directional":l=new Ea(h),l.target.position.set(0,0,-1),l.add(l.target);break;case"point":l=new Ra(h),l.distance=u;break;case"spot":l=new ka(h),l.distance=u,c.spot=c.spot||{},c.spot.innerConeAngle=c.spot.innerConeAngle!==void 0?c.spot.innerConeAngle:0,c.spot.outerConeAngle=c.spot.outerConeAngle!==void 0?c.spot.outerConeAngle:Math.PI/4,l.angle=c.spot.outerConeAngle,l.penumbra=1-c.spot.innerConeAngle/c.spot.outerConeAngle,l.target.position.set(0,0,-1),l.add(l.target);break;default:throw new Error("THREE.GLTFLoader: Unexpected light type: "+c.type)}return l.position.set(0,0,0),Vt(l,c),c.intensity!==void 0&&(l.intensity=c.intensity),l.name=e.createUniqueName(c.name||"light_"+t),n=Promise.resolve(l),e.cache.add(s,n),n}getDependency(t,e){if(t==="light")return this._loadLight(e)}createNodeAttachment(t){const e=this,s=this.parser,i=s.json.nodes[t],r=(i.extensions&&i.extensions[this.name]||{}).light;return r===void 0?null:this._loadLight(r).then(function(c){return s._getNodeRef(e.cache,r,c)})}}class Fl{constructor(){this.name=$.KHR_MATERIALS_UNLIT}getMaterialType(){return os}extendParams(t,e,s){const n=[];t.color=new oe(1,1,1),t.opacity=1;const i=e.pbrMetallicRoughness;if(i){if(Array.isArray(i.baseColorFactor)){const o=i.baseColorFactor;t.color.setRGB(o[0],o[1],o[2],Ft),t.opacity=o[3]}i.baseColorTexture!==void 0&&n.push(s.assignTexture(t,"map",i.baseColorTexture,Be))}return Promise.all(n)}}class Il{constructor(t){this.parser=t,this.name=$.KHR_MATERIALS_EMISSIVE_STRENGTH}extendMaterialParams(t,e){const n=this.parser.json.materials[t];if(!n.extensions||!n.extensions[this.name])return Promise.resolve();const i=n.extensions[this.name].emissiveStrength;return i!==void 0&&(e.emissiveIntensity=i),Promise.resolve()}}class Pl{constructor(t){this.parser=t,this.name=$.KHR_MATERIALS_CLEARCOAT}getMaterialType(t){const s=this.parser.json.materials[t];return!s.extensions||!s.extensions[this.name]?null:te}extendMaterialParams(t,e){const s=this.parser,n=s.json.materials[t];if(!n.extensions||!n.extensions[this.name])return Promise.resolve();const i=[],o=n.extensions[this.name];if(o.clearcoatFactor!==void 0&&(e.clearcoat=o.clearcoatFactor),o.clearcoatTexture!==void 0&&i.push(s.assignTexture(e,"clearcoatMap",o.clearcoatTexture)),o.clearcoatRoughnessFactor!==void 0&&(e.clearcoatRoughness=o.clearcoatRoughnessFactor),o.clearcoatRoughnessTexture!==void 0&&i.push(s.assignTexture(e,"clearcoatRoughnessMap",o.clearcoatRoughnessTexture)),o.clearcoatNormalTexture!==void 0&&(i.push(s.assignTexture(e,"clearcoatNormalMap",o.clearcoatNormalTexture)),o.clearcoatNormalTexture.scale!==void 0)){const r=o.clearcoatNormalTexture.scale;e.clearcoatNormalScale=new ct(r,r)}return Promise.all(i)}}class Nl{constructor(t){this.parser=t,this.name=$.KHR_MATERIALS_DISPERSION}getMaterialType(t){const s=this.parser.json.materials[t];return!s.extensions||!s.extensions[this.name]?null:te}extendMaterialParams(t,e){const n=this.parser.json.materials[t];if(!n.extensions||!n.extensions[this.name])return Promise.resolve();const i=n.extensions[this.name];return e.dispersion=i.dispersion!==void 0?i.dispersion:0,Promise.resolve()}}class Ol{constructor(t){this.parser=t,this.name=$.KHR_MATERIALS_IRIDESCENCE}getMaterialType(t){const s=this.parser.json.materials[t];return!s.extensions||!s.extensions[this.name]?null:te}extendMaterialParams(t,e){const s=this.parser,n=s.json.materials[t];if(!n.extensions||!n.extensions[this.name])return Promise.resolve();const i=[],o=n.extensions[this.name];return o.iridescenceFactor!==void 0&&(e.iridescence=o.iridescenceFactor),o.iridescenceTexture!==void 0&&i.push(s.assignTexture(e,"iridescenceMap",o.iridescenceTexture)),o.iridescenceIor!==void 0&&(e.iridescenceIOR=o.iridescenceIor),e.iridescenceThicknessRange===void 0&&(e.iridescenceThicknessRange=[100,400]),o.iridescenceThicknessMinimum!==void 0&&(e.iridescenceThicknessRange[0]=o.iridescenceThicknessMinimum),o.iridescenceThicknessMaximum!==void 0&&(e.iridescenceThicknessRange[1]=o.iridescenceThicknessMaximum),o.iridescenceThicknessTexture!==void 0&&i.push(s.assignTexture(e,"iridescenceThicknessMap",o.iridescenceThicknessTexture)),Promise.all(i)}}class Bl{constructor(t){this.parser=t,this.name=$.KHR_MATERIALS_SHEEN}getMaterialType(t){const s=this.parser.json.materials[t];return!s.extensions||!s.extensions[this.name]?null:te}extendMaterialParams(t,e){const s=this.parser,n=s.json.materials[t];if(!n.extensions||!n.extensions[this.name])return Promise.resolve();const i=[];e.sheenColor=new oe(0,0,0),e.sheenRoughness=0,e.sheen=1;const o=n.extensions[this.name];if(o.sheenColorFactor!==void 0){const r=o.sheenColorFactor;e.sheenColor.setRGB(r[0],r[1],r[2],Ft)}return o.sheenRoughnessFactor!==void 0&&(e.sheenRoughness=o.sheenRoughnessFactor),o.sheenColorTexture!==void 0&&i.push(s.assignTexture(e,"sheenColorMap",o.sheenColorTexture,Be)),o.sheenRoughnessTexture!==void 0&&i.push(s.assignTexture(e,"sheenRoughnessMap",o.sheenRoughnessTexture)),Promise.all(i)}}class Gl{constructor(t){this.parser=t,this.name=$.KHR_MATERIALS_TRANSMISSION}getMaterialType(t){const s=this.parser.json.materials[t];return!s.extensions||!s.extensions[this.name]?null:te}extendMaterialParams(t,e){const s=this.parser,n=s.json.materials[t];if(!n.extensions||!n.extensions[this.name])return Promise.resolve();const i=[],o=n.extensions[this.name];return o.transmissionFactor!==void 0&&(e.transmission=o.transmissionFactor),o.transmissionTexture!==void 0&&i.push(s.assignTexture(e,"transmissionMap",o.transmissionTexture)),Promise.all(i)}}class Ul{constructor(t){this.parser=t,this.name=$.KHR_MATERIALS_VOLUME}getMaterialType(t){const s=this.parser.json.materials[t];return!s.extensions||!s.extensions[this.name]?null:te}extendMaterialParams(t,e){const s=this.parser,n=s.json.materials[t];if(!n.extensions||!n.extensions[this.name])return Promise.resolve();const i=[],o=n.extensions[this.name];e.thickness=o.thicknessFactor!==void 0?o.thicknessFactor:0,o.thicknessTexture!==void 0&&i.push(s.assignTexture(e,"thicknessMap",o.thicknessTexture)),e.attenuationDistance=o.attenuationDistance||1/0;const r=o.attenuationColor||[1,1,1];return e.attenuationColor=new oe().setRGB(r[0],r[1],r[2],Ft),Promise.all(i)}}class Hl{constructor(t){this.parser=t,this.name=$.KHR_MATERIALS_IOR}getMaterialType(t){const s=this.parser.json.materials[t];return!s.extensions||!s.extensions[this.name]?null:te}extendMaterialParams(t,e){const n=this.parser.json.materials[t];if(!n.extensions||!n.extensions[this.name])return Promise.resolve();const i=n.extensions[this.name];return e.ior=i.ior!==void 0?i.ior:1.5,Promise.resolve()}}class Wl{constructor(t){this.parser=t,this.name=$.KHR_MATERIALS_SPECULAR}getMaterialType(t){const s=this.parser.json.materials[t];return!s.extensions||!s.extensions[this.name]?null:te}extendMaterialParams(t,e){const s=this.parser,n=s.json.materials[t];if(!n.extensions||!n.extensions[this.name])return Promise.resolve();const i=[],o=n.extensions[this.name];e.specularIntensity=o.specularFactor!==void 0?o.specularFactor:1,o.specularTexture!==void 0&&i.push(s.assignTexture(e,"specularIntensityMap",o.specularTexture));const r=o.specularColorFactor||[1,1,1];return e.specularColor=new oe().setRGB(r[0],r[1],r[2],Ft),o.specularColorTexture!==void 0&&i.push(s.assignTexture(e,"specularColorMap",o.specularColorTexture,Be)),Promise.all(i)}}class Kl{constructor(t){this.parser=t,this.name=$.EXT_MATERIALS_BUMP}getMaterialType(t){const s=this.parser.json.materials[t];return!s.extensions||!s.extensions[this.name]?null:te}extendMaterialParams(t,e){const s=this.parser,n=s.json.materials[t];if(!n.extensions||!n.extensions[this.name])return Promise.resolve();const i=[],o=n.extensions[this.name];return e.bumpScale=o.bumpFactor!==void 0?o.bumpFactor:1,o.bumpTexture!==void 0&&i.push(s.assignTexture(e,"bumpMap",o.bumpTexture)),Promise.all(i)}}class $l{constructor(t){this.parser=t,this.name=$.KHR_MATERIALS_ANISOTROPY}getMaterialType(t){const s=this.parser.json.materials[t];return!s.extensions||!s.extensions[this.name]?null:te}extendMaterialParams(t,e){const s=this.parser,n=s.json.materials[t];if(!n.extensions||!n.extensions[this.name])return Promise.resolve();const i=[],o=n.extensions[this.name];return o.anisotropyStrength!==void 0&&(e.anisotropy=o.anisotropyStrength),o.anisotropyRotation!==void 0&&(e.anisotropyRotation=o.anisotropyRotation),o.anisotropyTexture!==void 0&&i.push(s.assignTexture(e,"anisotropyMap",o.anisotropyTexture)),Promise.all(i)}}class ql{constructor(t){this.parser=t,this.name=$.KHR_TEXTURE_BASISU}loadTexture(t){const e=this.parser,s=e.json,n=s.textures[t];if(!n.extensions||!n.extensions[this.name])return null;const i=n.extensions[this.name],o=e.options.ktx2Loader;if(!o){if(s.extensionsRequired&&s.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");return null}return e.loadTextureImage(t,i.source,o)}}class jl{constructor(t){this.parser=t,this.name=$.EXT_TEXTURE_WEBP}loadTexture(t){const e=this.name,s=this.parser,n=s.json,i=n.textures[t];if(!i.extensions||!i.extensions[e])return null;const o=i.extensions[e],r=n.images[o.source];let c=s.textureLoader;if(r.uri){const l=s.options.manager.getHandler(r.uri);l!==null&&(c=l)}return s.loadTextureImage(t,o.source,c)}}class Vl{constructor(t){this.parser=t,this.name=$.EXT_TEXTURE_AVIF}loadTexture(t){const e=this.name,s=this.parser,n=s.json,i=n.textures[t];if(!i.extensions||!i.extensions[e])return null;const o=i.extensions[e],r=n.images[o.source];let c=s.textureLoader;if(r.uri){const l=s.options.manager.getHandler(r.uri);l!==null&&(c=l)}return s.loadTextureImage(t,o.source,c)}}class Yl{constructor(t){this.name=$.EXT_MESHOPT_COMPRESSION,this.parser=t}loadBufferView(t){const e=this.parser.json,s=e.bufferViews[t];if(s.extensions&&s.extensions[this.name]){const n=s.extensions[this.name],i=this.parser.getDependency("buffer",n.buffer),o=this.parser.options.meshoptDecoder;if(!o||!o.supported){if(e.extensionsRequired&&e.extensionsRequired.indexOf(this.name)>=0)throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");return null}return i.then(function(r){const c=n.byteOffset||0,l=n.byteLength||0,h=n.count,u=n.byteStride,d=new Uint8Array(r,c,l);return o.decodeGltfBufferAsync?o.decodeGltfBufferAsync(h,u,d,n.mode,n.filter).then(function(f){return f.buffer}):o.ready.then(function(){const f=new ArrayBuffer(h*u);return o.decodeGltfBuffer(new Uint8Array(f),h,u,d,n.mode,n.filter),f})})}else return null}}class Xl{constructor(t){this.name=$.EXT_MESH_GPU_INSTANCING,this.parser=t}createNodeMesh(t){const e=this.parser.json,s=e.nodes[t];if(!s.extensions||!s.extensions[this.name]||s.mesh===void 0)return null;const n=e.meshes[s.mesh];for(const l of n.primitives)if(l.mode!==Dt.TRIANGLES&&l.mode!==Dt.TRIANGLE_STRIP&&l.mode!==Dt.TRIANGLE_FAN&&l.mode!==void 0)return null;const o=s.extensions[this.name].attributes,r=[],c={};for(const l in o)r.push(this.parser.getDependency("accessor",o[l]).then(h=>(c[l]=h,c[l])));return r.length<1?null:(r.push(this.parser.createNodeMesh(t)),Promise.all(r).then(l=>{const h=l.pop(),u=h.isGroup?h.children:[h],d=l[0].count,f=[];for(const p of u){const m=new Oe,v=new Y,g=new Un,w=new Y(1,1,1),x=new Ti(p.geometry,p.material,d);for(let y=0;y<d;y++)c.TRANSLATION&&v.fromBufferAttribute(c.TRANSLATION,y),c.ROTATION&&g.fromBufferAttribute(c.ROTATION,y),c.SCALE&&w.fromBufferAttribute(c.SCALE,y),x.setMatrixAt(y,m.compose(v,g,w));for(const y in c)if(y==="_COLOR_0"){const T=c[y];x.instanceColor=new pe(T.array,T.itemSize,T.normalized)}else y!=="TRANSLATION"&&y!=="ROTATION"&&y!=="SCALE"&&p.geometry.setAttribute(y,c[y]);ge.prototype.copy.call(x,p),this.parser.assignFinalMaterial(x),f.push(x)}return h.isGroup?(h.clear(),h.add(...f),h):f[0]}))}}const na="glTF",Je=12,qo={JSON:1313821514,BIN:5130562};class Zl{constructor(t){this.name=$.KHR_BINARY_GLTF,this.content=null,this.body=null;const e=new DataView(t,0,Je),s=new TextDecoder;if(this.header={magic:s.decode(new Uint8Array(t.slice(0,4))),version:e.getUint32(4,!0),length:e.getUint32(8,!0)},this.header.magic!==na)throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");if(this.header.version<2)throw new Error("THREE.GLTFLoader: Legacy binary file detected.");const n=this.header.length-Je,i=new DataView(t,Je);let o=0;for(;o<n;){const r=i.getUint32(o,!0);o+=4;const c=i.getUint32(o,!0);if(o+=4,c===qo.JSON){const l=new Uint8Array(t,Je+o,r);this.content=s.decode(l)}else if(c===qo.BIN){const l=Je+o;this.body=t.slice(l,l+r)}o+=r}if(this.content===null)throw new Error("THREE.GLTFLoader: JSON content not found.")}}class Jl{constructor(t,e){if(!e)throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");this.name=$.KHR_DRACO_MESH_COMPRESSION,this.json=t,this.dracoLoader=e,this.dracoLoader.preload()}decodePrimitive(t,e){const s=this.json,n=this.dracoLoader,i=t.extensions[this.name].bufferView,o=t.extensions[this.name].attributes,r={},c={},l={};for(const h in o){const u=In[h]||h.toLowerCase();r[u]=o[h]}for(const h in t.attributes){const u=In[h]||h.toLowerCase();if(o[h]!==void 0){const d=s.accessors[t.attributes[h]],f=Ie[d.componentType];l[u]=f.name,c[u]=d.normalized===!0}}return e.getDependency("bufferView",i).then(function(h){return new Promise(function(u,d){n.decodeDracoFile(h,function(f){for(const p in f.attributes){const m=f.attributes[p],v=c[p];v!==void 0&&(m.normalized=v)}u(f)},r,l,Ft,d)})})}}class Ql{constructor(){this.name=$.KHR_TEXTURE_TRANSFORM}extendTexture(t,e){return(e.texCoord===void 0||e.texCoord===t.channel)&&e.offset===void 0&&e.rotation===void 0&&e.scale===void 0||(t=t.clone(),e.texCoord!==void 0&&(t.channel=e.texCoord),e.offset!==void 0&&t.offset.fromArray(e.offset),e.rotation!==void 0&&(t.rotation=e.rotation),e.scale!==void 0&&t.repeat.fromArray(e.scale),t.needsUpdate=!0),t}}class th{constructor(){this.name=$.KHR_MESH_QUANTIZATION}}class oa extends Ja{constructor(t,e,s,n){super(t,e,s,n)}copySampleValue_(t){const e=this.resultBuffer,s=this.sampleValues,n=this.valueSize,i=t*n*3+n;for(let o=0;o!==n;o++)e[o]=s[i+o];return e}interpolate_(t,e,s,n){const i=this.resultBuffer,o=this.sampleValues,r=this.valueSize,c=r*2,l=r*3,h=n-e,u=(s-e)/h,d=u*u,f=d*u,p=t*l,m=p-l,v=-2*f+3*d,g=f-d,w=1-v,x=g-d+u;for(let y=0;y!==r;y++){const T=o[m+y+r],b=o[m+y+c]*h,M=o[p+y+r],_=o[p+y]*h;i[y]=w*T+x*b+v*M+g*_}return i}}const eh=new Un;class sh extends oa{interpolate_(t,e,s,n){const i=super.interpolate_(t,e,s,n);return eh.fromArray(i).normalize().toArray(i),i}}const Dt={POINTS:0,LINES:1,LINE_LOOP:2,LINE_STRIP:3,TRIANGLES:4,TRIANGLE_STRIP:5,TRIANGLE_FAN:6},Ie={5120:Int8Array,5121:Uint8Array,5122:Int16Array,5123:Uint16Array,5125:Uint32Array,5126:Float32Array},jo={9728:ki,9729:Mt,9984:Ia,9985:Fa,9986:Da,9987:Gn},Vo={33071:Ut,33648:Pa,10497:An},dn={SCALAR:1,VEC2:2,VEC3:3,VEC4:4,MAT2:4,MAT3:9,MAT4:16},In={POSITION:"position",NORMAL:"normal",TANGENT:"tangent",TEXCOORD_0:"uv",TEXCOORD_1:"uv1",TEXCOORD_2:"uv2",TEXCOORD_3:"uv3",COLOR_0:"color",WEIGHTS_0:"skinWeight",JOINTS_0:"skinIndex"},le={scale:"scale",translation:"position",rotation:"quaternion",weights:"morphTargetInfluences"},nh={CUBICSPLINE:void 0,LINEAR:Ci,STEP:Xa},fn={OPAQUE:"OPAQUE",MASK:"MASK",BLEND:"BLEND"};function oh(a){return a.DefaultMaterial===void 0&&(a.DefaultMaterial=new Ri({color:16777215,emissive:0,metalness:1,roughness:1,transparent:!1,depthTest:!0,side:On})),a.DefaultMaterial}function xe(a,t,e){for(const s in e.extensions)a[s]===void 0&&(t.userData.gltfExtensions=t.userData.gltfExtensions||{},t.userData.gltfExtensions[s]=e.extensions[s])}function Vt(a,t){t.extras!==void 0&&(typeof t.extras=="object"?Object.assign(a.userData,t.extras):console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, "+t.extras))}function ih(a,t,e){let s=!1,n=!1,i=!1;for(let l=0,h=t.length;l<h;l++){const u=t[l];if(u.POSITION!==void 0&&(s=!0),u.NORMAL!==void 0&&(n=!0),u.COLOR_0!==void 0&&(i=!0),s&&n&&i)break}if(!s&&!n&&!i)return Promise.resolve(a);const o=[],r=[],c=[];for(let l=0,h=t.length;l<h;l++){const u=t[l];if(s){const d=u.POSITION!==void 0?e.getDependency("accessor",u.POSITION):a.attributes.position;o.push(d)}if(n){const d=u.NORMAL!==void 0?e.getDependency("accessor",u.NORMAL):a.attributes.normal;r.push(d)}if(i){const d=u.COLOR_0!==void 0?e.getDependency("accessor",u.COLOR_0):a.attributes.color;c.push(d)}}return Promise.all([Promise.all(o),Promise.all(r),Promise.all(c)]).then(function(l){const h=l[0],u=l[1],d=l[2];return s&&(a.morphAttributes.position=h),n&&(a.morphAttributes.normal=u),i&&(a.morphAttributes.color=d),a.morphTargetsRelative=!0,a})}function ah(a,t){if(a.updateMorphTargets(),t.weights!==void 0)for(let e=0,s=t.weights.length;e<s;e++)a.morphTargetInfluences[e]=t.weights[e];if(t.extras&&Array.isArray(t.extras.targetNames)){const e=t.extras.targetNames;if(a.morphTargetInfluences.length===e.length){a.morphTargetDictionary={};for(let s=0,n=e.length;s<n;s++)a.morphTargetDictionary[e[s]]=s}else console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.")}}function rh(a){let t;const e=a.extensions&&a.extensions[$.KHR_DRACO_MESH_COMPRESSION];if(e?t="draco:"+e.bufferView+":"+e.indices+":"+pn(e.attributes):t=a.indices+":"+pn(a.attributes)+":"+a.mode,a.targets!==void 0)for(let s=0,n=a.targets.length;s<n;s++)t+=":"+pn(a.targets[s]);return t}function pn(a){let t="";const e=Object.keys(a).sort();for(let s=0,n=e.length;s<n;s++)t+=e[s]+":"+a[e[s]]+";";return t}function Pn(a){switch(a){case Int8Array:return 1/127;case Uint8Array:return 1/255;case Int16Array:return 1/32767;case Uint16Array:return 1/65535;default:throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.")}}function ch(a){return a.search(/\.jpe?g($|\?)/i)>0||a.search(/^data\:image\/jpeg/)===0?"image/jpeg":a.search(/\.webp($|\?)/i)>0||a.search(/^data\:image\/webp/)===0?"image/webp":a.search(/\.ktx2($|\?)/i)>0||a.search(/^data\:image\/ktx2/)===0?"image/ktx2":"image/png"}const lh=new Oe;class hh{constructor(t={},e={}){this.json=t,this.extensions={},this.plugins={},this.options=e,this.cache=new Ll,this.associations=new Map,this.primitiveCache={},this.nodeCache={},this.meshCache={refs:{},uses:{}},this.cameraCache={refs:{},uses:{}},this.lightCache={refs:{},uses:{}},this.sourceCache={},this.textureCache={},this.nodeNamesUsed={};let s=!1,n=-1,i=!1,o=-1;if(typeof navigator<"u"){const r=navigator.userAgent;s=/^((?!chrome|android).)*safari/i.test(r)===!0;const c=r.match(/Version\/(\d+)/);n=s&&c?parseInt(c[1],10):-1,i=r.indexOf("Firefox")>-1,o=i?r.match(/Firefox\/([0-9]+)\./)[1]:-1}typeof createImageBitmap>"u"||s&&n<17||i&&o<98?this.textureLoader=new Ca(this.options.manager):this.textureLoader=new za(this.options.manager),this.textureLoader.setCrossOrigin(this.options.crossOrigin),this.textureLoader.setRequestHeader(this.options.requestHeader),this.fileLoader=new Ai(this.options.manager),this.fileLoader.setResponseType("arraybuffer"),this.options.crossOrigin==="use-credentials"&&this.fileLoader.setWithCredentials(!0)}setExtensions(t){this.extensions=t}setPlugins(t){this.plugins=t}parse(t,e){const s=this,n=this.json,i=this.extensions;this.cache.removeAll(),this.nodeCache={},this._invokeAll(function(o){return o._markDefs&&o._markDefs()}),Promise.all(this._invokeAll(function(o){return o.beforeRoot&&o.beforeRoot()})).then(function(){return Promise.all([s.getDependencies("scene"),s.getDependencies("animation"),s.getDependencies("camera")])}).then(function(o){const r={scene:o[0][n.scene||0],scenes:o[0],animations:o[1],cameras:o[2],asset:n.asset,parser:s,userData:{}};return xe(i,r,n),Vt(r,n),Promise.all(s._invokeAll(function(c){return c.afterRoot&&c.afterRoot(r)})).then(function(){for(const c of r.scenes)c.updateMatrixWorld();t(r)})}).catch(e)}_markDefs(){const t=this.json.nodes||[],e=this.json.skins||[],s=this.json.meshes||[];for(let n=0,i=e.length;n<i;n++){const o=e[n].joints;for(let r=0,c=o.length;r<c;r++)t[o[r]].isBone=!0}for(let n=0,i=t.length;n<i;n++){const o=t[n];o.mesh!==void 0&&(this._addNodeRef(this.meshCache,o.mesh),o.skin!==void 0&&(s[o.mesh].isSkinnedMesh=!0)),o.camera!==void 0&&this._addNodeRef(this.cameraCache,o.camera)}}_addNodeRef(t,e){e!==void 0&&(t.refs[e]===void 0&&(t.refs[e]=t.uses[e]=0),t.refs[e]++)}_getNodeRef(t,e,s){if(t.refs[e]<=1)return s;const n=s.clone(),i=(o,r)=>{const c=this.associations.get(o);c!=null&&this.associations.set(r,c);for(const[l,h]of o.children.entries())i(h,r.children[l])};return i(s,n),n.name+="_instance_"+t.uses[e]++,n}_invokeOne(t){const e=Object.values(this.plugins);e.push(this);for(let s=0;s<e.length;s++){const n=t(e[s]);if(n)return n}return null}_invokeAll(t){const e=Object.values(this.plugins);e.unshift(this);const s=[];for(let n=0;n<e.length;n++){const i=t(e[n]);i&&s.push(i)}return s}getDependency(t,e){const s=t+":"+e;let n=this.cache.get(s);if(!n){switch(t){case"scene":n=this.loadScene(e);break;case"node":n=this._invokeOne(function(i){return i.loadNode&&i.loadNode(e)});break;case"mesh":n=this._invokeOne(function(i){return i.loadMesh&&i.loadMesh(e)});break;case"accessor":n=this.loadAccessor(e);break;case"bufferView":n=this._invokeOne(function(i){return i.loadBufferView&&i.loadBufferView(e)});break;case"buffer":n=this.loadBuffer(e);break;case"material":n=this._invokeOne(function(i){return i.loadMaterial&&i.loadMaterial(e)});break;case"texture":n=this._invokeOne(function(i){return i.loadTexture&&i.loadTexture(e)});break;case"skin":n=this.loadSkin(e);break;case"animation":n=this._invokeOne(function(i){return i.loadAnimation&&i.loadAnimation(e)});break;case"camera":n=this.loadCamera(e);break;default:if(n=this._invokeOne(function(i){return i!=this&&i.getDependency&&i.getDependency(t,e)}),!n)throw new Error("Unknown type: "+t);break}this.cache.add(s,n)}return n}getDependencies(t){let e=this.cache.get(t);if(!e){const s=this,n=this.json[t+(t==="mesh"?"es":"s")]||[];e=Promise.all(n.map(function(i,o){return s.getDependency(t,o)})),this.cache.add(t,e)}return e}loadBuffer(t){const e=this.json.buffers[t],s=this.fileLoader;if(e.type&&e.type!=="arraybuffer")throw new Error("THREE.GLTFLoader: "+e.type+" buffer type is not supported.");if(e.uri===void 0&&t===0)return Promise.resolve(this.extensions[$.KHR_BINARY_GLTF].body);const n=this.options;return new Promise(function(i,o){s.load(ds.resolveURL(e.uri,n.path),i,void 0,function(){o(new Error('THREE.GLTFLoader: Failed to load buffer "'+e.uri+'".'))})})}loadBufferView(t){const e=this.json.bufferViews[t];return this.getDependency("buffer",e.buffer).then(function(s){const n=e.byteLength||0,i=e.byteOffset||0;return s.slice(i,i+n)})}loadAccessor(t){const e=this,s=this.json,n=this.json.accessors[t];if(n.bufferView===void 0&&n.sparse===void 0){const o=dn[n.type],r=Ie[n.componentType],c=n.normalized===!0,l=new r(n.count*o);return Promise.resolve(new G(l,o,c))}const i=[];return n.bufferView!==void 0?i.push(this.getDependency("bufferView",n.bufferView)):i.push(null),n.sparse!==void 0&&(i.push(this.getDependency("bufferView",n.sparse.indices.bufferView)),i.push(this.getDependency("bufferView",n.sparse.values.bufferView))),Promise.all(i).then(function(o){const r=o[0],c=dn[n.type],l=Ie[n.componentType],h=l.BYTES_PER_ELEMENT,u=h*c,d=n.byteOffset||0,f=n.bufferView!==void 0?s.bufferViews[n.bufferView].byteStride:void 0,p=n.normalized===!0;let m,v;if(f&&f!==u){const g=Math.floor(d/f),w="InterleavedBuffer:"+n.bufferView+":"+n.componentType+":"+g+":"+n.count;let x=e.cache.get(w);x||(m=new l(r,g*f,n.count*f/h),x=new La(m,f/h),e.cache.add(w,x)),v=new Za(x,c,d%f/h,p)}else r===null?m=new l(n.count*c):m=new l(r,d,n.count*c),v=new G(m,c,p);if(n.sparse!==void 0){const g=dn.SCALAR,w=Ie[n.sparse.indices.componentType],x=n.sparse.indices.byteOffset||0,y=n.sparse.values.byteOffset||0,T=new w(o[1],x,n.sparse.count*g),b=new l(o[2],y,n.sparse.count*c);r!==null&&(v=new G(v.array.slice(),v.itemSize,v.normalized)),v.normalized=!1;for(let M=0,_=T.length;M<_;M++){const S=T[M];if(v.setX(S,b[M*c]),c>=2&&v.setY(S,b[M*c+1]),c>=3&&v.setZ(S,b[M*c+2]),c>=4&&v.setW(S,b[M*c+3]),c>=5)throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.")}v.normalized=p}return v})}loadTexture(t){const e=this.json,s=this.options,i=e.textures[t].source,o=e.images[i];let r=this.textureLoader;if(o.uri){const c=s.manager.getHandler(o.uri);c!==null&&(r=c)}return this.loadTextureImage(t,i,r)}loadTextureImage(t,e,s){const n=this,i=this.json,o=i.textures[t],r=i.images[e],c=(r.uri||r.bufferView)+":"+o.sampler;if(this.textureCache[c])return this.textureCache[c];const l=this.loadImageSource(e,s).then(function(h){h.flipY=!1,h.name=o.name||r.name||"",h.name===""&&typeof r.uri=="string"&&r.uri.startsWith("data:image/")===!1&&(h.name=r.uri);const d=(i.samplers||{})[o.sampler]||{};return h.magFilter=jo[d.magFilter]||Mt,h.minFilter=jo[d.minFilter]||Gn,h.wrapS=Vo[d.wrapS]||An,h.wrapT=Vo[d.wrapT]||An,h.generateMipmaps=!h.isCompressedTexture&&h.minFilter!==ki&&h.minFilter!==Mt,n.associations.set(h,{textures:t}),h}).catch(function(){return null});return this.textureCache[c]=l,l}loadImageSource(t,e){const s=this,n=this.json,i=this.options;if(this.sourceCache[t]!==void 0)return this.sourceCache[t].then(u=>u.clone());const o=n.images[t],r=self.URL||self.webkitURL;let c=o.uri||"",l=!1;if(o.bufferView!==void 0)c=s.getDependency("bufferView",o.bufferView).then(function(u){l=!0;const d=new Blob([u],{type:o.mimeType});return c=r.createObjectURL(d),c});else if(o.uri===void 0)throw new Error("THREE.GLTFLoader: Image "+t+" is missing URI and bufferView");const h=Promise.resolve(c).then(function(u){return new Promise(function(d,f){let p=d;e.isImageBitmapLoader===!0&&(p=function(m){const v=new io(m);v.needsUpdate=!0,d(v)}),e.load(ds.resolveURL(u,i.path),p,void 0,f)})}).then(function(u){return l===!0&&r.revokeObjectURL(c),Vt(u,o),u.userData.mimeType=o.mimeType||ch(o.uri),u}).catch(function(u){throw console.error("THREE.GLTFLoader: Couldn't load texture",c),u});return this.sourceCache[t]=h,h}assignTexture(t,e,s,n){const i=this;return this.getDependency("texture",s.index).then(function(o){if(!o)return null;if(s.texCoord!==void 0&&s.texCoord>0&&(o=o.clone(),o.channel=s.texCoord),i.extensions[$.KHR_TEXTURE_TRANSFORM]){const r=s.extensions!==void 0?s.extensions[$.KHR_TEXTURE_TRANSFORM]:void 0;if(r){const c=i.associations.get(o);o=i.extensions[$.KHR_TEXTURE_TRANSFORM].extendTexture(o,r),i.associations.set(o,c)}}return n!==void 0&&(o.colorSpace=n),t[e]=o,o})}assignFinalMaterial(t){const e=t.geometry;let s=t.material;const n=e.attributes.tangent===void 0,i=e.attributes.color!==void 0,o=e.attributes.normal===void 0;if(t.isPoints){const r="PointsMaterial:"+s.uuid;let c=this.cache.get(r);c||(c=new Na,on.prototype.copy.call(c,s),c.color.copy(s.color),c.map=s.map,c.sizeAttenuation=!1,this.cache.add(r,c)),s=c}else if(t.isLine){const r="LineBasicMaterial:"+s.uuid;let c=this.cache.get(r);c||(c=new Oa,on.prototype.copy.call(c,s),c.color.copy(s.color),c.map=s.map,this.cache.add(r,c)),s=c}if(n||i||o){let r="ClonedMaterial:"+s.uuid+":";n&&(r+="derivative-tangents:"),i&&(r+="vertex-colors:"),o&&(r+="flat-shading:");let c=this.cache.get(r);c||(c=s.clone(),i&&(c.vertexColors=!0),o&&(c.flatShading=!0),n&&(c.normalScale&&(c.normalScale.y*=-1),c.clearcoatNormalScale&&(c.clearcoatNormalScale.y*=-1)),this.cache.add(r,c),this.associations.set(c,this.associations.get(s))),s=c}t.material=s}getMaterialType(){return Ri}loadMaterial(t){const e=this,s=this.json,n=this.extensions,i=s.materials[t];let o;const r={},c=i.extensions||{},l=[];if(c[$.KHR_MATERIALS_UNLIT]){const u=n[$.KHR_MATERIALS_UNLIT];o=u.getMaterialType(),l.push(u.extendParams(r,i,e))}else{const u=i.pbrMetallicRoughness||{};if(r.color=new oe(1,1,1),r.opacity=1,Array.isArray(u.baseColorFactor)){const d=u.baseColorFactor;r.color.setRGB(d[0],d[1],d[2],Ft),r.opacity=d[3]}u.baseColorTexture!==void 0&&l.push(e.assignTexture(r,"map",u.baseColorTexture,Be)),r.metalness=u.metallicFactor!==void 0?u.metallicFactor:1,r.roughness=u.roughnessFactor!==void 0?u.roughnessFactor:1,u.metallicRoughnessTexture!==void 0&&(l.push(e.assignTexture(r,"metalnessMap",u.metallicRoughnessTexture)),l.push(e.assignTexture(r,"roughnessMap",u.metallicRoughnessTexture))),o=this._invokeOne(function(d){return d.getMaterialType&&d.getMaterialType(t)}),l.push(Promise.all(this._invokeAll(function(d){return d.extendMaterialParams&&d.extendMaterialParams(t,r)})))}i.doubleSided===!0&&(r.side=Jt);const h=i.alphaMode||fn.OPAQUE;if(h===fn.BLEND?(r.transparent=!0,r.depthWrite=!1):(r.transparent=!1,h===fn.MASK&&(r.alphaTest=i.alphaCutoff!==void 0?i.alphaCutoff:.5)),i.normalTexture!==void 0&&o!==os&&(l.push(e.assignTexture(r,"normalMap",i.normalTexture)),r.normalScale=new ct(1,1),i.normalTexture.scale!==void 0)){const u=i.normalTexture.scale;r.normalScale.set(u,u)}if(i.occlusionTexture!==void 0&&o!==os&&(l.push(e.assignTexture(r,"aoMap",i.occlusionTexture)),i.occlusionTexture.strength!==void 0&&(r.aoMapIntensity=i.occlusionTexture.strength)),i.emissiveFactor!==void 0&&o!==os){const u=i.emissiveFactor;r.emissive=new oe().setRGB(u[0],u[1],u[2],Ft)}return i.emissiveTexture!==void 0&&o!==os&&l.push(e.assignTexture(r,"emissiveMap",i.emissiveTexture,Be)),Promise.all(l).then(function(){const u=new o(r);return i.name&&(u.name=i.name),Vt(u,i),e.associations.set(u,{materials:t}),i.extensions&&xe(n,u,i),u})}createUniqueName(t){const e=Ba.sanitizeNodeName(t||"");return e in this.nodeNamesUsed?e+"_"+ ++this.nodeNamesUsed[e]:(this.nodeNamesUsed[e]=0,e)}loadGeometries(t){const e=this,s=this.extensions,n=this.primitiveCache;function i(r){return s[$.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(r,e).then(function(c){return Yo(c,r,e)})}const o=[];for(let r=0,c=t.length;r<c;r++){const l=t[r],h=rh(l),u=n[h];if(u)o.push(u.promise);else{let d;l.extensions&&l.extensions[$.KHR_DRACO_MESH_COMPRESSION]?d=i(l):d=Yo(new Qt,l,e),n[h]={primitive:l,promise:d},o.push(d)}}return Promise.all(o)}loadMesh(t){const e=this,s=this.json,n=this.extensions,i=s.meshes[t],o=i.primitives,r=[];for(let c=0,l=o.length;c<l;c++){const h=o[c].material===void 0?oh(this.cache):this.getDependency("material",o[c].material);r.push(h)}return r.push(e.loadGeometries(o)),Promise.all(r).then(function(c){const l=c.slice(0,c.length-1),h=c[c.length-1],u=[];for(let f=0,p=h.length;f<p;f++){const m=h[f],v=o[f];let g;const w=l[f];if(v.mode===Dt.TRIANGLES||v.mode===Dt.TRIANGLE_STRIP||v.mode===Dt.TRIANGLE_FAN||v.mode===void 0)g=i.isSkinnedMesh===!0?new Ga(m,w):new bt(m,w),g.isSkinnedMesh===!0&&g.normalizeSkinWeights(),v.mode===Dt.TRIANGLE_STRIP?g.geometry=$o(g.geometry,Si):v.mode===Dt.TRIANGLE_FAN&&(g.geometry=$o(g.geometry,Sn));else if(v.mode===Dt.LINES)g=new Ua(m,w);else if(v.mode===Dt.LINE_STRIP)g=new Ha(m,w);else if(v.mode===Dt.LINE_LOOP)g=new Wa(m,w);else if(v.mode===Dt.POINTS)g=new Ka(m,w);else throw new Error("THREE.GLTFLoader: Primitive mode unsupported: "+v.mode);Object.keys(g.geometry.morphAttributes).length>0&&ah(g,i),g.name=e.createUniqueName(i.name||"mesh_"+t),Vt(g,i),v.extensions&&xe(n,g,v),e.assignFinalMaterial(g),u.push(g)}for(let f=0,p=u.length;f<p;f++)e.associations.set(u[f],{meshes:t,primitives:f});if(u.length===1)return i.extensions&&xe(n,u[0],i),u[0];const d=new ne;i.extensions&&xe(n,d,i),e.associations.set(d,{meshes:t});for(let f=0,p=u.length;f<p;f++)d.add(u[f]);return d})}loadCamera(t){let e;const s=this.json.cameras[t],n=s[s.type];if(!n){console.warn("THREE.GLTFLoader: Missing camera parameters.");return}return s.type==="perspective"?e=new Ei($a.radToDeg(n.yfov),n.aspectRatio||1,n.znear||1,n.zfar||2e6):s.type==="orthographic"&&(e=new qa(-n.xmag,n.xmag,n.ymag,-n.ymag,n.znear,n.zfar)),s.name&&(e.name=this.createUniqueName(s.name)),Vt(e,s),Promise.resolve(e)}loadSkin(t){const e=this.json.skins[t],s=[];for(let n=0,i=e.joints.length;n<i;n++)s.push(this._loadNodeShallow(e.joints[n]));return e.inverseBindMatrices!==void 0?s.push(this.getDependency("accessor",e.inverseBindMatrices)):s.push(null),Promise.all(s).then(function(n){const i=n.pop(),o=n,r=[],c=[];for(let l=0,h=o.length;l<h;l++){const u=o[l];if(u){r.push(u);const d=new Oe;i!==null&&d.fromArray(i.array,l*16),c.push(d)}else console.warn('THREE.GLTFLoader: Joint "%s" could not be found.',e.joints[l])}return new ja(r,c)})}loadAnimation(t){const e=this.json,s=this,n=e.animations[t],i=n.name?n.name:"animation_"+t,o=[],r=[],c=[],l=[],h=[];for(let u=0,d=n.channels.length;u<d;u++){const f=n.channels[u],p=n.samplers[f.sampler],m=f.target,v=m.node,g=n.parameters!==void 0?n.parameters[p.input]:p.input,w=n.parameters!==void 0?n.parameters[p.output]:p.output;m.node!==void 0&&(o.push(this.getDependency("node",v)),r.push(this.getDependency("accessor",g)),c.push(this.getDependency("accessor",w)),l.push(p),h.push(m))}return Promise.all([Promise.all(o),Promise.all(r),Promise.all(c),Promise.all(l),Promise.all(h)]).then(function(u){const d=u[0],f=u[1],p=u[2],m=u[3],v=u[4],g=[];for(let x=0,y=d.length;x<y;x++){const T=d[x],b=f[x],M=p[x],_=m[x],S=v[x];if(T===void 0)continue;T.updateMatrix&&T.updateMatrix();const A=s._createAnimationTracks(T,b,M,_,S);if(A)for(let L=0;L<A.length;L++)g.push(A[L])}const w=new Va(i,void 0,g);return Vt(w,n),w})}createNodeMesh(t){const e=this.json,s=this,n=e.nodes[t];return n.mesh===void 0?null:s.getDependency("mesh",n.mesh).then(function(i){const o=s._getNodeRef(s.meshCache,n.mesh,i);return n.weights!==void 0&&o.traverse(function(r){if(r.isMesh)for(let c=0,l=n.weights.length;c<l;c++)r.morphTargetInfluences[c]=n.weights[c]}),o})}loadNode(t){const e=this.json,s=this,n=e.nodes[t],i=s._loadNodeShallow(t),o=[],r=n.children||[];for(let l=0,h=r.length;l<h;l++)o.push(s.getDependency("node",r[l]));const c=n.skin===void 0?Promise.resolve(null):s.getDependency("skin",n.skin);return Promise.all([i,Promise.all(o),c]).then(function(l){const h=l[0],u=l[1],d=l[2];d!==null&&h.traverse(function(f){f.isSkinnedMesh&&f.bind(d,lh)});for(let f=0,p=u.length;f<p;f++)h.add(u[f]);return h})}_loadNodeShallow(t){const e=this.json,s=this.extensions,n=this;if(this.nodeCache[t]!==void 0)return this.nodeCache[t];const i=e.nodes[t],o=i.name?n.createUniqueName(i.name):"",r=[],c=n._invokeOne(function(l){return l.createNodeMesh&&l.createNodeMesh(t)});return c&&r.push(c),i.camera!==void 0&&r.push(n.getDependency("camera",i.camera).then(function(l){return n._getNodeRef(n.cameraCache,i.camera,l)})),n._invokeAll(function(l){return l.createNodeAttachment&&l.createNodeAttachment(t)}).forEach(function(l){r.push(l)}),this.nodeCache[t]=Promise.all(r).then(function(l){let h;if(i.isBone===!0?h=new Ya:l.length>1?h=new ne:l.length===1?h=l[0]:h=new ge,h!==l[0])for(let u=0,d=l.length;u<d;u++)h.add(l[u]);if(i.name&&(h.userData.name=i.name,h.name=o),Vt(h,i),i.extensions&&xe(s,h,i),i.matrix!==void 0){const u=new Oe;u.fromArray(i.matrix),h.applyMatrix4(u)}else i.translation!==void 0&&h.position.fromArray(i.translation),i.rotation!==void 0&&h.quaternion.fromArray(i.rotation),i.scale!==void 0&&h.scale.fromArray(i.scale);if(!n.associations.has(h))n.associations.set(h,{});else if(i.mesh!==void 0&&n.meshCache.refs[i.mesh]>1){const u=n.associations.get(h);n.associations.set(h,{...u})}return n.associations.get(h).nodes=t,h}),this.nodeCache[t]}loadScene(t){const e=this.extensions,s=this.json.scenes[t],n=this,i=new ne;s.name&&(i.name=n.createUniqueName(s.name)),Vt(i,s),s.extensions&&xe(e,i,s);const o=s.nodes||[],r=[];for(let c=0,l=o.length;c<l;c++)r.push(n.getDependency("node",o[c]));return Promise.all(r).then(function(c){for(let h=0,u=c.length;h<u;h++)i.add(c[h]);const l=h=>{const u=new Map;for(const[d,f]of n.associations)(d instanceof on||d instanceof io)&&u.set(d,f);return h.traverse(d=>{const f=n.associations.get(d);f!=null&&u.set(d,f)}),u};return n.associations=l(i),i})}_createAnimationTracks(t,e,s,n,i){const o=[],r=t.name?t.name:t.uuid,c=[];le[i.path]===le.weights?t.traverse(function(d){d.morphTargetInfluences&&c.push(d.name?d.name:d.uuid)}):c.push(r);let l;switch(le[i.path]){case le.weights:l=ro;break;case le.rotation:l=co;break;case le.translation:case le.scale:l=ao;break;default:switch(s.itemSize){case 1:l=ro;break;case 2:case 3:default:l=ao;break}break}const h=n.interpolation!==void 0?nh[n.interpolation]:Ci,u=this._getArrayFromAccessor(s);for(let d=0,f=c.length;d<f;d++){const p=new l(c[d]+"."+le[i.path],e.array,u,h);n.interpolation==="CUBICSPLINE"&&this._createCubicSplineTrackInterpolant(p),o.push(p)}return o}_getArrayFromAccessor(t){let e=t.array;if(t.normalized){const s=Pn(e.constructor),n=new Float32Array(e.length);for(let i=0,o=e.length;i<o;i++)n[i]=e[i]*s;e=n}return e}_createCubicSplineTrackInterpolant(t){t.createInterpolant=function(s){const n=this instanceof co?sh:oa;return new n(this.times,this.values,this.getValueSize()/3,s)},t.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline=!0}}function uh(a,t,e){const s=t.attributes,n=new Is;if(s.POSITION!==void 0){const r=e.json.accessors[s.POSITION],c=r.min,l=r.max;if(c!==void 0&&l!==void 0){if(n.set(new Y(c[0],c[1],c[2]),new Y(l[0],l[1],l[2])),r.normalized){const h=Pn(Ie[r.componentType]);n.min.multiplyScalar(h),n.max.multiplyScalar(h)}}else{console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");return}}else return;const i=t.targets;if(i!==void 0){const r=new Y,c=new Y;for(let l=0,h=i.length;l<h;l++){const u=i[l];if(u.POSITION!==void 0){const d=e.json.accessors[u.POSITION],f=d.min,p=d.max;if(f!==void 0&&p!==void 0){if(c.setX(Math.max(Math.abs(f[0]),Math.abs(p[0]))),c.setY(Math.max(Math.abs(f[1]),Math.abs(p[1]))),c.setZ(Math.max(Math.abs(f[2]),Math.abs(p[2]))),d.normalized){const m=Pn(Ie[d.componentType]);c.multiplyScalar(m)}r.max(c)}else console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.")}}n.expandByVector(r)}a.boundingBox=n;const o=new ie;n.getCenter(o.center),o.radius=n.min.distanceTo(n.max)/2,a.boundingSphere=o}function Yo(a,t,e){const s=t.attributes,n=[];function i(o,r){return e.getDependency("accessor",o).then(function(c){a.setAttribute(r,c)})}for(const o in s){const r=In[o]||o.toLowerCase();r in a.attributes||n.push(i(s[o],r))}if(t.indices!==void 0&&!a.index){const o=e.getDependency("accessor",t.indices).then(function(r){a.setIndex(r)});n.push(o)}return lo.workingColorSpace!==Ft&&"COLOR_0"in s&&console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${lo.workingColorSpace}" not supported.`),Vt(a,t),uh(a,t,e),Promise.all(n).then(function(){return t.targets!==void 0?ih(a,t.targets,e):a})}const dh=120,Cs=1/dh,Xo=5,Zo={gt:{name:"Grand Tourer",mass:1520,izz:2600,wheelbase:2.72,track:1.6,cgHeight:.45,weightRear:.5,power:165,peakTorque:235,redline:6800,cdA:1.9,rollPerG:3.4,topSpeed:135,zeroTo100:9.5,ratios:[4.1,2.62,1.9,1.47,1.15,.98],finalDrive:4.1,wheelRadius:.34,drive:"rwd"},sports:{name:"Sports",mass:1450,izz:2300,wheelbase:2.65,track:1.62,cgHeight:.42,weightRear:.53,power:300,peakTorque:370,redline:7200,cdA:1.62,rollPerG:2.5,topSpeed:165,zeroTo100:7,ratios:[3.9,2.5,1.81,1.4,1.1,.93],finalDrive:3.95,wheelRadius:.34,drive:"rwd"},hyper:{name:"Hyper",mass:1400,izz:2150,wheelbase:2.7,track:1.68,cgHeight:.38,weightRear:.56,power:380,peakTorque:405,redline:8200,cdA:1.48,rollPerG:1.7,topSpeed:190,zeroTo100:5.6,ratios:[3.7,2.38,1.77,1.4,1.12,.94],finalDrive:3.9,wheelRadius:.35,drive:"awd"}},et={peakSlipFront:8*Math.PI/180,peakSlipRear:9*Math.PI/180,tailFloor:.55,muLatFront:1.3,muLatRear:1.34,muLongPeak:1.42,peakSlipRatio:.12,awdCap:1.36,speedFadeAt:110,speedFade:.1,downforce:.22,ellipseExp:1.85,liftoffDrop:.06,liftoffHold:.25,liftoffRecover:.6,liftoffMinLatG:.4},H={maxAngle:40*Math.PI/180,minAngle:8*Math.PI/180,taperSpeed:16,taperPow:1.5,comfortG:8.4,attackG:14,minRadius:7,buildBase:2.4,buildBonus:4.2,buildFalloff:18,returnRate:8.5,padRateLimit:900*Math.PI/180,padDeadzone:.04,padSaturation:.95,padCurve:1.5,satGain:.3,satDamping:.55,trailPeak:.9,trailPostPeak:.25,driftLow:12*Math.PI/180,driftBonus:.18,driftYawDamp:1.9,spinYawDamp:4.2,spinAngle:42*Math.PI/180},Qe={throttleUp:1/.25,throttleDown:1/.15,throttleCurve:1.4,brakeUp:1/.07,brakeDown:1/.1},Rt={torque:15500,baseTorque:15500,splitFront:.68,splitFrontDive:.76,absHz:18,absRelease:.16,lockedLatFloor:.35,handbrakeTorque:2200,handbrakeRearMu:.55,handbrakeRecover:.35,handbrakeYawCap:130*Math.PI/180},Bt={shiftTimeAuto:.14,shiftTorqueCut:.25,downshiftHysteresis:900,upshiftAtThrottle:[[0,.38],[.2,.42],[.5,.62],[1,.97]],idleRpm:900,driveLoss:.12},fh=[[0,.42],[.12,.55],[.3,.88],[.55,1],[.8,.95],[1,.8]];function Jo(a,t){if(t<=a[0][0])return a[0][1];for(let e=1;e<a.length;e++)if(t<=a[e][0]){const[s,n]=a[e-1],[i,o]=a[e],r=(t-s)/(i-s||1);return n+(o-n)*r}return a[a.length-1][1]}const at={rollOmega:8.4,rollZeta:.85,pitchOmega:10.5,pitchZeta:.85,divePerG:1.6*Math.PI/180,squatPerG:1*Math.PI/180,rollClamp:5.5*Math.PI/180,pitchClamp:3*Math.PI/180,rollRate:50*Math.PI/180,pitchRate:35*Math.PI/180,loadTauPitch:.12,loadTauRoll:.15},yt={gravity:9.81,extraMin:.1,extraMax:1,extraDelay:.1,extraRamp:.1},be={restLength:.36,travel:.22,stiffness:42e3,damping:4200},mn={cruise:{counterSteer:.95,stability:.35,tcs:.4,abs:.8,autoGears:!0,lockFloor:10*Math.PI/180,brakeMul:1,airborne:1},sport:{counterSteer:.7,stability:.2,tcs:.2,abs:.6,autoGears:!0,lockFloor:H.minAngle,brakeMul:1,airborne:1},off:{counterSteer:.3,stability:.05,tcs:0,abs:.3,autoGears:!0,lockFloor:H.minAngle,brakeMul:1,airborne:1},hardcore:{counterSteer:0,stability:0,tcs:0,abs:0,autoGears:!1,lockFloor:H.minAngle,brakeMul:.82,airborne:0}},he={csKeyboard:.85,csGamepad:.45,csLag:.06,csMinSlip:4*Math.PI/180,csMinSpeed:8/3.6,csClamp:.75,stabilityYawGain:1.4},zs={cruise:{behind:6,above:1.85,lookAhead:1,lookHeight:.9,yawTau:.35,velocityBlend:0,fov:64,fovGain:0,stretch:0,rise:0,shake:0},sport:{behind:6.2,above:1.9,lookAhead:1,lookHeight:.9,yawTau:.22,velocityBlend:.62,lookIntoCorner:.18,lookIntoClamp:9*Math.PI/180,springOmega:7.7,springZeta:.85,stretch:1.8,rise:.25,fov:62,fovGain:17,fovPow:.7,fovRate:12*Math.PI/180,fovKick:5,fovKickTau:.6,lateralClamp:.12,pitchRate:20*Math.PI/180,pitchClamp:6*Math.PI/180,shake:.35*Math.PI/180,shakeHz:11,shakeFrom:145/3.6},hood:{behind:-.35,above:1.15,lookAhead:6,lookHeight:1.1,yawTau:.05,velocityBlend:0,fov:58,fovGain:0}},ve=[{id:"estate",file:"estate.glb",label:"Estate",blurb:"Soft, slow and forgiving. The one you learn the roads in.",unlockAt:0,tier:"gt",length:4.6,feel:{comfortG:7,assist:"cruise",rearGrip:1.06,buildRate:2.6,brakeMul:1.15}},{id:"hatch",file:"hatch.glb",label:"Hatch",blurb:"Light and eager. Turns in more sharply than it has any right to.",unlockAt:1e3,tier:"gt",length:4,feel:{comfortG:8.2,assist:"cruise",rearGrip:1,buildRate:3,brakeMul:1.1}},{id:"coupe",file:"coupe.glb",label:"Coupe",blurb:"The road car. Quick enough to be interesting, calm enough to cruise.",unlockAt:3e3,tier:"sports",length:4.3,feel:{comfortG:9.2,assist:"sport",rearGrip:1,buildRate:2.8,brakeMul:1}},{id:"sedan",file:"sedan.glb",label:"Sedan",blurb:"Long wheelbase, loose rear. It will hold a slide if you ask nicely.",unlockAt:8e3,tier:"sports",length:4.5,feel:{comfortG:10.4,assist:"sport",rearGrip:.9,buildRate:3.2,brakeMul:1}},{id:"rally",file:"rally.glb",label:"Rally",blurb:"Made for the gravel. The only one that is genuinely happy off the tarmac.",unlockAt:2e4,tier:"sports",length:4.2,feel:{comfortG:11.6,assist:"sport",rearGrip:.94,buildRate:3.6,brakeMul:1.05,offRoad:1.35}},{id:"taxi",file:"taxi.glb",label:"Taxi",blurb:"Somebody has to. Slow, indestructible, oddly relaxing.",unlockAt:45e3,tier:"gt",length:4.5,feel:{comfortG:7.6,assist:"cruise",rearGrip:1.04,buildRate:2.4,brakeMul:1.2}},{id:"patrol",file:"patrol.glb",label:"Patrol",blurb:"All-wheel drive and the strongest brakes in the fleet. The long-distance one.",unlockAt:1e5,tier:"hyper",length:4.6,feel:{comfortG:9.8,assist:"sport",rearGrip:1.02,buildRate:2.8,brakeMul:1.3}}],qs=Object.fromEntries(ve.map(a=>[a.id,a])),ph=ve[0].id,ia="wanderoad.unlocks.v1";function fs(){try{return new URLSearchParams(location.search).has("cheat")||localStorage.getItem(ia+".cheat")==="1"}catch{return!1}}function aa(a){try{localStorage.setItem(ia+".cheat",a?"1":"0")}catch{}}function Pe(){try{const a=localStorage.getItem("wanderoad.streak.v1");return a&&+JSON.parse(a).best||0}catch{return 0}}function ws(a,t=Pe()){return fs()||t>=a.unlockAt}function mh(a=Pe()){if(fs())return null;for(const t of ve)if(a<t.unlockAt)return{car:t,remaining:t.unlockAt-a,progress:a/t.unlockAt};return null}function ra(a){const t=a.feel;return H.comfortG=t.comfortG,H.attackG=t.comfortG*1.6,H.buildBase=t.buildRate,H.buildBonus=t.buildRate*1.6,et.muLatRear=1.34*t.rearGrip,Rt.torque=Rt.baseTorque*(t.brakeMul||1),t}function vh(a=location.search){const t=new URLSearchParams(a).get("car"),e=Pe(),s=qs[t];return s&&ws(s,e)?s:qs[ph]}function ca(a){return a<1e3?`${Math.round(a)} m`:`${(a/1e3).toFixed(a<1e4?1:0)} km`}const js=Object.fromEntries(ve.map(a=>[a.id,{file:a.file,label:a.label,tier:a.tier,length:a.length}]));ve.map(a=>a.id);const Qo=[ft.paintA,ft.paintB,ft.paintC,ft.paintD,ft.paintE,ft.paintF];function gh(a,t){const e=(a||"").toLowerCase();return e.includes("window")||e.includes("glass")?{col:ft.glass,mat:N.METAL}:e.includes("headlight")?{col:ft.head,mat:N.EMIT}:e.includes("taillight")||e.includes("brakelight")?{col:ft.tail,mat:N.EMIT}:e.includes("whitelight")?{col:ft.head,mat:N.EMIT}:e.includes("bluelight")?{col:"#5A8BD6",mat:N.EMIT}:e.includes("black")?{col:ft.tyre,mat:N.MATTE}:e.includes("grey")||e.includes("gray")||e.includes("chrome")||e.includes("metal")?{col:ft.chrome,mat:N.METAL}:e.includes("rust")?{col:ft.trunkShade,mat:N.MATTE}:{col:t,mat:N.MATTE}}const wh=a=>{const t=a.replace("#","");return[parseInt(t.slice(0,2),16)/255,parseInt(t.slice(2,4),16)/255,parseInt(t.slice(4,6),16)/255]};let vn=null;const gn=new Map;function xh(){return vn||(vn=new zl),vn}function bh(a){if(gn.has(a))return gn.get(a);const t=new Promise((e,s)=>xh().load(a,n=>e(n),void 0,s));return gn.set(a,t),t}async function ti({car:a="coupe",paint:t=0,base:e="./models/cars/",ghost:s=!1}={}){const n=js[a]||js.coupe,o=(await bh(e+n.file)).scene.clone(!0),r=Qo[t%Qo.length],c=qn(s?{ghost:!0,opacity:.85}:{});o.traverse(x=>{if(!x.isMesh)return;const y=Array.isArray(x.material)?x.material[0]:x.material,{col:T,mat:b}=gh(y&&y.name,r),M=wh(T),_=x.geometry,S=_.attributes.position.count,A=new Float32Array(S*3),L=new Float32Array(S);for(let E=0;E<S;E++)A[E*3]=M[0],A[E*3+1]=M[1],A[E*3+2]=M[2],L[E]=b;_.setAttribute("vcol",new G(A,3)),_.setAttribute("vmat",new G(L,1)),!_.attributes.nrm&&_.attributes.normal&&_.setAttribute("nrm",_.attributes.normal),_.attributes.nrm||(_.computeVertexNormals(),_.setAttribute("nrm",_.attributes.normal)),x.material=c,x.castShadow=!1,x.receiveShadow=!1});const l=new Is().setFromObject(o),h=new Y;l.getSize(h);const u=Math.max(h.x,h.z),d=u>.001?n.length/u:1;o.scale.setScalar(d),o.updateMatrixWorld(!0);const f=new Is().setFromObject(o);o.position.y-=f.min.y;const p=new ne;p.name=`car:${a}`,p.add(o);const m=new Map,v=[];o.traverse(x=>{x.isMesh&&/wheel/i.test(x.name||"")&&v.push(x)});for(const x of v){const y=(x.name||"").toLowerCase(),T=y.includes("frontleft")?"fl":y.includes("frontright")?"fr":y.includes("rearleft")?"rl":y.includes("rearright")?"rr":y.includes("front")?"f":"r";m.has(T)||m.set(T,[]),m.get(T).push(x)}const g={steer:[],spin:[],all:[]};for(const[x,y]of m){const T=new Is;for(const L of y)L.updateMatrixWorld(!0),T.expandByObject(L);const b=new Y;T.getCenter(b);const M=y[0].parent,_=M.worldToLocal(b.clone()),S=new ne;S.name=`wheel:${x}:steer`,S.position.copy(_),M.add(S);const A=new ne;A.name=`wheel:${x}:spin`,S.add(A);for(const L of y){const E=L.position.clone().sub(_);A.add(L),L.position.copy(E)}g.all.push(A),g.spin.push(A),(x==="fl"||x==="fr"||x==="f")&&g.steer.push(S)}return{group:p,wheels:g.all,steerNodes:g.steer,source:a,label:n.label,tier:n.tier,setSteer(x){for(const y of g.steer)y.rotation.y=-x},setWheelSpin(x){const y=x%(Math.PI*2);for(const T of g.spin)T.rotation.x=y},setBrakeGlow(){},setLights(){},setBodyRoll(x,y){p.rotation.z=x,p.rotation.x=y},dispose(){o.traverse(x=>{x.isMesh&&x.geometry.dispose()}),c.dispose()}}}const ei=(a,t)=>Tt(Math.round(a),Math.round(t),24301)/4294967296*2-1,ts=Math.PI*2,yh=.62,_h=1.45;function Mh(a,t){return a<=1?Math.sin(Math.PI/2*Math.pow(a,yh)):t+(1-t)*Math.exp(-.125*Math.pow(a-1,_h))}function si(a,t){const e=Math.abs(a)/t;return Math.sign(a)*Mh(e,et.tailFloor)}class Th{constructor({tier:t="sports",terrain:e=null,preset:s="sport"}={}){this.setTier(t),this.terrain=e,this.assist={...mn[s]},this.presetName=s,this.x=0,this.y=0,this.z=0,this.yaw=0,this.roll=0,this.pitch=0,this.vx=0,this.vy=0,this.vz=0,this.yawRate=0,this.steer=0,this.throttle=0,this.brake=0,this.handbrake=0,this.gear=1,this.rpm=Bt.idleRpm,this.reverse=!1,this._shiftTimer=0,this._shiftHold=0,this._absPhase=0,this._liftoff=0,this._liftoffTimer=0,this._airTime=0,this._loadLong=0,this._loadLat=0,this._rollV=0,this._pitchV=0,this._csState=0,this._hbRelease=1,this._acc=0,this._prevSpeed=0,this.speed=0,this.slip=0,this.limit=0,this.wheelSpin=0,this.longAccel=0,this.latAccel=0,this.onGround=!0,this.surfaceKind="ground",this.gripScale=1,this.rough=0,this.forces={drive:0,brake:0,contact:1,traction:0,drag:0,rr:0,engBrake:0,net:0,gear:1,ratio:0,latAvail:1},this.wheels=[{x:0,y:0,z:0,compression:0,load:0,slipAngle:0,slipRatio:0,contact:!0},{x:0,y:0,z:0,compression:0,load:0,slipAngle:0,slipRatio:0,contact:!0},{x:0,y:0,z:0,compression:0,load:0,slipAngle:0,slipRatio:0,contact:!0},{x:0,y:0,z:0,compression:0,load:0,slipAngle:0,slipRatio:0,contact:!0}]}setTier(t){this.tier=t;const e=Zo[t]||Zo.sports;this.spec=e,this.mass=e.mass,this.izz=e.izz,this.wb=e.wheelbase,this.track=e.track,this.a=e.wheelbase*e.weightRear,this.b=e.wheelbase*(1-e.weightRear),this.muCapAwd=e.drive==="awd"}setPreset(t){mn[t]&&(this.presetName=t,this.assist={...mn[t]})}placeAt(t,e,s=0){this.x=t,this.z=e,this.yaw=s;const n=this.terrain?this.terrain.surface(t,e):null;this.y=(n?n.y:0)+be.restLength,this.vx=this.vy=this.vz=0,this.yawRate=0,this.gear=1,this.rpm=Bt.idleRpm}maxSteerAngle(t=!1){const e=Math.abs(this.speed),s=H.minAngle+(H.maxAngle-H.minAngle)/(1+Math.pow(e/H.taperSpeed,H.taperPow)),n=t?H.attackG:H.comfortG,i=e>1?Math.atan(this.wb*n/(e*e)):H.maxAngle,o=1-D((e-5)/7),r=Math.atan(this.wb/H.minRadius)*o,c=Math.max(i,r);let l=Math.min(s,c);return l=Math.max(l,this.assist.lockFloor*.35,H.minAngle*.22),Math.abs(this.slip)>H.driftLow&&(l=Math.max(l,s*(1+H.driftBonus))),l}update(t,e){this._acc+=Math.min(t,Xo*Cs);let s=0;for(;this._acc>=Cs&&s<Xo;)this._step(Cs,e),this._acc-=Cs,s++;return s}_step(t,e){const s=this.assist,n=Math.pow(D(e.throttle),Qe.throttleCurve);this.throttle=Ct(this.throttle,n,n>this.throttle?Qe.throttleUp:Qe.throttleDown,t);const i=D(e.brake);this.brake=Ct(this.brake,i,i>this.brake?Qe.brakeUp:Qe.brakeDown,t),this.handbrake=D(e.handbrake||0);const o=Math.abs(this.speed);if(e.analogue){const V=H.padRateLimit/H.maxAngle*t,dt=K(e.steer,-1,1);this.steer+=K(dt-this.steer,-V,V)}else{const V=K(e.steer,-1,1);if(V===0||Math.sign(V)!==Math.sign(this.steer)){const dt=H.returnRate*t;if(this.steer+=K(-this.steer,-dt,dt),V!==0){const ee=(H.buildBase+H.buildBonus/(1+Math.pow(o/H.buildFalloff,2)))*t;this.steer+=K(V-this.steer,-ee,ee)}}else{const dt=(H.buildBase+H.buildBonus/(1+Math.pow(o/H.buildFalloff,2)))*t;this.steer+=K(V-this.steer,-dt,dt)}}this.steer=K(this.steer,-1,1);const r=Math.cos(this.yaw),c=Math.sin(this.yaw);let l=this.vz*r+this.vx*c,h=this.vx*r-this.vz*c;this.speed=l;const u=Math.hypot(l,h);this.slip=u>.6?Math.atan2(h,Math.abs(l)+.001):0;let d=this.steer*this.maxSteerAngle(!!e.attack);const f=s.counterSteer*(e.analogue?he.csGamepad:he.csKeyboard)*1.18;if(f>0&&Math.abs(this.slip)>he.csMinSlip&&u>he.csMinSpeed){const V=K(this.slip*f,-.75*this.maxSteerAngle(),he.csClamp*this.maxSteerAngle());this._csState=Ct(this._csState,V,1/he.csLag,t)}else this._csState=Ct(this._csState,0,1/he.csLag,t);d=K(d+this._csState,-this.maxSteerAngle()*1.35,this.maxSteerAngle()*1.35),this.steerAngle=d;const p=this.terrain?this.terrain.surface(this.x,this.z):null,m=p?p.y:0;this.surfaceKind=p?p.surfaceKind:"ground",this.gripScale=p?p.grip:1;const v=p?p.nx:0,g=p?Math.max(p.ny,.2):1,w=p?p.nz:0;this.slopeAngle=Math.acos(Math.min(1,g));const x=Math.cos(this.yaw),y=Math.sin(this.yaw),T=yt.gravity*g*(v*y+w*x),b=yt.gravity*g*(v*x-w*y),M=D((this.slopeAngle-.42)/.34);this.gripScale*=1-.85*M;const _=m+be.restLength,A=this.y-_>.06;this.onGround=!A;let L=yt.gravity;if(A){if(this._airTime+=t,s.airborne>0&&this._airTime>yt.extraDelay){const V=D((this._airTime-yt.extraDelay)/yt.extraRamp);L+=yt.gravity*I(yt.extraMin,yt.extraMax,V)*s.airborne}this.vy-=L*t}else{this._airTime=0;const V=K(_-this.y,-.22,be.travel),dt=be.stiffness*4*V/this.mass,ee=be.damping*4*-this.vy/this.mass;this.vy+=(dt+ee-L)*t,this.vy>2&&(this.vy=2)}this.y+=this.vy*t,this.y<_-be.travel&&(this.y=_-be.travel,this.vy<0&&(this.vy=0));const E=K(this.longAccel/yt.gravity,-1.2,1.2),k=K(this.latAccel/yt.gravity,-1.5,1.5);this._loadLong=Ct(this._loadLong,E,1/at.loadTauPitch,t),this._loadLat=Ct(this._loadLat,k,1/at.loadTauRoll,t);const R=this.mass*yt.gravity+(A?0:et.downforce*u*u),P=this.spec.cgHeight/this.wb;let W=R*(this.b/this.wb)-R*P*this._loadLong,U=R-W;W=Math.max(W,R*.08),U=Math.max(U,R*.08);const q=A?0:1,st=u>.5?Math.atan2(h+this.yawRate*this.a,Math.abs(l)+.001)-d:0,z=u>.5?Math.atan2(h-this.yawRate*this.b,Math.abs(l)+.001):0;if(this.throttle<.12&&Math.abs(this.latAccel)>et.liftoffMinLatG*yt.gravity&&this._liftoffTimer<=0&&(this._liftoffTimer=et.liftoffHold+et.liftoffRecover),this._liftoffTimer>0){this._liftoffTimer-=t;const V=this._liftoffTimer>et.liftoffRecover;this._liftoff=V?et.liftoffDrop:et.liftoffDrop*D(this._liftoffTimer/et.liftoffRecover)}else this._liftoff=0;this.handbrake>.01?this._hbRelease=0:this._hbRelease=D(this._hbRelease+t/Rt.handbrakeRecover);const O=1-Math.pow(1-this._hbRelease,3),j=I(Rt.handbrakeRearMu,1,this.handbrake>.01?0:O),it=1-et.speedFade*Math.min(u/et.speedFadeAt,1),tt=this.muCapAwd?et.awdCap:1e9,nt=Math.min(et.muLatFront,tt)*this.gripScale*it,gt=Math.min(et.muLatRear,tt)*this.gripScale*it*(1-this._liftoff)*j;let ht=-si(st,et.peakSlipFront)*nt*W*q,Pt=-si(z,et.peakSlipRear)*gt*U*q;const Q=this.spec,Nt=Q.ratios[this.gear-1]*Q.finalDrive,Ht=l/Q.wheelRadius;let $e=Math.abs(Ht)*Nt*(60/ts);if(this.rpm=K(Math.max($e,Bt.idleRpm),Bt.idleRpm,Q.redline*1.02),this._shiftTimer>0&&(this._shiftTimer-=t),this._shiftHold>0&&(this._shiftHold-=t),s.autoGears&&this._shiftTimer<=0&&this._shiftHold<=0&&!this.reverse){const V=Jo(Bt.upshiftAtThrottle,this.throttle)*Q.redline;if(this.throttle>.06&&this.rpm>V&&this.gear<Q.ratios.length)this.gear++,this._shiftTimer=Bt.shiftTimeAuto,this._shiftHold=.5;else if(this.gear>1){const dt=Q.ratios[this.gear-2]*Q.finalDrive,ee=Math.abs(Ht)*dt*(60/ts),ys=this.rpm<Bt.idleRpm+Bt.downshiftHysteresis*.9,sn=this.throttle<.05&&ee<Q.redline*.7;ee<Q.redline*.92&&(ys||sn)&&(this.gear--,this._shiftTimer=Bt.shiftTimeAuto,this._shiftHold=.5)}}const qe=this._shiftTimer>0?Bt.shiftTorqueCut:1,je=D(this.rpm/Q.redline),Ve=this.rpm>=Q.redline?.15:1;let F=Q.peakTorque*Jo(fh,je)*this.throttle*qe*Ve*Nt/Q.wheelRadius*(1-Bt.driveLoss);!e.auto&&Math.abs(l)<.6&&this.brake>.35&&this.throttle<.05?this.reverse=!0:this.throttle>.15&&l>-3&&(this.reverse=!1),this.reverse&&(F=-Math.max(Math.abs(F),this.brake*2600)*.5);const B=Q.drive==="awd"?R:U,ut=et.muLongPeak*this.gripScale*B;s.tcs>0&&Math.abs(F)>ut&&(F-=Math.sign(F)*(Math.abs(F)-ut)*s.tcs);const Ee=ut*1.15;Math.abs(F)>Ee&&(F=Math.sign(F)*Ee);const bs=Q.topSpeed/3.6;l>bs-4.2&&(F*=D((bs-l)/4.2));const we=ut>1?K(F/ut,-3,3)*et.peakSlipRatio:0;let Wt=0;if(this.brake>.001&&u>.2){I(Rt.splitFront,Rt.splitFrontDive,D(-this._loadLong));let V=Rt.torque*this.brake*s.brakeMul;if(s.abs>0){const ee=V/Q.wheelRadius,ys=et.muLongPeak*this.gripScale*R;if(ee>ys){this._absPhase+=t*Rt.absHz*ts;const sn=1-Rt.absRelease*(.5+.5*Math.sin(this._absPhase))*s.abs;V=Math.min(V,ys*Q.wheelRadius*1.02)*sn}}Wt=-Math.sign(l)*(V/Q.wheelRadius);const dt=D(1-s.abs)*D(this.brake*1.4-.5);dt>0&&(ht*=I(1,Rt.lockedLatFloor,dt))}this.handbrake>.01&&u>.2&&(Wt+=-Math.sign(l)*(Rt.handbrakeTorque*this.handbrake/Q.wheelRadius));const Ye=(F+Wt)*q,tn=et.muLongPeak*this.gripScale*R,zt=Math.pow(Math.min(Math.abs(Ye)/Math.max(tn,1),1),et.ellipseExp),kt=Math.pow(Math.max(1-zt,.04),1/et.ellipseExp);ht*=kt,Pt*=kt;const ae=.5*1.225*Q.cdA*l*Math.abs(l),re=p?p.onRoad:1,Yn=I(.145,.014,D(re))*this.mass*yt.gravity*Math.sign(l)+I(9.5,1.4,D(re))*l,da=Math.max(0,1-this.throttle*4),Xn=this._shiftTimer>0?0:da*95*(.3+.7*je)*(Nt/Q.wheelRadius)*Math.sign(l)*q;if(q&&re<.6){const V=1-re,dt=ei(this.x*.31,this.z*.31)*.6+ei(this.x*1.13+11.7,this.z*1.13-4.2)*.4;this.vy+=dt*V*Math.min(u,24)*.055*t*60,ht*=1-.34*V,Pt*=1-.28*V,this.rough=V}else this.rough=0;const fa=I(27.8,200,D(re*1.4));q&&l>fa&&(F=Math.min(F,0));const Zn=Ye-ae-Yn-Xn;this.forces.drive=F,this.forces.brake=Wt,this.forces.contact=q,this.forces.traction=ut,this.forces.drag=ae,this.forces.rr=Yn,this.forces.engBrake=Xn,this.forces.net=Zn,this.forces.gear=this.gear,this.forces.ratio=Nt,this.forces.latAvail=kt;const pa=(ht*Math.cos(d)+Pt)*1,Jn=Zn/this.mass+this.yawRate*h+T*q,Qn=pa/this.mass-this.yawRate*l+b*q;l+=Jn*t,h+=Qn*t;let en=ht*Math.cos(d)*this.a-Pt*this.b;if(s.stability>0&&u>3){const V=l/Math.max(this.wb,.1)*Math.tan(d);en-=(this.yawRate-V)*this.izz*he.stabilityYawGain*s.stability}const to=Math.abs(this.slip);if(to>H.driftLow){const V=to>H.spinAngle?H.spinYawDamp:H.driftYawDamp;en-=this.yawRate*this.izz*V}this.handbrake>.01&&(this.yawRate=K(this.yawRate,-Rt.handbrakeYawCap,Rt.handbrakeYawCap)),this.yawRate+=en/this.izz*t*q;const eo=(nt*W+gt*U)/this.mass/Math.max(u,4)*1.35,so=Math.abs(this.yawRate);if(q&&so>eo){const V=1-Math.exp(-7.5*t);this.yawRate-=Math.sign(this.yawRate)*(so-eo)*V}const ma=I(H.trailPeak,H.trailPostPeak,D(Math.abs(st)/et.peakSlipFront-1));this.yawRate-=this.yawRate*H.satDamping*H.satGain*ma*t,u<.25&&this.throttle<.02&&Math.abs(T)<.55&&(l*=.9,h*=.9,this.yawRate*=.85),this.yaw+=this.yawRate*t,this.yaw>Math.PI?this.yaw-=ts:this.yaw<-Math.PI&&(this.yaw+=ts);const no=Math.cos(this.yaw),oo=Math.sin(this.yaw);this.vz=l*no-h*oo,this.vx=l*oo+h*no,this.x+=this.vx*t,this.z+=this.vz*t,this.longAccel=Jn,this.latAccel=Qn,this.speed=l;const va=K(-this._loadLat*this.spec.rollPerG,-at.rollClamp,at.rollClamp),ga=K(this._loadLong>0?-this._loadLong*at.squatPerG:-this._loadLong*at.divePerG,-at.pitchClamp,at.pitchClamp),wa=(va-this.roll)*at.rollOmega*at.rollOmega-this._rollV*2*at.rollZeta*at.rollOmega;this._rollV=K(this._rollV+wa*t,-at.rollRate,at.rollRate),this.roll+=this._rollV*t;const xa=(ga-this.pitch)*at.pitchOmega*at.pitchOmega-this._pitchV*2*at.pitchZeta*at.pitchOmega;this._pitchV=K(this._pitchV+xa*t,-at.pitchRate,at.pitchRate),this.pitch+=this._pitchV*t,this.limit=D(Math.max(Math.abs(st)/et.peakSlipFront,Math.abs(z)/et.peakSlipRear,Math.abs(we)/et.peakSlipRatio)),this.wheelSpin+=l/Q.wheelRadius*t,this.wheels[0].slipAngle=st,this.wheels[1].slipAngle=st,this.wheels[2].slipAngle=z,this.wheels[3].slipAngle=z,this.wheels[0].load=this.wheels[1].load=W*.5,this.wheels[2].load=this.wheels[3].load=U*.5}get kph(){return Math.abs(this.speed)*3.6}groundTilt(){if(!this.terrain)return{pitch:0,roll:0};const t=Math.cos(this.yaw),e=Math.sin(this.yaw),s=this.track*.5,n=this.x+e*this.a,i=this.z+t*this.a,o=this.x-e*this.b,r=this.z-t*this.b,c=this.terrain.height(n,i),l=this.terrain.height(o,r),h=this.terrain.height(this.x-t*s,this.z+e*s),u=this.terrain.height(this.x+t*s,this.z-e*s);return{pitch:Math.atan2(c-l,this.wb),roll:Math.atan2(u-h,this.track)}}}const ni={steerLeft:["KeyA","ArrowLeft"],steerRight:["KeyD","ArrowRight"],throttle:["KeyW","ArrowUp"],brake:["KeyS","ArrowDown"],handbrake:["Space"],shiftUp:["KeyE","ShiftRight"],shiftDown:["KeyQ"],camera:["KeyC"],reset:["KeyR","KeyT"],reverse:["KeyB"],nextCar:["KeyV"],radio:["KeyN"],autodrive:["KeyG"],horn:["KeyH"],fine:["ShiftLeft"],attack:["ControlLeft"]};class Sh{constructor(t=window){this.keys=new Set,this.pressed=new Set,this.analogue=!1,this.padIndex=null,this._lastDevice="keyboard",this._deviceSince=0,this.state={steer:0,throttle:0,brake:0,handbrake:0,analogue:!1,fine:!1,attack:!1},this._onDown=e=>{e.repeat||(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.code)&&e.preventDefault(),this.keys.add(e.code),this.pressed.add(e.code))},this._onUp=e=>this.keys.delete(e.code),this._onBlur=()=>this.keys.clear(),t.addEventListener("keydown",this._onDown,{passive:!1}),t.addEventListener("keyup",this._onUp),t.addEventListener("blur",this._onBlur),t.addEventListener("gamepadconnected",e=>{this.padIndex=e.gamepad.index}),t.addEventListener("gamepaddisconnected",()=>{this.padIndex=null}),this._target=t,this.touch={steer:0,throttle:0,brake:0,active:!1}}tapped(t){const e=ni[t]||[];for(const s of e)if(this.pressed.has(s))return!0;return!1}held(t){const e=ni[t]||[];for(const s of e)if(this.keys.has(s))return!0;return!1}poll(){const t=this.state;let e=(this.held("steerLeft")?1:0)-(this.held("steerRight")?1:0),s=this.held("throttle")?1:0,n=this.held("brake")?1:0,i=this.held("handbrake")?1:0,o=0,r=0,c=0,l=0,h=!1;const u=navigator.getGamepads?navigator.getGamepads():[];for(const d of u){if(!d||!d.connected)continue;h=!0;const f=-(d.axes[0]||0),p=Math.abs(f);if(p>H.padDeadzone){const m=D((p-H.padDeadzone)/(H.padSaturation-H.padDeadzone));o=Math.sign(f)*Math.pow(m,H.padCurve)}r=d.buttons[7]?d.buttons[7].value:0,c=d.buttons[6]?d.buttons[6].value:0,l=d.buttons[0]&&d.buttons[0].pressed?1:0;break}return t.steer=Math.abs(o)>Math.abs(e)?o:e,this.touch.active&&Math.abs(this.touch.steer)>Math.abs(t.steer)&&(t.steer=this.touch.steer),t.throttle=Math.max(s,r,this.touch.throttle),t.brake=Math.max(n,c,this.touch.brake),t.handbrake=Math.max(i,l),t.analogue=h&&Math.abs(o)>=Math.abs(e)&&Math.abs(o)>.001,this.touch.active&&(t.analogue=!0),t.fine=this.held("fine"),t.attack=this.held("attack"),t.fine&&(t.throttle=Math.min(t.throttle,.45),t.steer*=.6),t.attack&&(t.steer=K(t.steer*1.25,-1,1)),t}endFrame(){this.pressed.clear()}attachTouch(t){const e=()=>t.getBoundingClientRect(),s=n=>{const i=e();let o=0,r=0,c=0,l=!1;for(const h of n.touches){l=!0;const u=(h.clientX-i.left)/i.width,d=(h.clientY-i.top)/i.height;u<.5?o=K(-(u/.5-.5)*2.4,-1,1):d>.55?c=1:r=1}this.touch.active=l,this.touch.steer=l?o:0,this.touch.throttle=r,this.touch.brake=c,l&&n.preventDefault()};t.addEventListener("touchstart",s,{passive:!1}),t.addEventListener("touchmove",s,{passive:!1}),t.addEventListener("touchend",s,{passive:!1}),t.addEventListener("touchcancel",s,{passive:!1})}dispose(){this._target.removeEventListener("keydown",this._onDown),this._target.removeEventListener("keyup",this._onUp),this._target.removeEventListener("blur",this._onBlur)}}const wn=["sport","hood"];class Ah{constructor(t,{mode:e="sport"}={}){this.camera=t,this.mode=e,this.yaw=0,this.px=0,this.py=0,this.pz=0,this.vxs=0,this.vys=0,this.vzs=0,this.fov=zs.sport.fov,this.pitch=0,this._kick=0,this._shakeT=0,this._first=!0,this._lookX=0,this._lookY=0,this._lookZ=0}cycle(){return this.mode=wn[(wn.indexOf(this.mode)+1)%wn.length],this.mode}update(t,e,s){const n=zs[this.mode]||zs.sport,i=Math.abs(t.speed),o=D(i/(250/3.6));let r=t.yaw;if(n.velocityBlend>0&&i>3){const M=Math.atan2(t.vx,t.vz);r=t.yaw+Us(t.yaw,M)*n.velocityBlend}if(n.lookIntoCorner){const M=K(n.lookIntoCorner*t.steer*t.maxSteerAngle()*4,-n.lookIntoClamp,n.lookIntoClamp);r+=M}this.yaw=this._first?r:zr(this.yaw,r,1/n.yawTau,e);const c=n.behind+(n.stretch||0)*o,l=n.above+(n.rise||0)*o,h=Math.sin(this.yaw),u=Math.cos(this.yaw);let d=t.x-h*c,f=t.z-u*c,p=t.y+l;if(this._first)this.px=d,this.py=p,this.pz=f,this._first=!1;else if(n.springOmega){const M=n.springOmega,_=n.springZeta,S=(A,L,E)=>{const k=(E-A)*M*M-L*2*_*M,R=L+k*e;return[A+R*e,R]};[this.px,this.vxs]=S(this.px,this.vxs,d),[this.py,this.vys]=S(this.py,this.vys,p),[this.pz,this.vzs]=S(this.pz,this.vzs,f)}else this.px=Ct(this.px,d,6.5,e),this.py=Ct(this.py,p,6.5,e),this.pz=Ct(this.pz,f,6.5,e);if(n.lateralClamp){const M=t.x-this.px,_=t.z-this.pz,S=M*u-_*h,A=n.lateralClamp*c*2;if(Math.abs(S)>A*.75){const L=(Math.abs(S)-A*.75)/(A*.25),E=D(L),k=E*E*(3-2*E),R=Math.sign(S)*(Math.abs(S)-A*.75)*k;this.px+=u*R,this.pz-=h*R}}if(s){let M=s(this.px,this.pz);for(let _=1;_<=4;_++){const S=_/5,A=this.px+(t.x-this.px)*S,L=this.pz+(t.z-this.pz)*S,E=s(A,L),k=E+1.2-(t.y+n.above-E)*0;k>M&&(M=k)}this.py<M+1.2&&(this.py=M+1.2)}const m=t.x+Math.sin(t.yaw)*n.lookAhead,v=t.z+Math.cos(t.yaw)*n.lookAhead,g=t.y+n.lookHeight;this._lookX=Ct(this._lookX||m,m,14,e),this._lookY=Ct(this._lookY||g,g,10,e),this._lookZ=Ct(this._lookZ||v,v,14,e);let w=n.fov;n.fovGain&&(w=n.fov+n.fovGain*Math.pow(o,n.fovPow),t.longAccel>.5*9.81&&(this._kick=5),this._kick=Ct(this._kick,0,1/zs.sport.fovKickTau,e),w+=this._kick);const x=12*e;this.fov+=K(w-this.fov,-x,x);let y=0,T=0;if(n.shake&&i>n.shakeFrom){this._shakeT+=e*n.shakeHz*Math.PI*2;const M=n.shake*D((i-n.shakeFrom)/30)*(.6+.8*t.limit);y=Math.sin(this._shakeT)*M,T=Math.sin(this._shakeT*1.37+1.1)*M*.6}const b=this.camera;return b.position.set(this.px,this.py,this.pz),b.up.set(Math.sin(y)*.06,1,0),b.lookAt(this._lookX+y*8,this._lookY+T*8,this._lookZ),Math.abs(b.fov-this.fov)>.01&&(b.fov=this.fov,b.updateProjectionMatrix()),o}reset(){this._first=!0,this.vxs=this.vys=this.vzs=0}}const oi=42;class kh{constructor({cruise:t=16}={}){this.on=!1,this.cruise=t,this.lastReason="",this._lostFor=0,this._feed=0}toggle(t){return this.on=!this.on,this._lostFor=0,this.on&&(this.cruise=Math.max(11,Math.min(Math.abs(t?.speed||0)||16,22))),this.on}off(t=""){return this.on?(this.on=!1,this.lastReason=t,!0):!1}update(t,e,s){if(!this.on)return null;if(Math.abs(e.steer)>.12||e.brake>.15||e.throttle>.5||e.handbrake>.1)return this.off("you took over"),null;const n=t.terrain;if(!n)return null;const i=n.roads.query(t.x,t.z);if(!isFinite(i.d)||i.d>i.width*2.2+14)return this._lostFor+=s,this._lostFor>4&&this.off("lost the road"),{steer:0,throttle:0,brake:.35,handbrake:0,analogue:!0,auto:!0};this._lostFor=0;let o=i.tx,r=i.tz;Math.sin(t.yaw)*o+Math.cos(t.yaw)*r<0&&(o=-o,r=-r);const c=(t.x-i.qx)*r-(t.z-i.qz)*o;let l=Math.atan2(o,r)-t.yaw;for(;l>Math.PI;)l-=Math.PI*2;for(;l<-Math.PI;)l+=Math.PI*2;const h=Math.max(Math.abs(t.speed),6),u=Math.atan2(3.2*c,h),d=K((l*1.5-u)*2.1+this._feed,-1,1),f=t.x+Math.sin(t.yaw)*oi,p=t.z+Math.cos(t.yaw)*oi,m=n.roads.query(f,p);let v=0,g=0;if(isFinite(m.d)&&m.d<m.width*1.6){let M=m.tx,_=m.tz;M*o+_*r<0&&(M=-M,_=-_);let S=Math.atan2(M,_)-Math.atan2(o,r);for(;S>Math.PI;)S-=Math.PI*2;for(;S<-Math.PI;)S+=Math.PI*2;Math.abs(S)<Math.PI*.5&&(g=S,v=Math.abs(S))}this._feed=K(g*.55,-.45,.45);const w=I(this.cruise,8,D(v/.55)),x=Math.abs(t.speed),y=w-x,T=y<=0?0:y>w*.25?D(.45+y/12):D(y/5),b=x>w+4?D((x-w-4)/8)*.5:0;return{steer:d,throttle:T,brake:b,handbrake:0,analogue:!0,auto:!0}}}const xn=100,es=56,Rh=1.35,Eh=`
in float aT;      // 0 at the car, 1 at the tail
in float aSide;   // -1 or +1 across the ribbon
out float vT;
out float vSide;
out vec3 vWorld;
void main(){
  vT = aT;
  vSide = aSide;
  vWorld = position;
  gl_Position = projectionMatrix * viewMatrix * vec4(position, 1.0);
}
`,Ch=`
in float vT;
in float vSide;
in vec3 vWorld;
out vec4 fragColor;

uniform float uDepth;   // 0 pale .. 1 deep — how long the streak is
uniform float uAlive;   // 1 while the streak runs, falls to 0 as it is reeled in
uniform float uBreak;   // 1 at the instant it broke, decaying — the red blip

void main(){
  // Pale sky blue to a deep ink blue. Both are in the game's own palette range so the trail
  // never looks like a UI element that wandered into the scene.
  vec3 pale = vec3(0.66, 0.82, 0.94);
  vec3 deep = vec3(0.10, 0.26, 0.62);
  vec3 col = mix(pale, deep, uDepth);

  // The break flash. One red pulse, brightest at the car end, so it reads as something
  // letting go rather than the whole world changing colour.
  col = mix(col, vec3(0.86, 0.22, 0.16), uBreak * (1.0 - vT * 0.6));

  // Soft edges across the ribbon and a fade towards the tail.
  float edge = 1.0 - abs(vSide);
  float a = smoothstep(0.0, 0.35, edge) * (1.0 - vT * vT) * uAlive;
  // A gentle glow while it is alive: the operator asked for things to "illumine a little bit"
  // when the streak is running.
  col += vec3(0.10, 0.16, 0.24) * uAlive * (1.0 - vT);

  if (a < 0.01) discard;
  fragColor = vec4(SAFE3(col), a * 0.72);
}
`;class zh{constructor({scene:t}){this.points=[],this.alive=0,this.breakFlash=0,this.depth=0;const e=es;this.pos=new Float32Array(e*2*3);const s=new Float32Array(e*2),n=new Float32Array(e*2);for(let r=0;r<e;r++)s[r*2]=s[r*2+1]=r/(e-1),n[r*2]=-1,n[r*2+1]=1;const i=new Uint16Array((e-1)*6);for(let r=0,c=0;r<e-1;r++){const l=r*2;i[c++]=l,i[c++]=l+2,i[c++]=l+1,i[c++]=l+1,i[c++]=l+2,i[c++]=l+3}const o=new Qt;o.setAttribute("position",new G(this.pos,3)),o.setAttribute("aT",new G(s,1)),o.setAttribute("aSide",new G(n,1)),o.setIndex(new G(i,1)),o.frustumCulled=!1,this.geometry=o,this.material=new pt({glslVersion:"300 es",uniforms:St({uDepth:{value:0},uAlive:{value:0},uBreak:{value:0}}),vertexShader:xt(Eh),fragmentShader:It(Ch),transparent:!0,depthWrite:!1,side:Jt}),this.mesh=new bt(o,this.material),this.mesh.frustumCulled=!1,this.mesh.name="streakTrail",this.mesh.renderOrder=6,t.add(this.mesh),this._prevDistance=0}update(t,e,s){const n=s.distance||0;this._prevDistance>xn&&n<this._prevDistance*.5&&(this.breakFlash=1),this._prevDistance=n,this.breakFlash=Math.max(0,this.breakFlash-t*1.6);const i=n>xn;this.alive=i?Math.min(1,this.alive+t*2.2):Math.max(0,this.alive-t*.9);const o=D((n-xn)/900);if(this.depth=D(Math.log10(1+n/220)/Math.log10(1+6e4/220)),this.material.uniforms.uAlive.value=this.alive,this.material.uniforms.uDepth.value=this.depth,this.material.uniforms.uBreak.value=this.breakFlash,this.alive<.005){this.mesh.visible=!1;return}this.mesh.visible=!0;const r=2.2,c=e.x-Math.sin(e.yaw)*r,l=e.z-Math.cos(e.yaw)*r,h=e.y+.35;if(!this.points.length)for(let f=0;f<es;f++)this.points.push({x:c,y:h,z:l});this.points[0].x=c,this.points[0].y=h,this.points[0].z=l;const u=Rh*(.35+.65*o);for(let f=1;f<es;f++){const p=this.points[f],m=this.points[f-1];let v=p.x-m.x,g=p.y-m.y,w=p.z-m.z;const x=Math.hypot(v,g,w)||1e-5,y=(x-u)/x;p.x-=v*y,p.y-=g*y,p.z-=w*y,p.y=I(p.y,m.y-.06,Math.min(1,t*6))}const d=I(.1,.34,o);for(let f=0;f<es;f++){const p=this.points[f],m=this.points[Math.min(f+1,es-1)],v=this.points[Math.max(f-1,0)];let g=m.x-v.x,w=m.z-v.z;const x=Math.hypot(g,w)||1;g/=x,w/=x;const y=w*d,T=-g*d,b=f*6;this.pos[b]=p.x-y,this.pos[b+1]=p.y,this.pos[b+2]=p.z-T,this.pos[b+3]=p.x+y,this.pos[b+4]=p.y,this.pos[b+5]=p.z+T}this.geometry.attributes.position.needsUpdate=!0}reset(t){const s=t.x-Math.sin(t.yaw)*2.2,n=t.z-Math.cos(t.yaw)*2.2;for(const i of this.points)i.x=s,i.y=t.y+.35,i.z=n}dispose(){this.geometry.dispose(),this.material.dispose()}}const Lh=.45,Ls=.55,Dh=8,ss=[{at:0,mul:1,label:null},{at:1e3,mul:1.25,label:"a kilometre without leaving the road"},{at:2500,mul:1.5,label:"two and a half"},{at:5e3,mul:2,label:"five kilometres. settling in"},{at:1e4,mul:2.75,label:"ten. the road is yours"},{at:2e4,mul:3.5,label:"twenty kilometres"},{at:4e4,mul:4.5,label:"forty. still going"},{at:8e4,mul:6,label:"eighty kilometres without a wheel off"}];function Fh(a){const t=a*3.6;return t<30?0:.35+.85*Math.pow(D((t-30)/220),.72)}class Ih{constructor({storageKey:t="wanderoad.streak.v1"}={}){this.storageKey=t,this.distance=0,this.score=0,this.total=0,this.best=0,this.bestScore=0,this.multiplier=1,this.onRoad=!1,this.tier=0,this._off=0,this._announced=0,this._events=[],this._lastBreakAt=0,this.load()}load(){try{const t=localStorage.getItem(this.storageKey);if(!t)return;const e=JSON.parse(t);this.total=+e.total||0,this.best=+e.best||0,this.bestScore=+e.bestScore||0}catch{}}save(){try{localStorage.setItem(this.storageKey,JSON.stringify({total:this.total,best:this.best,bestScore:this.bestScore}))}catch{}}get state(){return{distance:this.distance,km:this.distance/1e3,score:this.score,total:this.total,best:this.best,bestScore:this.bestScore,multiplier:this.multiplier,onRoad:this.onRoad,grace:this._off>0&&this._off<Ls,graceLeft:Math.max(0,Ls-this._off),tier:this.tier}}drain(){return this._events.length?this._events.shift():null}update(t,e,s){const n=Math.abs(e.speed||0),i=(s?s.onRoad:0)>=Lh&&e.onGround!==!1;if(this.onRoad=i,!i){this._off+=t,e.onGround===!1&&(this._off=Math.min(this._off,Ls*.4)),this._off>=Ls&&(this.distance>250&&this._events.push({kind:"break",distance:this.distance,score:this.score}),this._commit());return}if(this._off=0,n<Dh)return;const o=n*t;this.distance+=o;let r=0;for(let d=ss.length-1;d>=0;d--)if(this.distance>=ss[d].at){r=d;break}this.tier=r;const c=ss[r],l=ss[Math.min(r+1,ss.length-1)],h=Math.max(l.at-c.at,1),u=D((this.distance-c.at)/h);this.multiplier=I(c.mul,l.mul,u*.6),r>this._announced&&(this._announced=r,c.label&&this._events.push({kind:"milestone",text:c.label,distance:this.distance})),this.score+=o*Fh(n)*this.multiplier*.1}_commit(){this.distance>this.best&&(this.best=this.distance),this.score>this.bestScore&&(this.bestScore=this.score),this.total+=this.score,this.save(),this.distance=0,this.score=0,this.multiplier=1,this.tier=0,this._announced=0,this._off=0}flush(){this.distance>0?this._commit():this.save()}}function Ph(a){return a<1e3?String(Math.floor(a)):a<1e5?(a/1e3).toFixed(1)+"k":Math.round(a/1e3)+"k"}function ye(a){return a<1e3?`${Math.round(a)} m`:`${(a/1e3).toFixed(a<1e4?2:1)} km`}const Nh={cruiser:{label:"Cruiser",blurb:"Calm and planted. Full stick is 0.7 g, the camera never moves in a hurry. This is the cozy default.",comfortG:7,assist:"cruise",camera:"cruise",rearGrip:1.04,buildRate:1.6,tier:"gt",car:"estate"},road:{label:"Road",blurb:"The default. A fast road car: 0.96 g at full stick, sport aids, the chase camera looks into the corner.",comfortG:9.4,assist:"sport",camera:"sport",rearGrip:1,buildRate:2,tier:"sports",car:"coupe"},sharp:{label:"Sharp",blurb:"More lock, faster hands. 1.25 g at full stick and a quicker steering ramp — quick, still not twitchy.",comfortG:12.2,assist:"sport",camera:"sport",rearGrip:.98,buildRate:3.2,tier:"sports",car:"rally"},drift:{label:"Drift",blurb:"Loose rear end and a lot of lock. Made for holding a slide, not for lap times.",comfortG:13.5,assist:"off",camera:"sport",rearGrip:.86,buildRate:3.6,tier:"sports",car:"sedan"},sim:{label:"Raw",blurb:"No assists at all, no comfort limit — the full 40° rack, tapered only by speed. Hard.",comfortG:40,assist:"hardcore",camera:"sport",rearGrip:1,buildRate:4,tier:"sports",car:"coupe"},hyper:{label:"Hyper",blurb:"All-wheel drive, 800 hp, 340 km/h. Planted at speed, and quick enough to need the calm camera.",comfortG:10.5,assist:"sport",camera:"sport",rearGrip:1.02,buildRate:2.2,tier:"hyper",car:"patrol"}},Ae={meadow:{label:"Meadow",blurb:"The pen’s own valley. Soft rolling hills, wide sightlines, nothing you cannot drive over.",amp:.8,wave:1.25,bias:[2.2,1,.35,.3,.8]},rolling:{label:"Rolling",blurb:"The default mix. Meadow and steppe with hills and the occasional mountain on the horizon.",amp:1,wave:1,bias:[1,1,1,1,1]},alpine:{label:"Alpine",blurb:"Mountains close in. Switchbacks, cuttings and long climbs — the most dramatic and the least forgiving.",amp:1.35,wave:.9,bias:[.6,.5,3,.2,.5]},plains:{label:"Plains",blurb:"Almost flat. Kilometres of straight road under a huge sky — the best place to feel top speed.",amp:.45,wave:1.6,bias:[.8,3,.15,1.2,.7]},dunes:{label:"Dunes",blurb:"Rose and ochre sand sea. Loose grip, long crests, the road half-buried.",amp:.9,wave:1.1,bias:[.3,.9,.2,3.5,.2]},marsh:{label:"Wetland",blurb:"Flooded reed flats under standing mist. Dead flat, causeways and mirrors.",amp:.7,wave:1.2,bias:[.7,.3,.2,.1,3.5]}};function Oh(a){const t=Ae[a]||Ae.rolling;Yt.__base||(Yt.__base=Yt.map(s=>({...s})));const e=Yt.__base;for(let s=0;s<Yt.length;s++)Yt[s].amp=e[s].amp*t.amp*(t.bias[s]>1,1),Yt[s].wave=e[s].wave*t.wave;return t}function Bh(a){return(Ae[a]||Ae.rolling).bias}function Gh(a=location.search){const t=new URLSearchParams(a),e=Nh[t.get("feel")]?t.get("feel"):"road",s=Uh(t.get("terrain"))?t.get("terrain"):"rolling";return{feel:e,terrain:s,debug:t.has("debug"),offline:t.has("offline"),cheat:t.has("cheat")}}const Uh=a=>!!Ae[a],Hh=.02,Wh=4;class Kh{constructor({cell:t=64}={}){this.cell=t,this.grid=new Map,this.byChunk=new Map,this.lastHit=null}_key(t,e){return`${Math.floor(t/this.cell)},${Math.floor(e/this.cell)}`}addChunk(t,e){if(this.byChunk.has(t)&&this.removeChunk(t),!(!e||!e.length)){this.byChunk.set(t,e);for(const s of e){const n=this._key(s.x,s.z);let i=this.grid.get(n);i||(i=[],this.grid.set(n,i)),i.push(s)}}}removeChunk(t){const e=this.byChunk.get(t);if(e){for(const s of e){const n=this._key(s.x,s.z),i=this.grid.get(n);if(!i)continue;const o=i.indexOf(s);o>=0&&i.splice(o,1),i.length||this.grid.delete(n)}this.byChunk.delete(t)}}clear(){this.grid.clear(),this.byChunk.clear()}get count(){let t=0;for(const e of this.byChunk.values())t+=e.length;return t}resolve(t,e=1.05,s=1/60){const n=Math.floor(t.x/this.cell),i=Math.floor(t.z/this.cell);let o=null;for(let r=-1;r<=1;r++)for(let c=-1;c<=1;c++){const l=this.grid.get(`${n+c},${i+r}`);if(l)for(const h of l){const u=t.x-h.x,d=t.z-h.z,f=h.r+e,p=u*u+d*d;if(p>=f*f||h.h&&t.y-.4>h.y+h.h)continue;const m=Math.sqrt(p)||1e-4,v=f-m;if(v<Hh)continue;const g=u/m,w=d/m;t.x+=g*v,t.z+=w*v;const x=t.vx*g+t.vz*w;if(x<0){const y=Math.hypot(t.vx,t.vz),T=t.vx-x*g,b=t.vz-x*w,M=D(-x/Math.max(y,.001)),_=h.kind==="rock"?.18:.06,S=1-.55*M;t.vx=T*S-x*g*_,t.vz=b*S-x*w*_,t.yawRate*=1-.6*M,y>Wh&&(!o||M*y>o.severity*o.speed)&&(o={kind:h.kind,speed:y,severity:M,x:h.x,z:h.z})}}}return this.lastHit=o,o}}function $h(a,t){const e=[];if(!a)return e;const s=(n,i,o,r)=>{if(n)for(const c of n)e.push({x:c.x,z:c.z,y:c.y!==void 0?c.y:0,r:o(c),h:r(c),kind:i})};return s(a.trees,"tree",n=>.28+.22*(n.scale||1),n=>6*(n.scale||1)),s(a.rocks,"rock",n=>.7*(n.scale||1),n=>1.6*(n.scale||1)),s(a.posts,"post",()=>.16,()=>1.6),e}class qh{constructor(){this.root=document.getElementById("hud"),this.kph=document.getElementById("kph"),this.gear=document.getElementById("gear"),this.biome=document.getElementById("biome"),this.coords=document.getElementById("coords"),this.players=document.getElementById("players"),this.toast=document.getElementById("toast"),this.streakEl=document.createElement("div"),this.streakEl.id="streak",this.streakEl.innerHTML='<span id="streakKm">—</span><span id="streakMul"></span><span id="streakPts"></span>',this.bar=document.createElement("div"),this.bar.id="unlockBar",this.bar.innerHTML='<div class="fill"></div><div class="lbl"><span class="run"></span><span class="next"></span></div>',this.root.appendChild(this.bar),this.barFill=this.bar.querySelector(".fill"),this.barRun=this.bar.querySelector(".run"),this.barNext=this.bar.querySelector(".next"),this._blip=0,this.root.appendChild(this.streakEl),this.streakKm=this.streakEl.querySelector("#streakKm"),this.streakMul=this.streakEl.querySelector("#streakMul"),this.streakPts=this.streakEl.querySelector("#streakPts"),this._toastT=0,this._lastGear=null,this._lastBiome=-1,this._shownKm=0}say(t,e=3.6){this.toast.textContent=t,this.toast.classList.add("show"),this._toastT=e}update(t,{car:e,streak:s,surface:n,remotes:i,netState:o}){const r=Math.round(e.kph);this.kph.textContent=r;const c=e.reverse?"R":Math.abs(e.speed)<.6?"N":String(e.gear);c!==this._lastGear&&(this.gear.textContent=c,this._lastGear=c),n&&n.dominant!==this._lastBiome&&(this._lastBiome=n.dominant,this.biome.textContent=Cn[n.dominant],this.say(Cn[n.dominant],2.8)),this.coords.textContent=`${Math.round(e.x)}, ${Math.round(e.z)}`;const l=s.state;l.distance>0?(this.streakEl.classList.add("live"),this.streakEl.classList.toggle("grace",l.grace),this._shownKm+=(l.km-this._shownKm)*Math.min(1,t*9),this.streakKm.textContent=ye(this._shownKm*1e3),this.streakMul.textContent=l.multiplier>1.02?`×${l.multiplier.toFixed(2)}`:"",this.streakPts.textContent=l.score>5?Ph(l.score):""):(this.streakEl.classList.remove("live","grace"),this._shownKm=0,this.streakKm.textContent=l.best>0?`best ${ye(l.best)}`:"",this.streakMul.textContent="",this.streakPts.textContent="");const h=mh(Math.max(l.best,l.distance)),u=l.distance>0;if(this.bar.classList.toggle("live",u),h){const f=D(Math.max(l.best,l.distance)/h.car.unlockAt);this.barFill.style.width=`${(f*100).toFixed(1)}%`,this.barRun.textContent=u?ye(l.distance):`best ${ye(l.best)}`,this.barNext.textContent=`${h.car.label} at ${ca(h.car.unlockAt)}`}else this.barFill.style.width="100%",this.barRun.textContent=u?ye(l.distance):`best ${ye(l.best)}`,this.barNext.textContent="every car unlocked";this._blip>0&&(this._blip-=t,this._blip<=0&&this.bar.classList.remove("broke"));const d=s.drain();if(d&&(d.kind==="milestone"?this.say(d.text,3.2):d.kind==="break"&&(this.say(`${ye(d.distance)} — streak ended`,3),this.bar.classList.add("broke"),this._blip=1.2),d.kind==="unlock"&&this.say(`${d.label} unlocked`,4)),i){const f=i.list?i.list():[];f.length?this.players.innerHTML=f.slice(0,6).map(p=>`<div>${jh(p.name)} <span class="dist">${Math.round(p.dist)} m</span></div>`).join(""):this.players.childNodes.length&&(this.players.innerHTML="")}o&&o!==this._lastNet&&(this._lastNet=o,this.root.dataset.net=o),this._toastT>0&&(this._toastT-=t,this._toastT<=0&&this.toast.classList.remove("show"))}}function jh(a){return String(a).replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[t])}const Vh=["Escape","KeyM"];class Yh{constructor(t){this.hooks=t,this.open=!1,this.current={car:"coupe",feel:"road",terrain:"rolling"};const e=this.root=document.createElement("div");e.id="menu",e.hidden=!0,e.innerHTML=`
      <div class="sheet">
        <h2>Garage</h2>
        <p class="hint">Escape or M to close · everything here is also a URL parameter</p>

        <h3>Car <small>each one drives differently — unlocked by your best streak</small></h3>
        <div class="row" data-group="car"></div>

        <h3>Land <small>reloads the world</small></h3>
        <div class="row" data-group="terrain"></div>

        <div class="foot">
          <button data-act="auto">Auto-drive</button>
          <button data-act="cheat">Unlock all</button>
          <button data-act="camera">Camera: —</button>
          <button data-act="reset">Put me back on the road (R)</button>
          <a class="btn" href="./previews/">All previews</a>
          <button data-act="close">Drive</button>
        </div>
      </div>`,document.body.appendChild(e),this._fillCars(),this._fill("terrain",Object.keys(Ae).map(s=>[s,Ae[s].label])),e.addEventListener("click",s=>this._onClick(s)),addEventListener("keydown",s=>{Vh.includes(s.code)&&(s.preventDefault(),this.toggle())})}_fillCars(){const t=this.hooks.bestStreak?this.hooks.bestStreak():0,e=this.root.querySelector('[data-group="car"]');e.innerHTML=ve.map(s=>{const n=ws(s,t);return`<button data-group="car" data-key="${s.id}" title="${s.blurb}"${n?"":` class="locked" data-unlock="${ca(s.unlockAt)}"`}>${s.label}</button>`}).join("")}_fill(t,e){const s=this.root.querySelector(`[data-group="${t}"]`);s.innerHTML=e.map(([n,i])=>`<button data-group="${t}" data-key="${n}">${i}</button>`).join("")}_mark(){for(const n of this.root.querySelectorAll("button[data-key]"))n.classList.toggle("on",this.current[n.dataset.group]===n.dataset.key);const t=this.root.querySelector('[data-act="camera"]');t&&this.hooks.camera&&(t.textContent=`Camera: ${this.hooks.camera()}`);const e=this.root.querySelector('[data-act="cheat"]');e&&(e.textContent=fs()?"Unlocks: all open":"Unlock all (testing)",e.classList.toggle("on",fs()));const s=this.root.querySelector('[data-act="auto"]');if(s&&this.hooks.isAuto){const n=this.hooks.isAuto();s.textContent=n?"Auto-drive: on (G)":"Auto-drive (G)",s.classList.toggle("on",n)}}async _onClick(t){const e=t.target.closest("button");if(!e)return;const{group:s,key:n,act:i}=e.dataset;if(i==="close")return this.hide();if(i==="reset")return this.hooks.onReset?.(),this.hide();if(i==="camera")return this.hooks.cycleCam?.(),this._mark();if(i==="cheat"){this.hooks.onCheat?.(!fs()),this._fillCars(),this._mark();return}if(i==="auto")return this.hooks.onAuto?.(),this._mark(),this.hide();if(s==="car"){const o=qs[n],r=this.hooks.bestStreak?this.hooks.bestStreak():0;if(o&&!ws(o,r))return;this.current.car=n,this._mark(),e.disabled=!0,await this.hooks.onCar?.(n),e.disabled=!1,this.hide()}else if(s==="feel")this.current.feel=n,this._mark(),this.hooks.onFeel?.(n),this.hide();else if(s==="terrain"){const o=new URLSearchParams(location.search);o.set("terrain",n),o.set("feel",this.current.feel),o.set("car",this.current.car),location.search=o.toString()}}setCurrent(t){Object.assign(this.current,t),this._mark()}show(){this._fillCars(),this.open=!0,this.root.hidden=!1,this._mark()}hide(){this.open=!1,this.root.hidden=!0}toggle(){this.open?this.hide():this.show()}}const Xh="modulepreload",Zh=function(a,t){return new URL(a,t).href},ii={},Jh=function(t,e,s){let n=Promise.resolve();if(e&&e.length>0){let o=function(h){return Promise.all(h.map(u=>Promise.resolve(u).then(d=>({status:"fulfilled",value:d}),d=>({status:"rejected",reason:d}))))};const r=document.getElementsByTagName("link"),c=document.querySelector("meta[property=csp-nonce]"),l=c?.nonce||c?.getAttribute("nonce");n=o(e.map(h=>{if(h=Zh(h,s),h in ii)return;ii[h]=!0;const u=h.endsWith(".css"),d=u?'[rel="stylesheet"]':"";if(!!s)for(let m=r.length-1;m>=0;m--){const v=r[m];if(v.href===h&&(!u||v.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${h}"]${d}`))return;const p=document.createElement("link");if(p.rel=u?"stylesheet":Xh,u||(p.as="script"),p.crossOrigin="",p.href=h,l&&p.setAttribute("nonce",l),document.head.appendChild(p),u)return new Promise((m,v)=>{p.addEventListener("load",m),p.addEventListener("error",()=>v(new Error(`Unable to preload CSS for ${h}`)))})}))}function i(o){const r=new Event("vite:preloadError",{cancelable:!0});if(r.payload=o,window.dispatchEvent(r),!r.defaultPrevented)throw o}return n.then(o=>{for(const r of o||[])r.status==="rejected"&&i(r.reason);return t().catch(i)})},Qh=new Uint32Array([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]),qt=(a,t)=>(a>>>t|a<<32-t)>>>0;function t0(a){if(typeof TextEncoder<"u")return new TextEncoder().encode(a);const t=[];for(let e=0;e<a.length;e++){const s=a.charCodeAt(e);s<128?t.push(s):s<2048?t.push(192|s>>6,128|s&63):t.push(224|s>>12,128|s>>6&63,128|s&63)}return new Uint8Array(t)}function la(a){const t=typeof a=="string"?t0(a):a,e=t.length,s=new Uint8Array((e+8>>6)+1<<6);s.set(t),s[e]=128;const n=new DataView(s.buffer);n.setUint32(s.length-8,Math.floor(e/536870912)),n.setUint32(s.length-4,e<<3>>>0);const i=new Uint32Array([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]),o=new Uint32Array(64);for(let c=0;c<s.length;c+=64){for(let g=0;g<16;g++)o[g]=n.getUint32(c+g*4);for(let g=16;g<64;g++){const w=o[g-15],x=o[g-2],y=(qt(w,7)^qt(w,18)^w>>>3)>>>0,T=(qt(x,17)^qt(x,19)^x>>>10)>>>0;o[g]=o[g-16]+y+o[g-7]+T>>>0}let l=i[0],h=i[1],u=i[2],d=i[3],f=i[4],p=i[5],m=i[6],v=i[7];for(let g=0;g<64;g++){const w=(qt(f,6)^qt(f,11)^qt(f,25))>>>0,x=(f&p^~f&m)>>>0,y=v+w+x+Qh[g]+o[g]>>>0,T=(qt(l,2)^qt(l,13)^qt(l,22))>>>0,b=(l&h^l&u^h&u)>>>0,M=T+b>>>0;v=m,m=p,p=f,f=d+y>>>0,d=u,u=h,h=l,l=y+M>>>0}i[0]=i[0]+l>>>0,i[1]=i[1]+h>>>0,i[2]=i[2]+u>>>0,i[3]=i[3]+d>>>0,i[4]=i[4]+f>>>0,i[5]=i[5]+p>>>0,i[6]=i[6]+m>>>0,i[7]=i[7]+v>>>0}let r="";for(let c=0;c<8;c++)r+=i[c].toString(16).padStart(8,"0");return r}const ai="wanderoad.secret",e0="wanderoad.name",s0="wanderoad.look",Nn=new Map;function jn(a){try{const t=globalThis.localStorage?.getItem(a);if(t!=null)return t}catch{}return Nn.has(a)?Nn.get(a):null}function n0(a,t){Nn.set(a,t);try{globalThis.localStorage?.setItem(a,t)}catch{}}function o0(){const a=new Uint8Array(32),t=globalThis.crypto;if(t&&typeof t.getRandomValues=="function")t.getRandomValues(a);else{const s=`${Date.now()}:${globalThis.performance?.now?.()??0}:${Math.random()}:${Math.random()}`,n=la(s);for(let i=0;i<32;i++)a[i]=parseInt(n.slice(i*2,i*2+2),16)}let e="";for(let s=0;s<32;s++)e+=a[s].toString(16).padStart(2,"0");return e}const ri=["Amber","Cobalt","Dusty","Quiet","Distant","Salt","Paper","Copper","Slow","Wandering","Kite","Rain","Pale","Ember","Hollow","Lantern"],ci=["Fox","Heron","Kestrel","Pilot","Drifter","Sparrow","Comet","Wren","Otter","Moth","Rider","Finch","Marten","Hare","Swift","Crane"];function i0(a){const t=parseInt(a.slice(0,3),16)%ri.length,e=parseInt(a.slice(3,6),16)%ci.length,s=parseInt(a.slice(6,9),16)%100;return`${ri[t]} ${ci[e]} ${s}`}function a0(a){let t="";for(const e of String(a??"")){const s=e.codePointAt(0);s<32||s>=127&&s<=159||s>=8203&&s<=8207||s>=8232&&s<=8238||s>=8294&&s<=8297||(t+=e)}return t.replace(/\s+/g," ").trim().slice(0,18)||"Wanderer"}let bn=null,Ds=null;function Vn(){if(bn)return bn;let a=jn(ai);return(typeof a!="string"||!/^[0-9a-f]{64}$/.test(a))&&(a=o0(),n0(ai,a)),bn=a,a}function Zs(){return Ds||(Ds=la(Vn()).slice(0,12),Ds)}function ha(){const a=jn(e0);return a?a0(a):i0(Zs())}function r0(){const a=jn(s0);if(a)try{const t=JSON.parse(a);return{tier:t.tier|0,paint:t.paint|0}}catch{}return{tier:0,paint:parseInt(Zs().slice(9,12),16)%8}}function c0(){const a=r0();return{secret:Vn(),playerId:Zs(),name:ha(),tier:a.tier,paint:a.paint}}const li=8192,ua=6e3,l0=5;function h0({backend:a="auto",base44AppId:t=null,phpBase:e="./api/"}={}){const s=e.endsWith("/")?e:`${e}/`,n={base44:t?d0(t):null,php:u0(s),local:f0()},i=a==="auto"?["base44","php","local"].filter(p=>n[p]):[a,"local"].filter((p,m,v)=>n[p]&&v.indexOf(p)===m),o={pinned:null,fails:0,lastMs:0,sent:0,errors:0,lastError:null};let r=null;const c=new Promise(p=>{r=p});function l(p){o.pinned=p,o.fails=0,r(p)}function h(p){const m=JSON.stringify({v:1,secret:Vn(),name:ha(),t:Date.now(),...p});if(m.length>li)throw new Error(`[net] payload ${m.length} B exceeds the ${li} B cap`);return m}async function u(p,m){const v=Date.now(),g=await n[p].send(m);if(o.lastMs=Date.now()-v,!g||typeof g!="object")throw new Error(`[net] ${p} returned a non-object`);return g}async function d(p){const m=h(p);if(o.pinned)try{const g=await u(o.pinned,m);return o.fails=0,o.sent++,g}catch(g){if(o.fails++,o.errors++,o.lastError=String(g&&g.message?g.message:g),o.fails<l0)throw g;console.error(`[net] ${o.pinned} failed ${o.fails}x, re-probing`,o.lastError),o.pinned=null,o.fails=0}let v=null;for(const g of i)try{const w=await u(g,m);return l(g),o.sent++,w}catch(w){v=w,o.lastError=String(w&&w.message?w.message:w),g!=="local"&&console.info(`[net] ${g} not available here, trying the next backend`)}throw o.errors++,v??new Error("[net] no transport available")}function f(){return c}return{send:d,ready:f,get backend(){return o.pinned??(i[0]||"local")},info(){return{backend:o.pinned??"unresolved",chain:i.slice(),phpBase:s,appId:t,lastMs:o.lastMs,sent:o.sent,errors:o.errors,lastError:o.lastError}},close(){for(const p of Object.keys(n))n[p]?.close?.()}}}function u0(a){const t=`${a}drive.php`;return{async send(e){const s=new AbortController,n=setTimeout(()=>s.abort(),ua);try{const i=await fetch(t,{method:"POST",headers:{"Content-Type":"application/json"},body:e,signal:s.signal,credentials:"omit",cache:"no-store"});if(!i.ok){const o=new Error(`HTTP ${i.status}`);throw o.status=i.status,o}return await i.json()}finally{clearTimeout(n)}}}}function d0(a){let t=null;function e(){return t||(t=Jh(()=>import("./index-C5QPFtM6.js"),[],import.meta.url).then(s=>s.createClient({appId:a}))),t}return{async send(s){const n=await e(),i=new AbortController,o=setTimeout(()=>i.abort(),ua);try{const r=await n.functions.fetch("/drive",{method:"POST",headers:{"Content-Type":"application/json"},body:s,signal:i.signal});if(!r.ok){const c=new Error(`HTTP ${r.status}`);throw c.status=r.status,c}return await r.json()}finally{clearTimeout(o)}},close(){t?.then(s=>s.cleanup?.()).catch(()=>{}),t=null}}}function f0(){const a=new Map;return{async send(t){const e=JSON.parse(t),s=Date.now(),n=Zs(),i={now:s,you:{playerId:n},peers:[],rate:.25};if(e.op==="save"&&Array.isArray(e.ops)){const o=a.get(n)??{seed:null,visited:[],ops:[]};for(const r of e.ops)p0(o,r);a.set(n,o)}else e.op==="load"&&(i.save=a.get(n)??null);return i}}}function p0(a,t){if(!(!t||typeof t!="object"))if(t.k==="seed")a.seed=t.v|0;else if(t.k==="visited"){const e=a.visited.findIndex(s=>s.b===t.b);e<0?a.visited.push({b:t.b,d:t.d}):a.visited[e]={b:t.b,d:m0(a.visited[e].d,t.d)}}else a.ops.push(t),a.ops.length>4e3&&a.ops.splice(0,a.ops.length-4e3)}function m0(a,t){const e=atob(a),s=atob(t),n=Math.max(e.length,s.length);let i="";for(let o=0;o<n;o++)i+=String.fromCharCode((e.charCodeAt(o)||0)|(s.charCodeAt(o)||0));return btoa(i)}const hi=250,v0=1.2,g0=12,w0=11e3,x0=24;class b0{constructor({scene:t,buildGhostCar:e}){if(typeof e!="function")throw new Error("[remotes] buildGhostCar is required");this.scene=t,this.buildGhostCar=e,this.group=new ge,this.group.name="ghosts",this.group.frustumCulled=!1,t?.add(this.group),this.peers=new Map,this._offset=null}get count(){return this.peers.size}ingest(t,e){if(Number.isFinite(e)){const n=e-Date.now();this._offset===null||Math.abs(n-this._offset)>1500?this._offset=n:this._offset+=(n-this._offset)*.15}if(!Array.isArray(t))return;const s=Number.isFinite(e)?e:Date.now()+(this._offset??0);for(const n of t){if(!n||typeof n.id!="string")continue;let i=this.peers.get(n.id);if(!i&&(i=this._spawn(n),!i))continue;i.lastSeen=s,i.name=typeof n.name=="string"?n.name:i.name;const o=Number.isFinite(n.t)?n.t:s,r=i.buf;if(r.length&&o<=r[r.length-1].t)continue;i.placed&&(i.jumpT=Date.now()+(this._offset??0)-hi,i.preJump=yn(i.buf,i.jumpT));const c=r.length?r[r.length-1]:null,l=jt(n.yaw),h=c?c.yaw+Us(c.yaw,l):l,u=jt(n.y),d=c?K((u-c.y)/((o-c.t)/1e3),-12,12):0;r.push({t:o,x:jt(n.x),y:u,z:jt(n.z),yaw:h,vx:jt(n.vx),vy:d,vz:jt(n.vz),yawRate:jt(n.yawRate),steer:jt(n.steer),throttle:jt(n.throttle),brake:jt(n.brake),flags:n.flags|0}),r.length>x0&&r.shift(),i.corrected=!0,n.tier!==void 0&&(i.tier=n.tier|0),n.paint!==void 0&&(i.paint=n.paint|0)}}update(t,e=Date.now()){const s=e+(this._offset??0),n=s-hi;for(const[i,o]of this.peers){if(s-o.lastSeen>w0){this._despawn(i,o);continue}const r=yn(o.buf,n);if(!r)continue;const c=o.obj;if(!o.placed)o.placed=!0,c.visible=!0,o.ex=o.ey=o.ez=o.eyaw=0;else if(o.corrected&&o.preJump){const h=yn(o.buf,o.jumpT);h&&(o.ex=o.preJump.x+o.ex-h.x,o.ey=o.preJump.y+o.ey-h.y,o.ez=o.preJump.z+o.ez-h.z,o.eyaw=Us(h.yaw,o.preJump.yaw+o.eyaw)),Math.hypot(o.ex,o.ey,o.ez)>g0&&(o.ex=o.ey=o.ez=o.eyaw=0),o.preJump=null}o.corrected=!1;const l=Math.exp(-9*t);o.ex*=l,o.ey*=l,o.ez*=l,o.eyaw*=l,c.position.set(r.x+o.ex,r.y+o.ey,r.z+o.ez),c.rotation.y=r.yaw+o.eyaw,o.pose=r,o.api?.update?.(r,t)}}list(){const t=J.uCamPos.value,e=[];for(const[s,n]of this.peers){const i=n.pose,o=i?Math.hypot(i.x-t.x,i.y-t.y,i.z-t.z):1/0;e.push({id:s,name:n.name,dist:o})}return e.sort((s,n)=>s.dist-n.dist),e}nearestDistance(){const t=J.uCamPos.value;let e=1/0;for(const s of this.peers.values()){const n=s.pose;if(!n)continue;const i=Math.hypot(n.x-t.x,n.y-t.y,n.z-t.z);i<e&&(e=i)}return e}dispose(){for(const[t,e]of this.peers)this._despawn(t,e);this.peers.clear(),this.group.parent?.remove(this.group)}_spawn(t){let e;try{e=this.buildGhostCar({id:t.id,name:typeof t.name=="string"?t.name:"",tier:t.tier|0,paint:t.paint|0})}catch(i){return console.error("[remotes] buildGhostCar threw for",t.id,i),null}const s=e?.isObject3D?e:e?.root??e?.group??e?.object;if(!s?.isObject3D)return console.error("[remotes] buildGhostCar returned no Object3D for",t.id),null;s.visible=!1,s.matrixAutoUpdate=!0,this.group.add(s);const n={id:t.id,name:typeof t.name=="string"?t.name:"",tier:t.tier|0,paint:t.paint|0,obj:s,api:e?.isObject3D?null:e,buf:[],pose:null,placed:!1,corrected:!1,preJump:null,jumpT:0,ex:0,ey:0,ez:0,eyaw:0,lastSeen:0};return this.peers.set(t.id,n),n}_despawn(t,e){this.group.remove(e.obj),e.api?.dispose?e.api.dispose():y0(e.obj),this.peers.delete(t)}}function jt(a){return Number.isFinite(a)?a:0}function yn(a,t){const e=a.length;if(e===0)return null;if(e===1||t<=a[0].t)return ui(a[0],(t-a[0].t)/1e3);const s=a[e-1];if(t>=s.t)return ui(s,(t-s.t)/1e3);let n=e-2;for(;n>0&&a[n].t>t;)n--;const i=a[n],o=a[n+1],r=o.t-i.t,c=K((t-i.t)/r,0,1),l=r/1e3,h=n>0?a[n-1]:null,u=n+2<e?a[n+2]:null,d=o.y-i.y,f=h?.5*(o.y-h.y)*(r/(o.t-h.t)):d,p=u?.5*(u.y-i.y)*(r/(u.t-i.t)):d;return{x:Ms(i.x,i.vx*l,o.x,o.vx*l,c),y:Ms(i.y,f,o.y,p,c),z:Ms(i.z,i.vz*l,o.z,o.vz*l,c),yaw:Ms(i.yaw,i.yawRate*l,o.yaw,o.yawRate*l,c),steer:i.steer+(o.steer-i.steer)*c,throttle:i.throttle+(o.throttle-i.throttle)*c,brake:i.brake+(o.brake-i.brake)*c,vx:i.vx+(o.vx-i.vx)*c,vz:i.vz+(o.vz-i.vz)*c,flags:c<.5?i.flags:o.flags}}function ui(a,t){const e=K(t,0,v0);return{x:a.x+a.vx*e,y:a.y+a.vy*e,z:a.z+a.vz*e,yaw:a.yaw+a.yawRate*e,steer:a.steer,throttle:a.throttle,brake:a.brake,vx:a.vx,vz:a.vz,flags:a.flags}}function y0(a){a.traverse(t=>{t.geometry?.dispose?.();const e=t.material;Array.isArray(e)?e.forEach(s=>s.dispose?.()):e?.dispose?.()})}const Fs=4096,rt=16,di=rt*rt/8,_0=2e4,fi=5800,pi=4e3,M0="wanderoad",Le="save";class T0{constructor({seed:t,transport:e}){this.seed=t>>>0,this.transport=e,this.visited=new Map,this.dirtyBlocks=new Set,this.pending=[],this.ops=[],this._seq=0,this._timer=null,this._inflight=null,this._db=null,this._stats={uploads:0,uploadErrors:0,lastUpload:0,lastLocal:0},this.pending.push({k:"seed",v:this.seed})}markVisited(t,e){const s=Math.floor(t/Fs),n=Math.floor(e/Fs),i=Math.floor(s/rt),o=Math.floor(n/rt),r=`${i},${o}`;let c=this.visited.get(r);c||(c=new Uint8Array(di),this.visited.set(r,c));const l=(s%rt+rt)%rt,u=(n%rt+rt)%rt*rt+l,d=1<<(u&7),f=u>>3;return c[f]&d?!1:(c[f]|=d,this.dirtyBlocks.add(r),this._touch(),!0)}isVisited(t,e){const s=Math.floor(t/Fs),n=Math.floor(e/Fs),i=this.visited.get(`${Math.floor(s/rt)},${Math.floor(n/rt)}`);if(!i)return!1;const o=(s%rt+rt)%rt,c=(n%rt+rt)%rt*rt+o;return(i[c>>3]&1<<(c&7))!==0}note(t){if(!t||typeof t!="object")throw new Error("[save] note() needs an object");const e={...t,n:++this._seq,t:Date.now()};return this.ops.push(e),this.pending.push(e),this.ops.length>pi&&this.ops.splice(0,this.ops.length-pi),this._touch(),e}_touch(){this._writeLocal(),this._timer===null&&typeof setTimeout=="function"&&(this._timer=setTimeout(()=>{this._timer=null,this.flush().catch(()=>{})},_0))}flush(){return this._inflight?this._inflight:(this._inflight=this._flushOnce().finally(()=>{this._inflight=null}),this._inflight)}async _flushOnce(){if(!this.transport)return{sent:0,more:!1};let t=0;for(let e=0;e<6;e++){const s=this._takeBatch();if(s.ops.length===0)break;try{await this.transport.send({op:"save",seed:this.seed,ops:s.ops})}catch(n){throw this._stats.uploadErrors++,console.error("[save] upload failed, keeping the local copy",n?.message??n),n}this._stats.uploads++,this._stats.lastUpload=Date.now();for(const n of s.blocks)this.dirtyBlocks.delete(n);this.pending.splice(0,s.opCount),t+=s.ops.length}return{sent:t,more:this.pending.length+this.dirtyBlocks.size>0}}_takeBatch(){const t=[],e=[];let s=0;for(const i of this.dirtyBlocks){const o={k:"visited",b:i,d:mi(this.visited.get(i))},r=JSON.stringify(o).length+1;if(s+r>fi)break;t.push(o),e.push(i),s+=r}let n=0;for(const i of this.pending){const o=JSON.stringify(i).length+1;if(s+o>fi)break;t.push(i),s+=o,n++}return{ops:t,blocks:e,opCount:n}}async load(){const t=await this._readLocal();if(t&&this._absorb(t),this.transport)try{const e=await this.transport.send({op:"load",seed:this.seed});e?.save&&this._absorb(e.save)}catch(e){console.error("[save] remote load failed, using the local copy",e?.message??e)}return{seed:this.seed,visited:this.visited.size,ops:this.ops.length}}_absorb(t){if(!t||typeof t!="object")return;if(Number.isFinite(t.seed)&&t.seed>>>0!==this.seed){console.error(`[save] ignoring a save for seed ${t.seed>>>0}, this world is ${this.seed}`);return}for(const s of t.visited??[]){const n=A0(s.d);if(!n)continue;const i=this.visited.get(s.b);if(!i)this.visited.set(s.b,n);else for(let o=0;o<i.length&&o<n.length;o++)i[o]|=n[o]}const e=new Set(this.ops.map(s=>s.n));for(const s of t.ops??[])!s||e.has(s.n)||(this.ops.push(s),e.add(s.n),s.n>this._seq&&(this._seq=s.n));this.ops.sort((s,n)=>(s.n??0)-(n.n??0))}stats(){let t=0;for(const e of this.visited.values())for(let s=0;s<e.length;s++)t+=S0(e[s]);return{seed:this.seed,regions:t,blocks:this.visited.size,ops:this.ops.length,pending:this.pending.length+this.dirtyBlocks.size,bytes:this.visited.size*di+JSON.stringify(this.ops).length,uploads:this._stats.uploads,uploadErrors:this._stats.uploadErrors,lastUpload:this._stats.lastUpload,lastLocal:this._stats.lastLocal}}dispose(){this._timer!==null&&(clearTimeout(this._timer),this._timer=null)}_openDb(){if(this._db)return this._db;const t=globalThis.indexedDB;return t?(this._db=new Promise(e=>{let s;try{s=t.open(M0,1)}catch{e(null);return}s.onupgradeneeded=()=>{s.result.objectStoreNames.contains(Le)||s.result.createObjectStore(Le)},s.onsuccess=()=>e(s.result),s.onerror=()=>e(null),s.onblocked=()=>e(null)}),this._db):(this._db=Promise.resolve(null),this._db)}async _writeLocal(){const t=await this._openDb();if(!t)return;const e=this._serialise();try{const s=t.transaction(Le,"readwrite");s.objectStore(Le).put(e,`seed:${this.seed}`),s.oncomplete=()=>{this._stats.lastLocal=Date.now()},s.onerror=()=>console.error("[save] IndexedDB write failed")}catch(s){console.error("[save] IndexedDB transaction failed",s?.message??s)}}async _readLocal(){const t=await this._openDb();return t?new Promise(e=>{try{const n=t.transaction(Le,"readonly").objectStore(Le).get(`seed:${this.seed}`);n.onsuccess=()=>e(n.result??null),n.onerror=()=>e(null)}catch{e(null)}}):null}_serialise(){const t=[];for(const[e,s]of this.visited)t.push({b:e,d:mi(s)});return{seed:this.seed,visited:t,ops:this.ops}}}function S0(a){return a=a-(a>>1&85),a=(a&51)+(a>>2&51),a+(a>>4)&15}function mi(a){let t="";for(let e=0;e<a.length;e++)t+=String.fromCharCode(a[e]);return btoa(t)}function A0(a){if(typeof a!="string")return null;let t;try{t=atob(a)}catch{return null}const e=new Uint8Array(t.length);for(let s=0;s<t.length;s++)e[s]=t.charCodeAt(s);return e}const k0={open:[0,2,4,7,9],still:[0,3,5,7,10]},vi={open:[0,3,4,2],still:[0,4,2,3]},ns=[{id:"off",label:"Radio off",scale:null},{id:"valley",label:"Valley",scale:"open",root:55,chordSecs:22,bellRate:.16,drone:.5},{id:"longway",label:"The Long Way",scale:"still",root:51.9,chordSecs:26,bellRate:.1,drone:.7}],_n=(a,t)=>a*Math.pow(2,t/12);class R0{constructor(t,e,{volume:s=.5}={}){this.ctx=t,this.station=0,this._t=0,this._chordT=1e9,this._bellT=0,this._chord=0,this.out=t.createGain(),this.out.gain.value=0,this.tone=t.createBiquadFilter(),this.tone.type="lowpass",this.tone.frequency.value=1600,this.tone.Q.value=.4,this.out.connect(this.tone).connect(e);const n=Math.floor(t.sampleRate*2.6),i=t.createBuffer(2,n,t.sampleRate);for(let o=0;o<2;o++){const r=i.getChannelData(o);for(let c=0;c<n;c++)r[c]=(Math.random()*2-1)*Math.pow(1-c/n,3.2)}this.verb=t.createConvolver(),this.verb.buffer=i,this.verbGain=t.createGain(),this.verbGain.gain.value=.55,this.verb.connect(this.verbGain).connect(this.tone),this.volume=s}get label(){return ns[this.station].label}next(){this.station=(this.station+1)%ns.length;const t=ns[this.station].scale!==null;return this.out.gain.setTargetAtTime(t?this.volume*.16:0,this.ctx.currentTime,.5),this._chordT=1e9,this.label}setVolume(t){this.volume=D(t),ns[this.station].scale&&this.out.gain.setTargetAtTime(this.volume*.16,this.ctx.currentTime,.3)}_voice(t,e,s,n,i="triangle",o=0){const r=this.ctx,c=r.createOscillator();c.type=i,c.frequency.value=t,c.detune.value=o;const l=r.createGain();l.gain.setValueAtTime(0,e),l.gain.linearRampToValueAtTime(n,e+s*.34),l.gain.exponentialRampToValueAtTime(1e-4,e+s),c.connect(l),l.connect(this.out),l.connect(this.verb),c.start(e),c.stop(e+s+.05)}update(t,e=1){const s=ns[this.station];if(!s.scale)return;const n=this.ctx;if(!n||n.state!=="running")return;this._t+=t,this._chordT+=t,this._bellT+=t;const i=k0[s.scale],o=vi[s.scale];if(this._chordT>=s.chordSecs){this._chordT=0,this._chord=(this._chord+1)%o.length;const c=o[this._chord],l=n.currentTime+.05,h=s.chordSecs*1.25;for(const[u,d,f]of[[c,0,.16],[(c+2)%i.length,0,.11],[(c+4)%i.length,1,.08]]){const p=_n(s.root,i[u]+12*d);this._voice(p,l,h,f,"triangle",-5),this._voice(p,l,h,f*.8,"triangle",6)}this._voice(_n(s.root,i[c]-12),l,h,.09*s.drone,"sine")}const r=s.bellRate*I(.25,1,D(e));if(this._bellT>1/Math.max(r,.01)){this._bellT=0;const c=vi[s.scale][this._chord],l=i[(c+(Math.random()*i.length|0))%i.length],h=12*(1+(Math.random()*2|0));this._voice(_n(s.root,l+h),n.currentTime+.02,3.4,.055,"sine")}}}class E0{constructor({volume:t=.38}={}){this.ctx=null,this.volume=t,this.enabled=!0,this._started=!1,this._limitSmooth=0;const e=()=>this.start();for(const s of["pointerdown","keydown","touchstart"])addEventListener(s,e,{once:!0,passive:!0})}start(){if(this._started||!this.enabled)return;const t=window.AudioContext||window.webkitAudioContext;if(!t)return;this._started=!0;const e=this.ctx=new t,s=this.master=e.createGain();s.gain.value=this.volume,s.connect(e.destination),this.engGain=e.createGain(),this.engGain.gain.value=0;const n=e.createBiquadFilter();n.type="lowpass",n.frequency.value=420,n.Q.value=.8,this.engFilter=n,this.engGain.connect(n).connect(s),this.oscs=[];for(const[h,u,d]of[["sawtooth",.5,.5],["sawtooth",1,.34],["triangle",2,.06],["sine",.25,.42]]){const f=e.createOscillator();f.type=h;const p=e.createGain();p.gain.value=d,f.connect(p).connect(this.engGain),f.start(),this.oscs.push({o:f,mul:u})}const i=e.createBufferSource(),o=e.sampleRate*2,r=e.createBuffer(1,o,e.sampleRate),c=r.getChannelData(0);let l=0;for(let h=0;h<o;h++){const u=Math.random()*2-1;l=.99*l+.01*u,c[h]=l*3.5+u*.25}i.buffer=r,i.loop=!0,i.start(),this.noise=i,this.windFilter=e.createBiquadFilter(),this.windFilter.type="bandpass",this.windFilter.frequency.value=700,this.windFilter.Q.value=.5,this.windGain=e.createGain(),this.windGain.gain.value=0,i.connect(this.windFilter).connect(this.windGain).connect(s),this.roadFilter=e.createBiquadFilter(),this.roadFilter.type="bandpass",this.roadFilter.frequency.value=180,this.roadFilter.Q.value=1.6,this.roadGain=e.createGain(),this.roadGain.gain.value=0,i.connect(this.roadFilter).connect(this.roadGain).connect(s),this.scrubFilter=e.createBiquadFilter(),this.scrubFilter.type="bandpass",this.scrubFilter.frequency.value=1100,this.scrubFilter.Q.value=2.6,this.scrubGain=e.createGain(),this.scrubGain.gain.value=0,i.connect(this.scrubFilter).connect(this.scrubGain).connect(s),this.radio=new R0(e,s)}update(t,e){const s=this.ctx;if(!s||s.state==="suspended")return;const n=s.currentTime,i=.06,o=Math.abs(e.speed),r=D((e.rpm-900)/(e.spec.redline-900)),c=26+r*48;for(const{o:f,mul:p}of this.oscs)f.frequency.setTargetAtTime(c*p,n,i);const l=D(e.throttle*.85+r*.3);this.engGain.gain.setTargetAtTime(.032+l*.1,n,i),this.engFilter.frequency.setTargetAtTime(260+l*640+r*240,n,i);const h=Math.pow(D((o-15)/60),1.4);this.windGain.gain.setTargetAtTime(h*.085,n,i),this.windFilter.frequency.setTargetAtTime(330+o*4.5,n,i);const u=e.surfaceKind==="tarmac"?.35:1;this.roadGain.gain.setTargetAtTime(D(o/26)*.062*(.6+u),n,i),this.roadFilter.frequency.setTargetAtTime(78+o*3.2,n,i),this.roadFilter.Q.setTargetAtTime(I(2.4,.9,u),n,i),this._limitSmooth=I(this._limitSmooth,e.limit,Math.min(1,t*12));const d=D((this._limitSmooth-.72)/.28);if(this.scrubGain.gain.setTargetAtTime(d*d*.1*D(o/8),n,.03),this.scrubFilter.frequency.setTargetAtTime(900+d*620,n,i),this.radio){const f=D(1-Math.max(e.limit,Math.abs(e.slip)/.5)*1.2);this.radio.update(t,f)}}nextStation(){return this.start(),this.radio?this.radio.next():"no audio"}horn(){const t=this.ctx;if(!t)return;const e=t.currentTime;for(const[s,n]of[[392,0],[523.25,.11]]){const i=t.createOscillator();i.type="triangle",i.frequency.value=s;const o=t.createGain();o.gain.setValueAtTime(0,e+n),o.gain.linearRampToValueAtTime(.16,e+n+.02),o.gain.exponentialRampToValueAtTime(1e-4,e+n+.42),i.connect(o).connect(this.master),i.start(e+n),i.stop(e+n+.5)}}thump(t=.5){const e=this.ctx;if(!e)return;const s=e.currentTime,n=e.createOscillator();n.type="sine",n.frequency.setValueAtTime(140+90*t,s),n.frequency.exponentialRampToValueAtTime(48,s+.24);const i=e.createGain();i.gain.setValueAtTime(K(t,.05,1)*.4,s),i.gain.exponentialRampToValueAtTime(1e-4,s+.3),n.connect(i).connect(this.master),n.start(s),n.stop(s+.34)}chime(){const t=this.ctx;if(!t)return;const e=t.currentTime;[[659.25,0],[987.77,.14]].forEach(([s,n])=>{const i=t.createOscillator();i.type="sine",i.frequency.value=s;const o=t.createGain();o.gain.setValueAtTime(0,e+n),o.gain.linearRampToValueAtTime(.09,e+n+.03),o.gain.exponentialRampToValueAtTime(1e-4,e+n+.9),i.connect(o).connect(this.master),i.start(e+n),i.stop(e+n+1)})}setVolume(t){this.volume=D(t),this.master&&(this.master.gain.value=this.volume)}dispose(){this.ctx&&this.ctx.close().catch(()=>{}),this.ctx=null}}const Ne=a=>document.querySelector(a),ue=(a,t)=>{const e=Ne("#stat");e&&(e.textContent=a),t!==void 0&&Ne("#barIn")&&(Ne("#barIn").style.width=`${t*100|0}%`)},Js=new URLSearchParams(location.search),_t=(parseInt(Js.get("seed")??"",10)||20260726)>>>0,C0=Js.has("debug"),z0=Js.has("offline"),fe=Gh();fe.cheat&&aa(!0);const Ns=vh(),gi=ra(Ns),L0=Oh(fe.terrain);sc(Bh(fe.terrain));async function D0(){ue("warming the engine…",.04);const a=document.createElement("canvas");Ne("#app").appendChild(a);const t=Js.has("probe"),e=new Qa({canvas:a,antialias:!1,powerPreference:"high-performance",stencil:!1,preserveDrawingBuffer:t});if(!e.capabilities.isWebGL2){ue("this browser has no WebGL2 — try Chrome, Edge or Firefox");return}const s=Math.min(devicePixelRatio||1,1.75);e.setPixelRatio(s),e.setSize(innerWidth,innerHeight,!1),e.outputColorSpace=Be,e.toneMapping=0;const n=new Vs,i=new Ei(64,innerWidth/innerHeight,.28,16e3),o=new Er(e,{width:innerWidth,height:innerHeight,pixelRatio:s});n.add(hr()),ue("drawing the map…",.14);const r=pr(),c=new Ur({seed:_t,scene:n}),l=new Gc({seed:_t,scene:n}),h=new Kh,u=new Al({seed:_t,material:r,viewDistance:6800,terrain:fe.terrain,onChunk:F=>{if(F.water&&c.add(F),F.level<=gs){const B=Yi({cx:F.cx,cz:F.cz,level:F.level,seed:_t});l.add(F,B),F.level===0&&h.addChunk(`${F.cx},${F.cz}`,$h(B))}},onRelease:F=>{c.remove(F),l.remove(F),F.level===0&&h.removeChunk(`${F.cx},${F.cz}`)}});n.add(u.group);const d=new Jr({renderer:e,scene:n,seed:_t}),f=new tl({seed:_t,scene:n}),p=new il(e,{seed:_t}),m=new Ml({seed:_t,scene:n,wind:p});ue("finding a road…",.34);const v=Ro(_t);u.forceChunk(v.x,v.z);let g=new Ue(_t,v.x-420,v.z-420,v.x+420,v.z+420),w=v.x,x=v.z;const y=(F,B)=>((Math.abs(F-w)>240||Math.abs(B-x)>240)&&(g=new Ue(_t,F-420,B-420,F+420,B+420),w=F,x=B),g);ue("unloading the car…",.52);const T=c0(),b=new Th({tier:Ns.tier,terrain:g,preset:gi.assist});b.placeAt(v.x,v.z,v.heading);const M=Ns.id;let _;try{_=await ti({car:M,paint:T.look?.paint??0,base:new URL("./models/cars/",location.href).href})}catch(F){console.error("[car] model failed to load, using the built-in body",F?.message??F),_=El({tier:Ns.tier,paint:T.look?.paint??0})}n.add(_.group);const S=new Ah(i,{mode:"sport"}),A=new Sh(window);A.attachTouch(a);const L=new kh,E=new Ih;let k=null;const R=new qh;k=new zh({scene:n});const P=new E0;let W=M;async function U(F){if(!js[F]||F===W)return;const B=qs[F];if(B&&!ws(B,Math.max(Pe(),E.state.best))){R.say(`${B.label} unlocks at ${(B.unlockAt/1e3).toFixed(1)} km`,3);return}try{const ut=await ti({car:F,paint:T.look?.paint??0,base:new URL("./models/cars/",location.href).href});if(n.remove(_.group),_.dispose?.(),_=ut,n.add(_.group),W=F,window.WANDEROAD.model=_,B){const Ee=ra(B);b.setTier(B.tier),b.setPreset(Ee.assist)}k.reset(b),R.say(`${js[F].label} — ${B?B.blurb:""}`,3.2)}catch(ut){console.error("[car] swap failed",ut?.message??ut),R.say("that one would not load",2.5)}}const q=new Yh({onAuto:()=>L.toggle(b),isAuto:()=>L.on,onCar:U,bestStreak:()=>Math.max(Pe(),E.state.best),onCheat:F=>{aa(F),R.say(F?"every car unlocked":"unlocks restored",2.4)},onReset:()=>z(),camera:()=>S.mode,cycleCam:()=>S.cycle()});q.setCurrent({car:W,feel:fe.feel,terrain:fe.terrain});const st=document.createElement("div");st.id="openMenu",st.textContent="ESC — garage",R.root.appendChild(st);function z(){const B=(b.terrain||g).roads.query(b.x,b.z);if(isFinite(B.d))b.placeAt(B.qx,B.qz,Math.atan2(B.tx,B.tz));else{const ut=Ro(_t,b.x,b.z);b.placeAt(ut.x,ut.z,ut.heading)}S.reset(),k.reset(b),R.say("back on the road",2)}ue("looking for company…",.7);const O=h0({backend:z0?"none":"auto",phpBase:new URL("./api/",location.href).href}),j=new b0({scene:n,buildGhostCar:Cl}),it=new T0({seed:_t,transport:O});await it.load().catch(()=>{});const tt=()=>`c${Math.round(b.x/2048)}_${Math.round(b.z/2048)}`;addEventListener("resize",()=>{e.setSize(innerWidth,innerHeight,!1),o.setSize(innerWidth,innerHeight),i.aspect=innerWidth/innerHeight,i.updateProjectionMatrix()}),addEventListener("pagehide",()=>{E.flush(),it.flush(),O.send({op:"bye",cell:tt(),car:gt()}).catch(()=>{})}),document.addEventListener("visibilitychange",()=>{document.hidden&&(E.flush(),it.flush())});let nt=null;C0&&(nt=document.createElement("div"),nt.id="debug",document.body.appendChild(nt));const gt=()=>({x:b.x,y:b.y,z:b.z,yaw:b.yaw,vx:b.vx,vy:b.vy,vz:b.vz,yawRate:b.yawRate,steer:b.steer,throttle:b.throttle,brake:b.brake,gear:b.gear,tier:b.tier,paint:T.look?.paint??0,flags:(b.onGround?0:1)|(b.handbrake>.5?2:0)});let ht="offline",Pt=0;async function Q(F){if(!(F<Pt)){Pt=F+4e3;try{const B=await O.send({op:"tick",cell:tt(),car:gt()});if(!B){ht="offline";return}ht=O.backend==="local"?"solo":"online",B.peers&&j.ingest(B.peers,B.now),Pt=performance.now()+1e3/Math.max(.05,Math.min(B.rate||.25,10))}catch{ht="offline",Pt=performance.now()+8e3}}}let Nt=performance.now(),Ht=0,$e=Nt,qe=0,je=!1;const Ve=new Y;function Qs(F){requestAnimationFrame(Qs);const B=Math.min((F-Nt)/1e3,.1);Nt=F;const ut=A.poll();if(A.tapped("camera")&&R.say(`camera: ${S.cycle()}`,1.6),A.tapped("reverse")&&(b.reverse=!b.reverse),A.tapped("nextCar")){const zt=Math.max(Pe(),E.state.best),kt=ve.filter(ae=>ws(ae,zt)).map(ae=>ae.id);if(kt.length<2)R.say("one car so far — drive further to unlock more",2.6);else{const ae=kt.indexOf(W),re=kt[(ae+1)%kt.length];q.setCurrent({car:re}),U(re)}}A.tapped("horn")&&P.horn(),A.tapped("radio")&&R.say(P.nextStation(),2.4),A.tapped("autodrive")&&R.say(L.toggle(b)?"auto-drive on — sit back":"auto-drive off",2.4),A.tapped("reset")&&z();for(const[zt,kt]of[["Digit1","cruise"],["Digit2","sport"],["Digit3","off"],["Digit4","hardcore"]])A.pressed.has(zt)&&(b.setPreset(kt),R.say(`assists: ${kt}`,2));b.terrain=y(b.x,b.z);const Ee=L.on,bs=L.update(b,ut,B)||ut;Ee&&!L.on&&R.say(L.lastReason||"auto-drive off",2.2),q.open||b.update(B,bs);const we=h.resolve(b,1.05,B);we&&we.severity>.35&&we.speed>9&&(P.thump(Math.min(1,we.severity*we.speed/40)),E.update(2,b,{onRoad:0}),R.say("ouch",1.4));const Wt=b.terrain.surface(b.x,b.z);E.update(B,b,Wt),k.update(B,b,E.state);const Ye=b.groundTilt();_.group.position.set(b.x,b.y-.36,b.z),_.group.rotation.set(0,b.yaw,0),_.setBodyRoll(b.roll*1.3+Ye.roll*.6,b.pitch+Ye.pitch*.6),_.setSteer(b.steerAngle||0),_.setWheelSpin(b.wheelSpin),_.setBrakeGlow(b.brake);const tn=S.update(b,B,(zt,kt)=>b.terrain.height(zt,kt));if(J.uTime.value=F/1e3,J.uCamPos.value.copy(i.position),i.getWorldDirection(Ve),J.uCull.value.set(Ve.x,Ve.z,Math.cos(1.15),0),u.update(b.x,b.z),f.update(b.x,b.z),p.update(B,i.position),m.update(b.x,b.z,b.y,B),d.update(B,i.position),c.update(B,i.position),l.update(B,i.position),it.markVisited(b.x,b.z),j.update(B,F),Q(F),P.update(B,b),o.speed=tn,o.limit=b.limit,R.update(B,{car:b,streak:E,surface:Wt,remotes:j,netState:ht}),o.render(n,i),A.endFrame(),Ht++,F-$e>500&&(qe=Ht*1e3/(F-$e),Ht=0,$e=F,nt)){const zt=u.stats;nt.textContent=`fps ${qe.toFixed(0)}  live ${zt.live}  queue ${zt.queued}  built ${zt.built}  wk ${zt.workers}
pos ${b.x.toFixed(0)}, ${b.z.toFixed(0)}  ${b.kph.toFixed(0)} km/h  g${b.gear}  slip ${(b.slip*180/Math.PI).toFixed(0)}°  limit ${b.limit.toFixed(2)}
road ${Wt.onRoad.toFixed(2)}  grip ${Wt.grip.toFixed(2)}  ${Cn[Wt.dominant]}  solids ${h.count}
calls ${e.info.render.calls}  tris ${e.info.render.triangles/1e3|0}k  net ${ht}  peers ${j.count}`}!je&&u.stats.live>14&&(je=!0,ue("go anywhere.",1),setTimeout(()=>{Ne("#veil").classList.add("gone"),Ne("#hud").hidden=!1,(fe.feel!=="road"||fe.terrain!=="rolling")&&R.say(`${gi.label} · ${L0.label}`,4.5)},500))}requestAnimationFrame(Qs),window.THREE=tr,window.WANDEROAD={renderer:e,scene:n,camera:i,streamer:u,car:b,model:_,chase:S,streak:E,auto:L,trail:k,fleet:ve,solids:h,remotes:j,post:o,SEED:_t,stats:()=>u.stats,fps:()=>qe,drive:F=>Object.assign(window.WANDEROAD._auto||(window.WANDEROAD._auto={}),F)}}D0().catch(a=>{console.error(a),ue(`boot failed: ${a.message}`)});
